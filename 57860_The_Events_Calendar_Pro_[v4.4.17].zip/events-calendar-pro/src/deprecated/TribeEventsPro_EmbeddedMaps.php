<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Embedded_Maps' );


	class TribeEventsPro_EmbeddedMaps extends Tribe__Events__Pro__Embedded_Maps {

	}