<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Templates__Map' );


	class Tribe_Events_Pro_Map_Template extends Tribe__Events__Pro__Templates__Map {

	}