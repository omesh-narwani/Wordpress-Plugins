<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__APM_Filters__Organizer_Filter' );


	class Tribe_Organizer_Filter extends Tribe__Events__Pro__APM_Filters__Organizer_Filter {

	}