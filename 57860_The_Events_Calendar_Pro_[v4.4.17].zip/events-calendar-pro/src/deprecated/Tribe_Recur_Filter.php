<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__APM_Filters__Recur_Filter' );


	class Tribe_Recur_Filter extends Tribe__Events__Pro__APM_Filters__Recur_Filter {

	}