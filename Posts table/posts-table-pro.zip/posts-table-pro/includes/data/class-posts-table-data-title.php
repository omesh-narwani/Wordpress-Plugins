<?php
// Prevent direct file access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gets post data for the title column.
 *
 * @package   Posts_Table_Pro\Data
 * @author    Barn2 Media <info@barn2.co.uk>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Posts_Table_Data_Title extends Abstract_Posts_Table_Data {

	public function get_data() {
		//@todo - Don't link to post if it's not viewable on front-end
		if ( array_intersect( array( 'all', 'title' ), $this->links ) ) {
			$title = Posts_Table_Util::format_post_link( $this->post );
		} else {
			$title = "<span class='title'><h2>".get_the_title( $this->post )."</h2></span>";
			$title.= "<span class='RelDate'><b>Release Date: </b>".get_field('release_date',$this->post_ID)."</span>";
			$title.= "<span class='RunTime'><b>Runtime: </b>".get_field('runtime',$this->post_ID)."</span>";
		}

		return apply_filters( 'posts_table_data_title', $title, $this->post );
	}

}