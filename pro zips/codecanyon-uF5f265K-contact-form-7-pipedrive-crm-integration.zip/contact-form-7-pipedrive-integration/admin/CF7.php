<?php
namespace IwantToBelive\Cf7\Pipedrive\Integration\Admin;

use IwantToBelive\Cf7\Pipedrive\Integration\Includes\Crm;
use IwantToBelive\Cf7\Pipedrive\Integration\Includes\Bootstrap;

class CF7 extends \WPCF7_Service
{
    private static $instance = false;

    public static function getInstance()
    {
        if (!self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    protected function __construct()
    {
        add_action('wpcf7_init', [$this, 'registerService']);

        if ($this->is_active()) {
            add_filter('wpcf7_editor_panels', [$this, 'settingsPanels']);
            add_action('save_post_' . \WPCF7_ContactForm::post_type, [$this, 'saveSettings']);

            if (isset($_GET['page']) && $_GET['page'] === 'wpcf7' && !empty($_GET['post'])) {
                add_action('admin_enqueue_scripts', function () {
                    wp_enqueue_script('jquery-ui-tabs');
                    wp_enqueue_style('jquery-ui-tabs', '//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css', false, '1.8.8');
                });

                add_action('admin_footer', function () {
                    ?>
                    <script>
                        jQuery(document).on("ready", function () {
                            jQuery("#cf-pipedrive-tabs").tabs();
                        });
                    </script>
                    <?php
                }, PHP_INT_MAX);
            }
        }
    }

    public function registerService()
    {
        $integration = \WPCF7_Integration::get_instance();
        $categories = ['crm' => $this->get_title()];

        foreach ($categories as $name => $category) {
            $integration->add_category($name, $category);
        }

        $services = ['cf7-pipedrive-integration' => self::getInstance()];

        foreach ($services as $name => $service) {
            $integration->add_service($name, $service);
        }
    }

    // @codingStandardsIgnoreStart
    public function is_active()
    {
        // @codingStandardsIgnoreEnd
        $settings = get_option(Bootstrap::OPTIONS_KEY);

        return !empty($settings['token']);
    }

    // @codingStandardsIgnoreStart
    public function get_title()
    {
        // @codingStandardsIgnoreEnd
        return esc_html__('Integration with Pipedrive CRM', 'cf7-pipedrive-integration');
    }

    // @codingStandardsIgnoreStart
    public function get_categories()
    {
        // @codingStandardsIgnoreEnd
        return ['crm'];
    }

    public function icon()
    {
    }

    public function link()
    {
        echo '<a href="https://codecanyon.net/user/itgalaxycompany">itgalaxycompany</a>';
    }

    public function load($action = '')
    {
        if ('setup' == $action) {
            if (isset($_SERVER['REQUEST_METHOD']) && 'POST' == $_SERVER['REQUEST_METHOD']) {
                if (isset($_POST['purchase-code'])) {
                    check_admin_referer('wpcf7-pipedrive-integration-setup-license');
                    $code = trim(wp_unslash($_POST['purchase-code']));

                    $response = \wp_remote_post(
                        'https://wordpress-plugins.xyz/envato/license.php',
                        [
                            'body' => [
                                'purchaseCode' => $code,
                                'itemID' => '21052205',
                                'action' => isset($_POST['verify']) ? 'activate' : 'deactivate',
                                'domain' => site_url()
                            ],
                            'timeout' => 20
                        ]
                    );

                    if (is_wp_error($response)) {
                        // fix network connection problems
                        if ($response->get_error_code() === 'http_request_failed') {
                            if (isset($_POST['verify'])) {
                                $messageContent = 'Success verify.';
                                update_site_option(Bootstrap::PURCHASE_CODE_OPTIONS_KEY, $code);
                            } else {
                                $messageContent = 'Success unverify.';
                                update_site_option(Bootstrap::PURCHASE_CODE_OPTIONS_KEY, '');
                            }

                            $message = 'successCheck';
                        } else {
                            $messageContent = '(Code - '
                                . $response->get_error_code()
                                . ') '
                                . $response->get_error_message();

                            $message = 'failedCheck';
                        }
                    } else {
                        $response = json_decode(wp_remote_retrieve_body($response));

                        if ($response->status == 'successCheck') {
                            if (isset($_POST['verify'])) {
                                update_site_option(Bootstrap::PURCHASE_CODE_OPTIONS_KEY, $code);
                            } else {
                                update_site_option(Bootstrap::PURCHASE_CODE_OPTIONS_KEY, '');
                            }
                        } elseif (!isset($_POST['verify']) && $response->status == 'alreadyInactive') {
                            update_site_option(Bootstrap::PURCHASE_CODE_OPTIONS_KEY, '');
                        }

                        $messageContent = $response->message;
                        $message = $response->status;
                    }

                    wp_safe_redirect(
                        $this->menuPageUrl(
                            [
                                'action' => 'setup',
                                'message' => $message,
                                'messageContent' => rawurlencode($messageContent)
                            ]
                        )
                    );
                    exit();
                } else {
                    check_admin_referer('wpcf7-pipedrive-integration-setup');
                    $token = isset($_POST['token']) ? trim(wp_unslash($_POST['token'])) : '';
                    $enabledLogging =
                        isset($_POST['enabled_logging']) ? trim(wp_unslash($_POST['enabled_logging'])) : '';
                    $sendType = isset($_POST['send_type']) ? trim(wp_unslash($_POST['send_type'])) : '';

                    if (empty($token)) {
                        wp_safe_redirect($this->menuPageUrl(['message' => 'invalid', 'action' => 'setup']));
                        exit();
                    }

                    update_option(
                        Bootstrap::OPTIONS_KEY,
                        [
                            'token' => $token,
                            'enabled_logging' => $enabledLogging,
                            'send_type' => $sendType,
                        ]
                    );

                    Crm::checkConnection();
                    Crm::updateInformation();

                    wp_safe_redirect($this->menuPageUrl(['action' => 'setup', 'message' => 'success']));
                    exit();
                }
            }
        }
    }

    // @codingStandardsIgnoreStart
    public function admin_notice($message = '')
    {
        // @codingStandardsIgnoreEnd
        if ($message) {
            if ('invalid' === $message) {
                echo sprintf(
                    '<div class="error notice notice-error is-dismissible"><p><strong>%1$s</strong>: %2$s</p></div>',
                    esc_html__('ERROR', 'cf7-pipedrive-integration'),
                    esc_html__('API token is required field.', 'cf7-pipedrive-integration')
                );
            } elseif ('success' === $message) {
                echo sprintf(
                    '<div class="updated notice notice-success is-dismissible"><p>%s</p></div>',
                    esc_html__('Settings successfully updated.', 'cf7-pipedrive-integration')
                );
            } elseif ($message == 'successCheck') {
                echo sprintf(
                    '<div class="updated notice notice-success is-dismissible"><p>%s</p></div>',
                    esc_html(isset($_GET['messageContent']) ? $_GET['messageContent'] : '')
                );
            } elseif (isset($_GET['messageContent'])) {
                echo sprintf(
                    '<div class="error notice notice-error is-dismissible"><p>%s</p></div>',
                    esc_html(isset($_GET['messageContent']) ? $_GET['messageContent'] : '')
                );
            }
        }
    }

    public function display($action = '')
    {
        $settings = get_option(Bootstrap::OPTIONS_KEY);
        ?>
        <p>
            Formation of deals, persons or organizations in Pipedrive CRM from the hits that users send on your site,
            using the Contact Form 7 plugin.
        </p>
        <?php
        if ('setup' == $action) {
            ?>
            <form method="post" action="<?php echo esc_url($this->menuPageUrl('action=setup')); ?>">
                <?php wp_nonce_field('wpcf7-pipedrive-integration-setup'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="token">
                                <?php esc_html_e('API token', 'cf7-pipedrive-integration'); ?>
                            </label>
                        </th>
                        <td>
                            <input type="text"
                                aria-required="true"
                                value="<?php
                                echo isset($settings['token'])
                                    ? esc_attr($settings['token'])
                                    : '';
                                ?>"
                                id="token"
                                placeholder="Your personal API token"
                                name="token"
                                class="large-text">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="enabled_logging">
                                <?php esc_html_e('Enable logging', 'cf7-pipedrive-integration'); ?>
                            </label>
                        </th>
                        <td>
                            <input type="hidden" value="0" name="enabled_logging">
                            <input type="checkbox"
                                value="1"
                                <?php echo isset($settings['enabled_logging']) && $settings['enabled_logging'] == '1' ? 'checked' : ''; ?>
                                id="enabled_logging"
                                name="enabled_logging">
                            <br>
                            <small><?php echo esc_html(CF7_PIPEDRIVE_INTEGRATION_PLUGIN_DIR); ?>/logs/.cf7pd.log</small>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="send_type">
                                <?php esc_html_e('Send type', 'cf7-pipedrive-integration'); ?>
                            </label>
                        </th>
                        <td>
                            <select name="send_type" id="send_type">
                                <option value="wp_cron" <?php
                                echo empty($settings['send_type']) || $settings['send_type'] == 'wp_cron' ? 'selected' : '';
                                ?>>
                                    <?php esc_html_e('WP Cron', 'cf7-pipedrive-integration'); ?>
                                </option>
                                <option value="immediately" <?php
                                echo isset($settings['send_type']) && $settings['send_type'] == 'immediately' ? 'selected' : '';
                                ?>>
                                    <?php esc_html_e('Immediately upon submitting the form', 'cf7-pipedrive-integration'); ?>
                                </option>
                            </select>
                        </td>
                    </tr>
                </table>
                <?php
                echo sprintf(
                    '%1$s <a href="%2$s" target="_blank">%3$s</a>. %4$s.',
                    esc_html__('Plugin documentation: ', 'cf7-pipedrive-integration'),
                    esc_url(CF7_PIPEDRIVE_INTEGRATION_PLUGIN_URL . 'documentation/index.html#step-1'),
                    esc_html__('open', 'cf7-pipedrive-integration'),
                    esc_html__('Or open the folder `documentation` in the plugin and open index.html', 'cf7-pipedrive-integration')
                );
                ?>
                <p class="submit">
                    <input type="submit"
                        class="button button-primary"
                        value="<?php esc_attr_e('Save settings', 'cf7-pipedrive-integration'); ?>"
                        name="submit">
                </p>
            </form>
            <hr>
            <?php $code = get_site_option(Bootstrap::PURCHASE_CODE_OPTIONS_KEY); ?>
            <h1>
                <?php esc_html_e('License verification', 'cf7-pipedrive-integration'); ?>
                <?php if ($code) { ?>
                    - <small style="color: green;">verified</small>
                <?php } else { ?>
                    - <small style="color: red;">please verify your purchase code</small>
                <?php } ?>
            </h1>
            <form method="post" action="<?php echo esc_url($this->menuPageUrl('action=setup')); ?>">
                <?php wp_nonce_field('wpcf7-pipedrive-integration-setup-license'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="purchase-code">
                                <?php esc_html_e('Purchase code', 'cf7-pipedrive-integration'); ?>
                            </label>
                        </th>
                        <td>
                            <input type="text"
                                aria-required="true"
                                required
                                value="<?php
                                echo !empty($code)
                                    ? esc_attr($code)
                                    : '';
                                ?>"
                                id="purchase-code"
                                name="purchase-code"
                                class="large-text">
                            <small>
                                <a href="https://help.market.envato.com/hc/en-us/articles/202822600-Where-Is-My-Purchase-Code-"
                                    target="_blank">
                                    Where Is My Purchase Code?
                                </a>
                            </small>
                        </td>
                    </tr>
                </table>
                <p>
                    <input type="submit"
                        class="button button-primary"
                        value="<?php esc_attr_e('Verify', 'cf7-pipedrive-integration'); ?>"
                        name="verify">
                    <?php if ($code) { ?>
                        <input type="submit"
                            class="button button-primary"
                            value="<?php esc_attr_e('Unverify', 'cf7-pipedrive-integration'); ?>"
                            name="unverify">
                    <?php } ?>
                </p>
            </form>
            <?php
        } else {
            if ($this->is_active()) {
                ?>
                <table class="form-table">
                    <tbody>
                        <tr>
                            <th scope="row"><?php esc_html_e('API token', 'cf7-pipedrive-integration'); ?></th>
                            <td class="code"><?php echo esc_html($settings['token']); ?></td>
                        </tr>
                    </tbody>
                </table>
                <p>
                    <a href="<?php echo esc_url($this->menuPageUrl('action=setup')); ?>"
                        class="button">
                        <?php esc_html_e('Change settings', 'cf7-pipedrive-integration'); ?>
                    </a>
                </p>
                <?php
            } else {
                ?>
                <p>
                    <?php
                    esc_html_e(
                        'To work with the plugin, you must configure integration with Pipedrive CRM.',
                        'cf7-pipedrive-integration'
                    );
                    ?>
                </p>
                <p>
                    <a href="<?php echo esc_url($this->menuPageUrl('action=setup')); ?>"
                        class="button">
                        <?php esc_html_e('Go to setup', 'cf7-pipedrive-integration'); ?>
                    </a>
                </p>
                <p class="description">
                    <?php
                    esc_html_e(
                        'The fields sent to the CRM are configured on the form editing page, on the "Pipedrive CRM" tab.',
                        'cf7-pipedrive-integration'
                    );
                    ?>
                </p>
                <?php
            }
        }
    }

    public function settingsPanels($panels)
    {
        $panels['pipedrive-panel'] = [
            'title' => esc_html__('Pipedrive CRM', 'cf7-pipedrive-integration'),
            'callback' => [$this, 'panel']
        ];

        return $panels;
    }

    public function panel(\WPCF7_ContactForm $post)
    {
        $meta = get_post_meta($post->id(), Bootstrap::META_KEY, true);

        $enabled = isset($meta['ENABLED']) ? $meta['ENABLED'] : false;
        $enabledSendFiles = isset($meta['enable_send_files']) ? $meta['enable_send_files'] : false;
        ?>
        <input type="hidden" name="cf7Pipedrive[ENABLED]" value="0">
        <input
            type="checkbox"
            name="cf7Pipedrive[ENABLED]" value="1"
            <?php checked($enabled, true); ?>
            title="<?php
            esc_attr_e('Enable send', 'cf7-pipedrive-integration');
            ?>">
        <strong>
            <?php
            esc_html_e(
                'Enable send',
                'cf7-pipedrive-integration'
            );
            ?>
        </strong>
        <br><br>
        <input type="hidden" name="cf7Pipedrive[enable_send_files]" value="0">
        <input
            type="checkbox"
            name="cf7Pipedrive[enable_send_files]" value="1"
            <?php checked($enabledSendFiles, true); ?>
            title="<?php
            esc_attr_e('Enable auto send uploaded files in CRM', 'cf7-pipedrive-integration');
            ?>">
        <strong>
            <?php
            esc_html_e(
                'Enable auto send uploaded files in CRM',
                'cf7-pipedrive-integration'
            );
            ?>
        </strong>
        <br><br>
        <?php
        echo esc_html(__(
            'In the following fields, you can use these mail-tags:',
            'contact-form-7'
        ));
        ?>
        <br>
        <?php
        $post->suggest_mail_tags();
        ?>
        <br><br>
        Utm-fields:<br>
        <span class="mailtag code">[utm_source]</span>
        <span class="mailtag code">[utm_medium]</span>
        <span class="mailtag code">[utm_campaign]</span>
        <span class="mailtag code">[utm_term]</span>
        <span class="mailtag code">[utm_content]</span>
        <span class="mailtag code">and etc.</span>
        <br><br>
        Roistat-fields:<br>
        <span class="mailtag code">[roistat_visit]</span>
        <br><br>
        GA fields:<br>
        <span class="mailtag code">[gaClientID]</span>
        <hr>
        <p>
            <?php $currentType = isset($meta['TYPE']) ? $meta['TYPE'] : 'deal'; ?>
            <strong>
                <?php
                esc_html_e(
                    'Choose the type of lead that will be generated in CRM:',
                    'cf7-pipedrive-integration'
                );
                ?>
            </strong>
            <br>
            <label>
                <input type="radio"
                    value="deal"
                    name="cf7Pipedrive[TYPE]"
                    title="<?php esc_html_e('Deal', 'cf7-pipedrive-integration'); ?>"
                    <?php checked($currentType, 'deal'); ?>>
                    <?php
                    esc_html_e(
                        'Deal (Auto create/connect existing person and organization. '
                        . 'Search person by name and email, organization by name.)',
                        'cf7-pipedrive-integration'
                    );
                    ?>
                <br><small>Used tabs: Deal fields - main, Person fields, Organization fields, Note fields - additional.</small>
            </label>
            <br>
            <label>
                <input type="radio"
                    value="activity"
                    name="cf7Pipedrive[TYPE]"
                    title="<?php esc_html_e('Activity', 'cf7-pipedrive-integration'); ?>"
                    <?php checked($currentType, 'activity'); ?>>
                    <?php
                    esc_html_e(
                        'Activity (Auto create/connect existing person and organization. '
                        . 'Search person by name and email, organization by name.)',
                        'cf7-pipedrive-integration'
                    );
                    ?>
                <br><small>Used tabs: Activity fields - main, Person fields, Organization fields - additional.</small>
            </label>
            <br>
            <label>
                <input type="radio"
                    value="dealandactivity"
                    name="cf7Pipedrive[TYPE]"
                    title="<?php esc_html_e('Deal & Activity', 'cf7-pipedrive-integration'); ?>"
                    <?php checked($currentType, 'dealandactivity'); ?>>
                    <?php
                    esc_html_e(
                        'Deal & Activity (Auto create/connect existing person and organization. '
                        . 'Search person by name and email, organization by name.)',
                        'cf7-pipedrive-integration'
                    );
                    ?>
                <br><small>Used tabs: Deal fields - main, Activity fields, Person fields, Organization fields, Note fields - additional.</small>
            </label>
            <br>
            <label>
                <input type="radio"
                    value="personandorganization"
                    name="cf7Pipedrive[TYPE]"
                    title="<?php esc_html_e('Person & Organization', 'cf7-pipedrive-integration'); ?>"
                    <?php checked($currentType, 'personandorganization'); ?>>
                <?php esc_html_e('Person & Organization', 'cf7-pipedrive-integration'); ?>
                <br><small>Used tabs: Person fields and/or Organization fields - main, Note fields - additional.</small>
            </label>
        </p>
        <hr>
        <div id="cf-pipedrive-tabs">
            <ul>
                <li>
                    <a href="#deal-fields">
                        <?php esc_html_e('Deal fields', 'cf7-pipedrive-integration'); ?>
                    </a>
                </li>
                <li>
                    <a href="#person-fields">
                        <?php esc_html_e('Person fields', 'cf7-pipedrive-integration'); ?>
                    </a>
                </li>
                <li>
                    <a href="#organization-fields">
                        <?php esc_html_e('Organization fields', 'cf7-pipedrive-integration'); ?>
                    </a>
                </li>
                <li>
                    <a href="#note-fields">
                        <?php esc_html_e('Note fields', 'cf7-pipedrive-integration'); ?>
                    </a>
                </li>
                <li>
                    <a href="#activity-fields">
                        <?php esc_html_e('Activity fields', 'cf7-pipedrive-integration'); ?>
                    </a>
                </li>
            </ul>
            <div id="deal-fields">
                <?php DealSettings::getInstance()->render($meta); ?>
            </div>
            <div id="person-fields">
                <input type="hidden" name="cf7Pipedrive[update_exists_person]" value="0">
                <label>
                    <input type="checkbox"
                        name="cf7Pipedrive[update_exists_person]" value="1"
                        <?php checked(isset($meta['update_exists_person']) ? $meta['update_exists_person'] : '', true); ?>
                        title="<?php esc_attr_e('Update an existing person (search by name and email)', 'cf7-pipedrive-integration'); ?>">
                    <strong><?php esc_html_e('Update an existing person (search by name and email)', 'cf7-pipedrive-integration'); ?></strong>
                </label>
                <?php PersonSettings::getInstance()->render($meta); ?>
            </div>
            <div id="organization-fields">
                <input type="hidden" name="cf7Pipedrive[update_exists_organization]" value="0">
                <label>
                    <input type="checkbox"
                        name="cf7Pipedrive[update_exists_organization]" value="1"
                        <?php checked(isset($meta['update_exists_organization']) ? $meta['update_exists_organization'] : '', true); ?>
                        title="<?php esc_attr_e('Update an existing organization (search by name)', 'cf7-pipedrive-integration'); ?>">
                    <strong><?php esc_html_e('Update an existing organization (search by name)', 'cf7-pipedrive-integration'); ?></strong>
                </label>
                <?php OrganizationSettings::getInstance()->render($meta); ?>
            </div>
            <div id="note-fields">
                <?php NoteSettings::getInstance()->render($meta); ?>
            </div>
            <div id="activity-fields">
                <?php ActivitySettings::getInstance()->render($meta); ?>
            </div>
        </div>
        <?php
    }

    public function saveSettings($postID)
    {
        if (isset($_POST['cf7Pipedrive'])) {
            update_post_meta($postID, Bootstrap::META_KEY, wp_unslash($_POST['cf7Pipedrive']));
        }
    }

    protected function __clone()
    {
    }

    private function menuPageUrl($args = '')
    {
        $args = wp_parse_args($args, []);
        $url = menu_page_url('wpcf7-integration', false);
        $url = add_query_arg(['service' => 'cf7-pipedrive-integration'], $url);

        if (!empty($args)) {
            $url = add_query_arg($args, $url);
        }

        return $url;
    }
}
