<?php
namespace IwantToBelive\Cf7\Pipedrive\Integration\Admin;

use IwantToBelive\Cf7\Pipedrive\Integration\Includes\Bootstrap;
use IwantToBelive\Cf7\Pipedrive\Integration\Includes\CrmFields;

class PersonSettings
{
    private static $instance = false;

    public static function getInstance()
    {
        if (!self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    protected function __construct()
    {

    }

    public function render($meta)
    {
        $renderFields = new RenderFields('person');
        $currentValues = isset($meta['person']) ? $meta['person'] : [];
        ?>
        <table class="form-table">
            <?php
            $contactFields = (array) get_option(Bootstrap::PERSON_FIELDS_KEY);

            foreach ($contactFields as $field) {
                // Not show fields
                if (in_array($field['key'], CrmFields::$breakFields['person'])) {
                    continue;
                }

                // Skip not active
                if (!$field['active_flag']) {
                    continue;
                }
                ?>
                <tr>
                    <th>
                        <?php echo esc_html($field['name'] . ' (' . $field['key'] . ')'); ?>
                        <?php
                        echo in_array($field['key'], CrmFields::$requiredFields['person'])
                            ? '<span style="color:red;"> * </span>'
                            : '';
                        ?>
                    </th>
                    <td>
                        <?php
                        $currentValue = isset($currentValues[$field['key']]) ? $currentValues[$field['key']] : '';
                        $currentValuePopulate = isset($currentValues[$field['key']. '-populate'])
                            ? $currentValues[$field['key']. '-populate']
                            : '';

                        if (!empty($field['options'])) {
                            $selectItems = [];

                            foreach ($field['options'] as $item) {
                                $selectItems[$item['id']] = $item['label'];
                            }

                            $renderFields->selectFieldWithPopulate(
                                $selectItems,
                                $field['key'],
                                $field['name'],
                                $currentValue,
                                $currentValuePopulate
                            );
                        } elseif (in_array($field['field_type'], ['text'])) {
                            $renderFields->textareaField(
                                $field['key'],
                                $field['name'],
                                $currentValue
                            );
                        } else {
                            $renderFields->inputTextField(
                                $field['key'],
                                $field['name'],
                                $currentValue
                            );

                            if ($field['field_type'] === 'user') {
                                $renderFields->userList();
                            }
                        }
                        ?>
                    </td>
                </tr>
                <?php
            }
            ?>
        </table>
        <?php
    }
}
