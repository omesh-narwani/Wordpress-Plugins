<?php
/**
 * Plugin Name: Contact Form 7 - Pipedrive CRM - Integration
 * Description: Allows you to integrate your forms and Pipedrive CRM
 * Version: 1.13.1
 * Author: itgalaxycompany
 * Author URI: https://codecanyon.net/user/itgalaxycompany
 * Network: true
 * License: GPLv3
 * Text Domain: cf7-pipedrive-integration
 * Domain Path: /languages/
 */

use IwantToBelive\Cf7\Pipedrive\Integration\Admin\CF7 as Cf7Admin;
use IwantToBelive\Cf7\Pipedrive\Integration\Includes\Bootstrap;
use IwantToBelive\Cf7\Pipedrive\Integration\Includes\CF7 as Cf7Includes;
use IwantToBelive\Cf7\Pipedrive\Integration\Includes\Cron;

if (!defined('ABSPATH')) {
    exit();
}

/*
 * Require for `is_plugin_active` function.
 */
require_once ABSPATH . 'wp-admin/includes/plugin.php';

load_theme_textdomain('cf7-pipedrive-integration', __DIR__ . '/languages');

define('CF7_PIPEDRIVE_INTEGRATION_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CF7_PIPEDRIVE_INTEGRATION_PLUGIN_DIR', __DIR__);

require __DIR__ . '/vendor/autoload.php';

require __DIR__ . '/includes/Helper.php';
require __DIR__ . '/includes/CrmFields.php';
require __DIR__ . '/includes/Bootstrap.php';
require __DIR__ . '/includes/Crm.php';
require __DIR__ . '/includes/CF7.php';

Bootstrap::getInstance(__FILE__);
Cf7Includes::getInstance();

if (defined('DOING_CRON') && DOING_CRON) {
    include __DIR__ . '/includes/Cron.php';

    Cron::getInstance();
}

if (is_admin()
    && is_plugin_active('contact-form-7/wp-contact-form-7.php')
) {
    add_action('plugins_loaded', function () {
        include __DIR__ . '/admin/RenderFields.php';
        include __DIR__ . '/admin/DealSettings.php';
        include __DIR__ . '/admin/PersonSettings.php';
        include __DIR__ . '/admin/OrganizationSettings.php';
        include __DIR__ . '/admin/NoteSettings.php';
        include __DIR__ . '/admin/ActivitySettings.php';
        include __DIR__ . '/admin/CF7.php';

        Cf7Admin::getInstance();
    });
}
