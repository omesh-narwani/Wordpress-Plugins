<?php
namespace IwantToBelive\Cf7\Pipedrive\Integration\Includes;

class Bootstrap
{
    const OPTIONS_KEY = 'contactform7-pipedrive-integration-settings';
    const PURCHASE_CODE_OPTIONS_KEY = 'cf7_pd_purchase_code';
    const META_KEY = '_cf7-pipedrive-integration';
    const DEAL_FIELDS_KEY = '_cf7-pipedrive-deal-fields';
    const PERSON_FIELDS_KEY = '_cf7-pipedrive-person-fields';
    const ORGANIZATION_FIELDS_KEY = '_cf7-pipedrive-organzation-fields';
    const ACTIVITY_FIELDS_KEY = '_cf7-pipedrive-activity-fields';
    const NOTE_FIELDS_KEY = '_cf7-pipedrive-note-fields';
    const USERS_LIST_KEY = '_cf7-pipedrive-users';

    const UTM_COOKIES = 'cf7-pipedrive-utm-cookie';

    const CURRENCY_KEY = '_cf7-pipedrive-currency';
    const DEAL_STAGE_KEY = '_cf7-pipedrive-deal-stage';

    const SEND_CRON_TASK = 'cf7-pipedrive-send-cron-task';
    const CRON_TASK = 'cf7-pipedrive-cron-task';

    public static $plugin = '';
    private static $instance = false;

    protected function __construct($file)
    {
        self::$plugin = $file;

        register_activation_hook(
            self::$plugin,
            ['IwantToBelive\Cf7\Pipedrive\Integration\Includes\Bootstrap', 'pluginActivation']
        );

        register_deactivation_hook(
            self::$plugin,
            ['IwantToBelive\Cf7\Pipedrive\Integration\Includes\Bootstrap', 'pluginDeactivation']
        );

        register_uninstall_hook(
            self::$plugin,
            ['IwantToBelive\Cf7\Pipedrive\Integration\Includes\Bootstrap', 'pluginUninstall']
        );

        add_action('init', [$this, 'utmCookies']);
    }

    public static function getInstance($file)
    {
        if (!self::$instance) {
            self::$instance = new self($file);
        }

        return self::$instance;
    }

    public function utmCookies()
    {
        $strposFunction = 'mb_strpos';

        if (!function_exists('mb_strpos')) {
            $strposFunction = 'strpos';
        }

        if (!empty($_GET) && is_array($_GET)) {
            $utmParams = [];

            foreach ($_GET as $key => $value) {
                if ($strposFunction($key, 'utm_') === 0) {
                    $utmParams[$key] = wp_unslash($value);
                }
            }

            if (!empty($utmParams)) {
                setcookie(
                    self::UTM_COOKIES,
                    wp_json_encode($utmParams),
                    time() + 86400,
                    '/'
                );
            }
        }
    }

    public static function pluginActivation()
    {
        if (!is_plugin_active('contact-form-7/wp-contact-form-7.php')) {
            wp_die(
                esc_html__(
                    'To run the plug-in, you must first install and activate the Contact Form 7 plugin.',
                    'cf7-pipedrive-integration'
                ),
                esc_html__(
                    'Error while activating the Contact Form 7 - Pipedrive CRM - Integration',
                    'cf7-pipedrive-integration'
                ),
                [
                    'back_link' => true
                ]
            );
            // Escape ok
        }

        $roles = new \WP_Roles();

        foreach (self::capabilities() as $capGroup) {
            foreach ($capGroup as $cap) {
                $roles->add_cap('administrator', $cap);

                if (is_multisite()) {
                    $roles->add_cap('super_admin', $cap);
                }
            }
        }
    }

    public static function pluginDeactivation()
    {
        wp_clear_scheduled_hook(self::CRON_TASK);
    }

    public static function pluginUninstall()
    {
        // Nothing
    }

    public static function capabilities()
    {
        $capabilities = [];
        $capabilities['core'] = ['manage_' . self::OPTIONS_KEY];
        flush_rewrite_rules(true);

        return $capabilities;
    }

    private function __clone()
    {
    }
}
