<?php
namespace IwantToBelive\Cf7\Pipedrive\Integration\Includes;

class CF7
{
    private static $instance = false;

    public static function getInstance()
    {
        if (!self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    protected function __construct()
    {
        if ($this->isActive()) {
            add_action('wpcf7_mail_sent', [$this, 'onFormSubmit'], 10, 1);
        }
    }

    public function onFormSubmit(\WPCF7_ContactForm $contactForm)
    {
        if (!class_exists('\\WPCF7_Submission')) {
            return;
        }

        $submission = \WPCF7_Submission::get_instance();

        if (!$submission) {
            return;
        }

        $postedData = $submission->get_posted_data();

        if (!$postedData) {
            return;
        }

        // Compatible `Contact Form 7 Multi-Step Forms`
        if (function_exists('\\cf7msm_get')) {
            if (!empty($_POST['step'])) {
                $step = wp_unslash($_POST['step']);

                if (preg_match('/(\d+)-(\d+)/', $step, $matches)) {
                    $curr_step = $matches[1];
                    $last_step = $matches[2];

                    if ($curr_step != $last_step) {
                        return;
                    }
                }
            }

            $prevData = \cf7msm_get('cf7msm_posted_data', '');

            if (!is_array($prevData)) {
                $prevData = [];
            }

            $postedData = array_merge($prevData, $postedData);
        }

        $meta = get_post_meta($contactForm->id(), Bootstrap::META_KEY, true);

        // If empty form setting or not enabled send lead
        if (empty($meta) || !$meta['ENABLED']) {
            return;
        }

        $currentType = isset($meta['TYPE']) ? $meta['TYPE'] : 'deal';

        // If empty settings by type
        if ($currentType == 'deal' && empty($meta[$currentType])) {
            return;
        } elseif ($currentType == 'personandorganization'
            && empty($meta['person'])
            && empty($meta['organization'])
        ) {
            return;
        } elseif ($currentType == 'dealandactivity'
            && empty($meta['deal'])
            && empty($meta['activity'])
            && empty($meta['person'])
            && empty($meta['organization'])
        ) {
            return;
        }

        $postedData = $this->prepareSpecialMailTags($postedData);
        $postedData = $this->parseUtmCookie($postedData);

        // Set roistat client id
        $postedData['roistat_visit'] = isset($_COOKIE['roistat_visit'])
            ? $_COOKIE['roistat_visit']
            : '';

        // Set ga client id
        $postedData['gaClientID'] = '';

        if (!empty($_COOKIE['_ga'])) {
            $clientId = explode('.', wp_unslash($_COOKIE['_ga']));
            $postedData['gaClientID'] = $clientId[2] . '.' . $clientId[3];
        }

        $keys = array_map(function ($key) {
            return '[' . $key . ']';
        }, array_keys($postedData));
        $values = array_values($postedData);
        array_walk($values, function (&$value) {
            if (is_array($value)) {
                $value = implode(', ', $value);
            }
        });

        $settings = get_option(Bootstrap::OPTIONS_KEY);
        $data = [];
        $data['keys'] = $keys;
        $data['values'] = $values;

        $sendFields = [
            'update_exists_organization' => !empty($meta['update_exists_organization']),
            'update_exists_person' => !empty($meta['update_exists_person'])
        ];
        $crmFields = [];

        if (!empty($meta['enable_send_files'])) {
            $uploadedFiles = $submission->uploaded_files();

            if (!empty($uploadedFiles)) {
                $sendFields['uploads'] = $this->prepareUploads($uploadedFiles);
            }
        }

        switch ($currentType) {
            case 'deal':
                $crmFields['deal'] = (array) get_option(Bootstrap::DEAL_FIELDS_KEY);
                $crmFields['person'] = (array) get_option(Bootstrap::PERSON_FIELDS_KEY);
                $crmFields['organization'] = (array) get_option(Bootstrap::ORGANIZATION_FIELDS_KEY);
                $crmFields['note'] = (array) get_option(Bootstrap::NOTE_FIELDS_KEY);

                $sendFields['deal'] = $this->prepareSendFields($crmFields['deal'], $meta['deal'], $data);
                $sendFields['person'] = $this->prepareSendFields($crmFields['person'], $meta['person'], $data);
                $sendFields['organization'] = $this->prepareSendFields(
                    $crmFields['organization'],
                    $meta['organization'],
                    $data
                );

                $sendFields['note'] = $this->prepareSendFields($crmFields['note'], $meta['note'], $data);

                if (!empty($sendFields['deal'])) {
                    if (empty($settings['send_type']) || $settings['send_type'] === 'wp_cron') {
                        Helper::log(
                            'register send form event - ' . $contactForm->id() . ' - ' . $currentType,
                            $sendFields
                        );
                        wp_schedule_single_event(time() + 15, Bootstrap::SEND_CRON_TASK, [$sendFields, $currentType]);
                    } else {
                        Crm::send($sendFields, $currentType);
                    }
                }
                break;
            case 'personandorganization':
                $crmFields['person'] = (array) get_option(Bootstrap::PERSON_FIELDS_KEY);
                $crmFields['organization'] = (array) get_option(Bootstrap::ORGANIZATION_FIELDS_KEY);
                $crmFields['note'] = (array) get_option(Bootstrap::NOTE_FIELDS_KEY);

                $sendFields['person'] = $this->prepareSendFields(
                    $crmFields['person'],
                    $meta['person'],
                    $data
                );
                $sendFields['organization'] = $this->prepareSendFields(
                    $crmFields['organization'],
                    $meta['organization'],
                    $data
                );
                $sendFields['note'] = $this->prepareSendFields($crmFields['note'], $meta['note'], $data);

                if (!empty($sendFields['person']) || !empty($sendFields['organization'])) {
                    if (empty($settings['send_type']) || $settings['send_type'] === 'wp_cron') {
                        Helper::log(
                            'register send form event - ' . $contactForm->id() . ' - ' . $currentType,
                            $sendFields
                        );
                        wp_schedule_single_event(time() + 15, Bootstrap::SEND_CRON_TASK, [$sendFields, $currentType]);
                    } else {
                        Crm::send($sendFields, $currentType);
                    }
                }
                break;
            case 'activity':
                $crmFields['activity'] = (array) get_option(Bootstrap::ACTIVITY_FIELDS_KEY);
                $crmFields['person'] = (array) get_option(Bootstrap::PERSON_FIELDS_KEY);
                $crmFields['organization'] = (array) get_option(Bootstrap::ORGANIZATION_FIELDS_KEY);

                $sendFields['activity'] = $this->prepareSendFields($crmFields['activity'], $meta['activity'], $data);
                $sendFields['person'] = $this->prepareSendFields($crmFields['person'], $meta['person'], $data);
                $sendFields['organization'] = $this->prepareSendFields(
                    $crmFields['organization'],
                    $meta['organization'],
                    $data
                );

                if (!empty($sendFields['activity'])) {
                    if (empty($settings['send_type']) || $settings['send_type'] === 'wp_cron') {
                        Helper::log(
                            'register send form event - ' . $contactForm->id() . ' - ' . $currentType,
                            $sendFields
                        );
                        wp_schedule_single_event(time() + 15, Bootstrap::SEND_CRON_TASK, [$sendFields, $currentType]);
                    } else {
                        Crm::send($sendFields, $currentType);
                    }
                }
                break;
            case 'dealandactivity':
                $crmFields['deal'] = (array) get_option(Bootstrap::DEAL_FIELDS_KEY);
                $crmFields['person'] = (array) get_option(Bootstrap::PERSON_FIELDS_KEY);
                $crmFields['organization'] = (array) get_option(Bootstrap::ORGANIZATION_FIELDS_KEY);
                $crmFields['note'] = (array) get_option(Bootstrap::NOTE_FIELDS_KEY);
                $crmFields['activity'] = (array) get_option(Bootstrap::ACTIVITY_FIELDS_KEY);

                $sendFields['deal'] = $this->prepareSendFields($crmFields['deal'], $meta['deal'], $data);
                $sendFields['person'] = $this->prepareSendFields($crmFields['person'], $meta['person'], $data);
                $sendFields['organization'] = $this->prepareSendFields(
                    $crmFields['organization'],
                    $meta['organization'],
                    $data
                );
                $sendFields['note'] = $this->prepareSendFields($crmFields['note'], $meta['note'], $data);
                $sendFields['activity'] = $this->prepareSendFields(
                    $crmFields['activity'],
                    $meta['activity'],
                    $data
                );

                if (!empty($sendFields['deal'])) {
                    if (empty($settings['send_type']) || $settings['send_type'] === 'wp_cron') {
                        Helper::log(
                            'register send form event - ' . $contactForm->id() . ' - ' . $currentType,
                            $sendFields
                        );
                        wp_schedule_single_event(time() + 15, Bootstrap::SEND_CRON_TASK, [$sendFields, $currentType]);
                    } else {
                        Crm::send($sendFields, $currentType);
                    }
                }
                break;
            default:
                // Nothing
                break;
        }
    }

    public function prepareSendFields($fields, $meta, $postedData)
    {
        $prepareFields = [];

        foreach ($fields as $field) {
            $populateValue = isset($meta[$field['key'] . '-populate']) ? $meta[$field['key'] . '-populate'] : '';
            $value = isset($meta[$field['key']]) ? $meta[$field['key']] : '';

            if ($populateValue) {
                $populateValue = trim(
                    str_replace($postedData['keys'], $postedData['values'], $populateValue)
                );

                if (function_exists('wpcf7_mail_replace_tags')) {
                    $populateValue = \wpcf7_mail_replace_tags($populateValue);
                }
            }

            if ($populateValue) {
                $prepareFields[$field['key']] = $populateValue;
            } elseif ($value) {
                $prepareFields[$field['key']] = trim(
                    str_replace($postedData['keys'], $postedData['values'], $value)
                );

                if (function_exists('wpcf7_mail_replace_tags')) {
                    $prepareFields[$field['key']] = \wpcf7_mail_replace_tags($prepareFields[$field['key']]);
                }
            }

            // Populate select and multiselect
            if (isset($prepareFields[$field['key']]) && !empty($field['options'])) {
                $explodedField = explode(', ', $prepareFields[$field['key']]);
                $resolveValues = [];

                $ids = \array_column($field['options'], 'id');
                $labels = \array_column($field['options'], 'label');

                foreach ($explodedField as $explodeValue) {
                    if (array_search($explodeValue, $ids) !== false) {
                        $resolveValues[] = $explodeValue;
                    } elseif (array_search($explodeValue, $labels) !== false) {
                        $resolveValues[] = $ids[array_search($explodeValue, $labels)];
                    }
                }

                $prepareFields[$field['key']] = $resolveValues;
            }

            // support date field
            if ($field['field_type'] === 'date' && !empty($prepareFields[$field['key']])) {
                $prepareFields[$field['key']] = \date_i18n('Y-m-d H:i:s', strtotime($prepareFields[$field['key']]));
            }

            if (!empty($prepareFields[$field['key']]) && !is_array($prepareFields[$field['key']])) {
                $prepareFields[$field['key']] = trim(
                    preg_replace('/\[utm_.*?\]/is', '', $prepareFields[$field['key']])
                );
            }
        }

        return $prepareFields;
    }

    public function prepareSpecialMailTags($postedData)
    {
        $specialMailTags = [
            'geoip_detect2_user_info', // Support GeoIP Detection plugin
            'tracking-info'  // Support Contact Form 7 Lead info with country plugin
        ];

        foreach ($specialMailTags as $smt) {
            // Support Contact Form 7 Lead info with country plugin
            if ($smt === 'tracking-info') {
                if (function_exists('\\wpshore_wpcf7_before_send_mail')) {
                    $result = \wpshore_wpcf7_before_send_mail(['body' => '[tracking-info]'], 1, new \stdClass());

                    $postedData[$smt] = $result['body'];
                }
            } else {
                $postedData[$smt] = apply_filters(
                    'wpcf7_special_mail_tags',
                    '',
                    $smt,
                    false
                );
            }
        }

        return $postedData;
    }

    public function parseUtmCookie($postedData)
    {
        $basedUtm = [
            'utm_source',
            'utm_medium',
            'utm_campaign',
            'utm_term',
            'utm_content'
        ];

        foreach ($basedUtm as $utm) {
            if (!isset($postedData[$utm])) {
                $postedData[$utm] = '';
            }
        }

        if (!empty($_COOKIE[Bootstrap::UTM_COOKIES])) {
            $utmParams = json_decode(wp_unslash($_COOKIE[Bootstrap::UTM_COOKIES]), true);

            foreach ($utmParams as $key => $value) {
                $postedData[$key] = rawurldecode(wp_unslash($value));
            }

            return $postedData;
        }

        return $postedData;
    }

    public function prepareUploads($files)
    {
        $uploadsDir = wp_upload_dir();
        $uploadedFiles = [];

        if (!file_exists($uploadsDir['basedir'] . '/cf7-pipedrive-integration')) {
            mkdir($uploadsDir['basedir'] . '/cf7-pipedrive-integration', 0777);
        }

        foreach ($files as $file) {
            if (!file_exists($file)) {
                continue;
            }

            $filePathInfo = pathinfo($file);
            $newFileName = uniqid();

            $newFilePath = $uploadsDir['basedir']
                . '/cf7-pipedrive-integration/'
                . $newFileName;

            copy($file, $newFilePath);

            $uploadedFiles[] = [
                'name' => $filePathInfo['basename'],
                'path' => $newFilePath
            ];
        }

        return $uploadedFiles;
    }

    public function isActive()
    {
        $settings = get_option(Bootstrap::OPTIONS_KEY);

        return !empty($settings['token']);
    }

    protected function __clone()
    {
    }
}
