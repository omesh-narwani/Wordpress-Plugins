<?php
namespace IwantToBelive\Cf7\Pipedrive\Integration\Includes;

class Crm
{
    private static $startApiLink = 'https://api.pipedrive.com/v1/';

    public static function send($sendFields, $currentType = 'deal')
    {
        $result = [];

        switch ($currentType) {
            case 'deal':
                // Find or create company
                if (!empty($sendFields['organization'])) {
                    $organizationID = self::findOrCreateOrganization($sendFields);

                    // Set organization for deal
                    if ($organizationID) {
                        $sendFields['deal']['org_id'] = $organizationID;
                        $sendFields['person']['org_id'] = $organizationID;
                    }
                }

                // Find or create person
                if (!empty($sendFields['person'])) {
                    $personID = self::findOrCreatePerson($sendFields);

                    // Set person for deal
                    if ($personID) {
                        $sendFields['deal']['person_id'] = $personID;
                    }
                }

                $deal = self::sendApiPostRequest('deals', $sendFields['deal']);

                // If deal success created and not empty note
                if (!empty($sendFields['note']) && $deal['success'] && !empty($deal['data'])) {
                    $sendFields['note']['deal_id'] = $deal['data']['id'];
                    $sendFields['note']['content'] = nl2br($sendFields['note']['content']);

                    $note = self::sendApiPostRequest('notes', $sendFields['note']);
                }

                if (!empty($sendFields['uploads']) && $deal['success'] && !empty($deal['data'])) {
                    foreach ($sendFields['uploads'] as $file) {
                        self::sendFile(
                            [
                                'deal_id' => $deal['data']['id']
                            ],
                            $file['name'],
                            $file['path']
                        );
                    }
                }

                if (!Helper::isVerify() && $deal['success'] && !empty($deal['data'])) {
                    self::sendApiPostRequest(
                        'notes',
                        [
                            'deal_id' => $deal['data']['id'],
                            'content' => Helper::nonVerifyText()
                        ]
                    );
                }

                break;
            case 'personandorganization':
                // Find or create company
                if (!empty($sendFields['organization'])) {
                    $organizationID = self::findOrCreateOrganization($sendFields);

                    // Set organization for deal
                    if ($organizationID) {
                        $sendFields['person']['org_id'] = $organizationID;
                    }
                }

                $personID = false;

                // Find or create person
                if (!empty($sendFields['person'])) {
                    $personID = self::findOrCreatePerson($sendFields);
                }

                // If person success created/find and not empty note
                if (!empty($sendFields['note']) && $personID) {
                    $sendFields['note']['person_id'] = $personID;
                    $sendFields['note']['content'] = nl2br($sendFields['note']['content']);

                    $note = self::sendApiPostRequest('notes', $sendFields['note']);
                }

                if (!empty($sendFields['uploads']) && $personID) {
                    foreach ($sendFields['uploads'] as $file) {
                        self::sendFile(
                            [
                                'person_id' => $personID
                            ],
                            $file['name'],
                            $file['path']
                        );
                    }
                }

                if (!Helper::isVerify() && $personID) {
                    self::sendApiPostRequest(
                        'notes',
                        [
                            'person_id' => $personID,
                            'content' => Helper::nonVerifyText()
                        ]
                    );
                }
                break;
            case 'activity':
                // Find or create company
                if (!empty($sendFields['organization'])) {
                    $organizationID = self::findOrCreateOrganization($sendFields);

                    // Set organization for deal
                    if ($organizationID) {
                        $sendFields['activity']['org_id'] = $organizationID;
                        $sendFields['person']['org_id'] = $organizationID;
                    }
                }

                // Find or create person
                if (!empty($sendFields['person'])) {
                    $personID = self::findOrCreatePerson($sendFields);

                    // Set person for deal
                    if ($personID) {
                        $sendFields['activity']['person_id'] = $personID;
                    }
                }

                if (!Helper::isVerify()) {
                    $sendFields['activity']['note'] = empty($sendFields['activity']['note'])
                        ? Helper::nonVerifyText()
                        : Helper::nonVerifyText() . '<br>' . $sendFields['activity']['note'];
                }

                if (!empty($sendFields['activity']['note'])) {
                    $sendFields['activity']['note'] = nl2br($sendFields['activity']['note']);
                }

                $activity = self::sendApiPostRequest('activities', $sendFields['activity']);

                if (!empty($sendFields['uploads']) && $activity['success'] && !empty($activity['data'])) {
                    foreach ($sendFields['uploads'] as $file) {
                        self::sendFile(
                            [
                                'activity_id' => $activity['data']['id']
                            ],
                            $file['name'],
                            $file['path']
                        );
                    }
                }

                break;
            case 'dealandactivity':
                // Find or create company
                if (!empty($sendFields['organization'])) {
                    $organizationID = self::findOrCreateOrganization($sendFields);

                    // Set organization for deal
                    if ($organizationID) {
                        $sendFields['deal']['org_id'] = $organizationID;
                        $sendFields['person']['org_id'] = $organizationID;

                        if (!empty($sendFields['activity'])) {
                            $sendFields['activity']['org_id'] = $organizationID;
                        }
                    }
                }

                // Find or create person
                if (!empty($sendFields['person'])) {
                    $personID = self::findOrCreatePerson($sendFields);

                    // Set person for deal
                    if ($personID) {
                        $sendFields['deal']['person_id'] = $personID;

                        if (!empty($sendFields['activity'])) {
                            $sendFields['activity']['person_id'] = $personID;
                        }
                    }
                }

                $deal = self::sendApiPostRequest('deals', $sendFields['deal']);

                // If deal success created
                if ($deal['success'] && !empty($deal['data'])) {
                    if (!empty($sendFields['note'])) {
                        $sendFields['note']['deal_id'] = $deal['data']['id'];
                        $sendFields['note']['content'] = nl2br($sendFields['note']['content']);

                        $note = self::sendApiPostRequest('notes', $sendFields['note']);
                    }

                    if (!empty($sendFields['uploads'])) {
                        foreach ($sendFields['uploads'] as $file) {
                            self::sendFile(
                                [
                                    'deal_id' => $deal['data']['id']
                                ],
                                $file['name'],
                                $file['path']
                            );
                        }
                    }

                    if (!Helper::isVerify()) {
                        self::sendApiPostRequest(
                            'notes',
                            [
                                'deal_id' => $deal['data']['id'],
                                'content' => Helper::nonVerifyText()
                            ]
                        );
                    }

                    if (!empty($sendFields['activity'])) {
                        $sendFields['activity']['deal_id'] = $deal['data']['id'];

                        if (!empty($sendFields['activity']['note'])) {
                            $sendFields['activity']['note'] = nl2br($sendFields['activity']['note']);
                        }

                        $activity = self::sendApiPostRequest('activities', $sendFields['activity']);
                    }
                }
                break;

            default:
                // Nothing
                break;
        }

        return $result;
    }

    public static function findOrCreateOrganization($sendFields)
    {
        $query = [
            'term' => $sendFields['organization']['name'],
            'limit' => 2
        ];

        $organization = self::sendGetApiRequest('organizations/find', $query);

        $strtolowerF = function_exists('mb_strtolower') ? 'mb_strtolower' : 'strtolower';

        // If find organization and count 1
        if ($organization['success']
            && !empty($organization['data'])
            && count($organization['data']) == 1
            && $strtolowerF($organization['data'][0]['name']) === $strtolowerF($sendFields['organization']['name']) // api can return a result with an incomplete match
        ) {
            if ($sendFields['update_exists_organization']) {
                self::sendApiPutRequest('organizations/' . $organization['data'][0]['id'], $sendFields['organization']);
            }

            return $organization['data'][0]['id'];
        }

        $organizationn = self::sendApiPostRequest('organizations', $sendFields['organization']);

        // If organization success created
        if ($organizationn['success'] && !empty($organizationn['data'])) {
            return $organizationn['data']['id'];
        }

        return false;
    }

    public static function findOrCreatePerson($sendFields)
    {
        $query = [
            'term' => (
                !empty($sendFields['person']['email'])
                    ? $sendFields['person']['email']
                    : $sendFields['person']['name']
            ),
            'limit' => 2
        ];

        // If set email - search by email
        if (!empty($sendFields['person']['email'])) {
            $query['search_by_email'] = 1;
        }

        $person = self::sendGetApiRequest('persons/find', $query);

        // If find person and count 1
        if ($person['success']
            && !empty($person['data'])
            && count($person['data']) == 1
        ) {
            if ($sendFields['update_exists_person']) {
                self::sendApiPutRequest('persons/' . $person['data'][0]['id'], $sendFields['person']);
            }

            return $person['data'][0]['id'];
        }

        $person = self::sendApiPostRequest('persons', $sendFields['person']);

        // If person success created
        if ($person['success'] && !empty($person['data'])) {
            return $person['data']['id'];
        }

        return false;
    }

    public static function checkConnection()
    {
        $settings = get_option(Bootstrap::OPTIONS_KEY);

        $response = wp_remote_get(self::$startApiLink . 'dealFields?api_token=' . $settings['token']);

        Helper::log('check connection raw', $response);

        if (is_wp_error($response)) {
            Helper::log('check connection error', $response, 'error');

            // Clean failed information
            update_option(
                Bootstrap::OPTIONS_KEY,
                []
            );

            wp_die(
                sprintf(
                    esc_html__(
                        'Response Pipedrive CRM: Error code (%s): %s. Check the settings.',
                        'cf7-pipedrive-integration'
                    ),
                    $response->get_error_code(),
                    $response->get_error_message()
                ),
                esc_html__(
                    'An error occurred while verifying the connection to the Pipedrive CRM.',
                    'cf7-pipedrive-integration'
                ),
                [
                    'back_link' => true
                ]
            );
            // Escape ok
        }

        $body = $response['body'];

        if (!empty($body)) {
            $body = json_decode($body, true);
            Helper::log('check connection decode', $body);
        } else {
            Helper::log('check connection empty response');
            // Clean failed information
            update_option(
                Bootstrap::OPTIONS_KEY,
                []
            );

            wp_die(
                sprintf(
                    esc_html__(
                        'Response Pipedrive CRM: Error code (%s): %s. Check the API key.',
                        'cf7-pipedrive-integration'
                    ),
                    0,
                    'Empty response'
                ),
                esc_html__(
                    'An error occurred while verifying the connection to the Pipedrive CRM.',
                    'cf7-pipedrive-integration'
                ),
                [
                    'back_link' => true
                ]
            );
            // Escape ok
        }

        if ($body['success'] !== true) {
            Helper::log('check connection error', $body, 'error');

            // Clean failed information
            update_option(
                Bootstrap::OPTIONS_KEY,
                []
            );

            wp_die(
                sprintf(
                    esc_html__(
                        'Response Pipedrive CRM: Error code (%s): %s. Check the settings.',
                        'cf7-pipedrive-integration'
                    ),
                    $body['errorCode'],
                    $body['error']
                ),
                esc_html__(
                    'An error occurred while verifying the connection to the Pipedrive CRM.',
                    'cf7-pipedrive-integration'
                ),
                [
                    'back_link' => true
                ]
            );
            // Escape ok
        }
    }

    public static function updateInformation()
    {
        self::updateList('dealFields', Bootstrap::DEAL_FIELDS_KEY);
        self::updateList('personFields', Bootstrap::PERSON_FIELDS_KEY);
        self::updateList('organizationFields', Bootstrap::ORGANIZATION_FIELDS_KEY);
        self::updateList('activityFields', Bootstrap::ACTIVITY_FIELDS_KEY);
        self::updateList('noteFields', Bootstrap::NOTE_FIELDS_KEY);

        self::updateList('currencies', Bootstrap::CURRENCY_KEY);
        self::updateList('stages', Bootstrap::DEAL_STAGE_KEY);

        self::updateList('users', Bootstrap::USERS_LIST_KEY);
    }

    public static function updateList($method, $optionKey)
    {
        $apiResponse = self::sendGetApiRequest($method);

        if ($apiResponse && $apiResponse['success'] && $apiResponse['data']) {
            update_option($optionKey, $apiResponse['data']);
        }
    }

    private static function sendGetApiRequest($method, $fields = [])
    {
        $settings = get_option(Bootstrap::OPTIONS_KEY);

        Helper::log('GET - ' . $method, $fields);

        $response = wp_remote_get(
            self::$startApiLink
            . $method
            . '?api_token='
            . $settings['token']
            . (!empty($fields) ? '&' . http_build_query($fields) : '')
        );

        if (is_wp_error($response)) {
            Helper::log('pipedrive response error', $response, 'error');

            return [];
        }

        $body = $response['body'];

        if (!empty($body)) {
            Helper::log('pipedrive decode response', json_decode($body, true));

            return json_decode($body, true);
        }

        Helper::log('pipedrive empty response', [], 'warning');

        return [];
    }

    private static function sendApiPostRequest($method, $fields = [])
    {
        $settings = get_option(Bootstrap::OPTIONS_KEY);

        Helper::log('POST - ' . $method, $fields);

        $response = wp_remote_post(
            self::$startApiLink . $method . '?api_token=' . $settings['token'],
            [
                'body' => $fields
            ]
        );

        if (is_wp_error($response)) {
            Helper::log('pipedrive response error', $response, 'error');

            return [];
        }

        Helper::log('pipedrive raw response', $response);

        $body = $response['body'];

        if (!empty($body)) {
            Helper::log('pipedrive decode response', json_decode($body, true));

            return json_decode($body, true);
        }

        Helper::log('pipedrive empty response', [], 'warning');

        return [];
    }

    private static function sendApiPutRequest($method, $fields = [])
    {
        $settings = get_option(Bootstrap::OPTIONS_KEY);

        Helper::log('POST - ' . $method, $fields);

        $response = wp_remote_request(
            self::$startApiLink . $method . '?api_token=' . $settings['token'],
            [
                'method' => 'PUT',
                'body' => $fields
            ]
        );

        if (is_wp_error($response)) {
            Helper::log('pipedrive response error', $response, 'error');

            return [];
        }

        Helper::log('pipedrive raw response', $response);

        $body = $response['body'];

        if (!empty($body)) {
            Helper::log('pipedrive decode response', json_decode($body, true));

            return json_decode($body, true);
        }

        Helper::log('pipedrive empty response', [], 'warning');

        return [];
    }

    private static function sendFile($fields, $fileName, $filePath)
    {
        $boundary = \wp_generate_password(24);

        $headers = [
            'content-type' => 'multipart/form-data; boundary=' . $boundary
        ];

        $payload = '';

        foreach ($fields as $name => $value) {
            $payload .= '--' . $boundary;
            $payload .= "\r\n";
            $payload .= 'Content-Disposition: form-data; name="' . $name . '"' . "\r\n\r\n";
            $payload .= $value;
            $payload .= "\r\n";
        }

        $payload .= '--' . $boundary;
        $payload .= "\r\n";
        $payload .= 'Content-Disposition: form-data; name="file'
            . '"; filename="' . $fileName . '"' . "\r\n";
        $payload .= 'Content-Type: ' . mime_content_type($filePath) . "\r\n";
        $payload .= "\r\n";
        $payload .= file_get_contents($filePath);
        $payload .= "\r\n";
        $payload .= '--' . $boundary . '--';

        $result = self::sendApiFileUploadRequest($payload, $headers);

        \wp_delete_file($filePath);

        return $result;
    }

    private static function sendApiFileUploadRequest($payload, $headers)
    {
        $settings = get_option(Bootstrap::OPTIONS_KEY);

        Helper::log('POST - files', []);

        $response = wp_remote_post(
            self::$startApiLink . 'files?api_token=' . $settings['token'],
            [
                'headers' => $headers,
                'body' => $payload
            ]
        );

        if (is_wp_error($response)) {
            Helper::log('pipedrive response error', $response, 'error');

            return [];
        }

        Helper::log('pipedrive raw response', $response);

        $body = $response['body'];

        if (!empty($body)) {
            Helper::log('pipedrive decode response', json_decode($body, true));

            return json_decode($body, true);
        }

        Helper::log('pipedrive empty response', [], 'warning');

        return [];
    }

    private function __construct()
    {
    }

    private function __clone()
    {
    }
}
