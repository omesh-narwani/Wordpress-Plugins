<?php
namespace IwantToBelive\Cf7\Pipedrive\Integration\Includes;

class CrmFields
{
    public static $breakFields = [
        'deal' => [
            'person_id',
            'org_id',
            'add_time',
            'update_time',
            'stage_change_time',
            'next_activity_date',
            'last_activity_date',
            'weighted_value',
            'weighted_value_currency',
            'won_time',
            'pipeline',
            'last_incoming_mail_time',
            'last_outgoing_mail_time',
            'lost_time',
            'close_time',
            'lost_reason',
            'id',
            'activities_count',
            'done_activities_count',
            'undone_activities_count',
            'email_messages_count'
        ],
        'person' => [
            'add_time',
            'update_time',
            'open_deals_count',
            'next_activity_date',
            'last_activity_date',
            'id',
            'org_id',
            'won_deals_count',
            'lost_deals_count',
            'closed_deals_count',
            'activities_count',
            'done_activities_count',
            'undone_activities_count',
            'email_messages_count',
            'picture_id',
            'last_incoming_mail_time',
            'last_outgoing_mail_time'
        ],
        'organization' => [
            'open_deals_count',
            'add_time',
            'update_time',
            'next_activity_date',
            'last_activity_date',
            'id',
            'won_deals_count',
            'lost_deals_count',
            'closed_deals_count',
            'activities_count',
            'done_activities_count',
            'undone_activities_count',
            'email_messages_count',
            'picture_id',
            'address_subpremise',
            'address_street_number',
            'address_route',
            'address_sublocality',
            'address_locality',
            'address_admin_area_level_1',
            'address_admin_area_level_2',
            'address_country',
            'address_postal_code',
            'address_formatted_address'
        ],
        'note' => [
            'id',
            'org_id',
            'person_id',
            'deal_id',
            'add_time',
            'update_time',
            'user_id',
            'user_id',
            'pinned_to_deal_flag',
            'pinned_to_organization_flag',
            'pinned_to_person_flag'
        ],
        'activity' => [
            'id',
            'person_id',
            'org_id',
            'marked_as_done_time',
            'participants',
            'update_time',
            'last_notification_time',
            'add_time',
            'created_by_user_id'
        ]
    ];

    public static $requiredFields = [
        'deal' => [
            'title'
        ],
        'person' => [
            'name'
        ],
        'organization' => [
            'name'
        ],
        'note' => [
            'content'
        ],
        'activity' => [
            'subject',
            'type'
        ]
    ];

    public function __construct()
    {

    }

    private function __clone()
    {
    }
}
