<?php
namespace IwantToBelive\Cf7\Pipedrive\Integration\Includes;

class Cron
{
    private static $instance = false;

    protected function __construct()
    {
        add_action('init', [$this, 'createCron']);
        add_action(Bootstrap::CRON_TASK, [$this, 'cronAction']);
        add_action(Bootstrap::SEND_CRON_TASK, [$this, 'sendCronAction'], 10, 2);
    }

    public static function getInstance()
    {
        if (!self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function createCron()
    {
        if (!wp_next_scheduled(Bootstrap::CRON_TASK)) {
            wp_schedule_event(time(), 'hourly', Bootstrap::CRON_TASK);
        }
    }

    public function cronAction()
    {
        $last = get_option('cf7-pipedrive-integration-last-cron');

        if (!empty($last) && date_i18n('Y-m-d') == $last) {
            return;
        }

        $settings = get_option(Bootstrap::OPTIONS_KEY);

        if (!empty($settings['token'])) {
            update_option('cf7-pipedrive-integration-last-cron', date_i18n('Y-m-d'));

            Crm::updateInformation();
        }
    }

    public function sendCronAction($sendFields, $currentType)
    {
        Crm::send($sendFields, $currentType);
    }

    private function __clone()
    {
    }
}
