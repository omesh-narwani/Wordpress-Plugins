<?php
namespace IwantToBelive\Cf7\Pipedrive\Integration\Includes;

use Monolog\Handler\StreamHandler;
use Monolog\Logger;

class Helper
{
    public static $log;

    public static function log($message, $data = [], $type = 'info')
    {
        $settings = get_option(Bootstrap::OPTIONS_KEY);
        $enableLogging = isset($settings['enabled_logging']) && (int) $settings['enabled_logging'] === 1;

        if ($enableLogging) {
            try {
                if (empty(self::$log)) {
                    self::$log = new Logger('cf7pd');
                    self::$log->pushHandler(
                        new StreamHandler(CF7_PIPEDRIVE_INTEGRATION_PLUGIN_DIR . '/logs/.cf7pd.log', Logger::INFO)
                    );
                }

                self::$log->$type($message, (array) $data);
            } catch (\Exception $exception) {
                if (is_super_admin()) {
                    wp_die(
                        sprintf(
                            esc_html__(
                                'Error code (%s): %s.',
                                'cf7-pipedrive-integration'
                            ),
                            $exception->getCode(),
                            $exception->getMessage()
                        ),
                        esc_html__(
                            'An error occurred while writing the log file.',
                            'cf7-pipedrive-integration'
                        ),
                        [
                            'back_link' => true
                        ]
                    );
                    // escape ok
                }
            }
        }
    }

    public static function isVerify()
    {
        $value = get_site_option(Bootstrap::PURCHASE_CODE_OPTIONS_KEY);

        if (!empty($value)) {
            return true;
        }

        return false;
    }

    public static function nonVerifyText()
    {
        return 'Please verify the purchase code on the plugin integration settings page - '
            . admin_url()
            . 'admin.php?page=wpcf7-integration&service=cf7-pipedrive-integration&action=setup';
    }

    private function __construct()
    {
    }

    private function __clone()
    {
    }
}
