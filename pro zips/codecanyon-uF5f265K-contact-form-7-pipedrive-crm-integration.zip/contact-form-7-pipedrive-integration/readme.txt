=== Contact Form 7 - Pipedrive CRM - Integration ===
Contributors: https://codecanyon.net/user/itgalaxycompany
Tags: pipedrive crm, pipedrive deals, business pipedrive, contact form 7, contact form 7 pipedrive, form, integration, deal finder, deal management, deal scraper, deals, marketing deals, sales deals.

== Description ==

The main task of this plugin is a send your Contact Form 7 forms directly to your Pipedrive CRM account.

= Features =

* Integrate your `Contact Form 7` forms with Pipedrive CRM;
* You can choice that your want to generate – deal, person & organization, activity or deal & activity;
* When creating a deal/activity, a person and an organization are created (or used existing if there is) and connected to it;
* Fields are loaded from the CRM (including custom fields);
* Your can set up each form personally, specify which information your want to get;
* Supports getting `utm` params from the `URL`;
* Supports for sending `GA Client ID`;
* Supports for sending `roistat_visit` cookie;
* Supports uploaded files;
* Multiple pipeline support;
* Compatible with `Contact Form 7 Multi-Step Forms`. (when configuring, you need to fill in the fields with all the steps in the last form);
* Integrate unlimited `Contact Form 7` forms;
* Image previews;
* Super easy to set-up;

== Installation ==

1. Extract `contact-form-7-pipedrive-integration.zip` and upload it to your `WordPress` plugin directory
(usually /wp-content/plugins ), or upload the zip file directly from the WordPress plugins page.
Once completed, visit your plugins page.
2. Be sure `Contact Form 7` Plugin is enabled.
3. Activate the plugin through the `Plugins` menu in WordPress.
4. Go to the `Contact Form 7` -> `Integration`.
5. Find `Integration with `Pipedrive CRM` and click the button `Go to setup`.
6. Insert in the field `API token`. Your personal API key can be found under Settings > Personal > API.
   https://support.pipedrive.com/hc/en-us/articles/207344545-How-to-find-your-personal-API-key
7. Save settings.
8. When editing forms your can see the tab `Pipedrive CRM`.

== Changelog ==

= 1.13.1 =
Fixed: pupulate select and multiselect.

= 1.13.0 =
Feature: use any `utm_` params in `URL`.

= 1.12.1 =
Chore: the list of users id is displayed next to the field of the user type.

= 1.12.0 =
Feature: support sending cookie `roistat_visit` to CRM.

= 1.11.1 =
Fixed: check may be the utm is already filled.

= 1.11.0 =
Feature: update for an existing person and organization.
Fixed: possible search error of the existing organization in part of the name.

= 1.10.1 =
Fixed: pipedrive date format.

= 1.10.0 =
Feature: added compatibility `Contact Form 7 Lead info with country`.
Fixed: special mail tags support.

= 1.9.2 =
Chore: more error handling.

= 1.9.1 =
Fixed: `created_by_user_id` activity field is no longer used, its value is set automatically.
Fixed: pipedrive date format.

= 1.9.0 =
Feature: Support for uploaded files.

= 1.8.1 =
Feature: Add `note` to a `person` - for type `Person & Organization`.

= 1.8.0 =
Feature: added the ability to log requests to CRM (disabled by default).
Feature: populate the value of the select and multiselect field from the form field.

= 1.7.0 =
Feature: Send crm by cron.

= 1.6.0 =
Feature: Support for `GA Client ID`.

= 1.5.0 =
Feature: Added compatibility `Contact Form 7 – Success Page Redirects`.

= 1.4.1 =
Fixed: special mail tags support.

= 1.4.0 =
Feature: Create a `deal` and `activity` together.

= 1.3.0 =
Feature: Support for `activity`.

= 1.2.0 =
Feature: Support for `utm` params in `URL`.

= 1.1.0 =
Feature: Support for multi pipeline.
Feature: Add `note` to a `deal`.

= 1.0.0 =
Initial public release
