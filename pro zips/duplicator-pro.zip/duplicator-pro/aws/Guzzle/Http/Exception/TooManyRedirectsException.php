<?php
namespace DuplicatorPro\Guzzle\Http\Exception;

defined("ABSPATH") or die("");

class TooManyRedirectsException extends BadResponseException {}
