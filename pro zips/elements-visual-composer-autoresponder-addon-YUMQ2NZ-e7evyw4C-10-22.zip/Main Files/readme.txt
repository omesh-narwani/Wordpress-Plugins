
First of all I would like to thank you for your purchase!
Contact Form 7 Addon for WordPress is very powerful tool and soon you will wonder how did you live without it… But first, take a moment to read this file. 

In Contact Form 7 Autoresponder Addon zip you will get 3 files. 1 is documentation file, 2nd readme file and 3rd is Contact Form 7 Addon zip.
   

/* Documentation
---------------------------------------------------------- */
   
   Using Contact Form 7 Addon is very straight forward process, most accurate documentation is available in www.cf7addon.himanshusofttech.com site:
   
   http://cf7addon.himanshusofttech.com/wp-content/themes/twentytwelve/Contact-Form-7-Autoresponder-Addon.pdf
   
      
/* Contact Form 7 Addon Video Tutorial
---------------------------------------------------------- */
   For complete demonstration of plugin visit below video url
   
   http://youtu.be/8Zs3RM5ZJow


/* Contact-Form-7-Addon.zip
---------------------------------------------------------- */
   
   Contact-Form-7-Addon.zip is plugin itself and it should be uploaded to your site, according to WordPress plugin installation rules.
   http://codex.wordpress.org/Managing_Plugins#Installing_Plugins

   This plugin has a licensing system , so you have to activate the license by entering purchase code and your email after the installation of the plugin.
   
   To get your purchase please refer this image 
   http://cf7addon.himanshusofttech.com/wp-content/themes/twentytwelve/purchase-code.jpg