<?php
namespace PVBCF7Calculator\lib\Math;

use \DateTime;
use \DateInterval;
use \DatePeriod;

class PVBCalculator
{
    /**
     * @var array Defined functions.
     */
    private $functions = [];

    /**
     * @var TokenizerInterface .
     */
    private $tokenizer;

    public static function create()
    {
        return new self(new Tokenizer());
    }

    /**
     * Constructor.
     * Sets expression if provided.
     * Sets default functions: sqrt(n), ln(n), log(a,b).
     * @param TokenizerInterface $tokenizer
     */
    public function __construct($tokenizer)
    {
        $this->tokenizer = $tokenizer;

        $this->addFunction('sqrt', function ($x) {
            return sqrt($x);
        });
        $this->addFunction('log', function ($base, $arg) {
            return log($arg, $base);
        });
        $this->addFunction('fn_day', function ($timestamp) {
            return date('j', $timestamp * 86400);
        });
        $this->addFunction('fn_month', function ($timestamp) {
            return date('n', $timestamp * 86400);
        });
        $this->addFunction('fn_year', function ($timestamp) {
            return date('Y', $timestamp * 86400);
        });
        $this->addFunction('fn_day_of_year', function ($timestamp) {
            return date('z', $timestamp * 86400);
        });
        $this->addFunction('fn_weekday', function ($timestamp) {
            return date('N', $timestamp * 86400);
        });
        $this->addFunction('fn_business_days', function ($timestamp1, $timestamp2) {
            date_default_timezone_set('UTC');
            $workingDays = [1, 2, 3, 4, 5]; # date format = N (1 = Monday, ...)
            $holidayDays = ['*-12-25', '*-01-01', '2013-12-23']; # variable and fixed holidays

            if ($timestamp1 < $timestamp2) {
                $from = new DateTime(date('Y-m-d', $timestamp1 * 86400));
                $to = new DateTime(date('Y-m-d', $timestamp2 * 86400));
            } else {
                $from = new DateTime(date('Y-m-d', $timestamp2 * 86400));
                $to = new DateTime(date('Y-m-d', $timestamp1 * 86400));
            }
            $to->modify('+1 day');
            $interval = new DateInterval('P1D');
            $periods = new DatePeriod($from, $interval, $to);
            $days = 0;
            foreach ($periods as $period) {
                $count++;
                if (!in_array($period->format('N'), $workingDays)) {
                    continue;
                }
                if (in_array($period->format('Y-m-d'), $holidayDays)) {
                    continue;
                }
                if (in_array($period->format('*-m-d'), $holidayDays)) {
                    continue;
                }
                $days++;
            }
            return $days;
        });
    }

    /**
     * @return  array
     */
    public function getFunctions()
    {
        return $this->functions;
    }

    /**
     * @param  string $name Name of the function (as in arithmetic expressions).
     * @param  callable $function Interpretation of this function.
     * @throws \Exception
     */
    public function addFunction($name, $function)
    {
        $name = strtolower(trim($name));

        if (!ctype_alpha(str_replace('_', '', $name))) {
            throw new \InvalidArgumentException('Only letters and underscore are allowed for a name of a function');
        }

        if (array_key_exists($name, $this->functions)) {
            throw new \Exception(sprintf('Function %s exists', $name));
        }

        $reflection = new \ReflectionFunction($function);
        $paramsCount = $reflection->getNumberOfRequiredParameters();

        $this->functions[$name] = [
            'func'        => $function,
            'paramsCount' => $paramsCount,
        ];
    }

    /**
     * @param string $name Name of the function.
     * @param callable $function Interpretation.
     */
    public function replaceFunction($name, $function)
    {
        $this->removeFunction($name);
        $this->addFunction($name, $function);
    }

    /**
     * @param  string $name Name of function.
     */
    public function removeFunction($name)
    {
        if (!array_key_exists($name, $this->functions)) {
            return;
        }

        unset($this->functions[$name]);
    }

    /**
     * Rearranges tokens according to RPN (Reverse Polish Notation) or
     * also known as Postfix Notation.
     *
     * @param  array $tokens
     * @return \SplQueue
     * @throws \InvalidArgumentException
     */
    private function getReversePolishNotation($tokens)
    {
        $queue = new \SplQueue();
        $stack = new \SplStack();

        $tokensCount = count($tokens);
        for ($i = 0; $i < $tokensCount; $i++) {
            if (is_numeric($tokens[$i])) {
                // (string + 0) converts to int or float
                $queue->enqueue($tokens[$i] + 0);
            } elseif (array_key_exists($tokens[$i], $this->functions)) {
                $stack->push($tokens[$i]);
            } elseif ($tokens[$i] === Tokens::ARG_SEPARATOR) {
                // checking whether stack contains left parenthesis (dirty hack)
                if (substr_count($stack->serialize(), Tokens::PAREN_LEFT) === 0) {
                    throw new \InvalidArgumentException('Parenthesis are misplaced');
                }

                while ($stack->top() != Tokens::PAREN_LEFT) {
                    $queue->enqueue($stack->pop());
                }
            } elseif (in_array($tokens[$i], Tokens::OPERATORS)) {
                while ($stack->count() > 0 && in_array($stack->top(), Tokens::OPERATORS)
                    && (($this->isOperatorLeftAssociative($tokens[$i])
                        && $this->getOperatorPrecedence($tokens[$i]) === $this->getOperatorPrecedence($stack->top()))
                    || ($this->getOperatorPrecedence($tokens[$i]) < $this->getOperatorPrecedence($stack->top())))) {
                    $queue->enqueue($stack->pop());
                }

                $stack->push($tokens[$i]);
            } elseif ($tokens[$i] === Tokens::PAREN_LEFT) {
                $stack->push(Tokens::PAREN_LEFT);
            } elseif ($tokens[$i] === Tokens::PAREN_RIGHT) {
                // checking whether stack contains left parenthesis (dirty hack)
                if (substr_count($stack->serialize(), Tokens::PAREN_LEFT) === 0) {
                    throw new \InvalidArgumentException('Parenthesis are misplaced');
                }

                while ($stack->top() != Tokens::PAREN_LEFT) {
                    $queue->enqueue($stack->pop());
                }

                $stack->pop();

                if ($stack->count() > 0 && array_key_exists($stack->top(), $this->functions)) {
                    $queue->enqueue($stack->pop());
                }
            }
        }

        while ($stack->count() > 0) {
            $queue->enqueue($stack->pop());
        }

        return $queue;
    }

    /**
     * Calculates tokens ordered in RPN.
     *
     * @param  \SplQueue $queue
     * @return int|float Result of the calculation.
     * @throws \InvalidArgumentException
     */
    private function calculateFromRPN($queue)
    {
        $stack = new \SplStack();

        while ($queue->count() > 0) {
            $currentToken = $queue->dequeue();
            if (is_numeric($currentToken)) {
                $stack->push($currentToken);
            } else {
                if (in_array($currentToken, Tokens::OPERATORS)) {
                    if ($stack->count() < 2) {
                        throw new \InvalidArgumentException('Invalid expression');
                    }
                    $stack->push($this->executeOperator($currentToken, $stack->pop(), $stack->pop()));
                } elseif (array_key_exists($currentToken, $this->functions)) {
                    if ($stack->count() < $this->functions[$currentToken]['paramsCount']) {
                        throw new \InvalidArgumentException('Invalid expression');
                    }

                    $params = [];
                    for ($i = 0; $i < $this->functions[$currentToken]['paramsCount']; $i++) {
                        $params[] = $stack->pop();
                    }

                    $stack->push($this->executeFunction($currentToken, $params));
                }
            }
        }

        if ($stack->count() === 1) {
            return $stack->pop();
        }
        throw new \InvalidArgumentException('Invalid expression');
    }

    /**
     * Calculates the current arithmetic expression.
     *
     * @param string $expression
     * @return float|int Result of the calculation.
     */
    public function calculate($expression)
    {
        $tokens = $this->tokenizer->tokenize($expression, array_keys($this->functions));
        $rpn    = $this->getReversePolishNotation($tokens);
        $result = $this->calculateFromRPN($rpn);

        return $result;
    }

    /**
     * @param  string $operator A valid operator.
     * @return bool
     * @throws \InvalidArgumentException
     */
    private function isOperatorLeftAssociative($operator)
    {
        if (!in_array($operator, Tokens::OPERATORS)) {
            throw new \InvalidArgumentException("Cannot check association of $operator operator");
        }

        if ($operator === Tokens::POW) {
            return false;
        }

        return true;
    }

    /**
     * @param  string $operator A valid operator.
     * @return int
     * @throws \InvalidArgumentException
     */
    private function getOperatorPrecedence($operator)
    {
        if (!in_array($operator, Tokens::OPERATORS)) {
            throw new \InvalidArgumentException("Cannot check precedence of $operator operator");
        }

        if ($operator === Tokens::POW) {
            return 6;
        } elseif ($operator === Tokens::MULT || $operator === Tokens::DIV) {
            return 4;
        } elseif ($operator === Tokens::MOD) {
            return 2;
        }
        return 1;
    }

    /**
     * @param  string    $operator A valid operator.
     * @param  int|float $a First value.
     * @param  int|float $b Second value.
     * @return int|float Result.
     * @throws \InvalidArgumentException
     */
    private function executeOperator($operator, $a, $b)
    {



        if ($operator === Tokens::PLUS) {
            $r = BigDecimal::of($a);
            return $r->plus($b)->toFloat();
        } elseif ($operator === Tokens::MINUS) {
            $r = BigDecimal::of($b);
            return $r->minus($a)->toFloat();
        } elseif ($operator === Tokens::MOD) {
            return $b % $a;
        } elseif ($operator === Tokens::MULT) {
            $r = BigDecimal::of($a);
            return $r->multipliedBy($b)->toFloat();
        } elseif ($operator === Tokens::DIV) {
            if ($a === 0) {
                throw new \InvalidArgumentException('Division by zero occurred');
            }
            $r = BigDecimal::of($b);
            return $r->dividedBy($a, 16, RoundingMode::HALF_UP)->toFloat();
        } elseif ($operator === Tokens::POW) {
            return pow($b, $a);
        }

        throw new \InvalidArgumentException('Unknown operator provided');
    }

    /**
     * @param  string $functionName
     * @param  array  $params
     * @return int|float Result.
     */
    private function executeFunction($functionName, $params)
    {
        return call_user_func_array($this->functions[$functionName]['func'], array_reverse($params));
    }
}
