<?php
namespace PVBCF7Calculator\lib;

use \WPCF7_ContactForm;
use \WPCF7_FormTag;
use \WPCF7_TagGenerator;
use PVBCF7Calculator\lib\Math\PVBCalculator;
use PVBCF7Calculator\lib\wpSettingsFramework;
use PVBCF7Calculator\lib\wpSettingsFramework\WordPressSettingsFramework;

define('PVB_CF7_CALCULATOR_PATH', dirname(dirname(__FILE__)));

class PVBCF7Calculator
{

    /**
     * Minimum Contact Form 7 version required
     */
    const CF7_VERSION_REQUIRED = '5.0';

    /**
     * Output extra debugging info
     */
    const DEBUG = false;

    /**
     * Unique ID string for plugin settings page
     * @since 1.0.6
     */
    const SETTINGS_PAGE = 'pvb_cf7_calculator_settings_general';

    /**
     * This plugin's current version
     */
    private $plugin_version;

    /**
     * @var WordPressSettingsFramework
     * @since 1.0.6
     */
    private $wpsf;

    /**
     * Class constructor
     *
     * @since 1.0.0
     *
     */
    public function __construct()
    {
        if (self::DEBUG) {
            error_reporting(E_ALL);
            ini_set('display_errors', 1);
        }

        add_action('init', array($this, 'init'));
        add_action('wpcf7_init', array($this,'cf7Init'), 20);
        add_action('wpcf7_admin_init', array($this, 'adminInit'), 60);
        add_action('admin_menu', array($this, 'settingsMenu'));

        // Set plugin version
        $plugin_data = get_file_data(
            PVB_CF7_CALCULATOR_PATH . '/pvb-cf7-calculator.php',
            array('Version' => 'Version'),
            false
        );
        $this->pluginVersion = $plugin_data['Version'];

        // Register settings
        $this->wpsf = new WordPressSettingsFramework(
            PVB_CF7_CALCULATOR_PATH . '/settings/settings-general.php',
            self::SETTINGS_PAGE
        );
    }

    /**
     * Initialize the plugin
     *
     * @since 1.0.0
     *
     */
    public function init()
    {
        load_plugin_textdomain('pvb-cf7-calculator', false, PVB_CF7_CALCULATOR_PATH . '/languages');

        add_filter(
            'plugin_action_links_' .
                plugin_basename(
                    PVB_CF7_CALCULATOR_PATH . '/pvb-cf7-calculator.php'
                ),
            array($this, 'pluginActionLinks')
        );

        if (!$this->checkCF7()) {
            add_action('admin_notices', array($this, 'notActiveNotice'));
        } elseif(!(defined('DISABLE_NAG_NOTICES') && DISABLE_NAG_NOTICES)) {
            add_action('admin_notices', array($this, 'proNotice'));
        }
    }

    /**
     * Sets up the form tags and hooks supported by this plugin
     *
     * @since 1.0.0
     *
     */
    public function cf7Init()
    {
        wpcf7_add_form_tag(
            array('calculation', 'calculation*'),
            array($this, 'calculationTagHandler'),
            true
        );
        wpcf7_add_form_tag(
            array('calculate_button'),
            array($this, 'calculateButtonTagHandler'),
            true
        );
        add_action(
            'wp_enqueue_scripts',
            array($this, 'enqueueScripts')
        );
        add_action(
            'admin_enqueue_scripts',
            array($this, 'enqueueAdminScripts')
        );
        add_action(
            'wp_ajax_pvb_calculate',
            array($this, 'ajaxCalculate')
        );
        add_action(
            'wp_ajax_nopriv_pvb_calculate',
            array($this, 'ajaxCalculate')
        );
        add_action(
            'wp_ajax_pvb_powered_by_opt_in',
            array($this, 'poweredByOptIn')
        );
        add_action(
            'wp_ajax_pvb_promo_pause',
            array($this, 'promoPause')
        );
        add_action(
            'wp_ajax_pvb_promo_disable',
            array($this, 'promoDisable')
        );

        if (wpSettingsFramework\wpsf_get_setting(
            self::SETTINGS_PAGE,
            'features',
            'show_powered_by'
        ) == 1) {
            add_filter(
                'wpcf7_form_elements',
                array($this, 'poweredByOutput')
            );
        }
        $this->interceptSubmit();
    }

    /**
     * Set up tag generators for the admin area
     *
     * @since 1.0.0
     *
     */
    public function adminInit()
    {
        if (class_exists('WPCF7_TagGenerator')) {
            $tag_generator = WPCF7_TagGenerator::get_instance();
            $tag_generator->add(
                'calculation',
                __('Calculation', 'pvb-cf7-calculator'),
                array($this, 'calculationTagGenerator')
            );
            $tag_generator->add(
                'calculate_button',
                __('Calculate button', 'pvb-cf7-calculator'),
                array($this, 'calculateButtonTagGenerator')
            );
        }
    }

    /**
     * Enqueue front-end javascript
     *
     * @since 1.0.0
     *
     */
    public function enqueueScripts()
    {

        // CSS
        wp_enqueue_style(
            'pvb-cf7-calculator',
            plugins_url(
                'css/pvb-cf7-calculator.css',
                dirname(__FILE__)
            )
        );
        
        wp_enqueue_script(
            'pvb-cf7-calculator',                                       // handle
            plugins_url('js/pvb-cf7-calculator.js', dirname(__FILE__)), // url
            array('jquery'),                                            // dependencies
            $this->plugin_version,                                      // version
            true                                                        // in footer
        );

        // Provide the script with an URL where form data should be sent for calculation
        wp_localize_script(
            'pvb-cf7-calculator',
            'frontend_ajax_object',
            array(
                'ajaxurl' => admin_url('admin-ajax.php'),
            )
        );
    }

    /**
     * Enqueue admin javascript
     *
     * @since 1.0.1
     *
     */
    public function enqueueAdminScripts()
    {
        wp_enqueue_script(
            'pvb-cf7-calculator-admin',                                       // handle
            plugins_url('js/pvb-cf7-calculator-admin.js', dirname(__FILE__)), // url
            array('jquery'),                                                  // dependencies
            $this->plugin_version,                                            // version
            true                                                              // in footer
        );
    }
    /**
     * Display a notice in the admin area if CF7 not installed, not active, or too old
     *
     * @since 1.0.0
     *
     */
    public function notActiveNotice()
    {
        $this->loadView('not-active-notice');
    }

    /**
     * Opt-in for a "Powered by:" link
     *
     * @since 1.0.1
     *
     */
    public function poweredByOptIn()
    {
        if (current_user_can('manage_options')) {
            $this->wpsfSetSetting(
                self::SETTINGS_PAGE,
                'features',
                'show_powered_by',
                1
            );
            wp_send_json(true);
        } else {
            wp_send_json(false);
        }
    }

    /**
     * Add "Settings" and "Support" links on Plugins page
     *
     * @since 1.0.6
     *
     */
    public function pluginActionLinks($links)
    {
        $settings_page_slug = sprintf(
            '%s-settings',
            str_replace('_', '-', self::SETTINGS_PAGE)
        );
        $links[] = '<a href="' .
            esc_url(menu_page_url($settings_page_slug, false)) .
            '">Settings</a>';
        $links[] = '<a href="https://wordpress.org/support/plugin/pvb-contact-form-7-calculator/"' .
            ' target="_blank">Support</a>';
        return $links;
    }

    /**
     * Filter that outputs "Powered by:" link (only if admin opted in)
     *
     * @since 1.0.1
     *
     */
    public function poweredByOutput($form_elements)
    {
        return $form_elements . '<p><small>Powered by <a href="' .
            'https://wordpress.org/plugins/pvb-contact-form-7-calculator/' .
            '" target="_blank">PVB Contact Form 7 Calculator</a>';
    }

    /**
     * Dismiss promotional notices in the admin area for 2 days
     *
     * @since 1.0.6
     *
     */
    public function promoPause()
    {
        $this->wpsfSetSetting(
            self::SETTINGS_PAGE,
            'features',
            'hide_promo_admin_notices',
            1
        );
        $this->wpsfSetSetting(
            self::SETTINGS_PAGE,
            'features',
            'hide_promo_admin_notices_until',
            date('Y-m-d', strtotime('+2 days'))
        );
        wp_send_json(true);
    }

    /**
     * Dismiss promotional notices in the admin area forever
     *
     * @since 1.0.6
     *
     */
    public function promoDisable()
    {
        $this->wpsfSetSetting(
            self::SETTINGS_PAGE,
            'features',
            'hide_promo_admin_notices',
            2
        );
        wp_send_json(true);
    }

    /**
     * Display a promotional notice in the admin area
     *
     * @since 1.0.0
     *
     */
    public function proNotice()
    {
        $hide_option = wpSettingsFramework\wpsf_get_setting(
            self::SETTINGS_PAGE,
            'features',
            'hide_promo_admin_notices'
        );

        if ($hide_option == 1 &&
            strtotime(
                wpSettingsFramework\wpsf_get_setting(
                    self::SETTINGS_PAGE,
                    'features',
                    'hide_promo_admin_notices_until'
                )
            ) > time())
        {
            // Notifications temporarily dismissed
            return;
        }
        if ($hide_option == 2) {
            // Notifications permanently dismissed
            return;
        }
        $notices = array('pro-notice', 'review-notice');
        if (current_user_can('manage_options') &&
            wpSettingsFramework\wpsf_get_setting(
                self::SETTINGS_PAGE,
                'features',
                'show_powered_by'
            ) != 1
        ) {
            $notices[] = 'powered-by-notice';
        }

        $settings_page_slug = sprintf(
            '%s-settings',
            str_replace('_', '-', self::SETTINGS_PAGE)
        );
        $settings_url = esc_url(menu_page_url($settings_page_slug, false));

        $view = $notices[intval(mt_rand(0, count($notices)-1))];
        $this->loadView($view, array('settings_url' => $settings_url));
    }

    /**
     * Add a settings page to the admin menu
     *
     * @since 1.0.6
     *
     */
    public function settingsMenu()
    {
        $this->wpsf->add_settings_page(array(
            'parent_slug' => 'wpcf7',
            'page_title' => __('Calculator Settings', 'pvb-cf7-calculator'),
            'menu_title' => __('Calculator Settings', 'pvb-cf7-calculator'),
            'capability' => 'manage_options'
        ));
    }

    /**
     * Display a dialog to generate a "calculation" field in the form
     *
     * @param WPCF7_ContactForm $contact_form
     * @param array $options
     * @since 1.0.0
     *
     */
    public function calculationTagGenerator($contact_form, $options)
    {
        $data = array(
            'args' => wp_parse_args($options, array()),
            'type' => 'calculation'
        );
        $this->loadView('tag-generator-calculation', $data);
    }

    /**
     * Process "calculation" form tags
     *
     * @param WPCF7_FormTag $tag
     * @return string
     * @since 1.0.0
     *
     */
    public function calculationTagHandler($tag)
    {
        static $called = false;
        $tag = new WPCF7_FormTag($tag);
        if (empty($tag->name) || $called) {
            return '';
        } else {
            $called = true;
        }

        $validation_error = wpcf7_get_validation_error($tag->name);

        $class = wpcf7_form_controls_class($tag->type, 'wpcf7-calculation');

        if ($validation_error) {
            $class .= ' wpcf7-not-valid';
        }

        $atts = array();

        $atts['size'] = $tag->get_size_option('40');
        $atts['maxlength'] = $tag->get_maxlength_option();
        $atts['minlength'] = $tag->get_minlength_option();

        if ($atts['maxlength'] && $atts['minlength'] && $atts['maxlength'] < $atts['minlength']) {
            unset($atts['maxlength'], $atts['minlength']);
        }

        $atts['class'] = $tag->get_class_option($class);

        $cf_label = false;

        if ($tag->has_option('cf7-hide')) {
            $atts['class'] .=" pvb-display-none";
        }
        
        $atts['class'] .= " cf7-calculation";
        $atts['id'] = $tag->get_id_option();
        $atts['tabindex'] = $tag->get_option('tabindex', 'int', true);

        $atts['readonly'] = 'readonly';


        if ($tag->is_required()) {
            $atts['aria-required'] = 'true';
        }

        $atts['aria-invalid'] = $validation_error ? 'true' : 'false';

        $value = (string) reset($tag->values);


        if ($tag->has_option('placeholder') || $tag->has_option('watermark')) {
            $atts['placeholder'] = $value;
            $value = '';
        }

        $value = $tag->get_default_option($value);

        $value = wpcf7_get_hangover($tag->name, $value);

        $scval = do_shortcode('['.$value.']');
        if ($scval != '['.$value.']') {
            $value = esc_attr($scval);
        }
        $atts['value'] = 0;

        $atts['type'] = 'text';

        $atts['name'] = $tag->name;

        $atts = wpcf7_format_atts($atts);

        $html = sprintf(
            '<span class="wpcf7-form-control-wrap %1$s"><input %2$s />%3$s</span>',
            sanitize_html_class($tag->name),
            $atts,
            $validation_error
        );
        
        return $html;
    }

    /**
     * Display a dialog to generate a "calculate" button in the form
     *
     * @param WPCF7_ContactForm $contact_form
     * @param array $options
     * @return string
     * @since 1.0.0
     *
     */
    public function calculateButtonTagGenerator($contact_form, $options)
    {
        $data = array(
            'args' => wp_parse_args($options, array()),
            'type' => 'calculate_button'
        );
        $this->loadView('tag-generator-calculate-button', $data);
    }

    /**
     * Process "calculate" button tags
     *
     * @param WPCF7_FormTag $tag
     * @return string
     * @since 1.0.0
     *
     */
    public function calculateButtonTagHandler($tag)
    {
        $class = wpcf7_form_controls_class($tag->type, 'wpcf7-calculate_button');

        $atts = array();

        $atts['class'] = $tag->get_class_option($class) . " cf7-calculate_button";
        $atts['id'] = $tag->get_id_option();
        $atts['tabindex'] = $tag->get_option('tabindex', 'signed_int', true);

        $value = isset($tag->values[0]) ? $tag->values[0] : '';

        if (empty($value)) {
            $value = __('Calculate', 'pvb-cf7-calculator');
        }

        $atts['type'] = 'button';
        $atts['value'] = $value;

        $atts = wpcf7_format_atts($atts);

        $html = sprintf('<input %1$s />', $atts);

        return $html;
    }

    /**
     * Hook for ajax requests. Sends POST values to the form calculator and outputs the results in JSON format.
     *
     * @since 1.0.0
     *
     */
    public function ajaxCalculate()
    {
        $r = array(); // Return values will be stored here
        $input = $_POST;
        if (!empty($input['pvb_form_id'])) {
            $form = WPCF7_ContactForm::get_instance($input['pvb_form_id']);
            if ($form !== false) {
                $r = $this->calculateForm($form, $input);
            }
        }
        wp_send_json($r);
    }

    /**
     * Calculate all "calculation" values for a given form
     *
     * @param WPCF7_ContactForm $form
     * @param array $input
     * @return array
     * @since 1.0.0
     *
     */
    public function calculateForm($form, $input)
    {
        $r = array(); // Return values will be stored here
        $tags = $form->scan_form_tags();
        foreach ($tags as $tag) {
            if (empty($tag['name'])) {
                continue;
            } elseif ($tag['basetype'] == 'calculation') {
                $options = $this->extractOptions($tag);
                $r[$tag['name']] = $this->calculateEquation($form, $tag['values'], $input, $options);
                $input[$tag['name']] = $r[$tag['name']];
                break;
            }
        }
        return $r;
    }

    /**
     * Processes POST fields and does the calculations before CF7 gets them
     *
     * @since 1.0.0
     *
     */
    public function interceptSubmit()
    {
        if (!empty($_POST['_wpcf7']) && empty($_POST['pvb_form_id'])) {
            $form = WPCF7_ContactForm::get_instance((int)$_POST['_wpcf7']);
            if ($form !== false) {
                $input = $_POST;
                $r = $this->calculateForm($form, $input);
                if (is_array($r) && !empty($r)) {
                    foreach ($r as $key => $value) {
                        $_POST[$key] = $value;
                    }
                }
            }
        }
    }

    /**
     * Extracts attributes (such as "min", "max" and "precision") from a CF7 tag
     *
     * @param WPCF7_FormTag $tag
     * @return array
     * @since 1.0.0
     *
     */
    private function extractOptions($tag)
    {
        $r = array();
        if ($tag['options']) {
            foreach ($tag['options'] as $opt) {
                $pieces = explode(":", $opt);
                if ($pieces > 1) {
                    $r[$pieces[0]] = $pieces[1];
                }
            }
        }
        return $r;
    }

    /**
     * Calculate the value of a "calculation" field based on user input
     *
     * @param WPCF7_ContactForm $form
     * @param string $values
     * @param array $input
     * @return float
     * @since 1.0.0
     *
     */
    private function calculateEquation($form, $values, $input, $options = array())
    {

        if (is_array($values)) {
            $values = implode(' ', $values);
        }

        if (empty($values) || empty($input)) {
            return 0;
        }

        $expression = $values;

        // Order input variables from longest to shortest names
        $keys = array_keys($input);

        // Handle checkbox groups with nothing selected
        $tags = $form->scan_form_tags();
        foreach ($tags as $tag) {
            if ($tag['basetype'] == 'checkbox') {
                if (!in_array($tag['name'], $keys)) {
                    $keys[] = $tag['name'];
                }
            }
        }

        usort($keys, array($this, 'sortByLengthHelper'));

        // Replace input variables in equation
        date_default_timezone_set('UTC');
        foreach ($keys as $key) {
            if (is_array($input[$key])) {
                // Only one value?
                if (count($input[$key]) == 1) {
                    $input[$key] = array_shift($input[$key]);    
                } else {
                    // Sum values
                    $sum = 0;
                    foreach ($input[$key] as $value) {
                        if (is_numeric($value)) {
                            $sum += $value;
                        }
                    }
                    $input[$key] = $sum;
                }
            }
            if (preg_match('/[0-9]{4}\-[0-9]{2}-[0-9]{2}/', $input[$key])) {
                // Date
                $days = intval(strtotime($input[$key])/86400);
                $expression = preg_replace(
                    '/(^|[^A-Za-z0-9])' . preg_quote($key) . '($|[^A-Za-z0-9])/',
                    '$1###RPLC###$2',
                    $expression
                );
                $expression = str_replace("###RPLC###", $days, $expression);
            } else {
                // Not date
                if (is_array($input[$key])) {
                    // Sum values (for checkboxes)
                    $num = array_sum($input[$key]);
                } elseif (is_numeric($input[$key])) {
                    $num = $input[$key];
                } else {
                    $num = 0;
                }
                $expression = preg_replace(
                    '/(^|[^A-Za-z0-9])' . preg_quote($key) . '($|[^A-Za-z0-9])/',
                    '$1###RPLC###$2',
                    $expression
                );
                $expression = str_replace("###RPLC###", $num, $expression);
            }
        }

        // Fix nested parentheses bug
        while (preg_match('/\(\s*\(/', $expression)) {
            $expression = preg_replace('/\(\s*\(/', '(1*(', $expression);
        }

        if (self::DEBUG) {
            echo("\nEvaluating expression: $expression");
        }

        // Calculate
        $calculator = PVBCalculator::create();
        try {
            $r = $calculator->calculate($expression);
        } catch (\Exception $e) {
            $r = __($e->getMessage(), 'pvb-cf7-calculator');
        }
        

        // Apply minimum
        if (isset($options['min'])) {
            $r = max($r, $options['min']);
        }

        // Apply maximum
        if (isset($options['max'])) {
            $r = min($r, $options['max']);
        }

        // Apply rounding
        if (isset($options['precision'])) {
            $r = round($r, $options['precision']);
        }

        return $r;
    }

    /**
     * Check if Contact Form 7 is active and its version is the one required by this plugin (or newer)
     *
     * @return boolean
     * @since 1.0.0
     *
     */
    private function checkCF7()
    {
        return defined('WPCF7_VERSION') ? version_compare(WPCF7_VERSION, self::CF7_VERSION_REQUIRED, '>=') : false;
    }

    /**
     * Load a view
     *
     * @param string $view Name of the file in the views subdirectory of the plugin.
     * @param array $data Arguments to make available to the view as PHP variables.
     * @since 1.0.0
     *
     */
    private function loadView($view, $data = array())
    {
        extract($data);
        $pluginVersion = $this->pluginVersion;
        include(PVB_CF7_CALCULATOR_PATH . '/views/' . $view . '.php');
    }

    /**
     *
     * @since 1.0.0
     *
     */
    private function sortByLengthHelper($a, $b)
    {
        return strlen($b)-strlen($a);
    }

    /**
     * Programmatically update a setting managed by
     * the WordPressSettingsFramework class
     *
     * @param string $option_group
     * @param string $section_id May also be prefixed with tab ID
     * @param string $field_id
     * @param mixed  $value
     * @since 1.0.6
     *
     */
    private function wpsfSetSetting(
        $option_group,
        $section_id,
        $field_id,
        $value
    ) {
        $options = get_option($option_group . '_settings');
        $options[$section_id . '_' . $field_id] = $value;
        update_option($option_group . '_settings', $options);
    }
}
