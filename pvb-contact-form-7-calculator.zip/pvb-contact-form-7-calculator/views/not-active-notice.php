<div class="notice notice-warning">
    <p>
        <?php printf(
            __(
                'Contact Form 7 Price Calculator requires Contact Form 7 version %s or newer to be installed ' .
                    'and active.',
                'pvb-cf7-calculator'
            ),
            self::CF7_VERSION_REQUIRED
        ); ?>
    </p>
</div>