<div class="notice notice-info">
    <p style="min-height:64px">
        <img src="<?php
        echo plugins_url('images/icon.png', dirname(__FILE__));
        ?>" style="float:left; margin-right: 1em; margin-bottom: 3em">
        <?php echo(__(
            'Care to support the development of PVB Contact Form 7 Calculator?' .
                ' Please consider enabling a small &quot;Powered By&quot; ' .
                ' notice on your contact forms with a link to our plugin on' .
                ' wordpress.org. You can always disable that from the' .
                ' <a href="' . $settings_url . '">Calculator Settings' .
                ' page</a> if you change your mind.',
            'pvb-cf7-calculator'
        )); ?><br>
        <a href="#"
            onclick="pvbCf7CalculatorPoweredByEnable(this, '<?php
            echo(__("Activating...", "pvb-cf7-calculator"));
            ?>', '<?php
            echo(__("Thank you!", "pvb-cf7-calculator"));
            ?>')">
            <?php echo(__('Activate link', 'pvb-cf7-calculator')); ?>
        </a>
        <br>
        <a href="#" onclick="pvbCf7CalculatorHideAdminNotices(1, this)">
            <?php echo(__('Remind me later', 'pvb-cf7-calculator')); ?>
        </a>
        <br>
        <a href="#" onclick="pvbCf7CalculatorHideAdminNotices(2, this)">
            <?php echo(__('Do not show this again', 'pvb-cf7-calculator')); ?>
        </a>
    </p>
</div>



