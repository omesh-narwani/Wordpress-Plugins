<div class="notice notice-info">
    <p style="min-height:64px">
        <img src="<?php
        echo plugins_url('images/icon.png', dirname(__FILE__));
        ?>" style="float:left; margin-right: 1em; margin-bottom: 3em">
        <?php printf(
            __(
                'How is your experience with PVB Contact Form 7 Calculator?
                    Please consider <a href="%s" target="_blank">
                    giving us a review on wordpress.org.</a>',
                'pvb-cf7-calculator'
            ),
            'https://wordpress.org/support/plugin/pvb-contact-form-7-calculator/reviews/'
        ); ?><br>
        <a href="https://wordpress.org/support/plugin/pvb-contact-form-7-calculator/reviews/">
            <?php echo(__('Review plugin', 'pvb-cf7-calculator')); ?>
        </a>
        <br>
        <a href="#" onclick="pvbCf7CalculatorHideAdminNotices(1, this)">
            <?php echo(__('Remind me later', 'pvb-cf7-calculator')); ?>
        </a>
        <br>
        <a href="#" onclick="pvbCf7CalculatorHideAdminNotices(2, this)">
            <?php echo(__('Do not show this again', 'pvb-cf7-calculator')); ?>
        </a>        
    </p>
</div>



