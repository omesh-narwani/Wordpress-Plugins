<?php if ( ! defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$settings = array(
	'menu_title'      => __( 'Settings', 'testimonial-pro' ),
	'menu_parent'     => 'edit.php?post_type=spt_testimonial',
	'menu_type'       => 'submenu', // menu, submenu, options, theme, etc.
	'menu_slug'       => 'tpro_settings',
	'ajax_save'       => true,
	'show_reset_all'  => false,
	'framework_title' => __( 'Testimonial Pro', 'testimonial-pro' ),
);

// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options = array();

// ----------------------------------------
// a option section for options overview  -
// ----------------------------------------
$options[] = array(
	'name'   => 'general_settings',
	'title'  => __( 'General', 'testimonial-pro' ),
	'icon'   => 'fa fa-cogs',

	// begin: fields
	'fields' => array(

		array(
			'id'         => 'testimonial_approval_status',
			'type'       => 'radio',
			'title'      => __( 'Testimonial Approval Status', 'testimonial-pro' ),
			'desc'       => __( 'Select testimonial approval status for the front-end form submission.', 'testimonial-pro' ),
			'options'    => array(
				'publish' => 'Auto Publish',
				'pending' => 'Pending',
			),
			'default'    => 'pending',
			'attributes' => array(
				'data-depend-id' => 'testimonial_approval_status',
			),
		),
		array(
			'type'       => 'notice',
			'class'      => 'warning',
			'content'    => __( 'Use this option at your own risk.', 'testimonial-pro' ),
			'dependency' => array( 'testimonial_approval_status', '==', 'publish' ),
		),

	), // end: fields
);


// ------------------------------
// FrontEnd Form Section   -
// ------------------------------
$options[] = array(
	'name'     => 'frontend_form',
	'title'    => __( 'Front-End Form', 'testimonial-pro' ),
	'icon'     => 'fa fa-list-alt',
	'sections' => array(


		// ---------------------
		// Fields
		// ---------------------
		array(
			'name'   => 'frontend_fields',
			'title'  => __( 'Fields', 'testimonial-pro' ),
			'icon'   => 'fa fa-list',

			// begin: fields
			'fields' => array(

				array(
					'type'       => 'notice',
					'class'      => 'front-end-shortcode',
					'content'    => __( 'Front-end submission form <div class="tpro-sc-code selectable">[testimonial_pro_form]</div>', 'testimonial-pro' ),
				),
				array(
					'type'    => 'subheading',
					'content' => __( 'Name', 'testimonial-pro' ),
				),
				array(
					'id'      => 'client_name_field',
					'type'    => 'switcher',
					'title'   => __( 'Name Field', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide name field.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'client_name_required',
					'type'       => 'checkbox',
					'title'      => __( 'Field Required?', 'testimonial-pro' ),
					'desc'       => __( 'Check to make the field required.', 'testimonial-pro' ),
					'default'    => true,
					'dependency' => array( 'client_name_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_name_label',
					'type'       => 'text',
					'title'      => __( 'Label', 'testimonial-pro' ),
					'desc'       => __( 'Type name field label.', 'testimonial-pro' ),
					'default'    => __( 'Your Name', 'testimonial-pro' ),
					'dependency' => array( 'client_name_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_name_placeholder',
					'type'       => 'text',
					'title'      => __( 'Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type name field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type your name', 'testimonial-pro' ),
					'dependency' => array( 'client_name_field', '==', 'true' ),
				),

				array(
					'type'    => 'subheading',
					'content' => __( 'Email Address', 'testimonial-pro' ),
				),
				array(
					'id'      => 'client_email_label',
					'type'    => 'text',
					'title'   => __( 'Email Address', 'testimonial-pro' ),
					'desc'    => __( 'Type email address field label.', 'testimonial-pro' ),
					'default' => __( 'Email Address', 'testimonial-pro' ),
				),
				array(
					'id'      => 'client_email_placeholder',
					'type'    => 'text',
					'title'   => __( 'Placeholder', 'testimonial-pro' ),
					'desc'    => __( 'Type email address field placeholder.', 'testimonial-pro' ),
					'default' => __( 'Type your email address', 'testimonial-pro' ),
				),

				array(
					'type'    => 'subheading',
					'content' => __( 'Identity or Position', 'testimonial-pro' ),
				),
				array(
					'id'      => 'client_designation_field',
					'type'    => 'switcher',
					'title'   => __( 'Identity or Position Field', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide identity or position field.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'client_designation_required',
					'type'       => 'checkbox',
					'title'      => __( 'Field Required?', 'testimonial-pro' ),
					'desc'       => __( 'Check to make the field required.', 'testimonial-pro' ),
					'default'    => false,
					'dependency' => array( 'client_designation_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_designation_label',
					'type'       => 'text',
					'title'      => __( 'Label', 'testimonial-pro' ),
					'desc'       => __( 'Type identity or position field label.', 'testimonial-pro' ),
					'default'    => __( 'Identity or Position', 'testimonial-pro' ),
					'dependency' => array( 'client_designation_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_designation_placeholder',
					'type'       => 'text',
					'title'      => __( 'Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type identity or position field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type your identity or position', 'testimonial-pro' ),
					'dependency' => array( 'client_designation_field', '==', 'true' ),
				),

				array(
					'type'    => 'subheading',
					'content' => __( 'Company Name', 'testimonial-pro' ),
				),
				array(
					'id'      => 'client_company_name_field',
					'type'    => 'switcher',
					'title'   => __( 'Company Name Field', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide company name field.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'client_company_name_required',
					'type'       => 'checkbox',
					'title'      => __( 'Field Required?', 'testimonial-pro' ),
					'desc'       => __( 'Check to make the field required.', 'testimonial-pro' ),
					'default'    => false,
					'dependency' => array( 'client_company_name_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_company_name_label',
					'type'       => 'text',
					'title'      => __( 'Label', 'testimonial-pro' ),
					'desc'       => __( 'Type company name field label.', 'testimonial-pro' ),
					'default'    => __( 'Company Name', 'testimonial-pro' ),
					'dependency' => array( 'client_company_name_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_company_name_placeholder',
					'type'       => 'text',
					'title'      => __( 'Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type company name field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type your company name', 'testimonial-pro' ),
					'dependency' => array( 'client_company_name_field', '==', 'true' ),
				),

				array(
					'type'    => 'subheading',
					'content' => __( 'Location', 'testimonial-pro' ),
				),
				array(
					'id'      => 'client_location_field',
					'type'    => 'switcher',
					'title'   => __( 'Location Field', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide location field.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'client_location_required',
					'type'       => 'checkbox',
					'title'      => __( 'Field Required?', 'testimonial-pro' ),
					'desc'       => __( 'Check to make the field required.', 'testimonial-pro' ),
					'default'    => false,
					'dependency' => array( 'client_location_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_location_label',
					'type'       => 'text',
					'title'      => __( 'Label', 'testimonial-pro' ),
					'desc'       => __( 'Type location field label.', 'testimonial-pro' ),
					'default'    => __( 'Location', 'testimonial-pro' ),
					'dependency' => array( 'client_location_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_location_placeholder',
					'type'       => 'text',
					'title'      => __( 'Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type location field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type your location', 'testimonial-pro' ),
					'dependency' => array( 'client_location_field', '==', 'true' ),
				),

				array(
					'type'    => 'subheading',
					'content' => __( 'Phone or Mobile', 'testimonial-pro' ),
				),
				array(
					'id'      => 'client_phone_field',
					'type'    => 'switcher',
					'title'   => __( 'Phone or Mobile Field', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide phone or mobile field.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'client_phone_required',
					'type'       => 'checkbox',
					'title'      => __( 'Field Required?', 'testimonial-pro' ),
					'desc'       => __( 'Check to make the field required.', 'testimonial-pro' ),
					'default'    => false,
					'dependency' => array( 'client_phone_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_phone_label',
					'type'       => 'text',
					'title'      => __( 'Label', 'testimonial-pro' ),
					'desc'       => __( 'Type phone or mobile field label.', 'testimonial-pro' ),
					'default'    => __( 'Phone or Mobile', 'testimonial-pro' ),
					'dependency' => array( 'client_phone_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_phone_placeholder',
					'type'       => 'text',
					'title'      => __( 'Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type phone or mobile field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type your phone or mobile', 'testimonial-pro' ),
					'dependency' => array( 'client_phone_field', '==', 'true' ),
				),

				array(
					'type'    => 'subheading',
					'content' => __( 'Website', 'testimonial-pro' ),
				),
				array(
					'id'      => 'client_website_field',
					'type'    => 'switcher',
					'title'   => __( 'Website Field', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide website field.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'client_website_required',
					'type'       => 'checkbox',
					'title'      => __( 'Field Required?', 'testimonial-pro' ),
					'desc'       => __( 'Check to make the field required.', 'testimonial-pro' ),
					'default'    => false,
					'dependency' => array( 'client_website_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_website_label',
					'type'       => 'text',
					'title'      => __( 'Label', 'testimonial-pro' ),
					'desc'       => __( 'Type website field label.', 'testimonial-pro' ),
					'default'    => __( 'Website', 'testimonial-pro' ),
					'dependency' => array( 'client_website_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_website_placeholder',
					'type'       => 'text',
					'title'      => __( 'Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type website field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type your website', 'testimonial-pro' ),
					'dependency' => array( 'client_website_field', '==', 'true' ),
				),

				array(
					'type'    => 'subheading',
					'content' => __( 'Video Testimonial URL', 'testimonial-pro' ),
				),
				array(
					'id'      => 'client_video_url_field',
					'type'    => 'switcher',
					'title'   => __( 'Video URL Field', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide video url field.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'client_video_url_required',
					'type'       => 'checkbox',
					'title'      => __( 'Field Required?', 'testimonial-pro' ),
					'desc'       => __( 'Check to make the field required.', 'testimonial-pro' ),
					'default'    => false,
					'dependency' => array( 'client_video_url_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_video_url_label',
					'type'       => 'text',
					'title'      => __( 'Label', 'testimonial-pro' ),
					'desc'       => __( 'Type video url field label.', 'testimonial-pro' ),
					'default'    => __( 'Video URL', 'testimonial-pro' ),
					'dependency' => array( 'client_video_url_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_video_url_placeholder',
					'type'       => 'text',
					'title'      => __( 'Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type video url field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type your video url', 'testimonial-pro' ),
					'dependency' => array( 'client_video_url_field', '==', 'true' ),
				),

				array(
					'type'    => 'subheading',
					'content' => __( 'Image', 'testimonial-pro' ),
				),
				array(
					'id'      => 'client_image_field',
					'type'    => 'switcher',
					'title'   => __( 'Image Field', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide image field.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'client_image_required',
					'type'       => 'checkbox',
					'title'      => __( 'Field Required?', 'testimonial-pro' ),
					'desc'       => __( 'Check to make the field required.', 'testimonial-pro' ),
					'default'    => false,
					'dependency' => array( 'client_image_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_image_label',
					'type'       => 'text',
					'title'      => __( 'Label', 'testimonial-pro' ),
					'desc'       => __( 'Type image field label.', 'testimonial-pro' ),
					'default'    => __( 'Image', 'testimonial-pro' ),
					'dependency' => array( 'client_image_field', '==', 'true' ),
				),

				array(
					'type'    => 'subheading',
					'content' => __( 'Category', 'testimonial-pro' ),
				),
				array(
					'id'      => 'client_category_field',
					'type'    => 'switcher',
					'title'   => __( 'Category Field', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide category field.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'client_category_required',
					'type'       => 'checkbox',
					'title'      => __( 'Field Required?', 'testimonial-pro' ),
					'desc'       => __( 'Check to make the field required.', 'testimonial-pro' ),
					'default'    => false,
					'dependency' => array( 'client_category_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_category_multiple',
					'type'       => 'checkbox',
					'title'      => __( 'Multiple Category Selection?', 'testimonial-pro' ),
					'desc'       => __( 'Let user select multiple categories.', 'testimonial-pro' ),
					'default'    => true,
					'dependency' => array( 'client_category_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_category_label',
					'type'       => 'text',
					'title'      => __( 'Label', 'testimonial-pro' ),
					'desc'       => __( 'Type category field label.', 'testimonial-pro' ),
					'default'    => __( 'Category', 'testimonial-pro' ),
					'dependency' => array( 'client_category_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_category_placeholder',
					'type'       => 'text',
					'title'      => __( 'Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type category field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Select category', 'testimonial-pro' ),
					'dependency' => array( 'client_category_field', '==', 'true' ),
				),

				array(
					'id'         => 'client_selected_category',
					'type'       => 'select',
					'title'      => __( 'Select Category(s)', 'post-carousel-pro' ),
					'desc'       => __( 'Select categories for the frontend form. Leave blank for the all categories.', 'post-carousel-pro' ),
					'options'    => 'categories',
					'query_args' => array(
						'type'       => 'spt_testimonial',
						'taxonomy'   => 'testimonial_cat',
						'hide_empty' => 0,
					),
					'attributes' => array(
						'multiple'    => 'multiple',
						'placeholder' => __( 'Select Category', 'post-carousel-pro' ),
						'style'       => 'width: 321px;'
					),
					'class'      => 'chosen',
					'dependency' => array( 'client_category_field', '==', 'true' ),

				),

				array(
					'type'    => 'subheading',
					'content' => __( 'Testimonial Title', 'testimonial-pro' ),
				),
				array(
					'id'      => 'client_title_field',
					'type'    => 'switcher',
					'title'   => __( 'Title Field', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide title field.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'client_title_required',
					'type'       => 'checkbox',
					'title'      => __( 'Field Required?', 'testimonial-pro' ),
					'desc'       => __( 'Check to make the field required.', 'testimonial-pro' ),
					'default'    => false,
					'dependency' => array( 'client_title_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_title_label',
					'type'       => 'text',
					'title'      => __( 'Label', 'testimonial-pro' ),
					'desc'       => __( 'Type title field label.', 'testimonial-pro' ),
					'default'    => __( 'Title', 'testimonial-pro' ),
					'dependency' => array( 'client_title_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_title_placeholder',
					'type'       => 'text',
					'title'      => __( 'Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type title field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type title', 'testimonial-pro' ),
					'dependency' => array( 'client_title_field', '==', 'true' ),
				),

				array(
					'type'    => 'subheading',
					'content' => __( 'Testimonial Content', 'testimonial-pro' ),
				),
				array(
					'id'      => 'client_testimonial_field',
					'type'    => 'switcher',
					'title'   => __( 'Testimonial Field', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide testimonial field.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'client_testimonial_required',
					'type'       => 'checkbox',
					'title'      => __( 'Field Required?', 'testimonial-pro' ),
					'desc'       => __( 'Check to make the field required.', 'testimonial-pro' ),
					'default'    => false,
					'dependency' => array( 'client_testimonial_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_testimonial_label',
					'type'       => 'text',
					'title'      => __( 'Label', 'testimonial-pro' ),
					'desc'       => __( 'Type testimonial field label.', 'testimonial-pro' ),
					'default'    => __( 'Testimonial', 'testimonial-pro' ),
					'dependency' => array( 'client_testimonial_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_testimonial_placeholder',
					'type'       => 'text',
					'title'      => __( 'Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type testimonial field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type testimonial', 'testimonial-pro' ),
					'dependency' => array( 'client_testimonial_field', '==', 'true' ),
				),

				array(
					'type'    => 'subheading',
					'content' => __( 'Star Rating', 'testimonial-pro' ),
				),
				array(
					'id'      => 'client_rating_field',
					'type'    => 'switcher',
					'title'   => __( 'Rating Field', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide rating field.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'client_rating_label',
					'type'       => 'text',
					'title'      => __( 'Label', 'testimonial-pro' ),
					'desc'       => __( 'Type rating field label.', 'testimonial-pro' ),
					'default'    => __( 'Rating', 'testimonial-pro' ),
					'dependency' => array( 'client_rating_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_rating_one',
					'type'       => 'text',
					'title'      => __( 'One Star Title', 'testimonial-pro' ),
					'desc'       => __( 'Set one star title.', 'testimonial-pro' ),
					'default'    => __( 'One Star', 'testimonial-pro' ),
					'dependency' => array( 'client_rating_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_rating_two',
					'type'       => 'text',
					'title'      => __( 'Two Star Title', 'testimonial-pro' ),
					'desc'       => __( 'Set two star title.', 'testimonial-pro' ),
					'default'    => __( 'Two Stars', 'testimonial-pro' ),
					'dependency' => array( 'client_rating_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_rating_three',
					'type'       => 'text',
					'title'      => __( 'Three Star Title', 'testimonial-pro' ),
					'desc'       => __( 'Set three star title.', 'testimonial-pro' ),
					'default'    => __( 'Three Stars', 'testimonial-pro' ),
					'dependency' => array( 'client_rating_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_rating_four',
					'type'       => 'text',
					'title'      => __( 'Four Star Title', 'testimonial-pro' ),
					'desc'       => __( 'Set four star title.', 'testimonial-pro' ),
					'default'    => __( 'Four Stars', 'testimonial-pro' ),
					'dependency' => array( 'client_rating_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_rating_five',
					'type'       => 'text',
					'title'      => __( 'Five Star Title', 'testimonial-pro' ),
					'desc'       => __( 'Set five star title.', 'testimonial-pro' ),
					'default'    => __( 'Five Stars', 'testimonial-pro' ),
					'dependency' => array( 'client_rating_field', '==', 'true' ),
				),

				array(
					'type'    => 'subheading',
					'content' => __( 'Social Profiles', 'testimonial-pro' ),
				),
				array(
					'id'      => 'client_social_profile_field',
					'type'    => 'switcher',
					'title'   => __( 'Social Profiles Field', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide social profiles field.', 'testimonial-pro' ),
					'default' => false,
				),
				array(
					'id'         => 'client_social_profile_label',
					'type'       => 'text',
					'title'      => __( 'Label', 'testimonial-pro' ),
					'desc'       => __( 'Type social profiles field label.', 'testimonial-pro' ),
					'default'    => __( 'Add Social Profiles', 'testimonial-pro' ),
					'dependency' => array( 'client_social_profile_field', '==', 'true' ),
				),
				array(
					'id'      => 'client_social_profile_facebook',
					'type'    => 'switcher',
					'title'   => __( 'Facebook', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide facebook field.', 'testimonial-pro' ),
					'default' => true,
					'dependency' => array( 'client_social_profile_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_social_profile_facebook_label',
					'type'       => 'text',
					'title'      => __( 'Facebook Label', 'testimonial-pro' ),
					'desc'       => __( 'Type facebook field label.', 'testimonial-pro' ),
					'default'    => __( 'Facebook', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_facebook',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'         => 'client_social_profile_facebook_placeholder',
					'type'       => 'text',
					'title'      => __( 'Facebook Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type facebook field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type facebook URL', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_facebook',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'      => 'client_social_profile_twitter',
					'type'    => 'switcher',
					'title'   => __( 'Twitter', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide twitter field.', 'testimonial-pro' ),
					'default' => true,
					'dependency' => array( 'client_social_profile_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_social_profile_twitter_label',
					'type'       => 'text',
					'title'      => __( 'Twitter Label', 'testimonial-pro' ),
					'desc'       => __( 'Type twitter field label.', 'testimonial-pro' ),
					'default'    => __( 'Twitter', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_twitter',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'         => 'client_social_profile_twitter_placeholder',
					'type'       => 'text',
					'title'      => __( 'Twitter Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type twitter field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type twitter URL', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_twitter',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'      => 'client_social_profile_google_plus',
					'type'    => 'switcher',
					'title'   => __( 'Google Plus', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide google plus field.', 'testimonial-pro' ),
					'default' => true,
					'dependency' => array( 'client_social_profile_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_social_profile_google_plus_label',
					'type'       => 'text',
					'title'      => __( 'Google Plus Label', 'testimonial-pro' ),
					'desc'       => __( 'Type google plus field label.', 'testimonial-pro' ),
					'default'    => __( 'Google Plus', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_google_plus',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'         => 'client_social_profile_google_plus_placeholder',
					'type'       => 'text',
					'title'      => __( 'Google Plus Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type google plus field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type google plus URL', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_google_plus',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'      => 'client_social_profile_linkedin',
					'type'    => 'switcher',
					'title'   => __( 'LinkedIn', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide linkedin field.', 'testimonial-pro' ),
					'default' => true,
					'dependency' => array( 'client_social_profile_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_social_profile_linkedin_label',
					'type'       => 'text',
					'title'      => __( 'LinkedIn Label', 'testimonial-pro' ),
					'desc'       => __( 'Type linkedin field label.', 'testimonial-pro' ),
					'default'    => __( 'LinkedIn', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_linkedin',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'         => 'client_social_profile_linkedin_placeholder',
					'type'       => 'text',
					'title'      => __( 'LinkedIn Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type linkedin field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type linkedin URL', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_linkedin',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'      => 'client_social_profile_instagram',
					'type'    => 'switcher',
					'title'   => __( 'Instagram', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide instagram field.', 'testimonial-pro' ),
					'default' => true,
					'dependency' => array( 'client_social_profile_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_social_profile_instagram_label',
					'type'       => 'text',
					'title'      => __( 'Instagram Label', 'testimonial-pro' ),
					'desc'       => __( 'Type instagram field label.', 'testimonial-pro' ),
					'default'    => __( 'Instagram', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_instagram',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'         => 'client_social_profile_instagram_placeholder',
					'type'       => 'text',
					'title'      => __( 'Instagram Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type instagram field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type instagram URL', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_instagram',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'      => 'client_social_profile_youtube',
					'type'    => 'switcher',
					'title'   => __( 'YouTube', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide youtube field.', 'testimonial-pro' ),
					'default' => false,
					'dependency' => array( 'client_social_profile_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_social_profile_youtube_label',
					'type'       => 'text',
					'title'      => __( 'YouTube Label', 'testimonial-pro' ),
					'desc'       => __( 'Type youtube field label.', 'testimonial-pro' ),
					'default'    => __( 'YouTube', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_youtube',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'         => 'client_social_profile_youtube_placeholder',
					'type'       => 'text',
					'title'      => __( 'YouTube Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type youtube field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type youtube URL', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_youtube',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'      => 'client_social_profile_pinterest',
					'type'    => 'switcher',
					'title'   => __( 'Pinterest', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide pinterest field.', 'testimonial-pro' ),
					'default' => false,
					'dependency' => array( 'client_social_profile_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_social_profile_pinterest_label',
					'type'       => 'text',
					'title'      => __( 'Pinterest Label', 'testimonial-pro' ),
					'desc'       => __( 'Type pinterest field label.', 'testimonial-pro' ),
					'default'    => __( 'Pinterest', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_pinterest',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'         => 'client_social_profile_pinterest_placeholder',
					'type'       => 'text',
					'title'      => __( 'Pinterest Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type pinterest field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type pinterest URL', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_pinterest',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'      => 'client_social_profile_skype',
					'type'    => 'switcher',
					'title'   => __( 'Skype', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide skype field.', 'testimonial-pro' ),
					'default' => false,
					'dependency' => array( 'client_social_profile_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_social_profile_skype_label',
					'type'       => 'text',
					'title'      => __( 'Skype Label', 'testimonial-pro' ),
					'desc'       => __( 'Type skype field label.', 'testimonial-pro' ),
					'default'    => __( 'Skype', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_skype',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'         => 'client_social_profile_skype_placeholder',
					'type'       => 'text',
					'title'      => __( 'Skype Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type skype field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type skype URL', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_skype',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'      => 'client_social_profile_stumbleupon',
					'type'    => 'switcher',
					'title'   => __( 'StumbleUpon', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide stumbleupon field.', 'testimonial-pro' ),
					'default' => false,
					'dependency' => array( 'client_social_profile_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_social_profile_stumbleupon_label',
					'type'       => 'text',
					'title'      => __( 'StumbleUpon Label', 'testimonial-pro' ),
					'desc'       => __( 'Type stumbleupon field label.', 'testimonial-pro' ),
					'default'    => __( 'StumbleUpon', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_stumbleupon',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'         => 'client_social_profile_stumbleupon_placeholder',
					'type'       => 'text',
					'title'      => __( 'StumbleUpon Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type stumbleupon field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type stumbleupon URL', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_stumbleupon',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'      => 'client_social_profile_reddit',
					'type'    => 'switcher',
					'title'   => __( 'Reddit', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide reddit field.', 'testimonial-pro' ),
					'default' => false,
					'dependency' => array( 'client_social_profile_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_social_profile_reddit_label',
					'type'       => 'text',
					'title'      => __( 'Reddit Label', 'testimonial-pro' ),
					'desc'       => __( 'Type reddit field label.', 'testimonial-pro' ),
					'default'    => __( 'Reddit', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_reddit',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'         => 'client_social_profile_reddit_placeholder',
					'type'       => 'text',
					'title'      => __( 'Reddit Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type reddit field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type reddit URL', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_reddit',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'      => 'client_social_profile_dribbble',
					'type'    => 'switcher',
					'title'   => __( 'Dribbble', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide dribbble field.', 'testimonial-pro' ),
					'default' => false,
					'dependency' => array( 'client_social_profile_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_social_profile_dribbble_label',
					'type'       => 'text',
					'title'      => __( 'Dribbble Label', 'testimonial-pro' ),
					'desc'       => __( 'Type dribbble field label.', 'testimonial-pro' ),
					'default'    => __( 'Dribbble', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_dribbble',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'         => 'client_social_profile_dribbble_placeholder',
					'type'       => 'text',
					'title'      => __( 'Dribbble Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type dribbble field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type dribbble URL', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_dribbble',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'      => 'client_social_profile_snapchat',
					'type'    => 'switcher',
					'title'   => __( 'SnapChat', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide snapchat field.', 'testimonial-pro' ),
					'default' => false,
					'dependency' => array( 'client_social_profile_field', '==', 'true' ),
				),
				array(
					'id'         => 'client_social_profile_snapchat_label',
					'type'       => 'text',
					'title'      => __( 'SnapChat Label', 'testimonial-pro' ),
					'desc'       => __( 'Type snapchat field label.', 'testimonial-pro' ),
					'default'    => __( 'SnapChat', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_snapchat',
						'==|==',
						'true|true'
					),
				),
				array(
					'id'         => 'client_social_profile_snapchat_placeholder',
					'type'       => 'text',
					'title'      => __( 'SnapChat Placeholder', 'testimonial-pro' ),
					'desc'       => __( 'Type snapchat field placeholder.', 'testimonial-pro' ),
					'default'    => __( 'Type snapchat URL', 'testimonial-pro' ),
					'dependency' => array(
						'client_social_profile_field|client_social_profile_snapchat',
						'==|==',
						'true|true'
					),
				),

				array(
					'type'    => 'subheading',
					'content' => __( 'Submit Button', 'testimonial-pro' ),
				),
				array(
					'id'      => 'submit_button_text',
					'type'    => 'text',
					'title'   => __( 'Submit Button Text', 'testimonial-pro' ),
					'desc'    => __( 'Type submit button text.', 'testimonial-pro' ),
					'default' => __( 'Submit Testimonial', 'testimonial-pro' ),
				),

			),
		),

		// ---------------------
		// Fields Sorter
		// ---------------------
		array(
			'name'   => 'fields_sorter',
			'title'  => __( 'Fields Sorter', 'testimonial-pro' ),
			'icon'   => 'fa fa-sort-alpha-desc',

			// begin: fields
			'fields' => array(

				array(
					'type'       => 'notice',
					'class'      => 'front-end-shortcode',
					'content'    => __( 'Front-end submission form <div class="tpro-sc-code selectable">[testimonial_pro_form]</div>', 'testimonial-pro' ),
				),

				array(
					'id'             => 'fields_sorter',
					'type'           => 'sorter',
					'title'          => __( 'Fields Sorter', 'testimonial-pro' ),
					'default'        => array(
						'enabled' => array(
							'name'         => __( 'Name', 'testimonial-pro' ),
							'email'        => __( 'Email Address', 'testimonial-pro' ),
							'designation'  => __( 'Identity or Position', 'testimonial-pro' ),
							'company_name' => __( 'Company Name', 'testimonial-pro' ),
							'location'     => __( 'Location', 'testimonial-pro' ),
							'phone'        => __( 'Phone or Mobile', 'testimonial-pro' ),
							'website'      => __( 'Website', 'testimonial-pro' ),
							'video-url'    => __( 'Video Testimonial URL', 'testimonial-pro' ),
							'image'        => __( 'Image', 'testimonial-pro' ),
							'category'     => __( 'Category', 'testimonial-pro' ),
							'title'        => __( 'Testimonial Title', 'testimonial-pro' ),
							'testimonial'  => __( 'Testimonial Content', 'testimonial-pro' ),
							'rating'       => __( 'Rating', 'testimonial-pro' ),
							'social-profile'  => __( 'Social Profiles', 'testimonial-pro' ),
						),
					),
					'enabled_title'  => '',
					'disabled_title' => '',
				),

			),
		),

		// ---------------------
		// Google reCAPTCHA
		// ---------------------
		array(
			'name'   => 'google_recaptcha',
			'title'  => __( 'reCAPTCHA', 'testimonial-pro' ),
			'icon'   => 'fa fa-shield',

			// begin: fields
			'fields' => array(

				array(
					'type'       => 'notice',
					'class'      => 'front-end-shortcode',
					'content'    => __( 'Front-end submission form <div class="tpro-sc-code selectable">[testimonial_pro_form]</div>', 'testimonial-pro' ),
				),

				array(
					'id'      => 'google_recaptcha',
					'type'    => 'switcher',
					'title'   => __( 'reCaptcha', 'testimonial-pro' ),
					'desc'   => __( 'Enable/Disable reCaptcha for the front-end form.', 'testimonial-pro' ),
					'default' => false,
				),
				array(
					'type'       => 'notice',
					'class'      => 'info',
					'content'    => __( '<a href="https://www.google.com/recaptcha" target="_blank">reCAPTCHA</a> is a free anti-spam service of Google that protects your website from spam and abuse. <a 
href="https://www.google.com/recaptcha/admin#list" target="_blank"> Get your API Keys</a>.', 'testimonial-pro' ),
					'dependency' => array( 'google_recaptcha', '==', 'true' ),
				),
				array(
					'id'         => 'captcha_site_key',
					'type'       => 'text',
					'title'      => __( 'Site key', 'testimonial-pro' ),
					'desc'       => __( 'Set Site key.', 'testimonial-pro' ),
					'dependency' => array( 'google_recaptcha', '==', 'true' ),
				),
				array(
					'id'         => 'captcha_secret_key',
					'type'       => 'text',
					'title'      => __( 'Secret key', 'testimonial-pro' ),
					'desc'       => __( 'Set Secret key.', 'testimonial-pro' ),
					'dependency' => array( 'google_recaptcha', '==', 'true' ),
				),

			),
		),

		// ---------------------
		// Messages
		// ---------------------
		array(
			'name'   => 'messages_text',
			'title'  => __( 'Messages', 'testimonial-pro' ),
			'icon'   => 'fa fa-exclamation-triangle',

			// begin: fields
			'fields' => array(

				array(
					'type'       => 'notice',
					'class'      => 'front-end-shortcode',
					'content'    => __( 'Front-end submission form <div class="tpro-sc-code selectable">[testimonial_pro_form]</div>', 'testimonial-pro' ),
				),

				array(
					'id'      => 'successful_message',
					'type'    => 'text',
					'title'   => __( 'Successful Message', 'testimonial-pro' ),
					'desc'    => __( 'Notification for successful submission.', 'testimonial-pro' ),
					'default' => 'Thank you for submitting a new testimonial!',
				),

				array(
					'id'         => 'verification_fail_message',
					'type'       => 'text',
					'title'      => __( 'Robot Verification Fail', 'testimonial-pro' ),
					'desc'       => __( 'Notification for robot verification fail.', 'testimonial-pro' ),
					'default'    => 'Robot verification failed, please try again.',
					'dependency' => array( 'google_recaptcha', '==', 'true' ),
				),

				array(
					'id'         => 'captcha_missing_message',
					'type'       => 'text',
					'title'      => __( 'reCAPTCHA missing', 'testimonial-pro' ),
					'desc'       => __( 'Notification for reCAPTCHA missing.', 'testimonial-pro' ),
					'default'    => 'Please click on the reCAPTCHA box.',
					'dependency' => array( 'google_recaptcha', '==', 'true' ),
				),

			),
		),

		// ---------------------
		// Stylization
		// ---------------------
		array(
			'name'   => 'stylization',
			'title'  => __( 'Stylization', 'testimonial-pro' ),
			'icon'   => 'fa fa-paint-brush',

			// begin: fields
			'fields' => array(

				array(
					'type'       => 'notice',
					'class'      => 'front-end-shortcode',
					'content'    => __( 'Front-end submission form <div class="tpro-sc-code selectable">[testimonial_pro_form]</div>', 'testimonial-pro' ),
				),

				array(
					'id'      => 'label_text_color',
					'type'    => 'color_picker',
					'title'   => __( 'Label Color', 'testimonial-pro' ),
					'desc'    => __( 'Set color for the field label.', 'testimonial-pro' ),
					'default' => '#444444',
				),
				array(
					'id'      => 'submit_button_color',
					'type'    => 'color_picker',
					'title'   => __( 'Submit Button Color', 'testimonial-pro' ),
					'desc'    => __( 'Set color for the submit button text.', 'testimonial-pro' ),
					'default' => '#ffffff',
				),
				array(
					'id'      => 'submit_button_bg',
					'type'    => 'color_picker',
					'title'   => __( 'Submit Button Background', 'testimonial-pro' ),
					'desc'    => __( 'Set background color for the submit button.', 'testimonial-pro' ),
					'default' => '#444444',
				),

			),
		),

	)
);

// ------------------------------
// Notification                   -
// ------------------------------
$options[] = array(
	'name'   => 'notification_section',
	'title'  => __( 'Notification', 'testimonial-pro' ),
	'icon'   => 'fa fa-bell',
	'fields' => array(
		array(
			'type'       => 'notice',
			'class'      => 'danger',
			'content'    => __( '<b>Testimonial Approval Status</b> is set to "Auto Publish", set it to "Pending" for enabling <b>Pending Testimonial 
Email </b>option.', 'testimonial-pro' ),
			'dependency' => array( 'testimonial_approval_status', '==', 'publish' ),
		),
		array(
			'id'      => 'pending_testimonial_email',
			'type'    => 'switcher',
			'title'   => __( 'Pending Testimonial Email', 'testimonial-pro' ),
			'desc'   => __( 'Email notification for pending testimonial.', 'testimonial-pro' ),
			'default' => true,
		),
		array(
			'id'         => 'pending_testimonial_subject',
			'type'       => 'text',
			'title'      => __( 'Notification Email Subject', 'testimonial-pro' ),
			'desc'       => __( 'Type subject for the notification email.', 'testimonial-pro' ),
			'default'    => 'A New Testimonial is Pending!',
			'dependency' => array( 'pending_testimonial_email', '==', 'true' ),
		),
		array(
			'id'         => 'pending_testimonial_heading',
			'type'       => 'text',
			'title'      => __( 'Notification Email Heading', 'testimonial-pro' ),
			'desc'       => __( 'Type heading for the notification email.', 'testimonial-pro' ),
			'default'    => 'New Testimonial!',
			'dependency' => array( 'pending_testimonial_email', '==', 'true' ),
		),
		array(
			'id'         => 'pending_testimonial_message',
			'type'       => 'wysiwyg',
			'title'      => __( 'Notification Email Body', 'testimonial-pro' ),
			'default'    => 'Hey There,

A new testimonial has been submitted to your website. Following are the reviewer information.

Name: {name}
Email: {email}
Testimonial Content: {testimonial_text}
Rating: {rating}

Please go admin dashboard to review it and publish.

Thank you!',
			'after'      => '<br>
			Enter the text that will be sent as notification email for pending testimonial. HTML is accepted. Available template tags are:<br>
			{name} - The reviewer\'s full name.<br>
			{email} - The reviewer\'s email address.<br>
			{position} - The reviewer\'s position.<br>
			{company_name} - The reviewer\'s company name.<br>
			{location} - The reviewer\'s location address.<br>
			{phone} - The reviewer\'s phone number.<br>
			{website} - The reviewer\'s company website URL.<br>
			{video_url} - The reviewer\'s video URL.<br>
			{testimonial_title} - Testimonial top title.<br>
			{testimonial_text} - Testimonial content.<br>
			{category} - Testimonial category.<br>
			{rating} - Testimonial Star Rating.',
			'dependency' => array( 'pending_testimonial_email', '==', 'true' ),
		),
		array(
			'id'         => 'pending_testimonial_email_to',
			'type'       => 'textarea',
			'title'      => __( 'Email(s) to Notify', 'testimonial-pro' ),
			'after'      => __( '<br>Enter the email address(es) that will receive a notification for each pending testimonial. For multiple emails, use comma between these.', 'testimonial-pro' ),
			'default'    => get_option( 'admin_email' ),
			'dependency' => array( 'pending_testimonial_email', '==', 'true' ),
		),

	)
);

// ------------------------------
// Custom CSS                   -
// ------------------------------
$options[] = array(
	'name'   => 'custom_css_section',
	'title'  => __( 'Custom CSS', 'testimonial-pro' ),
	'icon'   => 'fa fa-css3',
	'fields' => array(

		array(
			'id'    => 'custom_css',
			'type'  => 'textarea',
			'title' => __( 'Custom CSS', 'testimonial-pro' ),
			'desc'  => __( 'Type your css.', 'testimonial-pro' ),
		),

	)
);


SP_TPRO_Framework::instance( $settings, $options );