<?php if ( ! defined( 'ABSPATH' ) ) {
	die;
}
// Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// METABOX OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options = array();

// -----------------------------------------
// Shortcode Generator Options
// -----------------------------------------
$options[] = array(
	'id'        => 'sp_tpro_shortcode_options',
	'title'     => __( 'Shortcode Options', 'testimonial-pro' ),
	'post_type' => 'sp_tpro_shortcodes',
	'context'   => 'normal',
	'priority'  => 'default',
	'sections'  => array(

		// begin: a section
		array(
			'name'   => 'sp_tpro_shortcode_option_1',
			'title'  => __( 'General Settings', 'testimonial-pro' ),
			'icon'   => 'fa fa-wrench',

			// begin: fields
			'fields' => array(

				// begin: a field
				array(
					'id'      => 'layout',
					'type'    => 'select',
					'title'   => __( 'Layout', 'testimonial-pro' ),
					'desc'    => __( 'Select a layout to display the testimonials.', 'testimonial-pro' ),
					'options' => array(
						'slider'         => __( 'Slider', 'testimonial-pro' ),
						'grid'           => __( 'Grid', 'testimonial-pro' ),
						'masonry'        => __( 'Masonry', 'testimonial-pro' ),
						'list'           => __( 'List', 'testimonial-pro' ),
						'filter_grid'    => __( 'Filter (Grid)', 'testimonial-pro' ),
						'filter_masonry' => __( 'Filter (Masonry)', 'testimonial-pro' ),
					),
					'default' => 'slider',
					'class'   => 'chosen',
				),
				array(
					'type'       => 'notice',
					'class'      => 'info',
					'content'    => __( 'Please select (Display Testimonials from: Taxonomy).', 'testimonial-pro' ),
					'dependency' => array(
						'layout',
						'any',
						'filter_grid,filter_masonry'
					),
				),
				array(
					'id'      => 'theme_style',
					'type'    => 'select',
					'title'   => __( 'Select Theme', 'testimonial-pro' ),
					'desc'    => __( 'Select which theme you want to display.', 'testimonial-pro' ),
					'options' => array(
						'theme-one'   => __( 'Theme One', 'testimonial-pro' ),
						'theme-two'   => __( 'Theme Two', 'testimonial-pro' ),
						'theme-three' => __( 'Theme Three', 'testimonial-pro' ),
						'theme-four'  => __( 'Theme Four', 'testimonial-pro' ),
						'theme-five'  => __( 'Theme Five', 'testimonial-pro' ),
						'theme-six'   => __( 'Theme Six', 'testimonial-pro' ),
						'theme-seven' => __( 'Theme Seven', 'testimonial-pro' ),
						'theme-eight' => __( 'Theme Eight', 'testimonial-pro' ),
						'theme-nine'  => __( 'Theme Nine', 'testimonial-pro' ),
						'theme-ten'   => __( 'Theme Ten', 'testimonial-pro' ),
					),
					'default' => 'theme-one',
					'class'   => 'chosen',
				),

				array(
					'id'      => 'display_testimonials_from',
					'type'    => 'select',
					'title'   => __( 'Display Testimonials from', 'testimonial-pro' ),
					'desc'    => __( 'Select an option to display the testimonials.', 'testimonial-pro' ),
					'options' => array(
						'latest'                => __( 'Latest', 'testimonial-pro' ),
						'category'              => __( 'Category', 'testimonial-pro' ),
						'specific_testimonials' => __( 'Specific Testimonials', 'testimonial-pro' ),
					),
					'default' => 'latest',
					'class'   => 'chosen',
				),

				array(
					'id'         => 'specific_testimonial',
					'type'       => 'select',
					'title'      => __( 'Select Testimonials', 'testimonial-pro' ),
					'desc'       => __( 'Choose the testimonials to display.', 'testimonial-pro' ),
					'options'    => 'all_testimonials',
					'class'      => 'chosen',
					'attributes' => array(
						'multiple'    => 'multiple',
						'placeholder' => __( 'Choose Testimonials', 'testimonial-pro' ),
						'style'       => 'width: 280px;'
					),
					'dependency' => array(
						'display_testimonials_from',
						'==',
						'specific_testimonials'
					),
				),

				array(
					'id'         => 'category_list',
					'type'       => 'select',
					'title'      => __( 'Choose Category(s)', 'testimonial-pro' ),
					'desc'       => __( 'Choose the category(s) to show the testimonial from.', 'testimonial-pro' ),
					'options'    => 'testimonial_categorise',
					'attributes' => array(
						'multiple'    => 'multiple',
						'placeholder' => __( 'Select Category(s)', 'testimonial-pro' ),
						'style'       => 'width: 280px;'
					),
					'class'      => 'chosen',
					'dependency' => array(
						'display_testimonials_from',
						'==',
						'category'
					),

				),
				array(
					'id'         => 'category_operator',
					'type'       => 'select',
					'title'      => __( 'Operator', 'testimonial-pro' ),
					'desc'       => __( 'Choose the operator.', 'testimonial-pro' ),
					'options'    => array(
						'IN'     => __( 'IN - Show testimonials which associate with one or more terms', 'testimonial-pro' ),
						'AND'    => __( 'AND - Show testimonials which match all terms', 'testimonial-pro' ),
						'NOT IN' => __( 'NOT IN - Show testimonials which don\'t match the terms', 'testimonial-pro' ),
					),
					'default'    => 'IN',
					'class'      => 'chosen',
					'dependency' => array(
						'display_testimonials_from',
						'==',
						'category'
					),
				),
				array(
					'id'      => 'number_of_total_testimonials',
					'type'    => 'number',
					'title'   => __( 'Total Testimonials', 'testimonial-pro' ),
					'desc'    => __( 'Number of total testimonials to display.', 'testimonial-pro' ),
					'default' => '50',
				),
				array(
					'id'         => 'number_of_testimonials',
					'type'       => 'number',
					'title'      => __( 'Testimonial Column(s)', 'testimonial-pro' ),
					'desc'       => __( 'Set number of column(s) for the screen larger than 1280px.', 'testimonial-pro' ),
					'default'    => '1',
					'dependency' => array(
						'layout|thumbnail_slider',
						'!=|!=',
						'list|true'
					),
				),
				array(
					'id'         => 'number_of_testimonials_desktop',
					'type'       => 'number',
					'title'      => __( 'Testimonial Column(s) on Desktop', 'testimonial-pro' ),
					'desc'       => __( 'Set number of column on desktop for the screen smaller than 1280px.', 'testimonial-pro' ),
					'default'    => '1',
					'dependency' => array(
						'layout|thumbnail_slider',
						'!=|!=',
						'list|true'
					),
				),
				array(
					'id'         => 'number_of_testimonials_small_desktop',
					'type'       => 'number',
					'title'      => __( 'Testimonial Column(s) on Small Desktop', 'testimonial-pro' ),
					'desc'       => __( 'Set number of column on small desktop for the screen smaller than 980px.', 'testimonial-pro' ),
					'default'    => '1',
					'dependency' => array(
						'layout|thumbnail_slider',
						'!=|!=',
						'list|true'
					),
				),
				array(
					'id'         => 'number_of_testimonials_tablet',
					'type'       => 'number',
					'title'      => __( 'Testimonial Column(s) on Tablet', 'testimonial-pro' ),
					'desc'       => __( 'Set number of column on tablet for the screen smaller than 736px.', 'testimonial-pro' ),
					'default'    => '1',
					'dependency' => array(
						'layout|thumbnail_slider',
						'!=|!=',
						'list|true'
					),
				),
				array(
					'id'         => 'number_of_testimonials_mobile',
					'type'       => 'number',
					'title'      => __( 'Testimonial Column(s) on Mobile', 'testimonial-pro' ),
					'desc'       => __( 'Set number of column on mobile for the screen smaller than 480px.', 'testimonial-pro' ),
					'default'    => '1',
					'dependency' => array(
						'layout|thumbnail_slider',
						'!=|!=',
						'list|true'
					),
				),
				array(
					'id'      => 'testimonial_order_by',
					'type'    => 'select',
					'title'   => __( 'Order by', 'testimonial-pro' ),
					'desc'    => __( 'Select an order by option.', 'testimonial-pro' ),
					'options' => array(
						'ID'         => __( 'ID', 'testimonial-pro' ),
						'date'       => __( 'Date', 'testimonial-pro' ),
						'rand'       => __( 'Random', 'testimonial-pro' ),
						'title'      => __( 'Title', 'testimonial-pro' ),
						'modified'   => __( 'Modified', 'testimonial-pro' ),
						'menu_order' => __( 'Drag & Drop', 'testimonial-pro' ),
					),
					'default' => 'menu_order',
					'class'   => 'chosen',
				),
				array(
					'id'      => 'testimonial_order',
					'type'    => 'select',
					'title'   => __( 'Order', 'testimonial-pro' ),
					'desc'    => __( 'Select an order option.', 'testimonial-pro' ),
					'options' => array(
						'ASC'  => __( 'Ascending', 'testimonial-pro' ),
						'DESC' => __( 'Descending', 'testimonial-pro' ),
					),
					'default' => 'DESC',
					'class'   => 'chosen',
				),


			), // end: fields
		), // end: General section


		// begin: Slider section
		array(
			'name'   => 'sp_tpro_shortcode_option_2',
			'title'  => __( 'Slider Settings', 'testimonial-pro' ),
			'icon'   => 'fa fa-sliders',
			'fields' => array(

				array(
					'type'       => 'notice',
					'class'      => 'info',
					'content'    => __( 'To see the slider setting fields, select Slider layout.', 'testimonial-pro' ),
					'dependency' => array( 'layout', 'any', 'filter_grid,filter_masonry,grid,masonry,list' ),
				),
				array(
					'id'         => 'slider_ticker_mode',
					'type'       => 'switcher',
					'title'      => __( 'Ticker Mode', 'testimonial-pro' ),
					'desc'       => __( 'On/Off ticker mode. Slider controls don\'t work in ticker mode. ', 'testimonial-pro' ),
					'default'    => false,
					'dependency' => array( 'layout|thumbnail_slider', '==|!=', 'slider|true' ),
				),
				array(
					'id'         => 'slider_auto_play',
					'type'       => 'switcher',
					'title'      => __( 'AutoPlay', 'testimonial-pro' ),
					'desc'       => __( 'On/Off auto play.', 'testimonial-pro' ),
					'default'    => true,
					'dependency' => array( 'slider_ticker_mode|layout', '==|==', 'false|slider' ),
				),
				array(
					'id'         => 'slider_auto_play_speed',
					'type'       => 'number',
					'title'      => __( 'AutoPlay Speed', 'testimonial-pro' ),
					'desc'       => __( 'Set auto play speed.', 'testimonial-pro' ),
					'after'      => __( '(millisecond)', 'testimonial-pro' ),
					'default'    => '3000',
					'dependency' => array(
						'slider_auto_play|slider_ticker_mode|layout',
						'==|==|==',
						'true|false|slider'
					),
				),
				array(
					'id'         => 'slider_scroll_speed',
					'type'       => 'number',
					'title'      => __( 'Pagination Speed', 'testimonial-pro' ),
					'desc'       => __( 'Set pagination/slide scroll speed.', 'testimonial-pro' ),
					'after'      => __( '(millisecond)', 'testimonial-pro' ),
					'default'    => '600',
					'dependency' => array( 'layout', '==', 'slider' ),
				),
				array(
					'id'         => 'number_of_slides_to_scroll',
					'type'       => 'number',
					'title'      => __( 'Slide to Scroll', 'testimonial-pro' ),
					'desc'       => __( 'Number of testimonial(s) to scroll at a time.', 'testimonial-pro' ),
					'default'    => '1',
					'dependency' => array( 'slider_ticker_mode|layout|thumbnail_slider', '==|==|!=', 'false|slider|true' ),
				),
				array(
					'id'         => 'slider_pause_on_hover',
					'type'       => 'switcher',
					'title'      => __( 'Pause on Hover', 'testimonial-pro' ),
					'desc'       => __( 'On/Off slider pause on hover.', 'testimonial-pro' ),
					'default'    => true,
					'dependency' => array( 'layout', '==', 'slider' ),
				),
				array(
					'id'         => 'slider_infinite',
					'type'       => 'switcher',
					'title'      => __( 'Infinite Loop', 'testimonial-pro' ),
					'desc'       => __( 'On/Off infinite loop mode.', 'testimonial-pro' ),
					'default'    => true,
					'dependency' => array( 'layout|thumbnail_slider', '==|!=', 'slider|true' ),
				),
				array(
					'id'         => 'slider_animation',
					'type'       => 'radio',
					'title'      => __( 'Slider Animation', 'testimonial-pro' ),
					'desc'       => __( 'Fade effect works only on single column view.', 'testimonial-pro' ),
					'options' => array(
						'slide' => __('Slide', 'testimonial-pro'),
						'fade' => __('Fade', 'testimonial-pro')
					),
					'default'    => 'slide',
					'attributes' => array(
						'data-depend-id' => 'slider_animation',
					),
					'dependency' => array( 'layout|slider_ticker_mode', '==|==', 'slider|false' ),
				),

				array(
					'type'       => 'subheading',
					'content'    => __( 'Navigation Settings', 'testimonial-pro' ),
					'dependency' => array( 'layout|slider_ticker_mode', '==|==', 'slider|false' ),
				),
				array(
					'id'         => 'navigation',
					'type'       => 'switcher',
					'title'      => __( 'Navigation', 'testimonial-pro' ),
					'desc'       => __( 'Show/Hide slider navigation.', 'testimonial-pro' ),
					'default'    => true,
					'dependency' => array( 'layout|slider_ticker_mode', '==|==', 'slider|false' ),
				),
				array(
					'id'         => 'navigation_position',
					'type'       => 'select',
					'title'      => __( 'Select Position', 'testimonial-pro' ),
					'desc'       => __( 'Select a position for the navigation arrows.', 'testimonial-pro' ),
					'options'    => array(
						'top_right'                   => __( 'Top right', 'testimonial-pro' ),
						'top_center'                  => __( 'Top center', 'testimonial-pro' ),
						'top_left'                    => __( 'Top left', 'testimonial-pro' ),
						'bottom_left'                 => __( 'Bottom left', 'testimonial-pro' ),
						'bottom_center'               => __( 'Bottom center', 'testimonial-pro' ),
						'bottom_right'                => __( 'Bottom right', 'testimonial-pro' ),
						'vertical_center'             => __( 'Vertically center', 'testimonial-pro' ),
						'vertical_center_inner'       => __( 'Vertically center inner', 'testimonial-pro' ),
						'vertical_center_inner_hover' => __( 'Vertically center inner on hover', 'testimonial-pro' ),
					),
					'default'    => 'vertical_center',
					'class'      => 'chosen',
					'dependency' => array( 'navigation|layout|slider_ticker_mode', '==|==|==', 'true|slider|false' ),
				),
				array(
					'id'         => 'navigation_style',
					'type'       => 'image_select',
					'title'      => __( 'Choose a Style', 'testimonial-pro' ),
					'desc'       => __( 'Choose a slider navigation style.', 'testimonial-pro' ),
					'options'    => array(
						'thirteen' => SP_TPRO_URL . 'admin/views/metabox/assets/images/nav-13.png',
						'one'      => SP_TPRO_URL . 'admin/views/metabox/assets/images/nav-1.png',
						'two'      => SP_TPRO_URL . 'admin/views/metabox/assets/images/nav-2.png',
						'three'    => SP_TPRO_URL . 'admin/views/metabox/assets/images/nav-3.png',
						'four'     => SP_TPRO_URL . 'admin/views/metabox/assets/images/nav-4.png',
						'five'     => SP_TPRO_URL . 'admin/views/metabox/assets/images/nav-5.png',
						'six'      => SP_TPRO_URL . 'admin/views/metabox/assets/images/nav-6.png',
						'seven'    => SP_TPRO_URL . 'admin/views/metabox/assets/images/nav-7.png',
						'eight'    => SP_TPRO_URL . 'admin/views/metabox/assets/images/nav-8.png',
						'nine'     => SP_TPRO_URL . 'admin/views/metabox/assets/images/nav-9.png',
						'ten'      => SP_TPRO_URL . 'admin/views/metabox/assets/images/nav-10.png',
						'eleven'   => SP_TPRO_URL . 'admin/views/metabox/assets/images/nav-11.png',
						'twelve'   => SP_TPRO_URL . 'admin/views/metabox/assets/images/nav-12.png',
					),
					'attributes' => array(
						'data-depend-id' => 'navigation_style',
					),
					'default'    => 'thirteen',
					'radio'      => true,
					'dependency' => array(
						'navigation|layout|slider_ticker_mode',
						'==|==|==',
						'true|slider|false'
					),
				),
				array(
					'id'         => 'navigation_icons',
					'type'       => 'image_select',
					'title'      => __( 'Choose a Icon', 'testimonial-pro' ),
					'desc'       => __( 'choose a slider navigation icon.', 'testimonial-pro' ),
					'options'    => array(
						'angle'   => SP_TPRO_URL . 'admin/views/metabox/assets/images/angle-arrow.png',
						'chevron' => SP_TPRO_URL . 'admin/views/metabox/assets/images/chevron-arrow.png',
						'angle-double'  => SP_TPRO_URL . 'admin/views/metabox/assets/images/double-arrow.png',
						'arrow'    => SP_TPRO_URL . 'admin/views/metabox/assets/images/bold-arrow.png',
						'long-arrow'    => SP_TPRO_URL . 'admin/views/metabox/assets/images/long-arrow.png',
						'caret'   => SP_TPRO_URL . 'admin/views/metabox/assets/images/caret-arrow.png',
					),
					'default'    => 'angle',
					'radio'      => true,
					'dependency' => array(
						'navigation|layout|slider_ticker_mode',
						'==|==|==',
						'true|slider|false'
					),
				),
				array(
					'id'         => 'navigation_bg_color',
					'type'       => 'color_picker',
					'title'      => __( 'Arrow Background', 'testimonial-pro' ),
					'desc'       => __( 'Set the navigation arrow background color.', 'testimonial-pro' ),
					'default'    => '#777777',
					'dependency' => array(
						'navigation|layout|navigation_style|slider_ticker_mode',
						'==|==|any|==',
						'true|slider|one,two,three,four,five,ten|false'
					),
				),
				array(
					'id'         => 'navigation_border_color',
					'type'       => 'color_picker',
					'title'      => __( 'Arrow Border Color', 'testimonial-pro' ),
					'desc'       => __( 'Set the navigation arrow border color.', 'testimonial-pro' ),
					'default'    => '#777777',
					'dependency' => array(
						'navigation|layout|navigation_style|slider_ticker_mode',
						'==|==|any|==',
						'true|slider|six,seven,eight,nine,eleven,twelve|false'
					),
				),
				array(
					'id'         => 'navigation_arrow_color',
					'type'       => 'color_picker',
					'title'      => __( 'Arrow Color', 'testimonial-pro' ),
					'desc'       => __( 'Set the navigation arrow color.', 'testimonial-pro' ),
					'default'    => '#ffffff',
					'dependency' => array(
						'navigation|layout|navigation_style|slider_ticker_mode',
						'==|==|any|==',
						'true|slider|one,two,three,four,five,ten|false'
					),
				),
				array(
					'id'         => 'navigation_arrow_color_two',
					'type'       => 'color_picker',
					'title'      => __( 'Arrow Color', 'testimonial-pro' ),
					'desc'       => __( 'Set the navigation arrow color.', 'testimonial-pro' ),
					'default'    => '#444444',
					'dependency' => array(
						'navigation|layout|navigation_style|slider_ticker_mode',
						'==|==|any|==',
						'true|slider|six,seven,eight,nine,eleven,twelve,thirteen|false'
					),
				),
				array(
					'id'         => 'navigation_hover_bg_color',
					'type'       => 'color_picker',
					'title'      => __( 'Arrow Hover Background', 'testimonial-pro' ),
					'desc'       => __( 'Set the navigation arrow hover background color.', 'testimonial-pro' ),
					'default'    => '#52b3d9',
					'dependency' => array(
						'navigation|layout|navigation_style|slider_ticker_mode',
						'==|==|any|==',
						'true|slider|one,two,three,four,five,ten|false'
					),
				),
				array(
					'id'         => 'navigation_hover_border_color',
					'type'       => 'color_picker',
					'title'      => __( 'Arrow Hover Border Color', 'testimonial-pro' ),
					'desc'       => __( 'Set the navigation arrow hover border color.', 'testimonial-pro' ),
					'default'    => '#52b3d9',
					'dependency' => array(
						'navigation|layout|navigation_style|slider_ticker_mode',
						'==|==|any|==',
						'true|slider|six,seven,eight,nine,eleven,twelve|false'
					),
				),
				array(
					'id'         => 'navigation_hover_arrow_color',
					'type'       => 'color_picker',
					'title'      => __( 'Arrow Hover Color', 'testimonial-pro' ),
					'desc'       => __( 'Set the navigation arrow hover color.', 'testimonial-pro' ),
					'default'    => '#ffffff',
					'dependency' => array(
						'navigation|layout|navigation_style|slider_ticker_mode',
						'==|==|any|==',
						'true|slider|one,two,three,four,five,ten|false'
					),
				),
				array(
					'id'         => 'navigation_hover_arrow_color_two',
					'type'       => 'color_picker',
					'title'      => __( 'Arrow Hover Color', 'testimonial-pro' ),
					'desc'       => __( 'Set the navigation arrow hover color.', 'testimonial-pro' ),
					'default'    => '#52b3d9',
					'dependency' => array(
						'navigation|layout|navigation_style|slider_ticker_mode',
						'==|==|any|==',
						'true|slider|six,seven,eight,nine,eleven,twelve,thirteen|false'
					),
				),

				array(
					'type'       => 'subheading',
					'content'    => __( 'Pagination Settings', 'testimonial-pro' ),
					'dependency' => array( 'layout|slider_ticker_mode', '==|==', 'slider|false' ),
				),
				array(
					'id'         => 'pagination',
					'type'       => 'switcher',
					'title'      => __( 'Pagination', 'testimonial-pro' ),
					'desc'       => __( 'Show/Hide pagination.', 'testimonial-pro' ),
					'default'    => true,
					'dependency' => array( 'layout|slider_ticker_mode', '==|==', 'slider|false' ),
				),
				array(
					'id'         => 'pagination_margin',
					'type'       => 'margin',
					'title'      => __( 'Set Margin', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial pagination margin.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '0',
						'top'    => '21',
						'bottom' => '0',
						'right'  => '0'
					),
					'dependency' => array( 'pagination|layout|slider_ticker_mode', '==|==|==', 'true|slider|false' ),
				),
				array(
					'id'         => 'pagination_style',
					'type'       => 'image_select',
					'title'      => __( 'Choose a Style', 'testimonial-pro' ),
					'desc'       => __( 'Choose a slider pagination style.', 'testimonial-pro' ),
					'options'    => array(
						'active_filled_dot'              => SP_TPRO_URL . 'admin/views/metabox/assets/images/dot-1.png',
						'active_unfilled_dot'            => SP_TPRO_URL . 'admin/views/metabox/assets/images/dot-2.png',
						'radius_square'                  => SP_TPRO_URL . 'admin/views/metabox/assets/images/dot-3.png',
						'sharp_square'                   => SP_TPRO_URL . 'admin/views/metabox/assets/images/dot-4.png',
						'rotate_square'                  => SP_TPRO_URL . 'admin/views/metabox/assets/images/dot-5.png',
						'rotate_unfilled_square'         => SP_TPRO_URL . 'admin/views/metabox/assets/images/dot-6.png',
						'circle'                         => SP_TPRO_URL . 'admin/views/metabox/assets/images/dot-7.png',
						'circle_active_filled'           => SP_TPRO_URL . 'admin/views/metabox/assets/images/dot-8.png',
						'bordered_dot'                   => SP_TPRO_URL . 'admin/views/metabox/assets/images/dot-9.png',
						'pill'                           => SP_TPRO_URL . 'admin/views/metabox/assets/images/dot-10.png',
						'active_rounded_bg_number'       => SP_TPRO_URL . 'admin/views/metabox/assets/images/dot-11.png',
						'active_rounded_bordered_number' => SP_TPRO_URL . 'admin/views/metabox/assets/images/dot-12.png',
						'active_square_bordered_number'  => SP_TPRO_URL . 'admin/views/metabox/assets/images/dot-13.png',
						'active_square_bg_number'        => SP_TPRO_URL . 'admin/views/metabox/assets/images/dot-14.png',
						'rounded_bg_number'              => SP_TPRO_URL . 'admin/views/metabox/assets/images/dot-15.png',
						'active_filled_rounded_bordered' => SP_TPRO_URL . 'admin/views/metabox/assets/images/dot-16.png',
					),
					'attributes' => array(
						'data-depend-id' => 'pagination_style',
					),
					'default'    => 'active_filled_dot',
					'radio'      => true,
					'dependency' => array( 'pagination|layout|slider_ticker_mode', '==|==|==', 'true|slider|false' ),
				),

				array(
					'id'         => 'pagination_text_color',
					'type'       => 'color_picker',
					'title'      => __( 'Number Color', 'testimonial-pro' ),
					'desc'       => __( 'Set the pagination number color.', 'testimonial-pro' ),
					'default'    => '#444444',
					'dependency' => array(
						'pagination|pagination_style|layout|slider_ticker_mode',
						'==|any|==|==',
						'true|active_rounded_bg_number,active_rounded_bordered_number,active_square_bordered_number,active_square_bg_number,rounded_bg_number,active_filled_rounded_bordered|slider|false'
					),
				),
				array(
					'id'         => 'pagination_active_text_color',
					'type'       => 'color_picker',
					'title'      => __( 'Active Number Color', 'testimonial-pro' ),
					'desc'       => __( 'Set the pagination active number color.', 'testimonial-pro' ),
					'default'    => '#ffffff',
					'dependency' => array(
						'pagination|pagination_style|layout|slider_ticker_mode',
						'==|any|==|==',
						'true|active_rounded_bg_number,active_square_bg_number,rounded_bg_number,active_filled_rounded_bordered|slider|false'
					),
				),

				array(
					'id'         => 'pagination_color',
					'type'       => 'color_picker',
					'title'      => __( 'Dots Color', 'testimonial-pro' ),
					'desc'       => __( 'Set the pagination dots color.', 'testimonial-pro' ),
					'default'    => '#cccccc',
					'dependency' => array(
						'pagination|pagination_style|layout|slider_ticker_mode',
						'==|any|==|==',
						'true|active_filled_dot,active_unfilled_dot,radius_square,sharp_square,rotate_square,rotate_unfilled_square,circle,circle_active_filled,bordered_dot,pill,rounded_bg_number,active_filled_rounded_bordered|slider|false'
					),
				),
				array(
					'id'         => 'pagination_active_color',
					'type'       => 'color_picker',
					'title'      => __( 'Active Color', 'testimonial-pro' ),
					'desc'       => __( 'Set the pagination active color.', 'testimonial-pro' ),
					'default'    => '#52b3d9',
					'dependency' => array(
						'pagination|pagination_style|layout|slider_ticker_mode',
						'==|any|==|==',
						'true|active_filled_dot,active_unfilled_dot,radius_square,sharp_square,rotate_square,rotate_unfilled_square,circle,circle_active_filled,bordered_dot,pill,active_rounded_bg_number,active_rounded_bordered_number,active_square_bordered_number,active_square_bg_number,rounded_bg_number,active_filled_rounded_bordered|slider|false'
					),
				),


				array(
					'type'       => 'subheading',
					'content'    => __( 'Misc. Settings', 'testimonial-pro' ),
					'dependency' => array( 'layout', '==', 'slider' ),
				),
				array(
					'id'         => 'slider_swipe',
					'type'       => 'switcher',
					'title'      => __( 'Swipe', 'testimonial-pro' ),
					'desc'       => __( 'On/Off swipe mode.', 'testimonial-pro' ),
					'default'    => true,
					'dependency' => array( 'slider_ticker_mode|layout', '==|==', 'false|slider' ),
				),
				array(
					'id'         => 'slider_draggable',
					'type'       => 'switcher',
					'title'      => __( 'Mouse Draggable', 'testimonial-pro' ),
					'desc'       => __( 'On/Off mouse draggable mode.', 'testimonial-pro' ),
					'default'    => true,
					'dependency' => array(
						'slider_swipe|slider_ticker_mode|layout',
						'==|==|==',
						'true|false|slider'
					),
				),
				array(
					'id'         => 'rtl_mode',
					'type'       => 'switcher',
					'title'      => __( 'RTL', 'testimonial-pro' ),
					'desc'       => __( 'On/Off right to left mode.', 'testimonial-pro' ),
					'default'    => false,
					'dependency' => array( 'layout', '==', 'slider' ),
				),
				array(
					'type'       => 'notice',
					'class'      => 'danger',
					'content'    => __( 'To make the RTL Mode work, please select an rtl language in the dashboard e.g. Arabic, Hebrew.', 'testimonial-pro' ),
					'dependency' => array( 'rtl_mode|layout', '==|==', 'true|slider' ),
				),

			), // End Fields
		),
		// end: a section
		// begin: Stylization section
		array(
			'name'   => 'sp_tpro_shortcode_option_3',
			'title'  => __( 'Stylization', 'testimonial-pro' ),
			'icon'   => 'fa fa-paint-brush',
			'fields' => array(

				array(
					'id'      => 'section_title',
					'type'    => 'switcher',
					'title'   => __( 'Section Title', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide the shortcode title as testimonial section title e.g. What Our Customers Saying.', 'testimonial-pro' ),
					'default' => false,
				),
				array(
					'id'         => 'section_title_margin_bottom',
					'type'       => 'number',
					'title'      => __( 'Section Title Margin Bottom', 'testimonial-pro' ),
					'desc'       => __( 'Set margin bottom for the testimonial section title.', 'testimonial-pro' ),
					'after'      => __( '(px)', 'testimonial-pro' ),
					'default'    => 23,
					'dependency' => array(
						'section_title',
						'==',
						'true'
					),
				),
				array(
					'id'         => 'testimonial_margin',
					'type'       => 'number',
					'title'      => __( 'Testimonial Margin', 'testimonial-pro' ),
					'desc'       => __( 'Set margin between the testimonials.', 'testimonial-pro' ),
					'after'      => __( '(px)', 'testimonial-pro' ),
					'default'    => 0,
					'dependency' => array(
						'theme_style|thumbnail_slider',
						'any|!=',
						'theme-one,theme-two,theme-three,theme-four,theme-five,theme-six,theme-seven,theme-eight,theme-nine,theme-ten|true'
					),
				),
				array(
					'id'         => 'testimonial_border_size',
					'type'       => 'number',
					'title'      => __( 'Testimonial Border Thickness', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial border thickness.', 'testimonial-pro' ),
					'after'      => __( '(px)', 'testimonial-pro' ),
					'default'    => 1,
					'dependency' => array(
						'theme_style',
						'any',
						'theme-two,theme-four,theme-six,theme-seven'
					),
				),
				array(
					'id'         => 'testimonial_border_size_two',
					'type'       => 'number',
					'title'      => __( 'Testimonial Border Thickness', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial border thickness.', 'testimonial-pro' ),
					'after'      => __( '(px)', 'testimonial-pro' ),
					'default'    => 0,
					'dependency' => array(
						'theme_style',
						'any',
						'theme-three,theme-five,theme-eight,theme-nine,theme-ten'
					),
				),
				array(
					'id'         => 'testimonial_border_color',
					'type'       => 'color_picker',
					'title'      => __( 'Testimonial Border Color', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial border color.', 'testimonial-pro' ),
					'default'    => '#e3e3e3',
					'dependency' => array(
						'theme_style',
						'any',
						'theme-two,theme-three,theme-four,theme-five,theme-six,theme-seven,theme-eight,theme-nine,theme-ten'
					),
				),
				array(
					'id'         => 'testimonial_box_shadow_color',
					'type'       => 'color_picker',
					'title'      => __( 'Testimonial Box-Shadow Color', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial box-shadow color.', 'testimonial-pro' ),
					'default'    => '#dddddd',
					'dependency' => array(
						'theme_style',
						'any',
						'theme-ten'
					),
				),
				array(
					'id'         => 'testimonial_top_bg',
					'type'       => 'color_picker',
					'title'      => __( 'Testimonial Top Background', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial top background color.', 'testimonial-pro' ),
					'default'    => '#ff8a00',
					'dependency' => array(
						'theme_style',
						'any',
						'theme-ten'
					),
				),
				array(
					'id'         => 'testimonial_bg',
					'type'       => 'color_picker',
					'title'      => __( 'Testimonial Background', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial background color.', 'testimonial-pro' ),
					'default'    => '#ffffff',
					'dependency' => array(
						'theme_style',
						'any',
						'theme-two,theme-three,theme-five,theme-six,theme-ten'
					),
				),
				array(
					'id'         => 'testimonial_bg_two',
					'type'       => 'color_picker',
					'title'      => __( 'Testimonial Background', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial background color.', 'testimonial-pro' ),
					'default'    => '#f5f5f5',
					'dependency' => array(
						'theme_style',
						'any',
						'theme-four'
					),
				),
				array(
					'id'         => 'testimonial_bg_three',
					'type'       => 'color_picker',
					'title'      => __( 'Testimonial Background', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial background color.', 'testimonial-pro' ),
					'default'    => '#e57373',
					'dependency' => array(
						'theme_style',
						'any',
						'theme-seven,theme-eight,theme-nine'
					),
				),
				array(
					'id'         => 'testimonial_border_radius',
					'type'       => 'number',
					'title'      => __( 'Testimonial Border Radius', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial border radius.', 'testimonial-pro' ),
					'after'      => __( '(px)', 'testimonial-pro' ),
					'default'    => 10,
					'dependency' => array(
						'theme_style',
						'any',
						'theme-ten'
					),
				),
				array(
					'id'         => 'testimonial_inner_padding',
					'type'       => 'margin',
					'title'      => __( 'Inner Padding', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial inner padding.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '22',
						'top'    => '22',
						'bottom' => '22',
						'right'  => '22'
					),
					'dependency' => array(
						'theme_style',
						'any',
						'theme-two,theme-three,theme-four,theme-five,theme-six,theme-seven,theme-eight,theme-nine,theme-ten'
					),
				),
				array(
					'id'         => 'testimonial_info_position',
					'type'       => 'select',
					'title'      => __( 'Testimonial Info Position', 'testimonial-pro' ),
					'desc'       => __( 'Select testimonial info position.', 'testimonial-pro' ),
					'options'    => array(
						'top'    => __( 'Top', 'testimonial-pro' ),
						'bottom' => __( 'Bottom', 'testimonial-pro' ),
						'left'   => __( 'Left', 'testimonial-pro' ),
						'right'  => __( 'Right', 'testimonial-pro' ),
					),
					'default'    => 'bottom',
					'class'      => 'chosen',
					'dependency' => array(
						'theme_style',
						'any',
						'theme-eight'
					),
				),
				array(
					'id'         => 'testimonial_info_position_two',
					'type'       => 'select',
					'title'      => __( 'Testimonial Info Position', 'testimonial-pro' ),
					'desc'       => __( 'Select testimonial info position.', 'testimonial-pro' ),
					'options'    => array(
						'top_left'     => __( 'Top Left', 'testimonial-pro' ),
						'top_right'    => __( 'Top Right', 'testimonial-pro' ),
						'bottom_left'  => __( 'Bottom Left', 'testimonial-pro' ),
						'bottom_right' => __( 'Bottom Right', 'testimonial-pro' ),
					),
					'default'    => 'bottom_left',
					'class'      => 'chosen',
					'dependency' => array(
						'theme_style',
						'any',
						'theme-nine'
					),
				),
				array(
					'id'         => 'testimonial_info_border_size',
					'type'       => 'number',
					'title'      => __( 'Testimonial Info Border Thickness', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial info border thickness.', 'testimonial-pro' ),
					'after'      => __( '(px)', 'testimonial-pro' ),
					'default'    => 0,
					'dependency' => array(
						'theme_style',
						'any',
						'theme-eight,theme-nine'
					),
				),
				array(
					'id'         => 'testimonial_info_border_color',
					'type'       => 'color_picker',
					'title'      => __( 'Testimonial Info Border Color', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial info border color.', 'testimonial-pro' ),
					'default'    => '#e3e3e3',
					'dependency' => array(
						'theme_style',
						'any',
						'theme-eight,theme-nine'
					),
				),
				array(
					'id'         => 'testimonial_info_bg',
					'type'       => 'color_picker',
					'title'      => __( 'Testimonial Info Background', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial info background color.', 'testimonial-pro' ),
					'default'    => '#f1e9e0',
					'dependency' => array(
						'theme_style',
						'any',
						'theme-eight,theme-nine'
					),
				),
				array(
					'id'         => 'testimonial_info_inner_padding',
					'type'       => 'margin',
					'title'      => __( 'Testimonial Info Inner Padding', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial info inner padding.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '22',
						'top'    => '22',
						'bottom' => '22',
						'right'  => '22'
					),
					'dependency' => array(
						'theme_style',
						'any',
						'theme-eight,theme-nine'
					),
				),
				array(
					'id'      => 'testimonial_title',
					'type'    => 'switcher',
					'title'   => __( 'Testimonial Title', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide testimonial tagline or title.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'testimonial_title_margin',
					'type'       => 'margin',
					'title'      => __( 'Testimonial Title Margin', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial tagline or title margin.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '0',
						'top'    => '0',
						'bottom' => '18',
						'right'  => '0'
					),
					'dependency' => array(
						'testimonial_title',
						'==',
						'true'
					),
				),
				array(
					'type'    => 'subheading',
					'content' => __( 'Testimonial Content Settings', 'testimonial-pro' ),
				),
				array(
					'id'      => 'testimonial_text',
					'type'    => 'switcher',
					'title'   => __( 'Testimonial Content', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide testimonial content.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'testimonial_text_margin',
					'type'       => 'margin',
					'title'      => __( 'Margin', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial content margin.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '0',
						'top'    => '0',
						'bottom' => '20',
						'right'  => '0'
					),
					'dependency' => array(
						'testimonial_text',
						'==',
						'true'
					),
				),

				array(
					'id'         => 'testimonial_content_type',
					'type'       => 'radio',
					'title'      => __( 'Content Display Type', 'testimonial-pro' ),
					'desc'       => __( 'Select content display type.', 'testimonial-pro' ),
					'options'    => array(
						'full_content' => __( 'Full Content', 'testimonial-pro' ),
						'content_with_limit'  => __( 'Content with Limit', 'testimonial-pro' ),
					),
					'default'    => 'content_with_limit',
					'attributes' => array(
						'data-depend-id' => 'testimonial_content_type',
					),
					'dependency' => array(
						'testimonial_text',
						'==',
						'true'
					),
				),

				array(
					'id'         => 'testimonial_characters_limit',
					'type'       => 'number',
					'title'      => __( 'Characters Limit', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial characters limit.', 'testimonial-pro' ),
					'default'    => '300',
					'dependency' => array(
						'testimonial_text|testimonial_content_type',
						'==|==',
						'true|content_with_limit'
					),
				),

				array(
					'id'         => 'testimonial_read_more_ellipsis',
					'type'       => 'text',
					'title'      => __( 'Ellipsis', 'testimonial-pro' ),
					'desc'       => __( 'Type ellipsis.', 'testimonial-pro' ),
					'default'    => '...',
					'dependency' => array(
						'testimonial_text|testimonial_content_type',
						'==|==',
						'true|content_with_limit'
					),
				),

				array(
					'id'         => 'testimonial_read_more',
					'type'       => 'switcher',
					'title'      => __( 'Read More', 'testimonial-pro' ),
					'desc'       => __( 'Show/Hide testimonial read more button.', 'testimonial-pro' ),
					'default'    => false,
					'dependency' => array(
						'testimonial_text|testimonial_content_type',
						'==|==',
						'true|content_with_limit'
					),
				),

				array(
					'id'         => 'testimonial_read_more_link_action',
					'type'       => 'radio',
					'title'      => __( 'Read More Action Type', 'testimonial-pro' ),
					'desc'       => __( 'Select read more link action type.', 'testimonial-pro' ),
					'options'    => array(
						'expand' => __( 'Expand', 'testimonial-pro' ),
						'popup'  => __( 'Popup', 'testimonial-pro' ),
					),
					'default'    => 'expand',
					'attributes' => array(
						'data-depend-id' => 'testimonial_read_more_link_action',
					),
					'dependency' => array(
						'testimonial_text|testimonial_read_more|testimonial_content_type',
						'==|==|==',
						'true|true|content_with_limit'
					),
				),

				array(
					'id'         => 'testimonial_read_more_text',
					'type'       => 'text',
					'title'      => __( 'Read More Text', 'testimonial-pro' ),
					'desc'       => __( 'Type custom read more text.', 'testimonial-pro' ),
					'default'    => 'Read More',
					'dependency' => array(
						'testimonial_text|testimonial_read_more|testimonial_content_type',
						'==|==|==',
						'true|true|content_with_limit'
					),
				),
				array(
					'id'         => 'testimonial_read_less_text',
					'type'       => 'text',
					'title'      => __( 'Read Less Text', 'testimonial-pro' ),
					'desc'       => __( 'Type custom read less text.', 'testimonial-pro' ),
					'default'    => 'Read Less',
					'dependency' => array(
						'testimonial_text|testimonial_read_more|testimonial_read_more_link_action|testimonial_content_type',
						'==|==|==|==',
						'true|true|expand|content_with_limit'
					),
				),
				array(
					'id'         => 'testimonial_read_more_color',
					'type'       => 'color_picker',
					'title'      => __( 'Read More Color', 'testimonial-pro' ),
					'desc'       => __( 'Set read more color.', 'testimonial-pro' ),
					'default'    => '#52b3d9',
					'dependency' => array(
						'testimonial_text|testimonial_read_more|testimonial_content_type',
						'==|==|==',
						'true|true|content_with_limit'
					),
				),
				array(
					'id'         => 'testimonial_read_more_hover_color',
					'type'       => 'color_picker',
					'title'      => __( 'Read More Hover Color', 'testimonial-pro' ),
					'desc'       => __( 'Set read more hover color.', 'testimonial-pro' ),
					'default'    => '#2684a6',
					'dependency' => array(
						'testimonial_text|testimonial_read_more|testimonial_content_type',
						'==|==|==',
						'true|true|content_with_limit'
					),
				),
				array(
					'type'    => 'subheading',
					'content' => __( 'Reviewer Information Settings', 'testimonial-pro' ),
				),
				array(
					'id'      => 'testimonial_client_name',
					'type'    => 'switcher',
					'title'   => __( 'Name', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide reviewer name.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'testimonial_client_name_margin',
					'type'       => 'margin',
					'title'      => __( 'Name Margin', 'testimonial-pro' ),
					'desc'       => __( 'Set margin for reviewer name.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '0',
						'top'    => '0',
						'bottom' => '8',
						'right'  => '0'
					),
					'dependency' => array(
						'testimonial_client_name',
						'==',
						'true'
					),
				),
				array(
					'id'      => 'testimonial_client_rating',
					'type'    => 'switcher',
					'title'   => __( 'Star Rating', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide star ratings.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'testimonial_client_rating_color',
					'type'       => 'color_picker',
					'title'      => __( 'Star Rating Color', 'testimonial-pro' ),
					'desc'       => __( 'Set color for star rating.', 'testimonial-pro' ),
					'default'    => '#f3bb00',
					'dependency' => array(
						'testimonial_client_rating',
						'==',
						'true'
					),
				),
				array(
					'id'         => 'testimonial_client_rating_alignment',
					'type'       => 'select',
					'title'      => __( 'Star Rating Alignment', 'testimonial-pro' ),
					'desc'       => __( 'Set alignment of star rating.', 'testimonial-pro' ),
					'options'    => array(
						'left'   => __( 'Left', 'testimonial-pro' ),
						'center' => __( 'Center', 'testimonial-pro' ),
						'right'  => __( 'Right', 'testimonial-pro' ),
					),
					'default'    => 'center',
					'class'      => 'chosen',
					'dependency' => array(
						'testimonial_client_rating|theme_style',
						'==|any',
						'true|theme-one,theme-two,theme-four,theme-ten'
					),
				),
				array(
					'id'         => 'testimonial_client_rating_alignment_two',
					'type'       => 'select',
					'title'      => __( 'Star Rating Alignment', 'testimonial-pro' ),
					'desc'       => __( 'Set alignment of star rating.', 'testimonial-pro' ),
					'options'    => array(
						'left'   => __( 'Left', 'testimonial-pro' ),
						'center' => __( 'Center', 'testimonial-pro' ),
						'right'  => __( 'Right', 'testimonial-pro' ),
					),
					'default'    => 'left',
					'class'      => 'chosen',
					'dependency' => array(
						'testimonial_client_rating|theme_style',
						'==|any',
						'true|theme-three,theme-five,theme-six,theme-seven,theme-nine'
					),
				),
				array(
					'id'         => 'testimonial_client_rating_margin',
					'type'       => 'margin',
					'title'      => __( 'Star Rating Margin', 'testimonial-pro' ),
					'desc'       => __( 'Set margin for star rating.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '0',
						'top'    => '0',
						'bottom' => '6',
						'right'  => '0'
					),
					'dependency' => array(
						'testimonial_client_rating',
						'==',
						'true'
					),
				),
				array(
					'id'      => 'client_designation',
					'type'    => 'switcher',
					'title'   => __( 'Identity or Position', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide identity or position.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'      => 'client_company_name',
					'type'    => 'switcher',
					'title'   => __( 'Company Name', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide company name.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'      => 'client_designation_company_margin',
					'type'    => 'margin',
					'title'   => __( 'Identity or Position & Company Margin', 'testimonial-pro' ),
					'desc'    => __( 'Set margin for identity or position and company.', 'testimonial-pro' ),
					'default' => array(
						'left'   => '0',
						'top'    => '0',
						'bottom' => '8',
						'right'  => '0'
					),
				),
				array(
					'id'      => 'testimonial_client_location',
					'type'    => 'switcher',
					'title'   => __( 'Location', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide Reviewer location.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'testimonial_client_location_margin',
					'type'       => 'margin',
					'title'      => __( 'Location Margin', 'testimonial-pro' ),
					'desc'       => __( 'Set margin for location.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '0',
						'top'    => '0',
						'bottom' => '5',
						'right'  => '0'
					),
					'dependency' => array(
						'testimonial_client_location',
						'==',
						'true'
					),
				),
				array(
					'id'      => 'testimonial_client_phone',
					'type'    => 'switcher',
					'title'   => __( 'Phone or Mobile', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide phone or mobile number.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'testimonial_client_phone_margin',
					'type'       => 'margin',
					'title'      => __( 'Phone or Mobile Margin', 'testimonial-pro' ),
					'desc'       => __( 'Set margin for phone or mobile number.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '0',
						'top'    => '0',
						'bottom' => '3',
						'right'  => '0'
					),
					'dependency' => array(
						'testimonial_client_phone',
						'==',
						'true'
					),
				),
				array(
					'id'      => 'testimonial_client_email',
					'type'    => 'switcher',
					'title'   => __( 'Email Address', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide email address.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'testimonial_client_email_margin',
					'type'       => 'margin',
					'title'      => __( 'Email Address Margin', 'testimonial-pro' ),
					'desc'       => __( 'Set email address margin.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '0',
						'top'    => '0',
						'bottom' => '5',
						'right'  => '0'
					),
					'dependency' => array(
						'testimonial_client_email',
						'==',
						'true'
					),
				),
				array(
					'id'      => 'testimonial_client_date',
					'type'    => 'switcher',
					'title'   => __( 'Date', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide testimonial date.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'testimonial_client_date_format',
					'type'       => 'text',
					'title'      => __( 'Date Format', 'testimonial-pro' ),
					'desc'       => __( 'Set date format.', 'testimonial-pro' ),
					'default'    => 'M j, Y',
					'after'      => '<br><a target="_blank" href="https://codex.wordpress.org/Formatting_Date_and_Time">Documentation on date formatting.</a>',
					'dependency' => array(
						'testimonial_client_date',
						'==',
						'true'
					),
				),
				array(
					'id'         => 'testimonial_client_date_margin',
					'type'       => 'margin',
					'title'      => __( 'Date Margin', 'testimonial-pro' ),
					'desc'       => __( 'Set margin for testimonial date.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '0',
						'top'    => '0',
						'bottom' => '6',
						'right'  => '0'
					),
					'dependency' => array(
						'testimonial_client_date',
						'==',
						'true'
					),
				),
				array(
					'id'      => 'testimonial_client_website',
					'type'    => 'switcher',
					'title'   => __( 'Website', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide website.', 'testimonial-pro' ),
					'default' => true,
				),

				array(
					'id'         => 'testimonial_client_website_margin',
					'type'       => 'margin',
					'title'      => __( 'Website Margin', 'testimonial-pro' ),
					'desc'       => __( 'Set website margin.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '0',
						'top'    => '0',
						'bottom' => '6',
						'right'  => '0'
					),
					'dependency' => array(
						'testimonial_client_website',
						'==',
						'true'
					),
				),

				array(
					'id'      => 'identity_linking_website',
					'type'    => 'checkbox',
					'title'   => __( 'Identity & Company linking via Website', 'testimonial-pro' ),
					'desc'    => __( 'Check to link identity & company name via website.', 'testimonial-pro' ),
					'default' => false,
				),

				array(
					'id'         => 'website_link_target',
					'type'       => 'radio',
					'title'      => __( 'Link Target', 'testimonial-pro' ),
					'desc'       => __( 'Set target to open the website URL.', 'testimonial-pro' ),
					'options'    => array(
						'_blank' => __( 'New Tab', 'testimonial-pro' ),
						'_self'  => __( 'Same Tab', 'testimonial-pro' ),
					),
					'default'    => '_blank',
					'attributes' => array(
						'data-depend-id' => 'website_link_target',
					),
				),

				array(
					'type'       => 'subheading',
					'content'    => __( 'Pagination Settings', 'testimonial-pro' ),
					'dependency' => array(
						'layout',
						'any',
						'grid,masonry,list'
					),
				),
				array(
					'id'         => 'grid_pagination',
					'type'       => 'switcher',
					'title'      => __( 'Pagination', 'testimonial-pro' ),
					'desc'       => __( 'Show/Hide pagination.', 'testimonial-pro' ),
					'default'    => true,
					'dependency' => array(
						'layout',
						'any',
						'grid,masonry,list'
					),
				),
				array(
					'id'         => 'grid_pagination_alignment',
					'type'       => 'select',
					'title'      => __( 'Pagination Alignment', 'testimonial-pro' ),
					'desc'       => __( 'Select pagination alignment.', 'testimonial-pro' ),
					'options'    => array(
						'left'   => __( 'Left', 'testimonial-pro' ),
						'center' => __( 'Center', 'testimonial-pro' ),
						'right'  => __( 'Right', 'testimonial-pro' ),
					),
					'default'    => 'left',
					'class'      => 'chosen',
					'dependency' => array(
						'grid_pagination|layout',
						'==|any',
						'true|grid,masonry,list'
					),
				),
				array(
					'id'         => 'grid_pagination_margin',
					'type'       => 'margin',
					'title'      => __( 'Pagination Margin', 'testimonial-pro' ),
					'desc'       => __( 'Set pagination margin.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '0',
						'top'    => '20',
						'bottom' => '20',
						'right'  => '0'
					),
					'dependency' => array(
						'grid_pagination|layout',
						'==|any',
						'true|grid,masonry,list'
					),
				),
				array(
					'id'         => 'grid_pagination_color',
					'type'       => 'color_picker',
					'title'      => __( 'Pagination Color', 'testimonial-pro' ),
					'desc'       => __( 'Set color for pagination.', 'testimonial-pro' ),
					'default'    => '#444444',
					'dependency' => array(
						'grid_pagination|layout',
						'==|any',
						'true|grid,masonry,list'
					),
				),
				array(
					'id'         => 'grid_pagination_bg',
					'type'       => 'color_picker',
					'title'      => __( 'Pagination Background', 'testimonial-pro' ),
					'desc'       => __( 'Set background color for pagination.', 'testimonial-pro' ),
					'default'    => '#ffffff',
					'dependency' => array(
						'grid_pagination|layout',
						'==|any',
						'true|grid,masonry,list'
					),
				),
				array(
					'id'         => 'grid_pagination_hover_color',
					'type'       => 'color_picker',
					'title'      => __( 'Pagination Hover Color', 'testimonial-pro' ),
					'desc'       => __( 'Set color for pagination hover.', 'testimonial-pro' ),
					'default'    => '#ffffff',
					'dependency' => array(
						'grid_pagination|layout',
						'==|any',
						'true|grid,masonry,list'
					),
				),
				array(
					'id'         => 'grid_pagination_hover_bg',
					'type'       => 'color_picker',
					'title'      => __( 'Pagination Hover Background', 'testimonial-pro' ),
					'desc'       => __( 'Set background color for pagination hover.', 'testimonial-pro' ),
					'default'    => '#52b3d9',
					'dependency' => array(
						'grid_pagination|layout',
						'==|any',
						'true|grid,masonry,list'
					),
				),
				array(
					'id'         => 'grid_pagination_border_color',
					'type'       => 'color_picker',
					'title'      => __( 'Pagination Border Color', 'testimonial-pro' ),
					'desc'       => __( 'Set color for pagination border.', 'testimonial-pro' ),
					'default'    => '#ececec',
					'dependency' => array(
						'grid_pagination|layout',
						'==|any',
						'true|grid,masonry,list'
					),
				),

				array(
					'type'       => 'subheading',
					'content'    => __( 'Filter Settings', 'testimonial-pro' ),
					'dependency' => array(
						'layout',
						'any',
						'filter_grid,filter_masonry'
					),
				),
				array(
					'id'         => 'filter_alignment',
					'type'       => 'select',
					'title'      => __( 'Filter Alignment', 'testimonial-pro' ),
					'desc'       => __( 'Set filter alignment.', 'testimonial-pro' ),
					'options'    => array(
						'left'   => __( 'Left', 'testimonial-pro' ),
						'center' => __( 'Center', 'testimonial-pro' ),
						'right'  => __( 'Right', 'testimonial-pro' ),
					),
					'default'    => 'left',
					'class'      => 'chosen',
					'dependency' => array(
						'layout',
						'any',
						'filter_grid,filter_masonry'
					),
				),
				array(
					'id'         => 'filter_margin',
					'type'       => 'margin',
					'title'      => __( 'Filter Margin', 'testimonial-pro' ),
					'desc'       => __( 'Set margin for filter.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '0',
						'top'    => '0',
						'bottom' => '24',
						'right'  => '0'
					),
					'dependency' => array(
						'layout',
						'any',
						'filter_grid,filter_masonry'
					),
				),
				array(
					'id'         => 'filter_color',
					'type'       => 'color_picker',
					'title'      => __( 'Filter Color', 'testimonial-pro' ),
					'desc'       => __( 'Set color for filter.', 'testimonial-pro' ),
					'default'    => '#444444',
					'dependency' => array(
						'layout',
						'any',
						'filter_grid,filter_masonry'
					),
				),
				array(
					'id'         => 'filter_bg_color',
					'type'       => 'color_picker',
					'title'      => __( 'Filter Background Color', 'testimonial-pro' ),
					'desc'       => __( 'Set background color for filter.', 'testimonial-pro' ),
					'default'    => '#e2e2e2',
					'dependency' => array(
						'layout',
						'any',
						'filter_grid,filter_masonry'
					),
				),
				array(
					'id'         => 'filter_active_color',
					'type'       => 'color_picker',
					'title'      => __( 'Filter Active Color', 'testimonial-pro' ),
					'desc'       => __( 'Set active color for filter.', 'testimonial-pro' ),
					'default'    => '#ffffff',
					'dependency' => array(
						'layout',
						'any',
						'filter_grid,filter_masonry'
					),
				),
				array(
					'id'         => 'filter_active_bg_color',
					'type'       => 'color_picker',
					'title'      => __( 'Filter Active Background Color', 'testimonial-pro' ),
					'desc'       => __( 'Set active background color for filter.', 'testimonial-pro' ),
					'default'    => '#52b3d9',
					'dependency' => array(
						'layout',
						'any',
						'filter_grid,filter_masonry'
					),
				),

				array(
					'type'    => 'subheading',
					'content' => __( 'Social Profiles Settings', 'testimonial-pro' ),
				),
				array(
					'id'      => 'social_profile',
					'type'    => 'switcher',
					'title'   => __( 'Social Profiles', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide social profiles.', 'testimonial-pro' ),
					'default' => false,
				),
				array(
					'id'         => 'social_profile_position',
					'type'       => 'select',
					'title'      => __( 'Social Profiles Position', 'testimonial-pro' ),
					'desc'       => __( 'Select social profiles position.', 'testimonial-pro' ),
					'options'    => array(
						'left'   => __( 'Left', 'testimonial-pro' ),
						'center' => __( 'Center', 'testimonial-pro' ),
						'right'  => __( 'Right', 'testimonial-pro' ),
					),
					'default'    => 'center',
					'class'      => 'chosen',
					'dependency' => array(
						'social_profile|theme_style',
						'==|any',
						'true|theme-one,theme-two,theme-four,theme-eight,theme-ten'
					),
				),
				array(
					'id'         => 'social_profile_position_two',
					'type'       => 'select',
					'title'      => __( 'Social Profiles Position', 'testimonial-pro' ),
					'desc'       => __( 'Select social profiles position.', 'testimonial-pro' ),
					'options'    => array(
						'left'   => __( 'Left', 'testimonial-pro' ),
						'center' => __( 'Center', 'testimonial-pro' ),
						'right'  => __( 'Right', 'testimonial-pro' ),
					),
					'default'    => 'left',
					'class'      => 'chosen',
					'dependency' => array(
						'social_profile|theme_style',
						'==|any',
						'true|theme-three,theme-five,theme-six,theme-seven,theme-nine'
					),
				),
				array(
					'id'         => 'social_profile_margin',
					'type'       => 'margin',
					'title'      => __( 'Social Profiles Margin', 'testimonial-pro' ),
					'desc'       => __( 'Set margin for social profiles.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '0',
						'top'    => '15',
						'bottom' => '6',
						'right'  => '0'
					),
					'dependency' => array(
						'social_profile',
						'==',
						'true'
					),
				),
				array(
					'id'         => 'social_icon_style',
					'type'       => 'image_select',
					'title'      => __( 'Choose a Style', 'testimonial-pro' ),
					'desc'       => __( 'Choose a social icon style.', 'testimonial-pro' ),
					'options'    => array(
						'circle' => SP_TPRO_URL . 'admin/views/metabox/assets/images/social-circle.png',
						'round'  => SP_TPRO_URL . 'admin/views/metabox/assets/images/social-round.png',
						'square' => SP_TPRO_URL . 'admin/views/metabox/assets/images/social-square.png',
					),
					'attributes' => array(
						'data-depend-id' => 'social_icon_style',
					),
					'default'    => 'circle',
					'radio'      => true,
					'dependency' => array(
						'social_profile',
						'==',
						'true'
					),
				),
				array(
					'id'         => 'social_profile_icon_color',
					'type'       => 'color_picker',
					'title'      => __( 'Icon Color', 'testimonial-pro' ),
					'desc'       => __( 'Set social icon color.', 'testimonial-pro' ),
					'default'    => '#aaaaaa',
					'dependency' => array(
						'social_profile',
						'==',
						'true'
					),
				),
				array(
					'id'         => 'social_profile_icon_hover_color',
					'type'       => 'color_picker',
					'title'      => __( 'Icon Hover Color', 'testimonial-pro' ),
					'desc'       => __( 'Set social icon hover color.', 'testimonial-pro' ),
					'default'    => '#ffffff',
					'dependency' => array(
						'social_profile',
						'==',
						'true'
					),
				),
				array(
					'id'         => 'social_profile_icon_bg',
					'type'       => 'color_picker',
					'title'      => __( 'Icon Background', 'testimonial-pro' ),
					'desc'       => __( 'Set social icon background color.', 'testimonial-pro' ),
					'default'    => 'transparent',
					'dependency' => array(
						'social_profile',
						'==',
						'true'
					),
				),
				array(
					'id'         => 'social_profile_icon_hover_bg',
					'type'       => 'color_picker',
					'title'      => __( 'Icon Hover Background', 'testimonial-pro' ),
					'desc'       => __( 'Set social icon hover background color.', 'testimonial-pro' ),
					'default'    => '#52b3d9',
					'dependency' => array(
						'social_profile',
						'==',
						'true'
					),
				),
				array(
					'id'         => 'social_profile_icon_border_color',
					'type'       => 'color_picker',
					'title'      => __( 'Icon Border Color', 'testimonial-pro' ),
					'desc'       => __( 'Set social icon border color.', 'testimonial-pro' ),
					'default'    => '#dddddd',
					'dependency' => array(
						'social_profile',
						'==',
						'true'
					),
				),
				array(
					'id'         => 'social_profile_icon_hover_border_color',
					'type'       => 'color_picker',
					'title'      => __( 'Icon Hover Border Color', 'testimonial-pro' ),
					'desc'       => __( 'Set social icon hover border color.', 'testimonial-pro' ),
					'default'    => '#52b3d9',
					'dependency' => array(
						'social_profile',
						'==',
						'true'
					),
				),

				array(
					'type'    => 'subheading',
					'content' => __( 'Image Settings', 'testimonial-pro' ),
				),
				array(
					'id'      => 'client_image',
					'type'    => 'switcher',
					'title'   => __( 'Image', 'testimonial-pro' ),
					'desc'    => __( 'Show/Hide image.', 'testimonial-pro' ),
					'default' => true,
				),
				array(
					'id'         => 'thumbnail_slider',
					'type'       => 'checkbox',
					'title'      => __( 'Enable Thumbnail Slider', 'testimonial-pro' ),
					'desc'       => __( 'Check to enable thumbnail slider.', 'testimonial-pro' ),
					'default'    => false,
					'dependency' => array(
						'layout|theme_style|client_image',
						'==|==|==',
						'slider|theme-one|true'
					),
				),
				array(
					'id'         => 'client_image_position',
					'type'       => 'select',
					'title'      => __( 'Image Position', 'testimonial-pro' ),
					'desc'       => __( 'Select image position.', 'testimonial-pro' ),
					'options'    => array(
						'left'   => __( 'Left', 'testimonial-pro' ),
						'center' => __( 'Center', 'testimonial-pro' ),
						'right'  => __( 'Right', 'testimonial-pro' ),
					),
					'default'    => 'center',
					'class'      => 'chosen',
					'dependency' => array(
						'client_image|theme_style|thumbnail_slider',
						'==|any|!=',
						'true|theme-one,theme-eight,theme-ten|true'
					),
				),
				array(
					'id'         => 'client_image_position_two',
					'type'       => 'select',
					'title'      => __( 'Image Position', 'testimonial-pro' ),
					'desc'       => __( 'Select image position.', 'testimonial-pro' ),
					'options'    => array(
						'left'   => __( 'Left', 'testimonial-pro' ),
						'right'  => __( 'Right', 'testimonial-pro' ),
						'top'    => __( 'Top', 'testimonial-pro' ),
						'bottom' => __( 'Bottom', 'testimonial-pro' ),
					),
					'default'    => 'left',
					'class'      => 'chosen',
					'dependency' => array(
						'client_image|theme_style',
						'==|any',
						'true|theme-two,theme-four,theme-five'
					),
				),
				array(
					'id'         => 'client_image_position_three',
					'type'       => 'select',
					'title'      => __( 'Image Position', 'testimonial-pro' ),
					'desc'       => __( 'Select image position.', 'testimonial-pro' ),
					'options'    => array(
						'left-top'     => __( 'Left Top', 'testimonial-pro' ),
						'left-bottom'  => __( 'Left Bottom', 'testimonial-pro' ),
						'right-top'    => __( 'Right Top', 'testimonial-pro' ),
						'right-bottom' => __( 'Right Bottom', 'testimonial-pro' ),
						'top-left'     => __( 'Top Left', 'testimonial-pro' ),
						'top-right'    => __( 'Top Right', 'testimonial-pro' ),
						'bottom-left'  => __( 'Bottom Left', 'testimonial-pro' ),
						'bottom-right' => __( 'Bottom Right', 'testimonial-pro' ),
					),
					'default'    => 'left-top',
					'class'      => 'chosen',
					'dependency' => array(
						'client_image|theme_style',
						'==|any',
						'true|theme-three,theme-six'
					),
				),
				array(
					'id'         => 'client_image_margin',
					'type'       => 'margin',
					'title'      => __( 'Margin', 'testimonial-pro' ),
					'desc'       => __( 'Set margin for reviewer image.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '0',
						'top'    => '0',
						'bottom' => '22',
						'right'  => '0'
					),
					'dependency' => array(
						'client_image|theme_style',
						'==|any',
						'true|theme-one,theme-eight,theme-ten'
					),
				),
				array(
					'id'         => 'client_image_margin_tow',
					'type'       => 'margin',
					'title'      => __( 'Margin', 'testimonial-pro' ),
					'desc'       => __( 'Set margin for reviewer image.', 'testimonial-pro' ),
					'default'    => array(
						'left'   => '0',
						'top'    => '0',
						'bottom' => '0',
						'right'  => '22'
					),
					'dependency' => array(
						'client_image|theme_style',
						'==|any',
						'true|theme-nine'
					),
				),
				array(
					'id'         => 'client_image_style',
					'type'       => 'image_select',
					'title'      => __( 'Choose a Style', 'testimonial-pro' ),
					'desc'       => __( 'Choose a image style.', 'testimonial-pro' ),
					'options'    => array(
						'one'   => SP_TPRO_URL . 'admin/views/metabox/assets/images/img-1.png',
						'two'   => SP_TPRO_URL . 'admin/views/metabox/assets/images/img-2.png',
						'three' => SP_TPRO_URL . 'admin/views/metabox/assets/images/img-3.png',
					),
					'attributes' => array(
						'data-depend-id' => 'client_image_style',
					),
					'default'    => 'one',
					'radio'      => true,
					'dependency' => array(
						'client_image',
						'==',
						'true'
					),
				),
				array(
					'id'         => 'client_image_border_shadow',
					'type'       => 'radio',
					'title'      => __( 'Border or Box-Shadow?', 'testimonial-pro' ),
					'desc'       => __( 'Select image border or box-shadow option.', 'testimonial-pro' ),
					'options'    => array(
						'border'     => 'Border',
						'box_shadow' => 'Box-Shadow',
					),
					'default'    => 'border',
					'attributes' => array(
						'data-depend-id' => 'client_image_border_shadow',
					),
					'dependency' => array(
						'client_image',
						'==',
						'true'
					),
				),
				array(
					'id'         => 'client_image_bg',
					'type'       => 'color_picker',
					'title'      => __( 'Background', 'testimonial-pro' ),
					'desc'       => __( 'Set image background color.', 'testimonial-pro' ),
					'default'    => '#ffffff',
					'dependency' => array(
						'client_image',
						'==',
						'true'
					),
				),
				array(
					'id'         => 'client_image_padding',
					'type'       => 'number',
					'title'      => __( 'Padding', 'testimonial-pro' ),
					'desc'       => __( 'Set image padding.', 'testimonial-pro' ),
					'after'      => __( '(px)', 'testimonial-pro' ),
					'default'    => '0',
					'dependency' => array(
						'client_image',
						'==',
						'true'
					),
				),
				array(
					'id'         => 'client_image_border_size',
					'type'       => 'number',
					'title'      => __( 'Border Thickness', 'testimonial-pro' ),
					'desc'       => __( 'Set image border thickness.', 'testimonial-pro' ),
					'after'      => __( '(px)', 'testimonial-pro' ),
					'default'    => '0',
					'dependency' => array(
						'client_image|client_image_border_shadow',
						'==|==',
						'true|border'
					),
				),
				array(
					'id'         => 'client_image_border_color',
					'type'       => 'color_picker',
					'title'      => __( 'Border Color', 'testimonial-pro' ),
					'desc'       => __( 'Set image border color.', 'testimonial-pro' ),
					'default'    => '#dddddd',
					'dependency' => array(
						'client_image|client_image_border_shadow',
						'==|==',
						'true|border'
					),
				),
				array(
					'id'         => 'client_image_box_shadow_color',
					'type'       => 'color_picker',
					'title'      => __( 'Box-Shadow Color', 'testimonial-pro' ),
					'desc'       => __( 'Set image box-shadow color.', 'testimonial-pro' ),
					'default'    => '#888888',
					'dependency' => array(
						'client_image|client_image_border_shadow',
						'==|==',
						'true|box_shadow'
					),
				),

				array(
					'id'         => 'video_icon_color',
					'type'       => 'color_picker',
					'title'      => __( 'Video Icon Color', 'testimonial-pro' ),
					'desc'       => __( 'Set video testimonial icon color.', 'testimonial-pro' ),
					'default'    => '#e2e2e2',
					'dependency' => array(
						'client_image|thumbnail_slider',
						'==|!=',
						'true|true'
					),
				),

				array(
					'id'         => 'video_icon_overlay',
					'type'       => 'color_picker',
					'title'      => __( 'Video Icon Overlay Color', 'testimonial-pro' ),
					'desc'       => __( 'Set video testimonial icon overlay color.', 'testimonial-pro' ),
					'default'    => 'rgba(51, 51, 51, 0.4)',
					'dependency' => array(
						'client_image|thumbnail_slider',
						'==|!=',
						'true|true'
					),
				),

				array(
					'id'         => 'client_image_width',
					'type'       => 'number',
					'title'      => __( 'Width', 'testimonial-pro' ),
					'desc'       => __( 'Maximum width of the reviewer image.', 'testimonial-pro' ),
					'after'      => __( '(px)', 'testimonial-pro' ),
					'default'    => '120',
					'dependency' => array(
						'client_image',
						'==',
						'true'
					),
				),
				array(
					'id'         => 'client_image_height',
					'type'       => 'number',
					'title'      => __( 'Height', 'testimonial-pro' ),
					'desc'       => __( 'Maximum height of the reviewer image.', 'testimonial-pro' ),
					'after'      => __( '(px)', 'testimonial-pro' ),
					'default'    => '120',
					'dependency' => array(
						'client_image',
						'==',
						'true'
					),
				),
				array(
					'id'         => 'client_image_crop',
					'type'       => 'switcher',
					'title'      => __( 'Crop', 'testimonial-pro' ),
					'desc'       => __( 'Hard cropping all the images equally.', 'testimonial-pro' ),
					'default'    => true,
					'dependency' => array(
						'client_image',
						'==',
						'true'
					),
				),
				array(
					'type'       => 'notice',
					'class'      => 'info',
					'content'    => __( 'Upload the images equal or larger than your desired crop size.', 'testimonial-pro' ),
					'dependency' => array(
						'client_image_crop|client_image',
						'==|==',
						'true|true'
					),
				),


			), // End Fields
		),
		// end: a section
		// begin: a section
		array(
			'name'   => 'sp_tpro_shortcode_option_4',
			'title'  => __( 'Typography', 'testimonial-pro' ),
			'icon'   => 'fa fa-font',

			// begin: fields
			'fields' => array(
				array(
					'id'         => 'section_title_font_load',
					'type'       => 'switcher',
					'title'      => __( 'Load Section Title Font', 'post-carousel-pro' ),
					'desc'       => __( 'On/Off google font for the section title.', 'post-carousel-pro' ),
					'default'    => true,
				),
				array(
					'id'           => 'section_title_typography',
					'type'         => 'typography_advanced',
					'title'        => __( 'Section Title Font', 'testimonial-pro' ),
					'desc'         => __( 'Set testimonial section title font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => '600',
						'font'      => 'google',
						'size'      => '22',
						'height'    => '22',
						'alignment' => 'center',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#444444'
					),
					'color'        => true,
					'hover_color'  => false,
					'preview'      => true,
					'preview_text' => 'What Our Customers Saying',//Replace preview text with any text you like.
				),
				array(
					'id'         => 'testimonial_title_font_load',
					'type'       => 'switcher',
					'title'      => __( 'Load Testimonial Title Font', 'post-carousel-pro' ),
					'desc'       => __( 'On/Off google font for the testimonial tagline or title.', 'post-carousel-pro' ),
					'default'    => true,
				),
				array(
					'id'           => 'testimonial_title_typography',
					'type'         => 'typography_advanced',
					'title'        => __( 'Testimonial Title Font', 'testimonial-pro' ),
					'desc'         => __( 'Set testimonial tagline or title font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => '600',
						'font'      => 'google',
						'size'      => '20',
						'height'    => '30',
						'alignment' => 'center',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#333333',
						//'hover_color' => '#e44646'
					),
					'color'        => true,
					//'hover_color'  => true,
					'preview'      => true,
					'preview_text' => 'The Testimonial Title',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-one,theme-two,theme-four,theme-ten'
					),
				),
				array(
					'id'           => 'testimonial_title_typography_two',
					'type'         => 'typography_advanced',
					'title'        => __( 'Testimonial Title Font', 'testimonial-pro' ),
					'desc'         => __( 'Set testimonial tagline or title font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => '600',
						'font'      => 'google',
						'size'      => '20',
						'height'    => '30',
						'alignment' => 'left',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#333333',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => 'The Testimonial Title',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-three,theme-five,theme-six'
					),
				),
				array(
					'id'           => 'testimonial_title_typography_three',
					'type'         => 'typography_advanced',
					'title'        => __( 'Testimonial Title Font', 'testimonial-pro' ),
					'desc'         => __( 'Set testimonial tagline or title font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => '600',
						'font'      => 'google',
						'size'      => '20',
						'height'    => '30',
						'alignment' => 'left',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#ffffff',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => 'The Testimonial Title',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-seven,theme-nine'
					),
				),
				array(
					'id'           => 'testimonial_title_typography_four',
					'type'         => 'typography_advanced',
					'title'        => __( 'Testimonial Title Font', 'testimonial-pro' ),
					'desc'         => __( 'Set testimonial tagline or title font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => '600',
						'font'      => 'google',
						'size'      => '20',
						'height'    => '30',
						'alignment' => 'center',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#ffffff',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => 'The Testimonial Title',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-eight'
					),
				),
				array(
					'id'         => 'testimonial_text_font_load',
					'type'       => 'switcher',
					'title'      => __( 'Load Testimonial Content Font', 'post-carousel-pro' ),
					'desc'       => __( 'On/Off google font for the testimonial content.', 'post-carousel-pro' ),
					'default'    => true,
				),
				array(
					'id'         => 'testimonial_text_typography',
					'type'       => 'typography_advanced',
					'title'      => __( 'Testimonial Content Font', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial content font properties.', 'testimonial-pro' ),
					'default'    => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '16',
						'height'    => '26',
						'alignment' => 'center',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#333333',
					),
					'color'      => true,
					'preview'    => true,
					'dependency' => array(
						'theme_style',
						'any',
						'theme-one,theme-two,theme-four,theme-ten'
					),
				),
				array(
					'id'         => 'testimonial_text_typography_two',
					'type'       => 'typography_advanced',
					'title'      => __( 'Testimonial Content Font', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial content font properties.', 'testimonial-pro' ),
					'default'    => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '16',
						'height'    => '26',
						'alignment' => 'left',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#333333',
					),
					'color'      => true,
					'preview'    => true,
					'dependency' => array(
						'theme_style',
						'any',
						'theme-three,theme-five,theme-six'
					),
				),
				array(
					'id'         => 'testimonial_text_typography_three',
					'type'       => 'typography_advanced',
					'title'      => __( 'Testimonial Content Font', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial content font properties.', 'testimonial-pro' ),
					'default'    => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '16',
						'height'    => '26',
						'alignment' => 'left',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#ffffff',
					),
					'color'      => true,
					'preview'    => true,
					'dependency' => array(
						'theme_style',
						'any',
						'theme-seven,theme-nine'
					),
				),
				array(
					'id'         => 'testimonial_text_typography_four',
					'type'       => 'typography_advanced',
					'title'      => __( 'Testimonial Content Font', 'testimonial-pro' ),
					'desc'       => __( 'Set testimonial content font properties.', 'testimonial-pro' ),
					'default'    => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '16',
						'height'    => '26',
						'alignment' => 'center',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#ffffff',
					),
					'color'      => true,
					'preview'    => true,
					'dependency' => array(
						'theme_style',
						'any',
						'theme-eight'
					),
				),
				array(
					'id'         => 'client_name_font_load',
					'type'       => 'switcher',
					'title'      => __( 'Load Name Font', 'post-carousel-pro' ),
					'desc'       => __( 'On/Off google font for the name.', 'post-carousel-pro' ),
					'default'    => true,
				),
				array(
					'id'           => 'client_name_typography',
					'type'         => 'typography_advanced',
					'title'        => __( 'Name Font', 'testimonial-pro' ),
					'desc'         => __( 'Set name font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => '700',
						'font'      => 'google',
						'size'      => '16',
						'height'    => '24',
						'alignment' => 'center',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#333333',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => 'Jacob Firebird',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-one,theme-two,theme-four,theme-eight,theme-ten'
					),
				),
				array(
					'id'           => 'client_name_typography_two',
					'type'         => 'typography_advanced',
					'title'        => __( 'Name Font', 'testimonial-pro' ),
					'desc'         => __( 'Set name font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => '700',
						'font'      => 'google',
						'size'      => '16',
						'height'    => '24',
						'alignment' => 'left',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#333333',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => 'Jacob Firebird',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-three,theme-five,theme-six,theme-seven,theme-nine'
					),
				),
				array(
					'id'         => 'designation_company_font_load',
					'type'       => 'switcher',
					'title'      => __( 'Load Identity or Position & Company Name Font', 'post-carousel-pro' ),
					'desc'       => __( 'On/Off google font for the identity or position & company name.', 'post-carousel-pro' ),
					'default'    => true,
				),
				array(
					'id'           => 'client_designation_company_typography',
					'type'         => 'typography_advanced',
					'title'        => __( 'Identity or Position & Company Name Font', 'testimonial-pro' ),
					'desc'         => __( 'Set identity or position & company name font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '16',
						'height'    => '24',
						'alignment' => 'center',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#444444',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => 'CEO - Firebird Media Inc.',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-one,theme-two,theme-four,theme-eight,theme-ten'
					),
				),
				array(
					'id'           => 'client_designation_company_typography_two',
					'type'         => 'typography_advanced',
					'title'        => __( 'Identity or Position & Company Name Font', 'testimonial-pro' ),
					'desc'         => __( 'Set identity or position & company name font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '16',
						'height'    => '24',
						'alignment' => 'left',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#444444',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => 'CEO - Firebird Media Inc.',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-three,theme-five,theme-six,theme-seven,theme-nine'
					),
				),
				array(
					'id'         => 'location_font_load',
					'type'       => 'switcher',
					'title'      => __( 'Load Location Font', 'post-carousel-pro' ),
					'desc'       => __( 'On/Off google font for the location.', 'post-carousel-pro' ),
					'default'    => true,
				),
				array(
					'id'           => 'client_location_typography',
					'type'         => 'typography_advanced',
					'title'        => __( 'Location Font', 'testimonial-pro' ),
					'desc'         => __( 'Set location font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '15',
						'height'    => '20',
						'alignment' => 'center',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#444444',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => 'Los Angeles',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-one,theme-two,theme-four,theme-eight,theme-ten'
					),
				),
				array(
					'id'           => 'client_location_typography_two',
					'type'         => 'typography_advanced',
					'title'        => __( 'Location Font', 'testimonial-pro' ),
					'desc'         => __( 'Set location font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '15',
						'height'    => '20',
						'alignment' => 'left',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#444444',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => 'Los Angeles',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-three,theme-five,theme-six,theme-seven,theme-nine'
					),
				),
				array(
					'id'         => 'phone_font_load',
					'type'       => 'switcher',
					'title'      => __( 'Load Phone or Mobile Font', 'post-carousel-pro' ),
					'desc'       => __( 'On/Off google font for the phone or mobile.', 'post-carousel-pro' ),
					'default'    => true,
				),
				array(
					'id'           => 'client_phone_typography',
					'type'         => 'typography_advanced',
					'title'        => __( 'Phone or Mobile Font', 'testimonial-pro' ),
					'desc'         => __( 'Set phone or mobile font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '15',
						'height'    => '20',
						'alignment' => 'center',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#444444',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => '+1 234567890',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-one,theme-two,theme-four,theme-eight,theme-ten'
					),
				),
				array(
					'id'           => 'client_phone_typography_two',
					'type'         => 'typography_advanced',
					'title'        => __( 'Phone or Mobile Font', 'testimonial-pro' ),
					'desc'         => __( 'Set phone or mobile font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '15',
						'height'    => '20',
						'alignment' => 'left',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#444444',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => '+1 234567890',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-three,theme-five,theme-six,theme-seven,theme-nine'
					),
				),
				array(
					'id'         => 'email_font_load',
					'type'       => 'switcher',
					'title'      => __( 'Load Email Address Font', 'post-carousel-pro' ),
					'desc'       => __( 'On/Off google font for the email address.', 'post-carousel-pro' ),
					'default'    => true,
				),
				array(
					'id'           => 'client_email_typography',
					'type'         => 'typography_advanced',
					'title'        => __( 'Email Address Font', 'testimonial-pro' ),
					'desc'         => __( 'Set email address font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '15',
						'height'    => '20',
						'alignment' => 'center',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#444444',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => 'mail@yourwebsite.com',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-one,theme-two,theme-four,theme-eight,theme-ten'
					),
				),
				array(
					'id'           => 'client_email_typography_two',
					'type'         => 'typography_advanced',
					'title'        => __( 'Email Address Font', 'testimonial-pro' ),
					'desc'         => __( 'Set email address font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '15',
						'height'    => '20',
						'alignment' => 'left',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#444444',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => 'mail@yourwebsite.com',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-three,theme-five,theme-six,theme-seven,theme-nine'
					),
				),
				array(
					'id'         => 'date_font_load',
					'type'       => 'switcher',
					'title'      => __( 'Load Date Font', 'post-carousel-pro' ),
					'desc'       => __( 'On/Off google font for the date.', 'post-carousel-pro' ),
					'default'    => true,
				),
				array(
					'id'           => 'testimonial_date_typography',
					'type'         => 'typography_advanced',
					'title'        => __( 'Date Font', 'testimonial-pro' ),
					'desc'         => __( 'Set date font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '15',
						'height'    => '20',
						'alignment' => 'center',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#444444',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => 'February 21, 2018',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-one,theme-two,theme-four,theme-eight,theme-ten'
					),
				),
				array(
					'id'           => 'testimonial_date_typography_two',
					'type'         => 'typography_advanced',
					'title'        => __( 'Date Font', 'testimonial-pro' ),
					'desc'         => __( 'Set date font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '15',
						'height'    => '20',
						'alignment' => 'left',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#444444',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => 'May 15, 2018',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-three,theme-five,theme-six,theme-seven,theme-nine'
					),
				),
				array(
					'id'         => 'website_font_load',
					'type'       => 'switcher',
					'title'      => __( 'Load Website Font', 'post-carousel-pro' ),
					'desc'       => __( 'On/Off google font for the website.', 'post-carousel-pro' ),
					'default'    => true,
				),
				array(
					'id'           => 'client_website_typography',
					'type'         => 'typography_advanced',
					'title'        => __( 'Website Font', 'testimonial-pro' ),
					'desc'         => __( 'Set website font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '15',
						'height'    => '20',
						'alignment' => 'center',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#444444',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => 'www.yourwebsite.com',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-one,theme-two,theme-four,theme-eight,theme-ten'
					),
				),
				array(
					'id'           => 'client_website_typography_two',
					'type'         => 'typography_advanced',
					'title'        => __( 'Website Font', 'testimonial-pro' ),
					'desc'         => __( 'Set website font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '15',
						'height'    => '20',
						'alignment' => 'left',
						'transform' => 'none',
						'spacing'   => 'normal',
						'color'     => '#444444',
					),
					'color'        => true,
					'preview'      => true,
					'preview_text' => 'www.yourwebsite.com',//Replace preview text with any text you like.
					'dependency'   => array(
						'theme_style',
						'any',
						'theme-three,theme-five,theme-six,theme-seven,theme-nine'
					),
				),
				array(
					'id'         => 'filter_font_load',
					'type'       => 'switcher',
					'title'      => __( 'Load Filter Font', 'post-carousel-pro' ),
					'desc'       => __( 'On/Off google font for the filter.', 'post-carousel-pro' ),
					'default'    => true,
					'dependency'   => array(
						'layout',
						'any',
						'filter_grid,filter_masonry'
					),
				),
				array(
					'id'           => 'filter_typography',
					'type'         => 'typography_advanced',
					'title'        => __( 'Filter Font', 'testimonial-pro' ),
					'desc'         => __( 'Set filter font properties.', 'testimonial-pro' ),
					'default'      => array(
						'family'    => 'Open Sans',
						'variant'   => 'regular',
						'font'      => 'google',
						'size'      => '15',
						'height'    => '20',
						'alignment' => 'center',
						'transform' => 'none',
						'spacing'   => 'normal',
					),
					'color'        => false,
					'preview'      => true,
					'preview_text' => 'All',//Replace preview text with any text you like.
					'dependency'   => array(
						'layout',
						'any',
						'filter_grid,filter_masonry'
					),
				),

			), // end: fields
		), // end: Typography section
		// end: a section

	),
);

// -----------------------------------------
// Testimonial Meta Options
// -----------------------------------------
$options[] = array(
	'id'        => 'sp_tpro_meta_options',
	'title'     => __( 'Testimonial Options', 'testimonial-pro' ),
	'post_type' => 'spt_testimonial',
	'context'   => 'normal',
	'priority'  => 'default',
	'sections'  => array(

		// begin: a section
		array(
			'name'   => 'sp_tpro_meta_option_1',
			'title'  => __( 'Reviewer Information', 'testimonial-pro' ),

			// begin: fields
			'fields' => array(

				// begin: a field
				array(
					'id'    => 'tpro_name',
					'type'  => 'text',
					'title' => __( 'Name', 'testimonial-pro' ),
					'desc'  => __( 'Type reviewer name here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_email',
					'type'  => 'text',
					'title' => __( 'E-mail Address', 'testimonial-pro' ),
					'desc'  => __( 'Type E-mail address here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_designation',
					'type'  => 'text',
					'title' => __( 'Identity or Position', 'testimonial-pro' ),
					'desc'  => __( 'Type reviewer identity or position here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_company_name',
					'type'  => 'text',
					'title' => __( 'Company Name', 'testimonial-pro' ),
					'desc'  => __( 'Type company name here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_location',
					'type'  => 'text',
					'title' => __( 'Location', 'testimonial-pro' ),
					'desc'  => __( 'Type location here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_phone',
					'type'  => 'text',
					'title' => __( 'Phone or Mobile', 'testimonial-pro' ),
					'desc'  => __( 'Type phone or mobile number here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_website',
					'type'  => 'text',
					'title' => __( 'Website URL', 'testimonial-pro' ),
					'desc'  => __( 'Type website URL here.', 'testimonial-pro' ),
				),

				array(
					'id'    => 'tpro_video_url',
					'type'  => 'text',
					'title' => __( 'Video Testimonial URL', 'testimonial-pro' ),
					'desc'  => __( 'Type video testimonial URL here.', 'testimonial-pro' ),
				),

				array(
					'id'      => 'tpro_rating',
					'type'    => 'rating',
					'title'   => __( 'Rating Star', 'testimonial-pro' ),
					'desc'    => __( 'Rating star along with testimonial.', 'testimonial-pro' ),
					'options' => array(
						'five_star'  => __( '5 Stars', 'testimonial-pro' ),
						'four_star'  => __( '4 Stars', 'testimonial-pro' ),
						'three_star' => __( '3 Stars', 'testimonial-pro' ),
						'two_star'   => __( '2 Stars', 'testimonial-pro' ),
						'one_star'   => __( '1 Star', 'testimonial-pro' ),
					),
					'default' => '',
				),
			), // end: fields
		), // end: a section

		// begin: a section
		array(
			'name'   => 'sp_tpro_meta_option_2',
			'title'  => __( 'Social Profiles', 'testimonial-pro' ),

			// begin: fields
			'fields' => array(

				// begin: a field
				array(
					'id'    => 'tpro_social_facebook_url',
					'type'  => 'text',
					'title' => __( 'Facebook', 'testimonial-pro' ),
					'desc'  => __( 'Type facebook URL here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_social_twitter_url',
					'type'  => 'text',
					'title' => __( 'Twitter', 'testimonial-pro' ),
					'desc'  => __( 'Type twitter URL here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_social_google_plus_url',
					'type'  => 'text',
					'title' => __( 'Google Plus', 'testimonial-pro' ),
					'desc'  => __( 'Type google plus URL here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_social_linked_in_url',
					'type'  => 'text',
					'title' => __( 'LinkedIn', 'testimonial-pro' ),
					'desc'  => __( 'Type linkedin URL here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_social_instagram_url',
					'type'  => 'text',
					'title' => __( 'Instagram', 'testimonial-pro' ),
					'desc'  => __( 'Type Instagram URL here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_social_youtube_url',
					'type'  => 'text',
					'title' => __( 'YouTube', 'testimonial-pro' ),
					'desc'  => __( 'Type youtube URL here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_social_pinterest_url',
					'type'  => 'text',
					'title' => __( 'Pinterest', 'testimonial-pro' ),
					'desc'  => __( 'Type pinterest URL here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_social_skype_url',
					'type'  => 'text',
					'title' => __( 'Skype', 'testimonial-pro' ),
					'desc'  => __( 'Type skype URL here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_social_stumble_upon_url',
					'type'  => 'text',
					'title' => __( 'StumbleUpon', 'testimonial-pro' ),
					'desc'  => __( 'Type stumbleupon URL here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_social_reddit_url',
					'type'  => 'text',
					'title' => __( 'Reddit', 'testimonial-pro' ),
					'desc'  => __( 'Type reddit URL here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_social_dribbble_url',
					'type'  => 'text',
					'title' => __( 'Dribbble', 'testimonial-pro' ),
					'desc'  => __( 'Type dribbble URL here.', 'testimonial-pro' ),
				),
				array(
					'id'    => 'tpro_social_snapchat_url',
					'type'  => 'text',
					'title' => __( 'SnapChat', 'testimonial-pro' ),
					'desc'  => __( 'Type snapchat URL here.', 'testimonial-pro' ),
				),

			), // end: fields
		), // end: a section

	),
);


SP_TPRO_Framework_Metabox::instance( $options );