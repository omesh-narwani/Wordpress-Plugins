<?php if ( ! defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.
/**
 *
 * Framework admin enqueue style and scripts
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'sp_tpro_admin_enqueue_scripts' ) ) {
	function sp_tpro_admin_enqueue_scripts() {
		$current_screen        = get_current_screen();
		$the_current_post_type = $current_screen->post_type;
		if ( $the_current_post_type == 'sp_tpro_shortcodes' || $the_current_post_type == 'spt_testimonial' ) {

			// admin utilities
			wp_enqueue_media();

			// wp core styles
			wp_enqueue_style( 'wp-color-picker' );
			wp_enqueue_style( 'wp-jquery-ui-dialog' );

			// framework core styles
			wp_enqueue_style( 'sp-tpro-framework', SP_TPRO_URL . 'admin/views/metabox/assets/css/sp-framework.css', array(),	SP_TPRO_VERSION, 'all' );
			wp_enqueue_style( 'sp-tpro-custom', SP_TPRO_URL . 'admin/views/metabox/assets/css/sp-custom.css', array(), SP_TPRO_VERSION, 'all' );
			wp_enqueue_style( 'tpro-style', SP_TPRO_URL . 'admin/views/metabox/assets/css/sp-style.css', array(), SP_TPRO_VERSION, 'all' );
			wp_enqueue_style( 'tpro-font-awesome', SP_TPRO_URL . 'public/assets/css/font-awesome.min.css', array(), SP_TPRO_VERSION, 'all' );

			if ( is_rtl() ) {
				wp_enqueue_style( 'sp-framework-rtl', SP_TPRO_URL . 'admin/views/metabox/assets/css/sp-framework-rtl.css', array(), SP_TPRO_VERSION, 'all' );
			}

			// wp core scripts
			wp_enqueue_script( 'wp-color-picker' );
			wp_enqueue_script( 'jquery-ui-dialog' );
			// wp_enqueue_script( 'jquery-ui-sortable' );

			// framework core scripts
			wp_enqueue_script( 'sp-tpro-dependency', SP_TPRO_URL . 'admin/views/metabox/assets/js/dependency.js', array('jquery'), SP_TPRO_VERSION, true );
			wp_enqueue_script( 'sp-tpro-plugins', SP_TPRO_URL . 'admin/views/metabox/assets/js/sp-plugins.js', array(), SP_TPRO_VERSION, true );
			wp_enqueue_script( 'sp-tpro-framework', SP_TPRO_URL . 'admin/views/metabox/assets/js/sp-framework.js', array( 'sp-tpro-plugins' ), SP_TPRO_VERSION, true );
		}

	}

	add_action( 'admin_enqueue_scripts', 'sp_tpro_admin_enqueue_scripts' );
}