<?php
$testimonial_date_weight = '400';
$testimonial_date_style = 'normal';

switch ($testimonial_date_typography['variant']) {
	case '100':
		$testimonial_date_weight = '100';
		break;
	case '100italic':
		$testimonial_date_weight = '100';
		$testimonial_date_style = 'italic';
		break;
	case '200':
		$testimonial_date_weight = '200';
		break;
	case '200italic':
		$testimonial_date_weight = '200';
		$testimonial_date_style = 'italic';
		break;
	case '300':
		$testimonial_date_weight = '300';
		break;
	case '300italic':
		$testimonial_date_weight = '300';
		$testimonial_date_style = 'italic';
		break;
	case '500':
		$testimonial_date_weight = '500';
		break;
	case '500italic':
		$testimonial_date_weight = '500';
		$testimonial_date_style = 'italic';
		break;
	case '600':
		$testimonial_date_weight = '600';
		break;
	case '600italic':
		$testimonial_date_weight = '600';
		$testimonial_date_style = 'italic';
		break;
	case '700':
		$testimonial_date_weight = '700';
		break;
	case '700italic':
		$testimonial_date_weight = '700';
		$testimonial_date_style = 'italic';
		break;
	case '800':
		$testimonial_date_weight = '800';
		break;
	case '800italic':
		$testimonial_date_weight = '800';
		$testimonial_date_style = 'italic';
		break;
	case '900':
		$testimonial_date_weight = '900';
		break;
	case '900italic':
		$testimonial_date_weight = '900';
		$testimonial_date_style = 'italic';
		break;
	case 'italic':
		$testimonial_date_style = 'italic';
		break;
}

$testimonial_date_weight_two = '400';
$testimonial_date_style_two = 'normal';

switch ($testimonial_date_typography_two['variant']) {
	case '100':
		$testimonial_date_weight_two = '100';
		break;
	case '100italic':
		$testimonial_date_weight_two = '100';
		$testimonial_date_style_two = 'italic';
		break;
	case '200':
		$testimonial_date_weight_two = '200';
		break;
	case '200italic':
		$testimonial_date_weight_two = '200';
		$testimonial_date_style_two = 'italic';
		break;
	case '300':
		$testimonial_date_weight_two = '300';
		break;
	case '300italic':
		$testimonial_date_weight_two = '300';
		$testimonial_date_style_two = 'italic';
		break;
	case '500':
		$testimonial_date_weight_two = '500';
		break;
	case '500italic':
		$testimonial_date_weight_two = '500';
		$testimonial_date_style_two = 'italic';
		break;
	case '600':
		$testimonial_date_weight_two = '600';
		break;
	case '600italic':
		$testimonial_date_weight_two = '600';
		$testimonial_date_style_two = 'italic';
		break;
	case '700':
		$testimonial_date_weight_two = '700';
		break;
	case '700italic':
		$testimonial_date_weight_two = '700';
		$testimonial_date_style_two = 'italic';
		break;
	case '800':
		$testimonial_date_weight_two = '800';
		break;
	case '800italic':
		$testimonial_date_weight_two = '800';
		$testimonial_date_style_two = 'italic';
		break;
	case '900':
		$testimonial_date_weight_two = '900';
		break;
	case '900italic':
		$testimonial_date_weight_two = '900';
		$testimonial_date_style_two = 'italic';
		break;
	case 'italic':
		$testimonial_date_style_two = 'italic';
		break;
}