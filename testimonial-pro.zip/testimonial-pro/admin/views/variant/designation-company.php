<?php
$client_designation_company_weight = '400';
$client_designation_company_style = 'normal';

switch ($client_designation_company_typography['variant']) {
	case '100':
		$client_designation_company_weight = '100';
		break;
	case '100italic':
		$client_designation_company_weight = '100';
		$client_designation_company_style = 'italic';
		break;
	case '200':
		$client_designation_company_weight = '200';
		break;
	case '200italic':
		$client_designation_company_weight = '200';
		$client_designation_company_style = 'italic';
		break;
	case '300':
		$client_designation_company_weight = '300';
		break;
	case '300italic':
		$client_designation_company_weight = '300';
		$client_designation_company_style = 'italic';
		break;
	case '500':
		$client_designation_company_weight = '500';
		break;
	case '500italic':
		$client_designation_company_weight = '500';
		$client_designation_company_style = 'italic';
		break;
	case '600':
		$client_designation_company_weight = '600';
		break;
	case '600italic':
		$client_designation_company_weight = '600';
		$client_designation_company_style = 'italic';
		break;
	case '700':
		$client_designation_company_weight = '700';
		break;
	case '700italic':
		$client_designation_company_weight = '700';
		$client_designation_company_style = 'italic';
		break;
	case '800':
		$client_designation_company_weight = '800';
		break;
	case '800italic':
		$client_designation_company_weight = '800';
		$client_designation_company_style = 'italic';
		break;
	case '900':
		$client_designation_company_weight = '900';
		break;
	case '900italic':
		$client_designation_company_weight = '900';
		$client_designation_company_style = 'italic';
		break;
	case 'italic':
		$client_designation_company_style = 'italic';
		break;
}

$client_designation_company_weight_two = '400';
$client_designation_company_style_two = 'normal';

switch ($client_designation_company_typography_two['variant']) {
	case '100':
		$client_designation_company_weight_two = '100';
		break;
	case '100italic':
		$client_designation_company_weight_two = '100';
		$client_designation_company_style_two = 'italic';
		break;
	case '200':
		$client_designation_company_weight_two = '200';
		break;
	case '200italic':
		$client_designation_company_weight_two = '200';
		$client_designation_company_style_two = 'italic';
		break;
	case '300':
		$client_designation_company_weight_two = '300';
		break;
	case '300italic':
		$client_designation_company_weight_two = '300';
		$client_designation_company_style_two = 'italic';
		break;
	case '500':
		$client_designation_company_weight_two = '500';
		break;
	case '500italic':
		$client_designation_company_weight_two = '500';
		$client_designation_company_style_two = 'italic';
		break;
	case '600':
		$client_designation_company_weight_two = '600';
		break;
	case '600italic':
		$client_designation_company_weight_two = '600';
		$client_designation_company_style_two = 'italic';
		break;
	case '700':
		$client_designation_company_weight_two = '700';
		break;
	case '700italic':
		$client_designation_company_weight_two = '700';
		$client_designation_company_style_two = 'italic';
		break;
	case '800':
		$client_designation_company_weight_two = '800';
		break;
	case '800italic':
		$client_designation_company_weight_two = '800';
		$client_designation_company_style_two = 'italic';
		break;
	case '900':
		$client_designation_company_weight_two = '900';
		break;
	case '900italic':
		$client_designation_company_weight_two = '900';
		$client_designation_company_style_two = 'italic';
		break;
	case 'italic':
		$client_designation_company_style_two = 'italic';
		break;
}