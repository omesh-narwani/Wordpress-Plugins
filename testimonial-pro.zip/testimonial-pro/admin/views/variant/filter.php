<?php
$filter_weight = '400';
$filter_style = 'normal';

switch ($filter_typography['variant']) {
	case '100':
		$filter_weight = '100';
		break;
	case '100italic':
		$filter_weight = '100';
		$filter_style = 'italic';
		break;
	case '200':
		$filter_weight = '200';
		break;
	case '200italic':
		$filter_weight = '200';
		$filter_style = 'italic';
		break;
	case '300':
		$filter_weight = '300';
		break;
	case '300italic':
		$filter_weight = '300';
		$filter_style = 'italic';
		break;
	case '500':
		$filter_weight = '500';
		break;
	case '500italic':
		$filter_weight = '500';
		$filter_style = 'italic';
		break;
	case '600':
		$filter_weight = '600';
		break;
	case '600italic':
		$filter_weight = '600';
		$filter_style = 'italic';
		break;
	case '700':
		$filter_weight = '700';
		break;
	case '700italic':
		$filter_weight = '700';
		$filter_style = 'italic';
		break;
	case '800':
		$filter_weight = '800';
		break;
	case '800italic':
		$filter_weight = '800';
		$filter_style = 'italic';
		break;
	case '900':
		$filter_weight = '900';
		break;
	case '900italic':
		$filter_weight = '900';
		$filter_style = 'italic';
		break;
	case 'italic':
		$filter_style = 'italic';
		break;
}