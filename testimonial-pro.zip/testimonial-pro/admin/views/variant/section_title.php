<?php
$section_title_weight = '400';
$section_title_style = 'normal';

switch ($section_title_typography['variant']) {
	case '100':
		$section_title_weight = '100';
		break;
	case '100italic':
		$section_title_weight = '100';
		$section_title_style = 'italic';
		break;
	case '200':
		$section_title_weight = '200';
		break;
	case '200italic':
		$section_title_weight = '200';
		$section_title_style = 'italic';
		break;
	case '300':
		$section_title_weight = '300';
		break;
	case '300italic':
		$section_title_weight = '300';
		$section_title_style = 'italic';
		break;
	case '500':
		$section_title_weight = '500';
		break;
	case '500italic':
		$section_title_weight = '500';
		$section_title_style = 'italic';
		break;
	case '600':
		$section_title_weight = '600';
		break;
	case '600italic':
		$section_title_weight = '600';
		$section_title_style = 'italic';
		break;
	case '700':
		$section_title_weight = '700';
		break;
	case '700italic':
		$section_title_weight = '700';
		$section_title_style = 'italic';
		break;
	case '800':
		$section_title_weight = '800';
		break;
	case '800italic':
		$section_title_weight = '800';
		$section_title_style = 'italic';
		break;
	case '900':
		$section_title_weight = '900';
		break;
	case '900italic':
		$section_title_weight = '900';
		$section_title_style = 'italic';
		break;
	case 'italic':
		$section_title_style = 'italic';
		break;
}