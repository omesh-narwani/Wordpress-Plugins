<?php
/**
 * This is to register the shortcode post type.
 * @package testimonial-pro
 */

if (! defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class SP_TPRO_Shortcode {

    private static $_instance;

    /**
     * SP_TPRO_Shortcode constructor.
     */
    public function __construct() {
        add_filter('init', array($this, 'register_post_type'));
    }

    /**
     * Allows for accessing single instance of class. Class should only be constructed once per call.
     * @return SP_TPRO_Shortcode
     */
    public static function getInstance() {
        if (! self::$_instance) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    /**
     * Shortcode Post Type
     */
    function register_post_type() {
        register_post_type('sp_tpro_shortcodes', array(
            'label'           => __('Generate Shortcode', 'testimonial-pro'),
            'description'     => __('Generate Shortcode for Testimonial', 'testimonial-pro'),
            'public'          => false,
            'has_archive'       => false,
            'publicaly_queryable'   => false,
            'show_ui'         => true,
            'show_in_menu'    => 'edit.php?post_type=spt_testimonial',
            'hierarchical'    => false,
            'query_var'       => false,
            'supports'        => array( 'title' ),
            'capability_type' => 'post',
            'labels'          => array(
                'name'               => __('Testimonial Shortcodes', 'testimonial-pro'),
                'singular_name'      => __('Testimonial Shortcode', 'testimonial-pro'),
                'menu_name'          => __('Shortcode Generator', 'testimonial-pro'),
                'add_new'            => __('Add New', 'testimonial-pro'),
                'add_new_item'       => __('Add New Shortcode', 'testimonial-pro'),
                'edit'               => __('Edit', 'testimonial-pro'),
                'edit_item'          => __('Edit Shortcode', 'testimonial-pro'),
                'new_item'           => __('New Shortcode', 'testimonial-pro'),
                'view'               => __('View Shortcode', 'testimonial-pro'),
                'view_item'          => __('View Shortcode', 'testimonial-pro'),
                'search_items'       => __('Search Shortcode', 'testimonial-pro'),
                'not_found'          => __('No Testimonial Shortcode Found', 'testimonial-pro'),
                'not_found_in_trash' => __('No Testimonial Shortcode Found in Trash', 'testimonial-pro'),
                'parent'             => __('Parent Testimonial Shortcode', 'testimonial-pro'),
            )
        ));
    }
}