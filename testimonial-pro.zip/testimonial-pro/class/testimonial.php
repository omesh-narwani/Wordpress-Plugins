<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class SP_TPRO_Testimonial {

    /**
     * @var
     * @since 2.0
     */
    private static $_instance;

    /**
     * @return SP_TPRO_Testimonial
     * @since 2.0
     */
    public static function getInstance() {
        if ( ! self::$_instance ) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    /**
     * SP_TPRO_Testimonial constructor.
     * @since 1.0
     */
    public function __construct() {
        add_filter('init', array($this, 'register_post_type'));
    }

    /**
     * Register post type
     * @since 1.0
     */
    function register_post_type() {
        register_post_type( 'spt_testimonial', array(
            'label'             => __('Testimonial', 'testimonial-pro'),
            'description'       => __('Testimonial custom post type.', 'testimonial-pro'),
            'taxonomies'        => array(),
            'public'            => false,
            'has_archive'       => false,
            'publicaly_queryable'   => false,
            'show_ui'           => true,
            'show_in_menu'      => true,
            'menu_icon'         => SP_TPRO_URL . '/admin/assets/images/icon-32.png',
            'show_in_nav_menus' => true,
            'show_in_admin_bar' => true,
            'hierarchical'      => false,
            'query_var'         => false,
            'menu_position'     => 20,
            'supports'          => array(
                'title',
                'editor',
                'thumbnail'
            ),
            'capability_type'   => 'post',
            'labels'            => array(
                'name'               => __('Testimonials', 'testimonial-pro'),
                'singular_name'      => __('Testimonial', 'testimonial-pro'),
                'menu_name'          => __('Testimonial Pro', 'testimonial-pro'),
                'all_items'          => __('Testimonials', 'testimonial-pro'),
                'add_new'            => __('Add Testimonial', 'testimonial-pro'),
                'add_new_item'       => __('Add Testimonial', 'testimonial-pro'),
                'edit'               => __('Edit', 'testimonial-pro'),
                'edit_item'          => __('Edit Testimonial', 'testimonial-pro'),
                'new_item'           => __('New Testimonial', 'testimonial-pro'),
                'search_items'       => __('Search Testimonials', 'testimonial-pro'),
                'not_found'          => __('No Testimonials found', 'testimonial-pro'),
                'not_found_in_trash' => __('No Testimonials found in Trash', 'testimonial-pro'),
                'parent'             => __('Parent Testimonials', 'testimonial-pro'),
                'featured_image'        => __('Featured Image for Testimonial', 'testimonial-pro'),
                'set_featured_image'    => __('Set Testimonial Thumbnail', 'testimonial-pro'),
                'remove_featured_image' => __('Remove image', 'testimonial-pro'),
                'use_featured_image'    => __('Use as image', 'testimonial-pro'),
            )
        ) );
    }

}