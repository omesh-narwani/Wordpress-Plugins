<?php
$custom_css = sp_get_option('custom_css');