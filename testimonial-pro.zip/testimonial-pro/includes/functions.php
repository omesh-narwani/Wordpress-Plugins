<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}  // if direct access

/**
 * Functions
 */
class SP_Testimonial_Pro_Functions {

	/**
	 * Initialize the class
	 */
	public function __construct() {
		add_filter( 'post_updated_messages', array( $this, 'sp_tpro_change_default_post_update_message' ) );
		add_filter( 'admin_footer_text', array( $this, 'admin_footer' ), 1, 2 );
		add_action( 'pending_spt_testimonial', array( $this, 'tpro_submit_send_mail' ), 10, 3 );
		add_action( 'admin_action_sp_tpro_duplicate_shortcode', array( $this, 'sp_tpro_duplicate_shortcode' ));
		add_filter( 'post_row_actions', array( $this, 'sp_tpro_duplicate_shortcode_link'), 10, 2 );
	}

	/**
	 * Post update messages for Shortcode Generator
	 */
	function sp_tpro_change_default_post_update_message( $message ) {
		$screen = get_current_screen();
		if ( 'sp_tpro_shortcodes' == $screen->post_type ) {
			$message['post'][1]  = $title = esc_html__( 'Shortcode updated.', 'testimonial-pro' );
			$message['post'][4]  = $title = esc_html__( 'Shortcode updated.', 'testimonial-pro' );
			$message['post'][6]  = $title = esc_html__( 'Shortcode published.', 'testimonial-pro' );
			$message['post'][8]  = $title = esc_html__( 'Shortcode submitted.', 'testimonial-pro' );
			$message['post'][10] = $title = esc_html__( 'Shortcode draft updated.', 'testimonial-pro' );
		}elseif ( 'spt_testimonial' == $screen->post_type ) {
			$message['post'][1]  = $title = esc_html__( 'Testimonial updated.', 'testimonial-pro' );
			$message['post'][4]  = $title = esc_html__( 'Testimonial updated.', 'testimonial-pro' );
			$message['post'][6]  = $title = esc_html__( 'Testimonial published.', 'testimonial-pro' );
			$message['post'][8]  = $title = esc_html__( 'Testimonial submitted.', 'testimonial-pro' );
			$message['post'][10] = $title = esc_html__( 'Testimonial draft updated.', 'testimonial-pro' );
		}

		return $message;
	}


	/**
	 * Shortcode converter function
	 */
	function testimonial_pro_id( $id ) {
		echo do_shortcode( '[testimonial_pro id="' . $id . '"]' );
	}

	/**
	 * Review Text
	 *
	 * @param $text
	 *
	 * @return string
	 */
	public function admin_footer( $text ) {
		$screen = get_current_screen();
		if ( 'spt_testimonial' == get_post_type() || $screen->id == 'spt_testimonial_page_tpro_help' || $screen->id == 'spt_testimonial_page_tpro_settings' || $screen->taxonomy == 'testimonial_cat' || $screen->post_type == 'sp_tpro_shortcodes' ) {
			$url  = 'https://shapedplugin.com/plugin/testimonial-pro/#reviews';
			$text = sprintf( __( 'If you like <strong>Testimonial Pro</strong> please leave us a <a href="%s" target="_blank">&#9733;&#9733;&#9733;&#9733;&#9733;</a> rating. Your Review is very important to us as it helps us to grow more. ', 'testimonial-pro' ), $url );
		}

		return $text;
	}


	/**
	 * Submit testimonial send mail.
	 *
	 * @param $post_id
	 * @param $post
	 */
	function tpro_submit_send_mail( $post_id, $post ) {

		if ( sp_get_option( 'pending_testimonial_email' ) == 'true' ) {

			$testimonial = 'spt_testimonial';

			if ( $testimonial != $post->post_type ) {
				return;
			}

			$testimonial_data       = get_post_meta( $post_id, 'sp_tpro_meta_options', true );
			$tpro_name              = $testimonial_data['tpro_name'];
			$tpro_email             = $testimonial_data['tpro_email'];
			$tpro_designation       = $testimonial_data['tpro_designation'];
			$tpro_company_name      = $testimonial_data['tpro_company_name'];
			$tpro_location          = $testimonial_data['tpro_location'];
			$tpro_phone             = $testimonial_data['tpro_phone'];
			$tpro_website           = $testimonial_data['tpro_website'];
			$tpro_video_url           = $testimonial_data['tpro_video_url'];
			$tpro_testimonial_title = get_the_title( $post_id );
			$tpro_testimonial_text  = get_post_field( 'post_content', $post_id );

			$tpro_category_list = get_the_terms( $post_id, 'testimonial_cat' );
			if ( ! empty( $tpro_category_list ) && ! is_wp_error( $tpro_category_list ) ) {
				foreach ( $tpro_category_list as $term ) {
					$tpro_category_name[] = $term->name;
				};
			}
			$tpro_category = implode( ", ", $tpro_category_name );

			$tpro_rating_star = $testimonial_data['tpro_rating'];
			$tpro_empty_star  = '<span style="color: #d4d4d4;font-size: 17px;">&#x2605;</span>';
			$tpro_fil_star    = '<span style="color: #FF9800;font-size: 17px;">&#x2605;</span>';
			if ( $tpro_rating_star == 'one_star' ) {
				$tpro_rating = $tpro_fil_star . $tpro_empty_star . $tpro_empty_star . $tpro_empty_star . $tpro_empty_star;
			} elseif ( $tpro_rating_star == 'two_star' ) {
				$tpro_rating = $tpro_fil_star . $tpro_fil_star . $tpro_empty_star . $tpro_empty_star . $tpro_empty_star;
			} elseif ( $tpro_rating_star == 'three_star' ) {
				$tpro_rating = $tpro_fil_star . $tpro_fil_star . $tpro_fil_star . $tpro_empty_star . $tpro_empty_star;
			} elseif ( $tpro_rating_star == 'four_star' ) {
				$tpro_rating = $tpro_fil_star . $tpro_fil_star . $tpro_fil_star . $tpro_fil_star . $tpro_empty_star;
			} elseif ( $tpro_rating_star == 'five_star' ) {
				$tpro_rating = $tpro_fil_star . $tpro_fil_star . $tpro_fil_star . $tpro_fil_star . $tpro_fil_star;
			}

			$subject = sp_get_option( 'pending_testimonial_subject' );
			$heading = sp_get_option( 'pending_testimonial_heading' );

			$email_to_list    = sp_get_option( 'pending_testimonial_email_to' );
			$email_to         = explode( ',', $email_to_list );
			$admin_email      = get_option( 'admin_email' );
			$site_name        = get_bloginfo( 'name' );
			$site_description = '- ' . get_bloginfo( 'description' );

			$message = "";
			$message .= '<div style="background-color: #f6f6f6;font-family: Helvetica Neue,Helvetica,Arial,sans-serif;">';
			$message .= '<div style="width: 100%;margin: 0;padding: 70px 0 70px 0;">';
			$message .= '<div style="background-color: #ffffff;border: 1px solid #e9e9e9;border-radius: 2px!important;padding: 20px 20px 10px 20px;width: 520px;margin: 0 auto;">';
			$message .= '<h1 style="color: #000000;margin: 0;padding: 28px 24px;font-size: 32px;font-weight: 500;text-align: center;">' . $heading . '</h1>';
			$message .= '<div style="padding: 30px 20px 40px;">';

			$message_content = sp_get_option( 'pending_testimonial_message' );

			$message_content = str_replace( '{name}', $tpro_name, $message_content );
			$message_content = str_replace( '{email}', $tpro_email, $message_content );
			$message_content = str_replace( '{position}', $tpro_designation, $message_content );
			$message_content = str_replace( '{company_name}', $tpro_company_name, $message_content );
			$message_content = str_replace( '{location}', $tpro_location, $message_content );
			$message_content = str_replace( '{phone}', $tpro_phone, $message_content );
			$message_content = str_replace( '{website}', $tpro_website, $message_content );
			$message_content = str_replace( '{video_url}', $tpro_video_url, $message_content );
			$message_content = str_replace( '{testimonial_title}', $tpro_testimonial_title, $message_content );
			$message_content = str_replace( '{testimonial_text}', $tpro_testimonial_text, $message_content );
			$message_content = str_replace( '{category}', $tpro_category, $message_content );
			$message_content = str_replace( '{rating}', $tpro_rating, $message_content );

			$message .= wpautop( $message_content );

			$message .= '</div>';

			$message .= '<div style="border-top:1px solid #efefef;padding:20px 0;clear:both;text-align:center"><small style="font-size:11px">' . $site_name . ' ' . $site_description . '</small></div>';

			$message .= '</div>';
			$message .= '</div>';
			$message .= '</div>';


			if ( ! empty( $tpro_email ) ) {
				$email_header = array(
					'Content-Type: text/html; charset=UTF-8',
					'From: "' . $tpro_name . '" < ' . $tpro_email . ' >'
				);
			} else {
				$email_header = array(
					'Content-Type: text/html; charset=UTF-8',
					'From: "' . $tpro_name . '" < ' . $admin_email . ' >'
				);
			}

			// Send email to.
			wp_mail( $email_to, $subject, $message, $email_header );

		}
	}


	/*
	 * Function creates testimonial slider duplicate as a draft.
	 */
	function sp_tpro_duplicate_shortcode(){
		global $wpdb;
		if (! ( isset( $_GET['post']) || isset( $_POST['post'])  || ( isset($_REQUEST['action']) && 'sp_tpro_duplicate_shortcode' == $_REQUEST['action'] ) ) ) {
			wp_die(__('No shortcode to duplicate has been supplied!','testimonial-pro'));
		}

		/*
		 * Nonce verification
		 */
		if ( !isset( $_GET['sp_tpro_duplicate_nonce'] ) || !wp_verify_nonce( $_GET['sp_tpro_duplicate_nonce'], basename( __FILE__ ) ) )
			return;

		/*
		 * Get the original shortcode id
		 */
		$post_id = (isset($_GET['post']) ? absint( $_GET['post'] ) : absint( $_POST['post'] ) );
		/*
		 * and all the original shortcode data then
		 */
		$post = get_post( $post_id );

		$current_user = wp_get_current_user();
		$new_post_author = $current_user->ID;

		/*
		 * if shortcode data exists, create the shortcode duplicate
		 */
		if (isset( $post ) && $post != null) {

			/*
			 * new shortcode data array
			 */
			$args = array(
				'comment_status' => $post->comment_status,
				'ping_status'    => $post->ping_status,
				'post_author'    => $new_post_author,
				'post_content'   => $post->post_content,
				'post_excerpt'   => $post->post_excerpt,
				'post_name'      => $post->post_name,
				'post_parent'    => $post->post_parent,
				'post_password'  => $post->post_password,
				'post_status'    => 'draft',
				'post_title'     => $post->post_title,
				'post_type'      => $post->post_type,
				'to_ping'        => $post->to_ping,
				'menu_order'     => $post->menu_order
			);

			/*
			 * insert the shortcode by wp_insert_post() function
			 */
			$new_post_id = wp_insert_post( $args );

			/*
			 * get all current post terms ad set them to the new post draft
			 */
			$taxonomies = get_object_taxonomies($post->post_type); // returns array of taxonomy names for post type, ex array("category", "post_tag");
			foreach ($taxonomies as $taxonomy) {
				$post_terms = wp_get_object_terms($post_id, $taxonomy, array('fields' => 'slugs'));
				wp_set_object_terms($new_post_id, $post_terms, $taxonomy, false);
			}

			/*
			 * duplicate all post meta just in two SQL queries
			 */
			$post_meta_infos = $wpdb->get_results("SELECT meta_key, meta_value FROM $wpdb->postmeta WHERE post_id=$post_id");
			if (count($post_meta_infos)!=0) {
				$sql_query = "INSERT INTO $wpdb->postmeta (post_id, meta_key, meta_value) ";
				foreach ($post_meta_infos as $meta_info) {
					$meta_key = $meta_info->meta_key;
					if( $meta_key == '_wp_old_slug' ) continue;
					$meta_value = addslashes($meta_info->meta_value);
					$sql_query_sel[]= "SELECT $new_post_id, '$meta_key', '$meta_value'";
				}
				$sql_query.= implode(" UNION ALL ", $sql_query_sel);
				$wpdb->query($sql_query);
			}


			/*
			 * finally, redirect to the edit post screen for the new draft
			 */
			wp_redirect( admin_url( 'edit.php?post_type=' . $post->post_type ) );
			exit;
		} else {
			wp_die(__('Shortcode creation failed, could not find original post: ', 'testimonial-pro') . $post_id);
		}
	}

	/*
	 * Add the duplicate link to action list for post_row_actions
	 */
	function sp_tpro_duplicate_shortcode_link( $actions, $post ) {
		if (current_user_can('edit_posts') && $post->post_type=='sp_tpro_shortcodes') {
			$actions['duplicate'] = '<a href="' . wp_nonce_url('admin.php?action=sp_tpro_duplicate_shortcode&post=' . $post->ID, basename(__FILE__), 'sp_tpro_duplicate_nonce' ) . '" rel="permalink">'.__('Duplicate', 'testimonial-pro').'</a>';
		}
		return $actions;
	}

}

new SP_Testimonial_Pro_Functions();

/**
 *
 * Multi Language Support
 *
 * @since 2.0
 *
 */

// Polylang plugin support for multi language support
if ( class_exists('Polylang') ) {

	add_filter( 'pll_get_post_types', 'sp_tpro_testimonial_polylang', 10, 2 );

	function sp_tpro_testimonial_polylang( $post_types, $is_settings ) {
		if ( $is_settings ) {
			// hides 'spt_testimonial,sp_tpro_shortcodes' from the list of custom post types in Polylang settings
			unset( $post_types['spt_testimonial'] );
			unset( $post_types['sp_tpro_shortcodes'] );
		} else {
			// enables language and translation management for 'spt_testimonial,sp_tpro_shortcodes'
			$post_types['spt_testimonial'] = 'spt_testimonial';
			$post_types['sp_tpro_shortcodes'] = 'sp_tpro_shortcodes';
		}
		return $post_types;
	}

	add_filter( 'pll_get_taxonomies', 'sp_tpro_cat_polylang', 10, 2 );

	function sp_tpro_cat_polylang( $taxonomies, $is_settings ) {
		if ( $is_settings ) {
			unset( $taxonomies['testimonial_cat'] );
		} else {
			$taxonomies['testimonial_cat'] = 'testimonial_cat';
		}
		return $taxonomies;
	}

}