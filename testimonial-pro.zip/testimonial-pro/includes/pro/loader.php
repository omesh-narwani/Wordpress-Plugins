<?php
/**
 * The Pro Loader Class
 * @package testimonial-pro
 * @since 2.0
 */
class SP_TPRO_Loader {

	function __construct() {
		require_once( SP_TPRO_PATH . "admin/views/scripts.php" );
		require_once( SP_TPRO_PATH . "admin/views/order.php" );
		require_once( SP_TPRO_PATH . "admin/views/mce-button.php" );
		require_once( SP_TPRO_PATH . "admin/views/vc-add-on.php" );
		require_once( SP_TPRO_PATH . "admin/views/widget.php" );
		require_once( SP_TPRO_PATH . "includes/resizer.php" );
		require_once( SP_TPRO_PATH . "public/views/shortcoderender.php" );
		require_once( SP_TPRO_PATH . "public/views/form.php" );
		require_once( SP_TPRO_PATH . "public/views/scripts.php" );
	}

}

new SP_TPRO_Loader();