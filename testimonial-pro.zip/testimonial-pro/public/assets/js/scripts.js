jQuery(function ($) {

    'use strict';

    /* === Masonery === */
    (function () {
        var masonry = $('.sp_testimonial_pro_masonry');
        $(window).load(function () {
            masonry.masonry();//Masonry
        });
    }());

    /* === Testimonial Submit Form === */
    (function () {
        $("#testimonial_form").validate();
    }());

    /* == MagnificPopup == */
    $(document).ready(function() {
        $('.sp-tpro-video').magnificPopup({
            type: 'iframe',
            mainClass: 'mfp-fade',
            preloader: false,
            fixedContentPos: false
        });
    });

});