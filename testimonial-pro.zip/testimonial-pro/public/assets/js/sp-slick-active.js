jQuery(document).ready(function ($) {

    $('.sp-testimonial-pro-section.tpro-layout-slider-false').each(function (index) {

        var tpro_custom_slider_id = $(this).attr('id');
        var tpro_config = $.parseJSON($(this).closest('.sp-testimonial-pro-wrapper').find('.sp-tpro-config').text());


        if ( tpro_custom_slider_id != '') {

            jQuery('#' + tpro_custom_slider_id).slick({
                pauseOnFocus: false,
                infinite: (tpro_config.slider_infinite),
                slidesToShow: parseInt(tpro_config.number_of_testimonials),
                slidesToScroll: parseInt(tpro_config.number_of_slides_to_scroll),
                autoplay: (tpro_config.slider_auto_play),
                autoplaySpeed: parseInt(tpro_config.slider_auto_play_speed),
                speed: parseInt(tpro_config.slider_scroll_speed),
                pauseOnHover: (tpro_config.slider_pause_on_hover),
                swipe: (tpro_config.slider_swipe),
                draggable: (tpro_config.slider_draggable),
                arrows: (tpro_config.navigation),
                prevArrow: "<div class=\'slick-prev\'><i class=\'fa fa-"+ (tpro_config.navigation_icons) +"-left\'></i></div>",
                nextArrow: "<div class=\'slick-next\'><i class=\'fa fa-"+ (tpro_config.navigation_icons) +"-right\'></i></div>",
                dots: (tpro_config.pagination),
                rtl: (tpro_config.rtl_mode),
                fade: (tpro_config.slider_fade_effect),
                responsive: [
                    {
                        breakpoint: 1280,
                        settings: {
                            slidesToShow: parseInt(tpro_config.number_of_testimonials_desktop)
                        }
                    },
                    {
                        breakpoint: 980,
                        settings: {
                            slidesToShow: parseInt(tpro_config.number_of_testimonials_small_desktop)
                        }
                    },
                    {
                        breakpoint: 736,
                        settings: {
                            slidesToShow: parseInt(tpro_config.number_of_testimonials_tablet)
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: parseInt(tpro_config.number_of_testimonials_mobile)
                        }
                    }
                ]
            });
        }
    });
});