<?php
$outline .= '<div class="remodal sp-tpro-modal-testimonial-' . $post_id . ' sp-tpro-modal-testimonial" data-remodal-id="sp-tpro-testimonial-id-' .
            get_the_ID() . '">
<a data-remodal-action="close" class="remodal-close"></a>';

$outline .= '<div class="sp-testimonial-pro-item" itemscope itemtype="http://schema.org/Review">';

$outline .= '<div class="sp-testimonial-pro">';

$outline .= '<div itemprop="itemReviewed" itemscope itemtype="http://schema.org/Thing">
                            <meta itemprop="name" content="Testimonials">
                        </div>';

if ($client_image == 'true') {
    $tpro_thumb   = get_post_thumbnail_id();
    $tpro_img_url = wp_get_attachment_url($tpro_thumb);
    $tpro_image   = aq_resize($tpro_img_url, $client_image_width, $client_image_height, $client_image_crop);

    if (has_post_thumbnail($post_query->post->ID)) {
        $outline .= '<div class="tpro-client-image tpro-image-style-'.$shortcode_data['client_image_style']
                    .'" itemprop="image">';
        if ($tpro_image == ! '') {
            $outline .= '<img src="' . $tpro_image . '">';
        } else {
            $outline .= '<img src="' . $tpro_img_url . '">';
        }
        $outline .= '</div>';
    }
}

if ($testimonial_title == 'true') {
    $outline .= '<div class="tpro-testimonial-title"><h3>' . get_the_title() . '</h3></div>';
}

if ($testimonial_text == 'true') {
    $outline .= '<div class="tpro-client-testimonial" itemprop="reviewBody">';
    $outline .= nl2br(get_the_content());
    $outline .= '</div>';
}

if ($testimonial_client_name == 'true') {
    $outline .= '<div itemprop="author" itemscope itemtype="http://schema.org/Person">';
    $outline .= '<meta itemprop="name" content="' . $tpro_name . '">';
    $outline .= '<h2 class="tpro-client-name">' . $tpro_name . '</h2>';
    $outline .= '</div>';
}

if ($testimonial_client_rating == 'true' && $tpro_rating_star !== '') {
    include SP_TPRO_PATH . '/public/views/content/rating.php';
}

if ($client_designation == 'true' && $tpro_designation !== '' || $client_company_name == 'true' && $tpro_company_name !== ''
) {
    $outline .= '<div class="tpro-client-designation-company">';
    if ($client_designation == 'true' && $tpro_designation !== '' ) {
        $outline .= $tpro_designation;
    }
    if ($client_designation == 'true' && $tpro_designation !== '' && $client_company_name == 'true' && $tpro_company_name !== '' ) {
        $outline .= ' - ';
    }
    if ($client_company_name == 'true' && $tpro_company_name !== '' ) {
        $outline .= $tpro_company_name;
    }
    $outline .= '</div>';
}
if ($shortcode_data['testimonial_client_location'] == 'true' && $tpro_location !== '' ) {
    $outline .= '<div class="tpro-client-location">' . $tpro_location . '</div>';
}
if ($shortcode_data['testimonial_client_phone'] == 'true' && $tpro_phone !== '' ) {
    $outline .= '<div class="tpro-client-phone">' . $tpro_phone . '</div>';
}
if ($shortcode_data['testimonial_client_email'] == 'true' && $tpro_email !== '' ) {
    $outline .= '<div class="tpro-client-email">' . $tpro_email . '</div>';
}
if ($shortcode_data['testimonial_client_date'] == 'true' ) {
    $outline .= '<div class="tpro-testimonial-date">' . get_the_date($shortcode_data['testimonial_client_date_format']) . '</div>';
}
if ($shortcode_data['testimonial_client_website'] == 'true' && $tpro_website !== '' ) {
    $outline .= '<div class="tpro-client-website"><a href="' . esc_url($tpro_website) . '">' . $tpro_website . '</a></div>';
}

include SP_TPRO_PATH . '/public/views/content/social-profile.php';

$outline .= '</div>'; //sp-testimonial-pro
$outline .= '</div>'; //sp-testimonial-pro-item

$outline .= '</div>';