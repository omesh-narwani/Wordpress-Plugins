<?php
switch ($tpro_rating_star) {
	case 'five_star':
		$rating_value = '5';
		break;
	case 'four_star':
		$rating_value = '4';
		break;
	case 'three_star':
		$rating_value = '3';
		break;
	case 'two_star':
		$rating_value = '2';
		break;
	case 'one_star':
		$rating_value = '1';
		break;
}

$outline .= '<div class="tpro-client-rating" itemprop="reviewRating" itemscope itemtype="http://schema.org/Rating">';
$outline .= '<meta itemprop="worstRating" content="1"><meta itemprop="ratingValue" content="'.$rating_value.'"><meta itemprop="bestRating" content="5">';
if ( $tpro_rating_star == 'five_star' ) {
	$outline .= $this->tpro_five_star;
} elseif ( $tpro_rating_star == 'four_star' ) {
	$outline .= $this->tpro_four_star;
} elseif ( $tpro_rating_star == 'three_star' ) {
	$outline .= $this->tpro_three_star;
} elseif ( $tpro_rating_star == 'two_star' ) {
	$outline .=$this-> tpro_two_star;
} elseif ( $tpro_rating_star == 'one_star' ) {
	$outline .= $this->tpro_one_star;
}
$outline .= '</div>';