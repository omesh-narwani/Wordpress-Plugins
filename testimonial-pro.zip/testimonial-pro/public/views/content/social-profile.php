<?php
if($shortcode_data['social_profile'] == 'true'){
	$outline .= '<div class="tpro-social-profile tpro-social-profile-'.$shortcode_data['social_icon_style'].'">';

	if(isset($testimonial_data['tpro_social_facebook_url']) && $testimonial_data['tpro_social_facebook_url'] !== ''){
		$outline .= '<a href="'.esc_url($testimonial_data['tpro_social_facebook_url']).'" target="_blank"><i class="fa fa-facebook"></i></a>';
	}
	if(isset($testimonial_data['tpro_social_twitter_url']) && $testimonial_data['tpro_social_twitter_url'] !== '') {
		$outline .= '<a href="'.esc_url($testimonial_data['tpro_social_twitter_url']).'" target="_blank"><i class="fa fa-twitter"></i></a>';
	}
	if(isset($testimonial_data['tpro_social_google_plus_url']) && $testimonial_data['tpro_social_google_plus_url'] !== '') {
		$outline .= '<a href="'.esc_url($testimonial_data['tpro_social_google_plus_url']).'" target="_blank"><i class="fa fa-google-plus"></i></a>';
	}
	if(isset($testimonial_data['tpro_social_linked_in_url']) && $testimonial_data['tpro_social_linked_in_url'] !== '') {
		$outline .= '<a href="'.esc_url($testimonial_data['tpro_social_linked_in_url']).'" target="_blank"><i class="fa fa-linkedin"></i></a>';
	}
	if(isset($testimonial_data['tpro_social_instagram_url']) && $testimonial_data['tpro_social_instagram_url'] !== '') {
		$outline .= '<a href="'.esc_url($testimonial_data['tpro_social_instagram_url']).'" target="_blank"><i class="fa fa-instagram"></i></a>';
	}
	if(isset($testimonial_data['tpro_social_youtube_url']) && $testimonial_data['tpro_social_youtube_url'] !== '') {
		$outline .= '<a href="'.esc_url($testimonial_data['tpro_social_youtube_url']).'" target="_blank"><i class="fa fa-youtube"></i></a>';
	}
	if(isset($testimonial_data['tpro_social_pinterest_url']) && $testimonial_data['tpro_social_pinterest_url'] !== '') {
		$outline .= '<a href="'.esc_url($testimonial_data['tpro_social_pinterest_url']).'" target="_blank"><i class="fa fa-pinterest-p"></i></a>';
	}
	if(isset($testimonial_data['tpro_social_skype_url']) && $testimonial_data['tpro_social_skype_url'] !== '') {
		$outline .= '<a href="'.esc_url($testimonial_data['tpro_social_skype_url']).'" target="_blank"><i class="fa fa-skype"></i></a>';
	}
	if(isset($testimonial_data['tpro_social_stumble_upon_url']) && $testimonial_data['tpro_social_stumble_upon_url'] !== '') {
		$outline .= '<a href="'.esc_url($testimonial_data['tpro_social_stumble_upon_url']).'" target="_blank"><i class="fa fa-stumbleupon"></i></a>';
	}
	if(isset($testimonial_data['tpro_social_reddit_url']) && $testimonial_data['tpro_social_reddit_url'] !== '') {
		$outline .= '<a href="'.esc_url($testimonial_data['tpro_social_reddit_url']).'" target="_blank"><i class="fa fa-reddit"></i></a>';
	}
	if(isset($testimonial_data['tpro_social_dribbble_url']) && $testimonial_data['tpro_social_dribbble_url'] !== '') {
		$outline .= '<a href="'.esc_url($testimonial_data['tpro_social_dribbble_url']).'" target="_blank"><i class="fa fa-dribbble"></i></a>';
	}
	if(isset($testimonial_data['tpro_social_snapchat_url']) && $testimonial_data['tpro_social_snapchat_url'] !== '') {
		$outline .= '<a href="'.esc_url($testimonial_data['tpro_social_snapchat_url']).'" target="_blank"><i class="fa fa-snapchat"></i></a>';
	}
	$outline .= '</div>';
}