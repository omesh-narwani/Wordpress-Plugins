<?php
$outline .= '<style>';

if ( $section_title == 'true' ) {
	$outline .= '#sp-testimonial-pro-wrapper-' . $post_id . ' .sp-testimonial-pro-section-title{
			margin: 0;
            padding: 0;
		    margin-bottom: ' . $shortcode_data['section_title_margin_bottom'] . 'px;
			color: ' . $section_title_typography['color'] . ';
			font-size: ' . $section_title_typography['size'] . 'px;
			line-height: ' . $section_title_typography['height'] . 'px;
			text-transform: ' . $section_title_typography['transform'] . ';
			letter-spacing: ' . $section_title_typography['spacing'] . ';
			text-align: ' . $section_title_typography['alignment'] . ';';
		if($shortcode_data['section_title_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $section_title_typography['family'] . ';
			font-weight: ' . $section_title_weight . ';
			font-style: ' . $section_title_style . ';
			';
		}
	$outline .= '}';
}

if($layout == 'slider'){
	$outline .= '
	#sp-testimonial-pro-wrapper-' . $post_id . ' .sp-testimonial-pro-section {
	    display: none;
	}
	#sp-testimonial-pro-wrapper-' . $post_id . ' .sp-testimonial-pro-section.slick-initialized {
	    display: block;
	}
	';
}elseif($layout == 'grid' || $layout == 'masonry' || $layout == 'list' || $layout == 'filter_grid' || $layout == 'filter_masonry'){
	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro-item{
		margin-bottom: '.$testimonial_margin.'px;
	}';
}

if( $layout == 'filter_grid' || $layout == 'filter_masonry'){
	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.sp_testimonial_pro_filter .sp-tpro-filter{
		text-align: '.$shortcode_data['filter_alignment'].';
		margin-right:' . $testimonial_margin . 'px;
	}
	#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.sp_testimonial_pro_filter ul.sp-tpro-items-filter{
		margin: ' . $filter_margin['top'] . 'px ' . $filter_margin['right'] . 'px ' . $filter_margin['bottom'] . 'px ' . $filter_margin['left'] . 'px;
	}
	#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.sp_testimonial_pro_filter ul.sp-tpro-items-filter li a{
		color: '.$shortcode_data['filter_color'].';
		background: '.$shortcode_data['filter_bg_color'].';
		font-size: ' . $filter_typography['size'] . 'px;
		line-height: ' . $filter_typography['height'] . 'px;
		text-transform: ' . $filter_typography['transform'] . ';
		text-align: ' . $filter_typography['alignment'] . ';
		letter-spacing: ' . $filter_typography['spacing'] . ';';
	if($shortcode_data['filter_font_load'] == 'true') {
		$outline .= '
		font-family: ' . $filter_typography['family'] . ';
		font-weight: ' . $filter_weight . ';
		font-style: ' . $filter_style . ';
		';
	}
	$outline .= '}
	#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.sp_testimonial_pro_filter ul.sp-tpro-items-filter li a.active{
		color: '.$shortcode_data['filter_active_color'].';
		background: '.$shortcode_data['filter_active_bg_color'].';
	}';
}

if($shortcode_data['testimonial_read_more'] == 'true'){
	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section a.tpro-read-more{
		color: '.$shortcode_data['testimonial_read_more_color'].';
	}
	#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section a.tpro-read-more:hover{
		color: '.$shortcode_data['testimonial_read_more_hover_color'].';
	}';
}

if ( $theme_style == 'theme-one' || $theme_style == 'theme-two' || $theme_style == 'theme-three' || $theme_style == 'theme-four' || $theme_style == 'theme-five' || $theme_style == 'theme-six' || $theme_style == 'theme-seven' || $theme_style == 'theme-eight' || $theme_style == 'theme-nine' || $theme_style == 'theme-ten' ) {

	if($layout !== 'list'){
	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro-item{
	padding-right:' . $testimonial_margin . 'px;
}
#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section{
	margin-right:-' . $testimonial_margin . 'px;
}';
	}
}

if ( $client_image == 'true' ) {
	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-image .sp-tpro-video i.fa{
		color: '.$shortcode_data['video_icon_color'].';
	}
	#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-image .sp-tpro-video:before{
		background: '.$shortcode_data['video_icon_overlay'].';
	}';
	if ( $theme_style == 'theme-one' || $theme_style == 'theme-eight' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-image{
			margin: ' . $client_image_margin['top'] . 'px ' . $client_image_margin['right'] . 'px ' . $client_image_margin['bottom'] . 'px ' . $client_image_margin['left'] . 'px;
			text-align: ' . $shortcode_data['client_image_position'] . ';
		}';
	}
	if ( $theme_style == 'theme-ten' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-image{
			margin: ' . $client_image_margin['top'] . 'px ' . $client_image_margin['right'] . 'px ' . $client_image_margin['bottom'] . 'px ' . $client_image_margin['left'] . 'px;
			text-align: ' . $shortcode_data['client_image_position'] . ';
			z-index: 2;
            position: relative;
		}';
	}
	if ( $theme_style == 'theme-nine' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-image{
			margin: ' . $client_image_margin_tow['top'] . 'px ' . $client_image_margin_tow['right'] . 'px ' . $client_image_margin_tow['bottom'] . 'px ' . $client_image_margin_tow['left'] . 'px;
		}';
	}
	if ( $theme_style == 'theme-four' || $theme_style == 'theme-five' ) {
		if ( $shortcode_data['client_image_position_two'] == 'left' ) {
			$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-image{
				float: left;
				margin-right: 25px;
				margin-bottom: 15px;
			}';
		} elseif ( $shortcode_data['client_image_position_two'] == 'right' ) {
			$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-image{
				float: right;
				margin-left: 25px;
				margin-bottom: 15px;
			}';
		} elseif ( $shortcode_data['client_image_position_two'] == 'top' ) {
			$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-image{
				text-align: center;
                margin-bottom: 22px;
			}
			#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-image img{
			    display: inline-block;
			}';
		} elseif ( $shortcode_data['client_image_position_two'] == 'bottom' ) {
			$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-image{
				text-align: center;
                margin-top: 22px;
			}
			#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-image img{
			    display: inline-block;
			}';
		}
	}
	if ( $shortcode_data['client_image_border_shadow'] == 'border' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-image img,
		.sp-tpro-modal-testimonial-' . $post_id . ' .tpro-client-image img{
			background: ' . $shortcode_data['client_image_bg'] . ';
			border: ' . $shortcode_data['client_image_border_size'] . 'px solid ' . $shortcode_data['client_image_border_color'] . ';
			padding: ' . $shortcode_data['client_image_padding'] . 'px;
		}';
	} else {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-image img,
		.sp-tpro-modal-testimonial-' . $post_id . ' .tpro-client-image img{
			background: ' . $shortcode_data['client_image_bg'] . ';
			padding: ' . $shortcode_data['client_image_padding'] . 'px;
			box-shadow: 0px 0px 7px 0px ' . $shortcode_data['client_image_box_shadow_color'] . ';
            margin: 7px;
		}';
	}
}

if ( $testimonial_title == 'true' ) {
	if ( $theme_style == 'theme-one' || $theme_style == 'theme-two' || $theme_style == 'theme-four' || $theme_style == 'theme-ten' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-testimonial-title{
			margin: ' . $testimonial_title_margin['top'] . 'px ' . $testimonial_title_margin['right'] . 'px ' . $testimonial_title_margin['bottom'] . 'px ' . $testimonial_title_margin['left'] . 'px;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-testimonial-title h3{
			font-size: ' . $testimonial_title_typography['size'] . 'px;
			color: ' . $testimonial_title_typography['color'] . ';
			line-height: ' . $testimonial_title_typography['height'] . 'px;
			text-transform: ' . $testimonial_title_typography['transform'] . ';
			text-align: ' . $testimonial_title_typography['alignment'] . ';
			letter-spacing: ' . $testimonial_title_typography['spacing'] . ';';
		if($shortcode_data['testimonial_title_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_title_typography['family'] . ';
			font-weight: ' . $testimonial_title_weight . ';
			font-style: ' . $testimonial_title_style . ';
			';
		}
		$outline .='padding: 0;
	        margin: 0;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-testimonial-title h3{
			font-size: ' . $testimonial_title_typography['size'] . 'px;
			color: #333333;
			line-height: ' . $testimonial_title_typography['height'] . 'px;
			text-transform: ' . $testimonial_title_typography['transform'] . ';
			text-align: center;
			letter-spacing: ' . $testimonial_title_typography['spacing'] . ';';
		if($shortcode_data['testimonial_title_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_title_typography['family'] . ';
			font-weight: ' . $testimonial_title_weight . ';
			font-style: ' . $testimonial_title_style . ';
			';
		}
		$outline .= '
			padding: 0;
	        margin: 0;
		}';
	}
	if ( $theme_style == 'theme-three' || $theme_style == 'theme-five' || $theme_style == 'theme-six' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-testimonial-title{
			margin: ' . $testimonial_title_margin['top'] . 'px ' . $testimonial_title_margin['right'] . 'px ' . $testimonial_title_margin['bottom'] . 'px ' . $testimonial_title_margin['left'] . 'px;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-testimonial-title h3{
			font-size: ' . $testimonial_title_typography_two['size'] . 'px;
			color: ' . $testimonial_title_typography_two['color'] . ';
			line-height: ' . $testimonial_title_typography_two['height'] . 'px;
			text-transform: ' . $testimonial_title_typography_two['transform'] . ';
			text-align: ' . $testimonial_title_typography_two['alignment'] . ';
			letter-spacing: ' . $testimonial_title_typography_two['spacing'] . ';';
		if($shortcode_data['testimonial_title_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_title_typography_two['family'] . ';
			font-weight: ' . $testimonial_title_weight_two . ';
			font-style: ' . $testimonial_title_style_two . ';
			';
		}
		$outline .= '
			padding: 0;
	        margin: 0;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-testimonial-title h3{
			font-size: ' . $testimonial_title_typography_two['size'] . 'px;
			color: #333333;
			line-height: ' . $testimonial_title_typography_two['height'] . 'px;
			text-transform: ' . $testimonial_title_typography_two['transform'] . ';
			text-align: center;
			letter-spacing: ' . $testimonial_title_typography_two['spacing'] . ';';
		if($shortcode_data['testimonial_title_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_title_typography_two['family'] . ';
			font-weight: ' . $testimonial_title_weight_two . ';
			font-style: ' . $testimonial_title_style_two . ';
			';
		}
		$outline .= '
			padding: 0;
	        margin: 0;
		}';
	}
	if ( $theme_style == 'theme-seven' || $theme_style == 'theme-nine' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-testimonial-title{
			margin: ' . $testimonial_title_margin['top'] . 'px ' . $testimonial_title_margin['right'] . 'px ' . $testimonial_title_margin['bottom'] . 'px ' . $testimonial_title_margin['left'] . 'px;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-testimonial-title h3{
			font-size: ' . $testimonial_title_typography_three['size'] . 'px;
			color: ' . $testimonial_title_typography_three['color'] . ';
			line-height: ' . $testimonial_title_typography_three['height'] . 'px;
			text-transform: ' . $testimonial_title_typography_three['transform'] . ';
			text-align: ' . $testimonial_title_typography_three['alignment'] . ';
			letter-spacing: ' . $testimonial_title_typography_three['spacing'] . ';';
		if($shortcode_data['testimonial_title_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_title_typography_three['family'] . ';
			font-weight: ' . $testimonial_title_weight_three . ';
			font-style: ' . $testimonial_title_style_three . ';
			';
		}
		$outline .= '
			padding: 0;
	        margin: 0;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-testimonial-title h3{
			font-size: ' . $testimonial_title_typography_three['size'] . 'px;
			color: #333333;
			line-height: ' . $testimonial_title_typography_three['height'] . 'px;
			text-transform: ' . $testimonial_title_typography_three['transform'] . ';
			text-align: center;
			letter-spacing: ' . $testimonial_title_typography_three['spacing'] . ';';
		if($shortcode_data['testimonial_title_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_title_typography_three['family'] . ';
			font-weight: ' . $testimonial_title_weight_three . ';
			font-style: ' . $testimonial_title_style_three . ';
			';
		}
		$outline .= '
			padding: 0;
	        margin: 0;
		}';
	}
	if ( $theme_style == 'theme-eight' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-testimonial-title{
			margin: ' . $testimonial_title_margin['top'] . 'px ' . $testimonial_title_margin['right'] . 'px ' . $testimonial_title_margin['bottom'] . 'px ' . $testimonial_title_margin['left'] . 'px;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-testimonial-title h3{
			font-size: ' . $testimonial_title_typography_four['size'] . 'px;
			color: ' . $testimonial_title_typography_four['color'] . ';
			line-height: ' . $testimonial_title_typography_four['height'] . 'px;
			text-transform: ' . $testimonial_title_typography_four['transform'] . ';
			text-align: ' . $testimonial_title_typography_four['alignment'] . ';
			letter-spacing: ' . $testimonial_title_typography_four['spacing'] . ';';
		if($shortcode_data['testimonial_title_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_title_typography_four['family'] . ';
			font-weight: ' . $testimonial_title_weight_four . ';
			font-style: ' . $testimonial_title_style_four . ';
			';
		}
		$outline .= '
			padding: 0;
	        margin: 0;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-testimonial-title h3{
			font-size: ' . $testimonial_title_typography_four['size'] . 'px;
			color: #333333;
			line-height: ' . $testimonial_title_typography_four['height'] . 'px;
			text-transform: ' . $testimonial_title_typography_four['transform'] . ';
			text-align: center;
			letter-spacing: ' . $testimonial_title_typography_four['spacing'] . ';';
		if($shortcode_data['testimonial_title_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_title_typography_four['family'] . ';
			font-weight: ' . $testimonial_title_weight_four . ';
			font-style: ' . $testimonial_title_style_four . ';
			';
		}
		$outline .= '
			padding: 0;
	        margin: 0;
		}';
	}
}

if ( $testimonial_text == 'true' ) {
	if ( $theme_style == 'theme-one' || $theme_style == 'theme-two' || $theme_style == 'theme-four' || $theme_style == 'theme-ten' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-testimonial{
			font-size: ' . $testimonial_text_typography['size'] . 'px;
			color: ' . $testimonial_text_typography['color'] . ';
			line-height: ' . $testimonial_text_typography['height'] . 'px;
			text-transform: ' . $testimonial_text_typography['transform'] . ';
			text-align: ' . $testimonial_text_typography['alignment'] . ';
			letter-spacing: ' . $testimonial_text_typography['spacing'] . ';';
		if($shortcode_data['testimonial_text_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_text_typography['family'] . ';
			font-weight: ' . $testimonial_text_weight . ';
			font-style: ' . $testimonial_text_style . ';
			';
		}
		$outline .= 'margin: ' . $testimonial_text_margin['top'] . 'px ' . $testimonial_text_margin['right'] . 'px ' . $testimonial_text_margin['bottom'] . 'px ' . $testimonial_text_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-client-testimonial{
			font-size: ' . $testimonial_text_typography['size'] . 'px;
			color: #333333;
			line-height: ' . $testimonial_text_typography['height'] . 'px;
			text-transform: ' . $testimonial_text_typography['transform'] . ';
			text-align: center;
			letter-spacing: ' . $testimonial_text_typography['spacing'] . ';';
		if($shortcode_data['testimonial_text_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_text_typography['family'] . ';
			font-weight: ' . $testimonial_text_weight . ';
			font-style: ' . $testimonial_text_style . ';
			';
		}
		$outline .= '}';
	}
	if ( $theme_style == 'theme-three' || $theme_style == 'theme-five' || $theme_style == 'theme-six' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-testimonial{
			font-size: ' . $testimonial_text_typography_two['size'] . 'px;
			color: ' . $testimonial_text_typography_two['color'] . ';
			line-height: ' . $testimonial_text_typography_two['height'] . 'px;
			text-transform: ' . $testimonial_text_typography_two['transform'] . ';
			text-align: ' . $testimonial_text_typography_two['alignment'] . ';
			letter-spacing: ' . $testimonial_text_typography_two['spacing'] . ';';
		if($shortcode_data['testimonial_text_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_text_typography_two['family'] . ';
			font-weight: ' . $testimonial_text_weight_two . ';
			font-style: ' . $testimonial_text_style_two . ';
			';
		}
		$outline .= 'margin: ' . $testimonial_text_margin['top'] . 'px ' . $testimonial_text_margin['right'] . 'px ' . $testimonial_text_margin['bottom'] . 'px ' . $testimonial_text_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-client-testimonial{
			font-size: ' . $testimonial_text_typography_two['size'] . 'px;
			color: #333333;
			line-height: ' . $testimonial_text_typography_two['height'] . 'px;
			text-transform: ' . $testimonial_text_typography_two['transform'] . ';
			text-align: center;
			letter-spacing: ' . $testimonial_text_typography_two['spacing'] . ';';
		if($shortcode_data['testimonial_text_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_text_typography_two['family'] . ';
			font-weight: ' . $testimonial_text_weight_two . ';
			font-style: ' . $testimonial_text_style_two . ';
			';
		}
		$outline .= '}';
	}
	if ( $theme_style == 'theme-seven' || $theme_style == 'theme-nine' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-testimonial{
			font-size: ' . $testimonial_text_typography_three['size'] . 'px;
			color: ' . $testimonial_text_typography_three['color'] . ';
			line-height: ' . $testimonial_text_typography_three['height'] . 'px;
			text-transform: ' . $testimonial_text_typography_three['transform'] . ';
			text-align: ' . $testimonial_text_typography_three['alignment'] . ';
			letter-spacing: ' . $testimonial_text_typography_three['spacing'] . ';';
		if($shortcode_data['testimonial_text_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_text_typography_three['family'] . ';
			font-weight: ' . $testimonial_text_weight_three . ';
			font-style: ' . $testimonial_text_style_three . ';
			';
		}
		$outline .= 'margin: ' . $testimonial_text_margin['top'] . 'px ' . $testimonial_text_margin['right'] . 'px ' . $testimonial_text_margin['bottom'] . 'px ' . $testimonial_text_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-client-testimonial{
			font-size: ' . $testimonial_text_typography_three['size'] . 'px;
			color: #333333;
			line-height: ' . $testimonial_text_typography_three['height'] . 'px;
			text-transform: ' . $testimonial_text_typography_three['transform'] . ';
			text-align: center;
			letter-spacing: ' . $testimonial_text_typography_three['spacing'] . ';';
		if($shortcode_data['testimonial_text_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_text_typography_three['family'] . ';
			font-weight: ' . $testimonial_text_weight_three . ';
			font-style: ' . $testimonial_text_style_three . ';
			';
		}
		$outline .= '}';
	}
	if ( $theme_style == 'theme-eight' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-testimonial{
			font-size: ' . $testimonial_text_typography_four['size'] . 'px;
			color: ' . $testimonial_text_typography_four['color'] . ';
			line-height: ' . $testimonial_text_typography_four['height'] . 'px;
			text-transform: ' . $testimonial_text_typography_four['transform'] . ';
			text-align: ' . $testimonial_text_typography_four['alignment'] . ';
			letter-spacing: ' . $testimonial_text_typography_four['spacing'] . ';';
		if($shortcode_data['testimonial_text_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_text_typography_four['family'] . ';
			font-weight: ' . $testimonial_text_weight_four . ';
			font-style: ' . $testimonial_text_style_four . ';
			';
		}
		$outline .= 'margin: ' . $testimonial_text_margin['top'] . 'px ' . $testimonial_text_margin['right'] . 'px ' . $testimonial_text_margin['bottom'] . 'px ' . $testimonial_text_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-client-testimonial{
			font-size: ' . $testimonial_text_typography_four['size'] . 'px;
			color: #333333;
			line-height: ' . $testimonial_text_typography_four['height'] . 'px;
			text-transform: ' . $testimonial_text_typography_four['transform'] . ';
			text-align: center;
			letter-spacing: ' . $testimonial_text_typography_four['spacing'] . ';';
		if($shortcode_data['testimonial_text_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_text_typography_four['family'] . ';
			font-weight: ' . $testimonial_text_weight_four . ';
			font-style: ' . $testimonial_text_style_four . ';
			';
		}
		$outline .= '}';
	}
}

if ( $testimonial_client_name == 'true' ) {
	if ( $theme_style == 'theme-one' || $theme_style == 'theme-two' || $theme_style == 'theme-four' || $theme_style == 'theme-eight' || $theme_style == 'theme-ten' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section h2.tpro-client-name{
			font-size: ' . $client_name_typography['size'] . 'px;
			color: ' . $client_name_typography['color'] . ';
			line-height: ' . $client_name_typography['height'] . 'px;
			text-transform: ' . $client_name_typography['transform'] . ';
			text-align: ' . $client_name_typography['alignment'] . ';
			letter-spacing: ' . $client_name_typography['spacing'] . ';';
		if($shortcode_data['client_name_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_name_typography['family'] . ';
			font-weight: ' . $client_name_weight . ';
			font-style: ' . $client_name_style . ';
			';
		}
		$outline .= 'margin: ' . $testimonial_client_name_margin['top'] . 'px ' . $testimonial_client_name_margin['right'] . 'px ' . $testimonial_client_name_margin['bottom'] . 'px ' . $testimonial_client_name_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial h2.tpro-client-name{
			font-size: ' . $client_name_typography['size'] . 'px;
			color: #333333;
			line-height: ' . $client_name_typography['height'] . 'px;
			text-transform: ' . $client_name_typography['transform'] . ';
			text-align: center;
			letter-spacing: ' . $client_name_typography['spacing'] . ';';
		if($shortcode_data['client_name_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_name_typography['family'] . ';
			font-weight: ' . $client_name_weight . ';
			font-style: ' . $client_name_style . ';
			';
		}
		$outline .= '}';
	}
	if ( $theme_style == 'theme-three' || $theme_style == 'theme-five' || $theme_style == 'theme-six' || $theme_style == 'theme-seven' || $theme_style == 'theme-nine' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section h2.tpro-client-name{
			font-size: ' . $client_name_typography_two['size'] . 'px;
			color: ' . $client_name_typography_two['color'] . ';
			line-height: ' . $client_name_typography_two['height'] . 'px;
			text-transform: ' . $client_name_typography_two['transform'] . ';
			text-align: ' . $client_name_typography_two['alignment'] . ';
			letter-spacing: ' . $client_name_typography_two['spacing'] . ';';
		if($shortcode_data['client_name_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_name_typography_two['family'] . ';
			font-weight: ' . $client_name_weight_two . ';
			font-style: ' . $client_name_style_two . ';
			';
		}
		$outline .= 'margin: ' . $testimonial_client_name_margin['top'] . 'px ' . $testimonial_client_name_margin['right'] . 'px ' . $testimonial_client_name_margin['bottom'] . 'px ' . $testimonial_client_name_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial h2.tpro-client-name{
			font-size: ' . $client_name_typography_two['size'] . 'px;
			color: #333333;
			line-height: ' . $client_name_typography_two['height'] . 'px;
			text-transform: ' . $client_name_typography_two['transform'] . ';
			text-align: center;
			letter-spacing: ' . $client_name_typography_two['spacing'] . ';';
		if($shortcode_data['client_name_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_name_typography_two['family'] . ';
			font-weight: ' . $client_name_weight_two . ';
			font-style: ' . $client_name_style_two . ';
			';
		}
		$outline .= '}';
	}
}

if ( $testimonial_client_rating == 'true' ) {
	if ( $theme_style == 'theme-one' || $theme_style == 'theme-two' || $theme_style == 'theme-four' || $theme_style == 'theme-eight' || $theme_style == 'theme-ten' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-rating{
			margin: ' . $testimonial_client_rating_margin['top'] . 'px ' . $testimonial_client_rating_margin['right'] . 'px ' . $testimonial_client_rating_margin['bottom'] . 'px ' . $testimonial_client_rating_margin['left'] . 'px;
			text-align: ' . $testimonial_client_rating_alignment . ';
			color: ' . $shortcode_data['testimonial_client_rating_color'] . ';
		}';
	}
	if ( $theme_style == 'theme-three' || $theme_style == 'theme-five' || $theme_style == 'theme-six' || $theme_style
	                                                                                                     == 'theme-seven' || $theme_style == 'theme-nine'
	) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-rating{
			margin: ' . $testimonial_client_rating_margin['top'] . 'px ' . $testimonial_client_rating_margin['right'] . 'px ' . $testimonial_client_rating_margin['bottom'] . 'px ' . $testimonial_client_rating_margin['left'] . 'px;
			text-align: ' . $testimonial_client_rating_alignment_two . ';
			color: ' . $shortcode_data['testimonial_client_rating_color'] . ';
		}';
	}
}

if ( $client_designation == 'true' || $client_company_name == 'true' ) {
	if ( $theme_style == 'theme-one' || $theme_style == 'theme-two' || $theme_style == 'theme-four' || $theme_style == 'theme-eight' || $theme_style == 'theme-ten' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-designation-company{
			font-size: ' . $client_designation_company_typography['size'] . 'px;
			color: ' . $client_designation_company_typography['color'] . ';
			line-height: ' . $client_designation_company_typography['height'] . 'px;
			text-transform: ' . $client_designation_company_typography['transform'] . ';
			text-align: ' . $client_designation_company_typography['alignment'] . ';
			letter-spacing: ' . $client_designation_company_typography['spacing'] . ';';
		if($shortcode_data['designation_company_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_designation_company_typography['family'] . ';
			font-weight: ' . $client_designation_company_weight . ';
			font-style: ' . $client_designation_company_style . ';
			';
		}
		$outline .= 'margin: ' . $client_designation_company_margin['top'] . 'px ' . $client_designation_company_margin['right'] . 'px ' . $client_designation_company_margin['bottom'] . 'px ' . $client_designation_company_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-client-designation-company{
			font-size: ' . $client_designation_company_typography['size'] . 'px;
			color: #444444;
			line-height: ' . $client_designation_company_typography['height'] . 'px;
			text-transform: ' . $client_designation_company_typography['transform'] . ';
			text-align: center;
			letter-spacing: ' . $client_designation_company_typography['spacing'] . ';';
		if($shortcode_data['designation_company_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_designation_company_typography['family'] . ';
			font-weight: ' . $client_designation_company_weight . ';
			font-style: ' . $client_designation_company_style . ';
			';
		}
		$outline .= '}';
	}
	if ( $theme_style == 'theme-three' || $theme_style == 'theme-five' || $theme_style == 'theme-six' || $theme_style
	                                                                                                     == 'theme-seven' || $theme_style == 'theme-nine'
	) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-designation-company{
			font-size: ' . $client_designation_company_typography_two['size'] . 'px;
			color: ' . $client_designation_company_typography_two['color'] . ';
			line-height: ' . $client_designation_company_typography_two['height'] . 'px;
			text-transform: ' . $client_designation_company_typography_two['transform'] . ';
			text-align: ' . $client_designation_company_typography_two['alignment'] . ';
			letter-spacing: ' . $client_designation_company_typography_two['spacing'] . ';';
		if($shortcode_data['designation_company_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_designation_company_typography_two['family'] . ';
			font-weight: ' . $client_designation_company_weight_two . ';
			font-style: ' . $client_designation_company_style_two . ';
			';
		}
		$outline .= 'margin: ' . $client_designation_company_margin['top'] . 'px ' . $client_designation_company_margin['right'] . 'px ' . $client_designation_company_margin['bottom'] . 'px ' . $client_designation_company_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-client-designation-company{
			font-size: ' . $client_designation_company_typography_two['size'] . 'px;
			color: #444444;
			line-height: ' . $client_designation_company_typography_two['height'] . 'px;
			text-transform: ' . $client_designation_company_typography_two['transform'] . ';
			text-align: center;
			letter-spacing: ' . $client_designation_company_typography_two['spacing'] . ';';
		if($shortcode_data['designation_company_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_designation_company_typography_two['family'] . ';
			font-weight: ' . $client_designation_company_weight_two . ';
			font-style: ' . $client_designation_company_style_two . ';
			';
		}
		$outline .= '}';
	}
}
if ( $shortcode_data['testimonial_client_location'] == 'true' ) {
	if ( $theme_style == 'theme-one' || $theme_style == 'theme-two' || $theme_style == 'theme-four' || $theme_style == 'theme-eight' || $theme_style == 'theme-ten' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-location{
			font-size: ' . $client_location_typography['size'] . 'px;
			color: ' . $client_location_typography['color'] . ';
			line-height: ' . $client_location_typography['height'] . 'px;
			text-transform: ' . $client_location_typography['transform'] . ';
			text-align: ' . $client_location_typography['alignment'] . ';
			letter-spacing: ' . $client_location_typography['spacing'] . ';';
		if($shortcode_data['location_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_location_typography['family'] . ';
			font-weight: ' . $client_location_weight . ';
			font-style: ' . $client_location_style . ';
			';
		}
		$outline .= 'margin: ' . $testimonial_client_location_margin['top'] . 'px ' . $testimonial_client_location_margin['right'] . 'px ' . $testimonial_client_location_margin['bottom'] . 'px ' . $testimonial_client_location_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-client-location{
			font-size: ' . $client_location_typography['size'] . 'px;
			color: #444444;
			line-height: ' . $client_location_typography['height'] . 'px;
			text-transform: ' . $client_location_typography['transform'] . ';
			text-align: center;
			letter-spacing: ' . $client_location_typography['spacing'] . ';';
		if($shortcode_data['location_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_location_typography['family'] . ';
			font-weight: ' . $client_location_weight . ';
			font-style: ' . $client_location_style . ';
			';
		}
		$outline .= '}';
	}
	if ( $theme_style == 'theme-three' || $theme_style == 'theme-five' || $theme_style == 'theme-six' || $theme_style
	                                                                                                     == 'theme-seven' || $theme_style == 'theme-nine'
	) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-location{
			font-size: ' . $client_location_typography_two['size'] . 'px;
			color: ' . $client_location_typography_two['color'] . ';
			line-height: ' . $client_location_typography_two['height'] . 'px;
			text-transform: ' . $client_location_typography_two['transform'] . ';
			text-align: ' . $client_location_typography_two['alignment'] . ';
			letter-spacing: ' . $client_location_typography_two['spacing'] . ';';
		if($shortcode_data['location_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_location_typography_two['family'] . ';
			font-weight: ' . $client_location_weight_two . ';
			font-style: ' . $client_location_style_two . ';
			';
		}
		$outline .= 'margin: ' . $testimonial_client_location_margin['top'] . 'px ' . $testimonial_client_location_margin['right'] . 'px ' . $testimonial_client_location_margin['bottom'] . 'px ' . $testimonial_client_location_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-client-location{
			font-size: ' . $client_location_typography_two['size'] . 'px;
			color: #444444;
			line-height: ' . $client_location_typography_two['height'] . 'px;
			text-transform: ' . $client_location_typography_two['transform'] . ';
			text-align: center;
			letter-spacing: ' . $client_location_typography_two['spacing'] . ';';
		if($shortcode_data['location_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_location_typography_two['family'] . ';
			font-weight: ' . $client_location_weight_two . ';
			font-style: ' . $client_location_style_two . ';
			';
		}
		$outline .= '}';
	}
}
if ( $shortcode_data['testimonial_client_phone'] == 'true' ) {
	if ( $theme_style == 'theme-one' || $theme_style == 'theme-two' || $theme_style == 'theme-four' || $theme_style == 'theme-eight' || $theme_style == 'theme-ten' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-phone{
			font-size: ' . $client_phone_typography['size'] . 'px;
			color: ' . $client_phone_typography['color'] . ';
			line-height: ' . $client_phone_typography['height'] . 'px;
			text-transform: ' . $client_phone_typography['transform'] . ';
			text-align: ' . $client_phone_typography['alignment'] . ';
			letter-spacing: ' . $client_phone_typography['spacing'] . ';';
		if($shortcode_data['phone_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_phone_typography['family'] . ';
			font-weight: ' . $client_phone_weight . ';
			font-style: ' . $client_phone_style . ';
			';
		}
		$outline .= 'margin: ' . $testimonial_client_phone_margin['top'] . 'px ' . $testimonial_client_phone_margin['right'] . 'px ' . $testimonial_client_phone_margin['bottom'] . 'px ' . $testimonial_client_phone_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-client-phone{
			font-size: ' . $client_phone_typography['size'] . 'px;
			color: #444444;
			line-height: ' . $client_phone_typography['height'] . 'px;
			text-transform: ' . $client_phone_typography['transform'] . ';
			text-align: center;
			letter-spacing: ' . $client_phone_typography['spacing'] . ';';
		if($shortcode_data['phone_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_phone_typography['family'] . ';
			font-weight: ' . $client_phone_weight . ';
			font-style: ' . $client_phone_style . ';
			';
		}
		$outline .= '}';
	}
	if ( $theme_style == 'theme-three' || $theme_style == 'theme-five' || $theme_style == 'theme-six' || $theme_style
	                                                                                                     == 'theme-seven' || $theme_style == 'theme-nine'
	) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-phone{
			font-size: ' . $client_phone_typography_two['size'] . 'px;
			color: ' . $client_phone_typography_two['color'] . ';
			line-height: ' . $client_phone_typography_two['height'] . 'px;
			text-transform: ' . $client_phone_typography_two['transform'] . ';
			text-align: ' . $client_phone_typography_two['alignment'] . ';
			letter-spacing: ' . $client_phone_typography_two['spacing'] . ';';
		if($shortcode_data['phone_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_phone_typography_two['family'] . ';
			font-weight: ' . $client_phone_weight_two . ';
			font-style: ' . $client_phone_style_two . ';
			';
		}
		$outline .= 'margin: ' . $testimonial_client_phone_margin['top'] . 'px ' . $testimonial_client_phone_margin['right'] . 'px ' . $testimonial_client_phone_margin['bottom'] . 'px ' . $testimonial_client_phone_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-client-phone{
			font-size: ' . $client_phone_typography_two['size'] . 'px;
			color: #444444;
			line-height: ' . $client_phone_typography_two['height'] . 'px;
			text-transform: ' . $client_phone_typography_two['transform'] . ';
			text-align: center;
			letter-spacing: ' . $client_phone_typography_two['spacing'] . ';';
		if($shortcode_data['phone_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_phone_typography_two['family'] . ';
			font-weight: ' . $client_phone_weight_two . ';
			font-style: ' . $client_phone_style_two . ';
			';
		}
		$outline .= '}';
	}
}
if ( $shortcode_data['testimonial_client_email'] == 'true' ) {
	if ( $theme_style == 'theme-one' || $theme_style == 'theme-two' || $theme_style == 'theme-four' || $theme_style == 'theme-eight' || $theme_style == 'theme-ten' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-email{
			font-size: ' . $client_email_typography['size'] . 'px;
			color: ' . $client_email_typography['color'] . ';
			line-height: ' . $client_email_typography['height'] . 'px;
			text-transform: ' . $client_email_typography['transform'] . ';
			text-align: ' . $client_email_typography['alignment'] . ';
			letter-spacing: ' . $client_email_typography['spacing'] . ';';
		if($shortcode_data['email_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_email_typography['family'] . ';
			font-weight: ' . $client_email_weight . ';
			font-style: ' . $client_email_style . ';
			';
		}
		$outline .= 'margin: ' . $testimonial_client_email_margin['top'] . 'px ' . $testimonial_client_email_margin['right'] . 'px ' . $testimonial_client_email_margin['bottom'] . 'px ' . $testimonial_client_email_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-client-email{
			font-size: ' . $client_email_typography['size'] . 'px;
			color: #444444;
			line-height: ' . $client_email_typography['height'] . 'px;
			text-transform: ' . $client_email_typography['transform'] . ';
			text-align: center;
			letter-spacing: ' . $client_email_typography['spacing'] . ';';
		if($shortcode_data['email_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_email_typography['family'] . ';
			font-weight: ' . $client_email_weight . ';
			font-style: ' . $client_email_style . ';
			';
		}
		$outline .= '}';
	}
	if ( $theme_style == 'theme-three' || $theme_style == 'theme-five' || $theme_style == 'theme-six' || $theme_style
	                                                                                                     == 'theme-seven' || $theme_style == 'theme-nine'
	) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-email{
			font-size: ' . $client_email_typography_two['size'] . 'px;
			color: ' . $client_email_typography_two['color'] . ';
			line-height: ' . $client_email_typography_two['height'] . 'px;
			text-transform: ' . $client_email_typography_two['transform'] . ';
			text-align: ' . $client_email_typography_two['alignment'] . ';
			letter-spacing: ' . $client_email_typography_two['spacing'] . ';';
		if($shortcode_data['email_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_email_typography_two['family'] . ';
			font-weight: ' . $client_email_weight_two . ';
			font-style: ' . $client_email_style_two . ';
			';
		}
		$outline .= 'margin: ' . $testimonial_client_email_margin['top'] . 'px ' . $testimonial_client_email_margin['right'] . 'px ' . $testimonial_client_email_margin['bottom'] . 'px ' . $testimonial_client_email_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-client-email{
			font-size: ' . $client_email_typography_two['size'] . 'px;
			color: #444444;
			line-height: ' . $client_email_typography_two['height'] . 'px;
			text-transform: ' . $client_email_typography_two['transform'] . ';
			text-align: center;
			letter-spacing: ' . $client_email_typography_two['spacing'] . ';';
		if($shortcode_data['email_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_email_typography_two['family'] . ';
			font-weight: ' . $client_email_weight_two . ';
			font-style: ' . $client_email_style_two . ';
			';
		}
		$outline .= '}';
	}
}
if ( $shortcode_data['testimonial_client_date'] == 'true' ) {
	if ( $theme_style == 'theme-one' || $theme_style == 'theme-two' || $theme_style == 'theme-four' || $theme_style == 'theme-eight' || $theme_style == 'theme-ten' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-testimonial-date{
			font-size: ' . $testimonial_date_typography['size'] . 'px;
			color: ' . $testimonial_date_typography['color'] . ';
			line-height: ' . $testimonial_date_typography['height'] . 'px;
			text-transform: ' . $testimonial_date_typography['transform'] . ';
			text-align: ' . $testimonial_date_typography['alignment'] . ';
			letter-spacing: ' . $testimonial_date_typography['spacing'] . ';';
		if($shortcode_data['date_font_load'] == 'true'){
			$outline .= '
			font-family: ' . $testimonial_date_typography['family'] . ';
			font-weight: ' . $testimonial_date_weight . ';
			font-style: ' . $testimonial_date_style . ';
			';
		}
		$outline .= 'margin: ' . $testimonial_client_date_margin['top'] . 'px ' . $testimonial_client_date_margin['right'] . 'px ' . $testimonial_client_date_margin['bottom'] . 'px ' . $testimonial_client_date_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-testimonial-date{
			font-size: ' . $testimonial_date_typography['size'] . 'px;
			color: #444444;
			line-height: ' . $testimonial_date_typography['height'] . 'px;
			text-transform: ' . $testimonial_date_typography['transform'] . ';
			text-align: center;
			letter-spacing: ' . $testimonial_date_typography['spacing'] . ';';
		if($shortcode_data['date_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_date_typography['family'] . ';
			font-weight: ' . $testimonial_date_weight . ';
			font-style: ' . $testimonial_date_style . ';
			';
		}
		$outline .= '}';
	}
	if ( $theme_style == 'theme-three' || $theme_style == 'theme-five' || $theme_style == 'theme-six' || $theme_style
	                                                                                                     == 'theme-seven' || $theme_style == 'theme-nine'
	) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-testimonial-date{
			font-size: ' . $testimonial_date_typography_two['size'] . 'px;
			color: ' . $testimonial_date_typography_two['color'] . ';
			line-height: ' . $testimonial_date_typography_two['height'] . 'px;
			text-transform: ' . $testimonial_date_typography_two['transform'] . ';
			text-align: ' . $testimonial_date_typography_two['alignment'] . ';
			letter-spacing: ' . $testimonial_date_typography_two['spacing'] . ';';
		if($shortcode_data['date_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_date_typography_two['family'] . ';
			font-weight: ' . $testimonial_date_weight_two . ';
			font-style: ' . $testimonial_date_style_two . ';
			';
		}
		$outline .= 'margin: ' . $testimonial_client_date_margin['top'] . 'px ' . $testimonial_client_date_margin['right'] . 'px ' . $testimonial_client_date_margin['bottom'] . 'px ' . $testimonial_client_date_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-testimonial-date{
			font-size: ' . $testimonial_date_typography_two['size'] . 'px;
			color: #444444;
			line-height: ' . $testimonial_date_typography_two['height'] . 'px;
			text-transform: ' . $testimonial_date_typography_two['transform'] . ';
			text-align: center;
			letter-spacing: ' . $testimonial_date_typography_two['spacing'] . ';';
		if($shortcode_data['date_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $testimonial_date_typography_two['family'] . ';
			font-weight: ' . $testimonial_date_weight_two . ';
			font-style: ' . $testimonial_date_style_two . ';
			';
		}
		$outline .= '}';
	}
}
if ( $shortcode_data['testimonial_client_website'] == 'true' ) {
	if ( $theme_style == 'theme-one' || $theme_style == 'theme-two' || $theme_style == 'theme-four' || $theme_style == 'theme-eight' || $theme_style == 'theme-ten' ) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-website{
			font-size: ' . $client_website_typography['size'] . 'px;
			color: ' . $client_website_typography['color'] . ';
			line-height: ' . $client_website_typography['height'] . 'px;
			text-transform: ' . $client_website_typography['transform'] . ';
			text-align: ' . $client_website_typography['alignment'] . ';
			letter-spacing: ' . $client_website_typography['spacing'] . ';';
		if($shortcode_data['website_font_load'] == 'true'){
			$outline .= '
			font-family: ' . $client_website_typography['family'] . ';
			font-weight: ' . $client_website_weight . ';
			font-style: ' . $client_website_style . ';
			';
		}
		$outline .= 'margin: ' . $testimonial_client_website_margin['top'] . 'px ' . $testimonial_client_website_margin['right'] . 'px ' . $testimonial_client_website_margin['bottom'] . 'px ' . $testimonial_client_website_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-client-website{
			font-size: ' . $client_website_typography['size'] . 'px;
			color: #444444;
			line-height: ' . $client_website_typography['height'] . 'px;
			text-transform: ' . $client_website_typography['transform'] . ';
			text-align: center;
			letter-spacing: ' . $client_website_typography['spacing'] . ';';
		if($shortcode_data['website_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_website_typography['family'] . ';
			font-weight: ' . $client_website_weight . ';
			font-style: ' . $client_website_style . ';
			';
		}
		$outline .= '}';
	}
	if ( $theme_style == 'theme-three' || $theme_style == 'theme-five' || $theme_style == 'theme-six' || $theme_style
	                                                                                                     == 'theme-seven' || $theme_style == 'theme-nine'
	) {
		$outline .= '
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .tpro-client-website{
			font-size: ' . $client_website_typography_two['size'] . 'px;
			color: ' . $client_website_typography_two['color'] . ';
			line-height: ' . $client_website_typography_two['height'] . 'px;
			text-transform: ' . $client_website_typography_two['transform'] . ';
			text-align: ' . $client_website_typography_two['alignment'] . ';
			letter-spacing: ' . $client_website_typography_two['spacing'] . ';';
		if($shortcode_data['website_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_website_typography_two['family'] . ';
			font-weight: ' . $client_website_weight_two . ';
			font-style: ' . $client_website_style_two . ';
			';
		}
		$outline .='margin: ' . $testimonial_client_website_margin['top'] . 'px ' . $testimonial_client_website_margin['right'] . 'px ' . $testimonial_client_website_margin['bottom'] . 'px ' . $testimonial_client_website_margin['left'] . 'px;
		}
		.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-client-website{
			font-size: ' . $client_website_typography_two['size'] . 'px;
			color: #444444;
			line-height: ' . $client_website_typography_two['height'] . 'px;
			text-transform: ' . $client_website_typography_two['transform'] . ';
			text-align: center;
			letter-spacing: ' . $client_website_typography_two['spacing'] . ';';
		if($shortcode_data['website_font_load'] == 'true') {
			$outline .= '
			font-family: ' . $client_website_typography_two['family'] . ';
			font-weight: ' . $client_website_weight_two . ';
			font-style: ' . $client_website_style_two . ';
			';
		}
		$outline .= '}';
	}
}

if ( $theme_style == 'theme-two' || $theme_style == 'theme-six' ) {
	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
		border: ' . $shortcode_data['testimonial_border_size'] . 'px solid ' . $shortcode_data['testimonial_border_color'] . ';
	    background: ' . $shortcode_data['testimonial_bg'] . ';
	}';
	if ( $client_image !== 'true' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
			padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
		}';
	}
} elseif ( $theme_style == 'theme-three' ) {
	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
		border: ' . $shortcode_data['testimonial_border_size_two'] . 'px solid ' . $shortcode_data['testimonial_border_color'] . ';
	    background: ' . $shortcode_data['testimonial_bg'] . ';
	}';
	if ( $client_image !== 'true' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
			padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
		}';
	}
} elseif ( $theme_style == 'theme-four' ) {
	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
		border: ' . $shortcode_data['testimonial_border_size'] . 'px solid ' . $shortcode_data['testimonial_border_color'] . ';
	    background: ' . $shortcode_data['testimonial_bg_two'] . ';
	}';
	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
		padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
	}';
} elseif ( $theme_style == 'theme-five' ) {
	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
		border: ' . $shortcode_data['testimonial_border_size_two'] . 'px solid ' . $shortcode_data['testimonial_border_color'] . ';
	    background: ' . $shortcode_data['testimonial_bg'] . ';
	}';
	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
			padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
		}';
} elseif ( $theme_style == 'theme-seven' ) {
	$tpro_border_width  = $shortcode_data['testimonial_border_size'] + 13;
	$tpro_border_height = $shortcode_data['testimonial_border_size'] + 17;
	$tpro_margin_top    = $tpro_border_height + 10;
	$outline            .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area{
		border: ' . $shortcode_data['testimonial_border_size'] . 'px solid ' . $shortcode_data['testimonial_border_color'] . ';
	    background: ' . $shortcode_data['testimonial_bg_three'] . ';
	    margin-top: ' . $tpro_margin_top . 'px;
	}';
	$outline            .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after, #sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
		bottom: 100%;
	    left: 30px;
	    border: solid transparent;
	    content: "";
	    height: 0;
	    width: 0;
	    position: absolute;
	    pointer-events: none;
	}
	#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after {
	    border-color: transparent;
	    border-bottom-color: ' . $shortcode_data['testimonial_bg_three'] . ';
	    border-width: 0 13px 17px 13px;
	    margin-left: 0;
	}
	
	#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
	    border-color: transparent;
	    border-bottom-color: ' . $shortcode_data['testimonial_border_color'] . ';
	    border-width: 0 ' . $tpro_border_width . 'px ' . $tpro_border_height . 'px ' . $tpro_border_width . 'px;
	    margin-left: -' . $shortcode_data['testimonial_border_size'] . 'px;
	}';

	if ( $client_image !== 'true' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area{
			padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
		}';
	}
} elseif ( $theme_style == 'theme-eight' ) {

	if ( $shortcode_data['testimonial_info_position'] == 'bottom' ) {
		$tpro_border_width  = $shortcode_data['testimonial_border_size_two'] + 13;
		$tpro_border_height = $shortcode_data['testimonial_border_size_two'] + 17;

		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area{
			border: ' . $shortcode_data['testimonial_border_size_two'] . 'px solid ' . $shortcode_data['testimonial_border_color'] . ';
		    background: ' . $shortcode_data['testimonial_bg_three'] . ';
		    padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
			position: relative;
		}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-meta-area{
			border-top: 0 solid;
			border-bottom: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-left: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-right: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-color: ' . $shortcode_data['testimonial_info_border_color'] . ';
		    background: ' . $shortcode_data['testimonial_info_bg'] . ';
		    padding: ' . $testimonial_info_inner_padding['top'] . 'px ' . $testimonial_info_inner_padding['right'] . 'px ' . $testimonial_info_inner_padding['bottom'] . 'px ' . $testimonial_info_inner_padding['left'] . 'px;
		}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after, #sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
			top: 100%;
		    right: 50%;
		    border: solid transparent;
		    content: "";
		    height: 0;
		    width: 0;
		    position: absolute;
		    pointer-events: none;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after {
		    border-color: transparent;
		    border-top-color: ' . $shortcode_data['testimonial_bg_three'] . ';
		    border-width: 17px 13px 0 13px;
		    margin-right: -13px;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
		    border-color: transparent;
		    border-top-color: ' . $shortcode_data['testimonial_border_color'] . ';
		    border-width: ' . $tpro_border_height . 'px ' . $tpro_border_width . 'px 0 ' . $tpro_border_width . 'px;
		    margin-right: -' . $tpro_border_width . 'px;
		}';
	} elseif ( $shortcode_data['testimonial_info_position'] == 'top' ) {
		$tpro_border_width  = $shortcode_data['testimonial_border_size_two'] + 13;
		$tpro_border_height = $shortcode_data['testimonial_border_size_two'] + 17;

		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area{
			border: ' . $shortcode_data['testimonial_border_size_two'] . 'px solid ' . $shortcode_data['testimonial_border_color'] . ';
		    background: ' . $shortcode_data['testimonial_bg_three'] . ';
		    padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
			position: relative;
		}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-meta-area{
			border-top: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-bottom: 0 solid;
			border-left: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-right: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-color: ' . $shortcode_data['testimonial_info_border_color'] . ';
		    background: ' . $shortcode_data['testimonial_info_bg'] . ';
		    padding: ' . $testimonial_info_inner_padding['top'] . 'px ' . $testimonial_info_inner_padding['right'] . 'px ' . $testimonial_info_inner_padding['bottom'] . 'px ' . $testimonial_info_inner_padding['left'] . 'px;
		}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after, #sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
			bottom: 100%;
		    right: 50%;
		    border: solid transparent;
		    content: "";
		    height: 0;
		    width: 0;
		    position: absolute;
		    pointer-events: none;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after {
		    border-color: transparent;
		    border-bottom-color: ' . $shortcode_data['testimonial_bg_three'] . ';
		    border-width: 0 13px 17px 13px;
		    margin-right: -13px;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
		    border-color: transparent;
		    border-bottom-color: ' . $shortcode_data['testimonial_border_color'] . ';
		    border-width: 0 ' . $tpro_border_width . 'px ' . $tpro_border_height . 'px ' . $tpro_border_width . 'px;
		    margin-right: -' . $tpro_border_width . 'px;
		}';
	} elseif ( $shortcode_data['testimonial_info_position'] == 'right' ) {
		$tpro_border_width  = $shortcode_data['testimonial_border_size_two'] + 13;
		$tpro_border_height = $shortcode_data['testimonial_border_size_two'] + 17;

		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area{
			border: ' . $shortcode_data['testimonial_border_size_two'] . 'px solid ' . $shortcode_data['testimonial_border_color'] . ';
		    background: ' . $shortcode_data['testimonial_bg_three'] . ';
		    padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
			position: relative;
			display: table-cell;
			vertical-align: top;
			width: 100%;
		}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-meta-area{
			border-top: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-bottom: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-left: 0 solid;
			border-right: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-color: ' . $shortcode_data['testimonial_info_border_color'] . ';
		    background: ' . $shortcode_data['testimonial_info_bg'] . ';
		    padding: ' . $testimonial_info_inner_padding['top'] . 'px ' . $testimonial_info_inner_padding['right'] . 'px ' . $testimonial_info_inner_padding['bottom'] . 'px ' . $testimonial_info_inner_padding['left'] . 'px;
		    display: table-cell;
            vertical-align: top;
		}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after, #sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
			left: 100%;
		    top: 50px;
		    border: solid transparent;
		    content: "";
		    height: 0;
		    width: 0;
		    position: absolute;
		    pointer-events: none;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after {
		    border-color: transparent;
		    border-left-color: ' . $shortcode_data['testimonial_bg_three'] . ';
		    border-width: 13px 0 13px 17px;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
		    border-color: transparent;
		    border-left-color: ' . $shortcode_data['testimonial_border_color'] . ';
		    border-width: ' . $tpro_border_width . 'px 0 ' . $tpro_border_width . 'px ' . $tpro_border_height . 'px;		    
		    margin-top: -' . $shortcode_data['testimonial_border_size_two'] . 'px;
		}';
	} elseif ( $shortcode_data['testimonial_info_position'] == 'left' ) {
		$tpro_border_width  = $shortcode_data['testimonial_border_size_two'] + 13;
		$tpro_border_height = $shortcode_data['testimonial_border_size_two'] + 17;

		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area{
			border: ' . $shortcode_data['testimonial_border_size_two'] . 'px solid ' . $shortcode_data['testimonial_border_color'] . ';
		    background: ' . $shortcode_data['testimonial_bg_three'] . ';
		    padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
			position: relative;
			display: table-cell;
			vertical-align: top;
			width: 100%;
		}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-meta-area{
			border-top: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-bottom: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-left: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-right: 0 solid;
			border-color: ' . $shortcode_data['testimonial_info_border_color'] . ';
		    background: ' . $shortcode_data['testimonial_info_bg'] . ';
		    padding: ' . $testimonial_info_inner_padding['top'] . 'px ' . $testimonial_info_inner_padding['right'] . 'px ' . $testimonial_info_inner_padding['bottom'] . 'px ' . $testimonial_info_inner_padding['left'] . 'px;
		    display: table-cell;
            vertical-align: top;
		}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after, #sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
			right: 100%;
		    top: 50px;
		    border: solid transparent;
		    content: "";
		    height: 0;
		    width: 0;
		    position: absolute;
		    pointer-events: none;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after {
		    border-color: transparent;
		    border-right-color: ' . $shortcode_data['testimonial_bg_three'] . ';
		    border-width: 13px 17px 13px 0;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
		    border-color: transparent;
		    border-right-color: ' . $shortcode_data['testimonial_border_color'] . ';
		    border-width: ' . $tpro_border_width . 'px ' . $tpro_border_height . 'px ' . $tpro_border_width . 'px 0;		    
		    margin-top: -' . $shortcode_data['testimonial_border_size_two'] . 'px;
		}';
	}
} elseif ( $theme_style == 'theme-nine' ) {
	$tpro_border_width  = $shortcode_data['testimonial_border_size_two'] + 13;
	$tpro_border_height = $shortcode_data['testimonial_border_size_two'] + 17;

	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area{
			border: ' . $shortcode_data['testimonial_border_size_two'] . 'px solid ' . $shortcode_data['testimonial_border_color'] . ';
		    background: ' . $shortcode_data['testimonial_bg_three'] . ';
		    padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
			position: relative;
		}';

	if ( $shortcode_data['testimonial_info_position_two'] == 'bottom_left' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-meta-area{
			display: flex;
			border-top: 0 solid;
			border-bottom: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-left: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-right: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-color: ' . $shortcode_data['testimonial_info_border_color'] . ';
		    background: ' . $shortcode_data['testimonial_info_bg'] . ';
		    padding: ' . $testimonial_info_inner_padding['top'] . 'px ' . $testimonial_info_inner_padding['right'] . 'px ' . $testimonial_info_inner_padding['bottom'] . 'px ' . $testimonial_info_inner_padding['left'] . 'px;
		}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-meta-text{
			flex: 1;
		}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after, #sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
			top: 100%;
		    left: 70px;
		    border: solid transparent;
		    content: "";
		    height: 0;
		    width: 0;
		    position: absolute;
		    pointer-events: none;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after {
		    border-color: transparent;
		    border-top-color: ' . $shortcode_data['testimonial_bg_three'] . ';
		    border-width: 17px 13px 0 13px;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
		    border-color: transparent;
		    border-top-color: ' . $shortcode_data['testimonial_border_color'] . ';
		    border-width: ' . $tpro_border_height . 'px ' . $tpro_border_width . 'px 0 ' . $tpro_border_width . 'px;
		    margin-left: -' . $shortcode_data['testimonial_border_size_two'] . 'px;
		}';
	} elseif ( $shortcode_data['testimonial_info_position_two'] == 'bottom_right' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-meta-area{
			display: flex;
			border-top: 0 solid;
			border-bottom: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-left: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-right: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-color: ' . $shortcode_data['testimonial_info_border_color'] . ';
		    background: ' . $shortcode_data['testimonial_info_bg'] . ';
		    padding: ' . $testimonial_info_inner_padding['top'] . 'px ' . $testimonial_info_inner_padding['right'] . 'px ' . $testimonial_info_inner_padding['bottom'] . 'px ' . $testimonial_info_inner_padding['left'] . 'px;
		}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-meta-text{
			flex: 1;
		}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after, #sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
			top: 100%;
		    right: 70px;
		    border: solid transparent;
		    content: "";
		    height: 0;
		    width: 0;
		    position: absolute;
		    pointer-events: none;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after {
		    border-color: transparent;
		    border-top-color: ' . $shortcode_data['testimonial_bg_three'] . ';
		    border-width: 17px 13px 0 13px;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
		    border-color: transparent;
		    border-top-color: ' . $shortcode_data['testimonial_border_color'] . ';
		    border-width: ' . $tpro_border_height . 'px ' . $tpro_border_width . 'px 0 ' . $tpro_border_width . 'px;
		    margin-right: -' . $shortcode_data['testimonial_border_size_two'] . 'px;
		}';
	} elseif ( $shortcode_data['testimonial_info_position_two'] == 'top_left' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-meta-area{
			display: flex;
			border-top: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-bottom: 0 solid;
			border-left: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-right: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-color: ' . $shortcode_data['testimonial_info_border_color'] . ';
		    background: ' . $shortcode_data['testimonial_info_bg'] . ';
		    padding: ' . $testimonial_info_inner_padding['top'] . 'px ' . $testimonial_info_inner_padding['right'] . 'px ' . $testimonial_info_inner_padding['bottom'] . 'px ' . $testimonial_info_inner_padding['left'] . 'px;
		}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-meta-text{
			flex: 1;
		}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after, #sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
			bottom: 100%;
		    left: 70px;
		    border: solid transparent;
		    content: "";
		    height: 0;
		    width: 0;
		    position: absolute;
		    pointer-events: none;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after {
		    border-color: transparent;
		    border-bottom-color: ' . $shortcode_data['testimonial_bg_three'] . ';
		    border-width: 0 13px 17px 13px;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
		    border-color: transparent;
		    border-bottom-color: ' . $shortcode_data['testimonial_border_color'] . ';
		    border-width: 0 ' . $tpro_border_width . 'px ' . $tpro_border_height . 'px ' . $tpro_border_width . 'px;
		    margin-left: -' . $shortcode_data['testimonial_border_size_two'] . 'px;
		}';
	} elseif ( $shortcode_data['testimonial_info_position_two'] == 'top_right' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-meta-area{
			display: flex;
			border-top: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-bottom: 0 solid;
			border-left: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-right: ' . $shortcode_data['testimonial_info_border_size'] . 'px solid;
			border-color: ' . $shortcode_data['testimonial_info_border_color'] . ';
		    background: ' . $shortcode_data['testimonial_info_bg'] . ';
		    padding: ' . $testimonial_info_inner_padding['top'] . 'px ' . $testimonial_info_inner_padding['right'] . 'px ' . $testimonial_info_inner_padding['bottom'] . 'px ' . $testimonial_info_inner_padding['left'] . 'px;
		}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-meta-text{
			flex: 1;
		}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after, #sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
			bottom: 100%;
		    right: 70px;
		    border: solid transparent;
		    content: "";
		    height: 0;
		    width: 0;
		    position: absolute;
		    pointer-events: none;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:after {
		    border-color: transparent;
		    border-bottom-color: ' . $shortcode_data['testimonial_bg_three'] . ';
		    border-width: 0 13px 17px 13px;
		}
		#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area:before {
		    border-color: transparent;
		    border-bottom-color: ' . $shortcode_data['testimonial_border_color'] . ';
		    border-width: 0 ' . $tpro_border_width . 'px ' . $tpro_border_height . 'px ' . $tpro_border_width . 'px;
		    margin-right: -' . $shortcode_data['testimonial_border_size_two'] . 'px;
		}';
	}

} elseif ( $theme_style == 'theme-ten' ) {
	if ( $shortcode_data['client_image_border_shadow'] == 'border' ) {
		$client_image_total_height_size = $client_image_height + $shortcode_data['client_image_border_size'] + $shortcode_data['client_image_border_size'] + $shortcode_data['client_image_padding'] + $shortcode_data['client_image_padding'];
	} elseif ( $shortcode_data['client_image_border_shadow'] == 'box_shadow' ) {
		$client_image_total_height_size = $client_image_height + 14 + $shortcode_data['client_image_padding'] + $shortcode_data['client_image_padding'];
	}

	$client_image_height_size_two = $client_image_total_height_size / 2;
	$client_image_height_size     = $client_image_height_size_two + $testimonial_inner_padding['top'];

	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
		border: ' . $shortcode_data['testimonial_border_size_two'] . 'px solid ' . $shortcode_data['testimonial_border_color'] . ';
	    background: ' . $shortcode_data['testimonial_bg'] . ';
	    -webkit-border-radius: ' . $shortcode_data['testimonial_border_radius'] . 'px;
	    -moz-border-radius: ' . $shortcode_data['testimonial_border_radius'] . 'px;
	    border-radius: ' . $shortcode_data['testimonial_border_radius'] . 'px;
	    box-shadow: 0px 0px 10px ' . $shortcode_data['testimonial_box_shadow_color'] . ';
        margin: 10px;
        position: relative;
	}
	#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .sp-tpro-top-background {
	    background: ' . $shortcode_data['testimonial_top_bg'] . ';
	    height: ' . $client_image_height_size . 'px;
	    width: 100%;
	    position: absolute;
	    top: 0;
	    left: 0;
	    z-index: 1;
	    -webkit-border-radius: ' . $shortcode_data['testimonial_border_radius'] . 'px ' . $shortcode_data['testimonial_border_radius'] . 'px 0 0;
	    -moz-border-radius: ' . $shortcode_data['testimonial_border_radius'] . 'px ' . $shortcode_data['testimonial_border_radius'] . 'px 0 0;
	    border-radius: ' . $shortcode_data['testimonial_border_radius'] . 'px ' . $shortcode_data['testimonial_border_radius'] . 'px 0 0;
	}
	';
	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
		padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
	}';
}

if ( $client_image == 'true' && $theme_style == 'theme-two' ) {

	if ( $shortcode_data['client_image_border_shadow'] == 'border' ) {
		$client_image_total_width_size  = $client_image_width + $shortcode_data['client_image_border_size'] + $shortcode_data['client_image_border_size'] + $shortcode_data['client_image_padding'] + $shortcode_data['client_image_padding'];
		$client_image_total_height_size = $client_image_height + $shortcode_data['client_image_border_size'] + $shortcode_data['client_image_border_size'] + $shortcode_data['client_image_padding'] + $shortcode_data['client_image_padding'];
	} elseif ( $shortcode_data['client_image_border_shadow'] == 'box_shadow' ) {
		$client_image_total_width_size  = $client_image_width + 14 + $shortcode_data['client_image_padding'] + $shortcode_data['client_image_padding'];
		$client_image_total_height_size = $client_image_height + 14 + $shortcode_data['client_image_padding'] + $shortcode_data['client_image_padding'];
	}

	$client_image_width_size       = $client_image_total_width_size / 2;
	$client_image_width_size_right = $client_image_width_size + $testimonial_margin;
	$client_image_height_size      = $client_image_total_height_size / 2;

	$testimonial_inner_padding_left   = $testimonial_inner_padding['left'] + $client_image_width_size;
	$testimonial_inner_padding_right  = $testimonial_inner_padding['right'] + $client_image_width_size;
	$testimonial_inner_padding_top    = $testimonial_inner_padding['top'] + $client_image_width_size;
	$testimonial_inner_padding_bottom = $testimonial_inner_padding['bottom'] + $client_image_width_size;

	// Left site image
	if ( $shortcode_data['client_image_position_two'] == 'left' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-left:' . $client_image_width_size . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding_left . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    top: 50%;
			    left: -' . $client_image_width_size . 'px;
			    margin-top: -' . $client_image_height_size . 'px;
			}';
	} // Right site image
	elseif ( $shortcode_data['client_image_position_two'] == 'right' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-right:' . $client_image_width_size_right . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding_right . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    top: 50%;
			    right: -' . $client_image_width_size . 'px;
			    margin-top: -' . $client_image_height_size . 'px;
			}';
	} // Top site image
	elseif ( $shortcode_data['client_image_position_two'] == 'top' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-top:' . $client_image_width_size . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding_top . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    left: 50%;
			    top: -' . $client_image_height_size . 'px;
			    margin-left: -' . $client_image_width_size . 'px;
			}';
	} // Bottom site image
	elseif ( $shortcode_data['client_image_position_two'] == 'bottom' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-bottom:' . $client_image_width_size . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding_bottom . 'px ' . $testimonial_inner_padding['left'] . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    left: 50%;
			    bottom: -' . $client_image_height_size . 'px;
			    margin-left: -' . $client_image_width_size . 'px;
			}';
	}
}

if ( $client_image == 'true' && $theme_style == 'theme-three' ) {

	if ( $shortcode_data['client_image_border_shadow'] == 'border' ) {
		$client_image_total_width_size  = $client_image_width + $shortcode_data['client_image_border_size'] + $shortcode_data['client_image_border_size'] + $shortcode_data['client_image_padding'] + $shortcode_data['client_image_padding'];
		$client_image_total_height_size = $client_image_height + $shortcode_data['client_image_border_size'] + $shortcode_data['client_image_border_size'] + $shortcode_data['client_image_padding'] + $shortcode_data['client_image_padding'];
	} elseif ( $shortcode_data['client_image_border_shadow'] == 'box_shadow' ) {
		$client_image_total_width_size  = $client_image_width + 14 + $shortcode_data['client_image_padding'] + $shortcode_data['client_image_padding'];
		$client_image_total_height_size = $client_image_height + 14 + $shortcode_data['client_image_padding'] + $shortcode_data['client_image_padding'];
	}

	$client_image_width_size       = $client_image_total_width_size / 2;
	$client_image_width_size_right = $client_image_width_size + $testimonial_margin;
	$client_image_height_size      = $client_image_total_height_size / 2;

	$testimonial_inner_padding_left   = $testimonial_inner_padding['left'] + $client_image_width_size;
	$testimonial_inner_padding_right  = $testimonial_inner_padding['right'] + $client_image_width_size;
	$testimonial_inner_padding_top    = $testimonial_inner_padding['top'] + $client_image_width_size;
	$testimonial_inner_padding_bottom = $testimonial_inner_padding['bottom'] + $client_image_width_size;

	// Left-Top site image
	if ( $shortcode_data['client_image_position_three'] == 'left-top' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-left:' . $client_image_width_size . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding_left . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    top: 45px;
			    left: -' . $client_image_width_size . 'px;
			}';
	} // Left-Bottom site image
	elseif ( $shortcode_data['client_image_position_three'] == 'left-bottom' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-left:' . $client_image_width_size . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding_left . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    bottom: 45px;
			    left: -' . $client_image_width_size . 'px;
			}';
	} // Right-Top site image
	elseif ( $shortcode_data['client_image_position_three'] == 'right-top' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-right:' . $client_image_width_size_right . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding_right . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    top: 45px;
			    right: -' . $client_image_width_size . 'px;
			}';
	} // Right-Bottom site image
	elseif ( $shortcode_data['client_image_position_three'] == 'right-bottom' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-right:' . $client_image_width_size_right . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding_right . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    bottom: 45px;
			    right: -' . $client_image_width_size . 'px;
			}';
	} // Top-Left site image
	elseif ( $shortcode_data['client_image_position_three'] == 'top-left' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-top:' . $client_image_width_size . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding_top . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    left: 45px;
			    top: -' . $client_image_height_size . 'px;
			}';
	} // Top-Left site image
	elseif ( $shortcode_data['client_image_position_three'] == 'top-right' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-top:' . $client_image_width_size . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding_top . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    right: 45px;
			    top: -' . $client_image_height_size . 'px;
			}';
	} // Bottom-Left site image
	elseif ( $shortcode_data['client_image_position_three'] == 'bottom-left' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-bottom:' . $client_image_width_size . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding_bottom . 'px ' . $testimonial_inner_padding['left'] . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    left: 45px;
			    bottom: -' . $client_image_height_size . 'px;
			}';
	} // Bottom-Right site image
	elseif ( $shortcode_data['client_image_position_three'] == 'bottom-right' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-bottom:' . $client_image_width_size . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding_bottom . 'px ' . $testimonial_inner_padding['left'] . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    right: 45px;
			    bottom: -' . $client_image_height_size . 'px;
			}';
	}
}

if ( $client_image == 'true' && $theme_style == 'theme-six' ) {

	if ( $shortcode_data['client_image_border_shadow'] == 'border' ) {
		$client_image_total_width_size  = $client_image_width + $shortcode_data['client_image_border_size'] + $shortcode_data['client_image_border_size'] + $shortcode_data['client_image_padding'] + $shortcode_data['client_image_padding'];
		$client_image_total_height_size = $client_image_height + $shortcode_data['client_image_border_size'] + $shortcode_data['client_image_border_size'] + $shortcode_data['client_image_padding'] + $shortcode_data['client_image_padding'];
	} elseif ( $shortcode_data['client_image_border_shadow'] == 'box_shadow' ) {
		$client_image_total_width_size  = $client_image_width + 14 + $shortcode_data['client_image_padding'] + $shortcode_data['client_image_padding'];
		$client_image_total_height_size = $client_image_height + 14 + $shortcode_data['client_image_padding'] + $shortcode_data['client_image_padding'];
	}

	$client_image_width_size       = $client_image_total_width_size / 2;
	$client_image_width_size_right = $client_image_width_size + $testimonial_margin;
	$client_image_height_size      = $client_image_total_height_size / 2;

	$testimonial_inner_padding_left   = $testimonial_inner_padding['left'] + $client_image_width_size;
	$testimonial_inner_padding_right  = $testimonial_inner_padding['right'] + $client_image_width_size;
	$testimonial_inner_padding_top    = $testimonial_inner_padding['top'] + $client_image_width_size;
	$testimonial_inner_padding_bottom = $testimonial_inner_padding['bottom'] + $client_image_width_size;

	// Left-Top site image
	if ( $shortcode_data['client_image_position_three'] == 'left-top' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-left:' . $client_image_width_size . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding_left . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    top: 30px;
			    left: -' . $client_image_width_size . 'px;
			}';
	} // Left-Bottom site image
	elseif ( $shortcode_data['client_image_position_three'] == 'left-bottom' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-left:' . $client_image_width_size . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding_left . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    bottom: 30px;
			    left: -' . $client_image_width_size . 'px;
			}';
	} // Right-Top site image
	elseif ( $shortcode_data['client_image_position_three'] == 'right-top' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-right:' . $client_image_width_size_right . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding_right . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    top: 30px;
			    right: -' . $client_image_width_size . 'px;
			}';
	} // Right-Bottom site image
	elseif ( $shortcode_data['client_image_position_three'] == 'right-bottom' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-right:' . $client_image_width_size_right . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding_right . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    bottom: 30px;
			    right: -' . $client_image_width_size . 'px;
			}';
	} // Top-Left site image
	elseif ( $shortcode_data['client_image_position_three'] == 'top-left' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-top:' . $client_image_width_size . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding_top . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    left: 30px;
			    top: -' . $client_image_height_size . 'px;
			}';
	} // Top-Left site image
	elseif ( $shortcode_data['client_image_position_three'] == 'top-right' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-top:' . $client_image_width_size . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding_top . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    right: 30px;
			    top: -' . $client_image_height_size . 'px;
			}';
	} // Bottom-Left site image
	elseif ( $shortcode_data['client_image_position_three'] == 'bottom-left' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-bottom:' . $client_image_width_size . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding_bottom . 'px ' . $testimonial_inner_padding['left'] . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    left: 30px;
			    bottom: -' . $client_image_height_size . 'px;
			}';
	} // Bottom-Right site image
	elseif ( $shortcode_data['client_image_position_three'] == 'bottom-right' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro{
				margin-bottom:' . $client_image_width_size . 'px;
				position: relative;
				padding: ' . $testimonial_inner_padding['top'] . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding_bottom . 'px ' . $testimonial_inner_padding['left'] . 'px;
			}';
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
				position: absolute;
			    right: 30px;
			    bottom: -' . $client_image_height_size . 'px;
			}';
	}
}

if ( $client_image == 'true' && $theme_style == 'theme-seven' ) {

	if ( $shortcode_data['client_image_border_shadow'] == 'border' ) {
		$client_image_total_height_size = $client_image_height + $shortcode_data['client_image_border_size'] + $shortcode_data['client_image_border_size'] + $shortcode_data['client_image_padding'] + $shortcode_data['client_image_padding'];
	} elseif ( $shortcode_data['client_image_border_shadow'] == 'box_shadow' ) {
		$client_image_total_height_size = $client_image_height + 14 + $shortcode_data['client_image_padding'] + $shortcode_data['client_image_padding'];
	}

	$client_image_height_size        = $client_image_total_height_size / 100;
	$client_image_height_size_top    = $client_image_height_size * 75;
	$client_image_height_size_bottom = $client_image_height_size * 25;

	$testimonial_inner_padding_top = $testimonial_inner_padding['top'] + $client_image_height_size_bottom;

	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-testimonial-content-area{
		position: relative;
		padding: ' . $testimonial_inner_padding_top . 'px ' . $testimonial_inner_padding['right'] . 'px ' . $testimonial_inner_padding['bottom'] . 'px ' . $testimonial_inner_padding['left'] . 'px;
	}';
	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .sp-testimonial-pro .tpro-client-image{
		position: absolute;
	    right: 30px;
	    top: -' . $client_image_height_size_top . 'px;
	}';
}

// $pagination
if ( $pagination == 'true' && $layout == 'slider' ) {
	$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section .slick-dots{
		margin: ' . $pagination_margin['top'] . 'px ' . $pagination_margin['right'] . 'px ' . $pagination_margin['bottom'] . 'px ' . $pagination_margin['left'] . 'px;
	}';
	if ( $pagination_style == 'active_filled_dot' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_filled_dot .slick-dots li button{
				    background: ' . $pagination_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_filled_dot .slick-dots li.slick-active button{
					background: ' . $pagination_active_color . ';
				}';
	}
	if ( $pagination_style == 'active_unfilled_dot' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_unfilled_dot .slick-dots li button{
				    background: ' . $pagination_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_unfilled_dot .slick-dots li.slick-active button{
					background: transparent;
                    border-color: ' . $pagination_active_color . ';
				}';
	}
	if ( $pagination_style == 'radius_square' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-radius_square .slick-dots li button{
				    background: ' . $pagination_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-radius_square .slick-dots li.slick-active button{
					background: ' . $pagination_active_color . ';
				}';
	}
	if ( $pagination_style == 'sharp_square' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-sharp_square .slick-dots li button{
				    background: ' . $pagination_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-sharp_square .slick-dots li.slick-active button{
					background: ' . $pagination_active_color . ';
				}';
	}
	if ( $pagination_style == 'rotate_square' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-rotate_square .slick-dots li button{
				    background: ' . $pagination_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-rotate_square .slick-dots li.slick-active button{
					background: ' . $pagination_active_color . ';
				}';
	}
	if ( $pagination_style == 'rotate_unfilled_square' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-rotate_unfilled_square .slick-dots li button{
					border: 3px solid ' . $pagination_color . ';
                    background: transparent;
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-rotate_unfilled_square .slick-dots li.slick-active button{
					background: transparent;
                    border-color: ' . $pagination_active_color . ';
				}';
	}
	if ( $pagination_style == 'circle' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-circle .slick-dots li button{
					border: 3px solid ' . $pagination_color . ';
                    background: transparent;
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-circle .slick-dots li.slick-active button{
					background: transparent;
                    border-color: ' . $pagination_active_color . ';
				}';
	}
	if ( $pagination_style == 'circle_active_filled' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-circle_active_filled .slick-dots li{
                    border: 1px solid ' . $pagination_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-circle_active_filled .slick-dots li.slick-active button{
					background: ' . $pagination_active_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-circle_active_filled .slick-dots li.slick-active{
					border-color: ' . $pagination_active_color . ';
				}';
	}
	if ( $pagination_style == 'bordered_dot' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-bordered_dot .slick-dots li{
                    border: 1px solid ' . $pagination_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-bordered_dot .slick-dots li button{
                    background: ' . $pagination_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-bordered_dot .slick-dots li.slick-active button{
					background: ' . $pagination_active_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-bordered_dot .slick-dots li.slick-active{
					border-color: ' . $pagination_active_color . ';
				}';
	}
	if ( $pagination_style == 'pill' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-pill .slick-dots li button{
                    background: ' . $pagination_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-pill .slick-dots li.slick-active button{
					background: ' . $pagination_active_color . ';
				}';
	}
	if ( $pagination_style == 'active_rounded_bg_number' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_rounded_bg_number .slick-dots li button{
                    color: ' . $pagination_text_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_rounded_bg_number .slick-dots li button:before{
					background: ' . $pagination_active_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_rounded_bg_number .slick-dots li.slick-active button,
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_rounded_bg_number .slick-dots li button:hover{
					color: ' . $pagination_active_text_color . ';
				}';
	}
	if ( $pagination_style == 'active_rounded_bordered_number' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_rounded_bordered_number .slick-dots li button{
                    color: ' . $pagination_text_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_rounded_bordered_number .slick-dots li button:before{
					border: 2px solid ' . $pagination_active_color . ';
					background: transparent;
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_rounded_bordered_number .slick-dots li.slick-active button,
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_rounded_bordered_number .slick-dots li button:hover{
					color: ' . $pagination_text_color . ';
				}';
	}
	if ( $pagination_style == 'active_square_bordered_number' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_square_bordered_number .slick-dots li button{
                    color: ' . $pagination_text_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_square_bordered_number .slick-dots li button:before{
					border: 2px solid ' . $pagination_active_color . ';
					background: transparent;
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_square_bordered_number .slick-dots li.slick-active button,
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_square_bordered_number .slick-dots li button:hover{
					color: ' . $pagination_text_color . ';
				}';
	}
	if ( $pagination_style == 'active_square_bg_number' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_square_bg_number .slick-dots li button{
                    color: ' . $pagination_text_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_square_bg_number .slick-dots li button:before{
					background: ' . $pagination_active_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_square_bg_number .slick-dots li.slick-active button,
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_square_bg_number .slick-dots li button:hover{
					color: ' . $pagination_active_text_color . ';
				}';
	}
	if ( $pagination_style == 'rounded_bg_number' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-rounded_bg_number .slick-dots li button{
                    color: ' . $pagination_text_color . ';
                    background: ' . $pagination_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-rounded_bg_number .slick-dots li button:before{
					background: ' . $pagination_active_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-rounded_bg_number .slick-dots li.slick-active button,
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-rounded_bg_number .slick-dots li button:hover{
					color: ' . $pagination_active_text_color . ';
                    background: ' . $pagination_active_color . ';
				}';
	}
	if ( $pagination_style == 'active_filled_rounded_bordered' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_filled_rounded_bordered .slick-dots li{
                    border: 2px solid ' . $pagination_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_filled_rounded_bordered .slick-dots li button{
					color: ' . $pagination_text_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_filled_rounded_bordered .slick-dots li.slick-active button,
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_filled_rounded_bordered .slick-dots li:hover button{
					color: ' . $pagination_active_text_color . ';
                    background: ' . $pagination_active_color . ';
				}
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_filled_rounded_bordered .slick-dots li.slick-active,
				#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-pagination-style-active_filled_rounded_bordered .slick-dots li:hover{
                    border-color: ' . $pagination_active_color . ';
				}';
	}
} //$pagination

if ( $navigation == 'true' && $layout == 'slider' ) {
	if ( $navigation_style == 'one' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-one .slick-prev,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-one .slick-next{
	                    background: ' . $navigation_bg_color . ';
                        color: ' . $navigation_arrow_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-one .slick-prev:hover,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-one .slick-next:hover{
	                    background: ' . $navigation_hover_bg_color . ';
                        color: ' . $navigation_hover_arrow_color . ';
					}';
	}
	if ( $navigation_style == 'two' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-two .slick-prev,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-two .slick-next{
	                    background: ' . $navigation_bg_color . ';
                        color: ' . $navigation_arrow_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-two .slick-prev:hover,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-two .slick-next:hover{
	                    background: ' . $navigation_hover_bg_color . ';
                        color: ' . $navigation_hover_arrow_color . ';
					}';
	}
	if ( $navigation_style == 'three' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-three .slick-prev,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-three .slick-next{
	                    background: ' . $navigation_bg_color . ';
                        color: ' . $navigation_arrow_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-three .slick-prev:before,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-three .slick-next:before{
						border: 2px solid ' . $navigation_bg_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-three .slick-prev:hover,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-three .slick-next:hover{
	                    background: ' . $navigation_hover_bg_color . ';
                        color: ' . $navigation_hover_arrow_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-three .slick-prev:hover:before,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-three .slick-next:hover:before{
                        border-color: ' . $navigation_hover_bg_color . ';
					}';
	}
	if ( $navigation_style == 'four' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-four .slick-prev,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-four .slick-next{
	                    background: ' . $navigation_bg_color . ';
                        color: ' . $navigation_arrow_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-four .slick-prev:before,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-four .slick-next:before{
						border: 2px solid ' . $navigation_bg_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-four .slick-prev:hover,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-four .slick-next:hover{
	                    background: ' . $navigation_hover_bg_color . ';
                        color: ' . $navigation_hover_arrow_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-four .slick-prev:hover:before,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-four .slick-next:hover:before{
                        border-color: ' . $navigation_hover_bg_color . ';
					}';
	}
	if ( $navigation_style == 'five' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-five .slick-prev,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-five .slick-next{
	                    background: ' . $navigation_bg_color . ';
                        color: ' . $navigation_arrow_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-five .slick-prev:before,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-five .slick-next:before{
						border: 2px solid ' . $navigation_bg_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-five .slick-prev:hover,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-five .slick-next:hover{
	                    background: ' . $navigation_hover_bg_color . ';
                        color: ' . $navigation_hover_arrow_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-five .slick-prev:hover:before,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-five .slick-next:hover:before{
                        border-color: ' . $navigation_hover_bg_color . ';
					}';
	}
	if ( $navigation_style == 'six' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-six .slick-prev,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-six .slick-next{
	                    background: transparent;
                        color: ' . $navigation_arrow_color_two . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-six .slick-prev:before,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-six .slick-next:before{
						border: 2px solid ' . $navigation_border_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-six .slick-prev:hover,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-six .slick-next:hover{
	                    background: transparent;
                        color: ' . $navigation_hover_arrow_color_two . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-six .slick-prev:hover:before,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-six .slick-next:hover:before{
                        border-color: ' . $navigation_hover_border_color . ';
					}';
	}
	if ( $navigation_style == 'seven' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-seven .slick-prev,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-seven .slick-next{
	                    background: transparent;
                        color: ' . $navigation_arrow_color_two . ';
                        border-color: ' . $navigation_border_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-seven .slick-prev:before,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-seven .slick-next:before,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-seven .slick-prev:after,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-seven .slick-next:after{
						background: ' . $navigation_border_color . ';
						-webkit-transition: all 0.3s ease;
					    -moz-transition: all 0.3s ease;
					    transition: all 0.3s ease;
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-seven .slick-prev:hover,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-seven .slick-next:hover{
	                    background: transparent;
                        color: ' . $navigation_hover_arrow_color_two . ';
                        border-color: ' . $navigation_hover_border_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-seven .slick-prev:hover:before,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-seven .slick-next:hover:before,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-seven .slick-prev:hover:after,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-seven .slick-next:hover:after{
						background: ' . $navigation_hover_border_color . ';
					}';
	}
	if ( $navigation_style == 'eight' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-eight .slick-prev,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-eight .slick-next{
	                    background: transparent;
                        color: ' . $navigation_arrow_color_two . ';
                        border-color: ' . $navigation_border_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-eight .slick-prev:hover,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-eight .slick-next:hover{
	                    background: transparent;
                        color: ' . $navigation_hover_arrow_color_two . ';
                        border-color: ' . $navigation_hover_border_color . ';
					}';
	}
	if ( $navigation_style == 'nine' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-nine .slick-prev,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-nine .slick-next{
	                    background: transparent;
                        color: ' . $navigation_arrow_color_two . ';
                        border: 2px solid ' . $navigation_border_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-nine .slick-prev:before,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-nine .slick-next:before{
						border: 2px solid ' . $navigation_border_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-nine .slick-prev:hover,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-nine .slick-next:hover{
	                    background: transparent;
                        color: ' . $navigation_hover_arrow_color_two . ';
                        border-color: ' . $navigation_hover_border_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-nine .slick-prev:hover:before,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-nine .slick-next:hover:before{
						border-color: ' . $navigation_hover_border_color . ';
					}';
	}
	if ( $navigation_style == 'ten' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-ten .slick-prev,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-ten .slick-next{
	                    background: ' . $navigation_bg_color . ';
                        color: ' . $navigation_arrow_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-ten .slick-prev:hover,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-ten .slick-next:hover{
	                    background: ' . $navigation_hover_bg_color . ';
                        color: ' . $navigation_hover_arrow_color . ';
					}';
	}
	if ( $navigation_style == 'eleven' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-eleven .slick-prev,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-eleven .slick-next{
	                    background: transparent;
                        color: ' . $navigation_arrow_color_two . ';
                        border: 2px solid ' . $navigation_border_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-eleven .slick-prev:hover,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-eleven .slick-next:hover{
                        color: ' . $navigation_hover_arrow_color_two . ';
                        border-color: ' . $navigation_hover_border_color . ';
					}';
	}
	if ( $navigation_style == 'twelve' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-twelve .slick-prev,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-twelve .slick-next{
	                    background: transparent;
                        color: ' . $navigation_arrow_color_two . ';
                        border: 2px solid ' . $navigation_border_color . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-twelve .slick-prev:hover,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-twelve .slick-next:hover{
                        color: ' . $navigation_hover_arrow_color_two . ';
                        border-color: ' . $navigation_hover_border_color . ';
					}';
	}
	if ( $navigation_style == 'thirteen' ) {
		$outline .= '#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-thirteen .slick-prev,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-thirteen .slick-next{
	                    background: transparent;
                        color: ' . $navigation_arrow_color_two . ';
					}
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-thirteen .slick-prev:hover,
					#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section.tpro-navigation-thirteen .slick-next:hover{
                        color: ' . $navigation_hover_arrow_color_two . ';
					}';
	}

	if ( $layout == 'slider' && $navigation == 'true' ) {

		if ( $section_title == 'true' ) {
			if ( $navigation_position == 'top_right' || $navigation_position == 'top_center' || $navigation_position == 'top_left' ) {
				if($navigation_style == 'three' || $navigation_style == 'four' || $navigation_style == 'nine') {
					$outline .= '#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_right,
					#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_center,
					#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_left {
					    padding-top: 4px;
					}';
				}elseif($navigation_style == 'five') {
					$outline .= '#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_right,
					#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_center,
					#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_left {
					    padding-top: 11px;
					}';
				}
			}
		} else {
			if ( $navigation_position == 'top_right' || $navigation_position == 'top_center' || $navigation_position == 'top_left' ) {
				$outline .= '#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_right,
					#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_center,
					#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_left {
					    padding-top: 46px;
					}';
			}
		}
		if ( $navigation_position == 'bottom_right' || $navigation_position == 'bottom_center' || $navigation_position == 'bottom_left'
		) {
			$outline .= '#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_bottom_right,
					#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_bottom_center,
					#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_bottom_left {
					    padding-bottom: 46px;
					}';
		}
		if ( $navigation_position == 'top_right' ) {

			if($navigation_style == 'three' || $navigation_style == 'four' || $navigation_style == 'nine'){
				$nav_margin_right_three = $testimonial_margin+'4';
				$nav_margin_right_three2 = $testimonial_margin+'46';
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_right .slick-next {
				    right: '.$nav_margin_right_three.'px;
				}
				
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_right .slick-prev {
				    right: '.$nav_margin_right_three2.'px;
				}
				';
			}elseif($navigation_style == 'five'){
				$nav_margin_right_five = $testimonial_margin+'11';
				$nav_margin_right_five2 = $testimonial_margin+'63';
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_right {
					padding-top: 11px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_right .slick-next {
				    right: '.$nav_margin_right_five.'px;
				}
				
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_right .slick-prev {
				    right: '.$nav_margin_right_five2.'px;
				}
				';
			}elseif($navigation_style == 'six'){
				$nav_margin_right_six = $testimonial_margin+'9';
				$nav_margin_right_six2 = $testimonial_margin+'60';
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_right {
					padding-top: 9px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_right .slick-next {
				    right: '.$nav_margin_right_six.'px;
				}
				
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_right .slick-prev {
				    right: '.$nav_margin_right_six2.'px;
				}
				';
			} else {
				$nav_margin_right = $testimonial_margin+'38';
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_right .slick-next {
				    right: '.$testimonial_margin.'px;
				}
				
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_right .slick-prev {
				    right: '.$nav_margin_right.'px;
				}
				';
			}
		}
		if ( $navigation_position == 'bottom_right' ) {

			if($navigation_style == 'three' || $navigation_style == 'four' || $navigation_style == 'nine'){
				$nav_margin_right_three = $testimonial_margin+'4';
				$nav_margin_right_three2 = $testimonial_margin+'46';
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-next {
				    right: '.$nav_margin_right_three.'px;
				}
				
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-prev {
				    right: '.$nav_margin_right_three2.'px;
				}
				';
			}elseif($navigation_style == 'five'){
				$nav_margin_right_five = $testimonial_margin+'11';
				$nav_margin_right_five2 = $testimonial_margin+'63';
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_bottom_right {
					padding-bottom: 54px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-next {
				    right: '.$nav_margin_right_five.'px;
				}
				
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-prev {
				    right: '.$nav_margin_right_five2.'px;
				}
				';
			}elseif($navigation_style == 'six'){
				$nav_margin_right_six = $testimonial_margin+'9';
				$nav_margin_right_six2 = $testimonial_margin+'60';
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_bottom_right {
					padding-bottom: 51px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-next {
				    right: '.$nav_margin_right_six.'px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-prev {
				    right: '.$nav_margin_right_six2.'px;
				}
				';
			} else {
				$nav_margin_right = $testimonial_margin+'38';
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-next {
				    right: '.$testimonial_margin.'px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-prev {
				    right: '.$nav_margin_right.'px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-prev {
				    right: '.$nav_margin_right.'px;
				}
				';
			}
		}
		if ( $navigation_position == 'top_center' ) {
			if($navigation_style == 'six' || $navigation_style == 'five'){
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_center {
					padding-top: 54px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-next {			
                    margin-left: 9px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-prev {
				    margin-left: -41px;
				}
				';
			}
		}
		if ( $navigation_position == 'bottom_center' ) {
			if($navigation_style == 'six' || $navigation_style == 'five'){
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_bottom_center {
					padding-bottom: 54px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_bottom_center .slick-next {			
                    margin-left: 9px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_bottom_center .slick-prev {
				    margin-left: -41px;
				}
				';
			}
		}
		if ( $navigation_position == 'bottom_left' ) {
			if($navigation_style == 'three' || $navigation_style == 'four' || $navigation_style == 'nine'){
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-next {			
                    left: 45px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-prev {
				    left: 4px;
				}
				';
			}elseif($navigation_style == 'five'){
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_bottom_left {
					padding-bottom: 54px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-next {			
                    left: 66px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-prev {
				    left: 12px;
				}
				';
			}elseif($navigation_style == 'six'){
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_bottom_left {
					padding-bottom: 51px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-next {			
                    left: 59px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-prev {
				    left: 9px;
				}
				';
			}
		}
		if ( $navigation_position == 'top_left' ) {
			if($navigation_style == 'three' || $navigation_style == 'four' || $navigation_style == 'nine'){
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-next {			
                    left: 45px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-prev {
				    left: 4px;
				}
				';
			}elseif($navigation_style == 'five'){
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_left {
					padding-top: 54px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-next {			
                    left: 66px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-prev {
				    left: 12px;
				}
				';
			}elseif($navigation_style == 'six'){
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . '.sp_tpro_nav_position_top_left {
					padding-top: 51px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-next {			
                    left: 59px;
				}
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-prev {
				    left: 9px;
				}
				';
			}
		}
		if ( $navigation_position == 'vertical_center' ) {
			$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . ' .sp-testimonial-pro-section{
				    padding: 0 60px;
				}
				';
		}
		if ( $navigation_position == 'vertical_center' || $navigation_position == 'vertical_center_inner' ) {

			if($navigation_style == 'three' || $navigation_style == 'four' || $navigation_style == 'nine'){
				$nav_margin_right_vertical_center_three = $testimonial_margin+'4';
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-next {
				    right: '.$nav_margin_right_vertical_center_three.'px;
				}
				
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-prev {
				    left: 4px;
				}
				';
			}elseif($navigation_style == 'five'){
				$nav_margin_right_vertical_center_five = $testimonial_margin+'12';
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-next {
				    right: '.$nav_margin_right_vertical_center_five.'px;
				}
				
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-prev {
				    left: 12px;
				}
				';
			}elseif($navigation_style == 'six'){
				$nav_margin_right_vertical_center_six = $testimonial_margin+'9';
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-next {
				    right: '.$nav_margin_right_vertical_center_six.'px;
				}
				
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-prev {
				    left: 9px;
				}
				';
			} else {
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-next {
				    right: '.$testimonial_margin.'px;
				}
				
				#sp-testimonial-pro-wrapper-' . $post_id . ' .slick-prev {
				    left: 0;
				}
				';
			}
		}
		if ( $navigation_position == 'vertical_center_inner_hover' ) {

			if($navigation_style == 'three' || $navigation_style == 'four' || $navigation_style == 'nine'){
				$nav_margin_right_vertical_center_three = $testimonial_margin+'4';
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . ':hover .slick-next {
				    right: '.$nav_margin_right_vertical_center_three.'px;
				}
				
				#sp-testimonial-pro-wrapper-' . $post_id . ':hover .slick-prev {
				    left: 4px;
				}
				';
			}elseif($navigation_style == 'five'){
				$nav_margin_right_vertical_center_five = $testimonial_margin+'12';
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . ':hover .slick-next {
				    right: '.$nav_margin_right_vertical_center_five.'px;
				}
				
				#sp-testimonial-pro-wrapper-' . $post_id . ':hover .slick-prev {
				    left: 12px;
				}
				';
			}elseif($navigation_style == 'six'){
				$nav_margin_right_vertical_center_six = $testimonial_margin+'9';
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . ':hover .slick-next {
				    right: '.$nav_margin_right_vertical_center_six.'px;
				}
				
				#sp-testimonial-pro-wrapper-' . $post_id . ':hover .slick-prev {
				    left: 9px;
				}
				';
			} else {
				$outline .= '
				#sp-testimonial-pro-wrapper-' . $post_id . ':hover .slick-next {
				    right: '.$testimonial_margin.'px;
				}
				
				#sp-testimonial-pro-wrapper-' . $post_id . ':hover .slick-prev {
				    left: 0;
				}
				';
			}
		}

	}
}//$navigation

if($layout == 'grid' || $layout == 'masonry' || $layout == 'list'){
	if($shortcode_data['grid_pagination'] == 'true'){
		$outline .= '
		#sp-testimonial-pro-wrapper-' . $post_id . ' .sp-testimonial-pro-section .sp-tpro-pagination-area {
		     text-align: '.$shortcode_data['grid_pagination_alignment'].';
		}
		#sp-testimonial-pro-wrapper-' . $post_id . ' .sp-testimonial-pro-section ul.sp-tpro-pagination {
		     margin: '.$grid_pagination_margin['top'].'px '.$grid_pagination_margin['right'].'px '
		            .$grid_pagination_margin['bottom'].'px '.$grid_pagination_margin['left'].'px;
		}
		#sp-testimonial-pro-wrapper-' . $post_id . ' .sp-testimonial-pro-section ul.sp-tpro-pagination li a,
		#sp-testimonial-pro-wrapper-' . $post_id . ' .sp-testimonial-pro-section ul.sp-tpro-pagination li span {
		     color: '.$shortcode_data['grid_pagination_color'].';
		     background: '.$shortcode_data['grid_pagination_bg'].';
             border: 1px solid '.$shortcode_data['grid_pagination_border_color'].';
		}
		#sp-testimonial-pro-wrapper-' . $post_id . ' .sp-testimonial-pro-section ul.sp-tpro-pagination li span.current,
		#sp-testimonial-pro-wrapper-' . $post_id . ' .sp-testimonial-pro-section ul.sp-tpro-pagination li a:hover{
		     background: '.$shortcode_data['grid_pagination_hover_bg'].';
            color: '.$shortcode_data['grid_pagination_hover_color'].';
		}
		';
		if($shortcode_data['grid_pagination_alignment'] == 'right'){
			$outline .= '#sp-testimonial-pro-wrapper-' . $post_id . ' .sp-testimonial-pro-section ul.sp-tpro-pagination{
				padding-right:' . $testimonial_margin . 'px;
			}';
		}
	}
}
if($shortcode_data['social_profile'] == 'true') {
	if($theme_style == 'theme-three' || $theme_style == 'theme-five' || $theme_style == 'theme-six' || $theme_style == 'theme-seven' || $theme_style == 'theme-nine'){
		$outline .= '#sp-testimonial-pro-wrapper-' . $post_id . ' .sp-testimonial-pro-section .tpro-social-profile{
			text-align: '.$shortcode_data['social_profile_position_two'].';
		}';
	} else{
		$outline .= '#sp-testimonial-pro-wrapper-' . $post_id . ' .sp-testimonial-pro-section .tpro-social-profile{
			text-align: '.$shortcode_data['social_profile_position'].';
		}';
	}
	$outline .= '#sp-testimonial-pro-wrapper-' . $post_id . ' .sp-testimonial-pro-section .tpro-social-profile,
	.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-social-profile{
		margin: '.$social_profile_margin['top'].'px '.$social_profile_margin['right'].'px ' .$social_profile_margin['bottom'].'px '.$social_profile_margin['left'].'px;
	}
	#sp-testimonial-pro-wrapper-' . $post_id . ' .sp-testimonial-pro-section .tpro-social-profile a,
	.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-social-profile a{
		color: '.$shortcode_data['social_profile_icon_color'].';
		background: '.$shortcode_data['social_profile_icon_bg'].';
		border: 1px solid '.$shortcode_data['social_profile_icon_border_color'].';
	}
	#sp-testimonial-pro-wrapper-' . $post_id . ' .sp-testimonial-pro-section .tpro-social-profile a:hover,
	.sp-tpro-modal-testimonial-' . $post_id . '.sp-tpro-modal-testimonial .tpro-social-profile a:hover{
		color: '.$shortcode_data['social_profile_icon_hover_color'].';
		background: '.$shortcode_data['social_profile_icon_hover_bg'].';
		border: 1px solid '.$shortcode_data['social_profile_icon_hover_border_color'].';
	}';
}

$outline .= '</style>';