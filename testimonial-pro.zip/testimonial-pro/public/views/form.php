<?php
/**
 * This file render the shortcode to the frontend form
 * @package testimonial-pro
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Testimonial Pro - FrontEnd form Shortcode Render class
 * @since 2.0
 */
if ( ! class_exists( 'TPRO_Form_Render' ) ) {
	class TPRO_Form_Render {

		/**
		 * @var TPRO_Form_Render single instance of the class
		 *
		 * @since 2.0
		 */
		protected static $_instance = null;


		/**
		 * TPRO_Form_Render Instance
		 *
		 * @since 2.0
		 * @static
		 * @return self Main instance
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

		/**
		 * TPRO_Form_Render constructor.
		 */
		public function __construct() {
			add_shortcode( 'testimonial_pro_form', array( $this, 'form_shortcode_render' ) );
		}

		/**
		 * @param $attributes
		 *
		 * @return string
		 * @since 2.0
		 */
		public function form_shortcode_render( $attributes ) {
			extract( shortcode_atts( array(), $attributes, 'testimonial_pro_form' ) );

			// Form Scripts and Styles.
			wp_enqueue_script( 'tpro-chosen-jquery' );
			wp_enqueue_script( 'tpro-chosen-config' );
			wp_enqueue_style( 'tpro-chosen' );

			$outline = '';


			// Testimonial submit form.
			if ( 'POST' == $_SERVER['REQUEST_METHOD'] && ! empty( $_POST['action'] ) && $_POST['action'] == "testimonial_form" ) {

				// Do some minor form validation to make sure there is content.
				if ( isset ( $_POST['tpro_client_name'] ) ) {
					$tpro_client_name = wp_strip_all_tags( $_POST['tpro_client_name'] );
				} else {
					$tpro_client_name = '';
				}

				if ( isset ( $_POST['tpro_client_designation'] ) ) {
					$tpro_client_designation = $_POST['tpro_client_designation'];
				} else {
					$tpro_client_designation = '';
				}

				if ( isset ( $_POST['tpro_client_company_name'] ) ) {
					$tpro_client_company_name = $_POST['tpro_client_company_name'];
				} else {
					$tpro_client_company_name = '';
				}

				if ( isset ( $_POST['tpro_client_location'] ) ) {
					$tpro_client_location = $_POST['tpro_client_location'];
				} else {
					$tpro_client_location = '';
				}

				if ( isset ( $_POST['tpro_client_phone'] ) ) {
					$tpro_client_phone = $_POST['tpro_client_phone'];
				} else {
					$tpro_client_phone = '';
				}

				if ( isset ( $_POST['tpro_client_website'] ) ) {
					$tpro_client_website = $_POST['tpro_client_website'];
				} else {
					$tpro_client_website = '';
				}

				if ( isset ( $_POST['tpro_client_video_url'] ) ) {
					$tpro_client_video_url = $_POST['tpro_client_video_url'];
				} else {
					$tpro_client_video_url = '';
				}

				if ( isset ( $_POST['tpro_client_testimonial_cat'] ) ) {
					$tpro_client_testimonial_cat = implode( ", ", $_POST['tpro_client_testimonial_cat'] );
				} else {
					$tpro_client_testimonial_cat = '';
				}

				if ( isset ( $_POST['tpro_testimonial_title'] ) ) {
					$tpro_testimonial_title = $_POST['tpro_testimonial_title'];
				} else {
					$tpro_testimonial_title = '';
				}

				if ( isset ( $_POST['tpro_client_testimonial'] ) ) {
					$tpro_client_testimonial = $_POST['tpro_client_testimonial'];
				} else {
					$tpro_client_testimonial = '';
				}

				if ( isset ( $_POST['tpro_client_rating'] ) ) {
					$tpro_client_rating = $_POST['tpro_client_rating'];
				} else {
					$tpro_client_rating = '';
				}

				if ( isset ( $_POST['tpro_social_profile_facebook'] ) ) {
					$tpro_social_profile_facebook = $_POST['tpro_social_profile_facebook'];
				} else {
					$tpro_social_profile_facebook = '';
				}

				if ( isset ( $_POST['tpro_social_profile_twitter'] ) ) {
					$tpro_social_profile_twitter = $_POST['tpro_social_profile_twitter'];
				} else {
					$tpro_social_profile_twitter = '';
				}

				if ( isset ( $_POST['tpro_social_profile_google_plus'] ) ) {
					$tpro_social_profile_google_plus = $_POST['tpro_social_profile_google_plus'];
				} else {
					$tpro_social_profile_google_plus = '';
				}
				if ( isset ( $_POST['tpro_social_profile_linkedin'] ) ) {
					$tpro_social_profile_linkedin = $_POST['tpro_social_profile_linkedin'];
				} else {
					$tpro_social_profile_linkedin = '';
				}
				if ( isset ( $_POST['tpro_social_profile_instagram'] ) ) {
					$tpro_social_profile_instagram = $_POST['tpro_social_profile_instagram'];
				} else {
					$tpro_social_profile_instagram = '';
				}
				if ( isset ( $_POST['tpro_social_profile_youtube'] ) ) {
					$tpro_social_profile_youtube = $_POST['tpro_social_profile_youtube'];
				} else {
					$tpro_social_profile_youtube = '';
				}
				if ( isset ( $_POST['tpro_social_profile_pinterest'] ) ) {
					$tpro_social_profile_pinterest = $_POST['tpro_social_profile_pinterest'];
				} else {
					$tpro_social_profile_pinterest = '';
				}
				if ( isset ( $_POST['tpro_social_profile_skype'] ) ) {
					$tpro_social_profile_skype = $_POST['tpro_social_profile_skype'];
				} else {
					$tpro_social_profile_skype = '';
				}
				if ( isset ( $_POST['tpro_social_profile_stumbleupon'] ) ) {
					$tpro_social_profile_stumbleupon = $_POST['tpro_social_profile_stumbleupon'];
				} else {
					$tpro_social_profile_stumbleupon = '';
				}
				if ( isset ( $_POST['tpro_social_profile_reddit'] ) ) {
					$tpro_social_profile_reddit = $_POST['tpro_social_profile_reddit'];
				} else {
					$tpro_social_profile_reddit = '';
				}
				if ( isset ( $_POST['tpro_social_profile_dribbble'] ) ) {
					$tpro_social_profile_dribbble = $_POST['tpro_social_profile_dribbble'];
				} else {
					$tpro_social_profile_dribbble = '';
				}
				if ( isset ( $_POST['tpro_social_profile_snapchat'] ) ) {
					$tpro_social_profile_snapchat = $_POST['tpro_social_profile_snapchat'];
				} else {
					$tpro_social_profile_snapchat = '';
				}


				// ADD THE FORM INPUT TO $testimonial_form ARRAY
				$testimonial_form = array(
					'post_title'   => $tpro_testimonial_title,
					'post_content' => $tpro_client_testimonial,
					'post_status'  => sp_get_option( 'testimonial_approval_status' ),
					'post_type'    => 'spt_testimonial',
					'tax_input'    => array(
						'testimonial_cat' => $tpro_client_testimonial_cat
					),
					'meta_input'   => array(
						'sp_tpro_meta_options' => array(
							'tpro_name'                    => $tpro_client_name,
							'tpro_email'                   => ( $_POST['tpro_client_email'] ),
							'tpro_designation'             => $tpro_client_designation,
							'tpro_company_name'            => $tpro_client_company_name,
							'tpro_location'                => $tpro_client_location,
							'tpro_phone'                   => $tpro_client_phone,
							'tpro_website'                 => $tpro_client_website,
							'tpro_video_url'               => $tpro_client_video_url,
							'tpro_rating'                  => $tpro_client_rating,
							'tpro_social_facebook_url'     => $tpro_social_profile_facebook,
							'tpro_social_twitter_url'      => $tpro_social_profile_twitter,
							'tpro_social_google_plus_url'  => $tpro_social_profile_google_plus,
							'tpro_social_linked_in_url'    => $tpro_social_profile_linkedin,
							'tpro_social_instagram_url'    => $tpro_social_profile_instagram,
							'tpro_social_youtube_url'      => $tpro_social_profile_youtube,
							'tpro_social_pinterest_url'    => $tpro_social_profile_pinterest,
							'tpro_social_skype_url'        => $tpro_social_profile_skype,
							'tpro_social_stumble_upon_url' => $tpro_social_profile_stumbleupon,
							'tpro_social_reddit_url'       => $tpro_social_profile_reddit,
							'tpro_social_dribbble_url'     => $tpro_social_profile_dribbble,
							'tpro_social_snapchat_url'     => $tpro_social_profile_snapchat,

						),
					)
				);


				if ( sp_get_option( 'google_recaptcha' ) == true && sp_get_option( 'captcha_site_key' ) !== '' && sp_get_option( 'captcha_secret_key' ) !== '' ) {
					// Empty MSG
					$captcha_error_msg = '';
					$validation_msg    = '';

					if ( isset( $_POST['submit'] ) && ! empty( $_POST['submit'] ) ) {
						if ( isset( $_POST['g-recaptcha-response'] ) && ! empty( $_POST['g-recaptcha-response'] ) ) {
							//your site secret key
							$secret = sp_get_option( 'captcha_secret_key' );
							//get verify response data
							$verifyResponse = wp_remote_get( 'https://www.google.com/recaptcha/api/siteverify?secret=' . $secret . '&response=' . $_POST['g-recaptcha-response'] );
							$responseData   = json_decode( $verifyResponse['body'], true );
							$responseData2  = json_decode( $responseData['success'], true );

							if ( $responseData2 == true ) {

								//Save The Testimonial
								$pid = wp_insert_post( $testimonial_form );

								//Thanks
								if ( $pid ) {
									$validation_msg .= sp_get_option( 'successful_message' );
								}

							} else {
								$captcha_error_msg .= sp_get_option( 'verification_fail_message' );
							}

						} else {
							$captcha_error_msg .= sp_get_option( 'captcha_missing_message' );
						}
					}
				} else {
					//Empty MSG
					$validation_msg = '';

					//Save The Testimonial
					$pid = wp_insert_post( $testimonial_form );

					//Thanks
					if ( $pid ) {
						$validation_msg .= sp_get_option( 'successful_message' );
					}
				}


				// Client Image
				if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
					require_once( ABSPATH . "wp-admin" . '/includes/image.php' );
					require_once( ABSPATH . "wp-admin" . '/includes/file.php' );
					require_once( ABSPATH . "wp-admin" . '/includes/media.php' );
				}
				if ( $_FILES ) {
					foreach ( $_FILES as $file => $array ) {
						if ( $_FILES[ $file ]['error'] !== UPLOAD_ERR_OK ) {

						} else {
							$attach_id = media_handle_upload( $file, $pid );

							if ( $attach_id > 0 ) {
								//set post image
								update_post_meta( $pid, '_thumbnail_id', $attach_id );
							}
						}
					}
				}


			} // END THE IF STATEMENT THAT STARTED THE WHOLE FORM

			// POST THE POST.
			do_action( 'wp_insert_post', 'wp_insert_post', true );

			$outline .= '<style>';
			// Form Style.
			$outline .= '.sp-tpro-fronted-form .sp-tpro-form-field label{
				color: ' . sp_get_option( 'label_text_color' ) . ' ;
				display: inline-block;
				max-width: 100%;
				margin-bottom: 5px;
				font-weight: 700;
			}
			.sp-tpro-fronted-form .sp-tpro-form-submit-button input[type="submit"]{
				background: ' . sp_get_option( 'submit_button_bg' ) . ';
				color: ' . sp_get_option( 'submit_button_color' ) . ';
				border: 0;
				padding: 8px 16px;
			}';
			$outline .= '</style>';

			$outline .= '
	<!-- Frontend Submission Form -->
	<div class="sp-tpro-fronted-form">
		<form id="testimonial_form" name="testimonial_form" method="post" action="" enctype="multipart/form-data">';

			if ( sp_get_option( 'client_name_field' ) == 'true' ) {
				$client_name = '
				<!-- Name -->
				<div class="sp-tpro-form-field">';
				if ( sp_get_option( 'client_name_label' ) !== '' ) {
					$client_name .= '<label for="tpro_client_name">' . sp_get_option( 'client_name_label' ) . '</label><br>';
				}
				$client_name .= '<input type="text" id="tpro_client_name" name="tpro_client_name"';
				if ( sp_get_option( 'client_name_required' ) == 'true' ) {
					$client_name .= 'required ';
				}
				if ( sp_get_option( 'client_name_placeholder' ) !== '' ) {
					$client_name .= 'placeholder="' . sp_get_option( 'client_name_placeholder' ) . '"';
				}
				$client_name .= '/>
				</div>';
			} else {
				$client_name = '';
			}

			$client_email = '
			<!-- Email -->
			<div class="sp-tpro-form-field">';
			if ( sp_get_option( 'client_email_label' ) !== '' ) {
				$client_email .= '<label for="tpro_client_email">' . sp_get_option( 'client_email_label' ) . '</label><br>';
			}
			$client_email .= '<input type="email" name="tpro_client_email" id="tpro_client_email" required ';
			if ( sp_get_option( 'client_email_placeholder' ) !== '' ) {
				$client_email .= 'placeholder="' . sp_get_option( 'client_email_placeholder' ) . '"';
			}
			$client_email .= '/>
			</div>';

			if ( sp_get_option( 'client_designation_field' ) == 'true' ) {
				$client_designation = '
				<!-- Designation -->
				<div class="sp-tpro-form-field">';
				if ( sp_get_option( 'client_designation_label' ) !== '' ) {
					$client_designation .= '<label for="tpro_client_designation">' . sp_get_option( 'client_designation_label' ) . '</label><br>';
				}
				$client_designation .= '<input type="text" name="tpro_client_designation" id="tpro_client_designation" ';
				if ( sp_get_option( 'client_designation_required' ) == 'true' ) {
					$client_designation .= 'required ';
				}
				if ( sp_get_option( 'client_designation_placeholder' ) !== '' ) {
					$client_designation .= 'placeholder="' . sp_get_option( 'client_designation_placeholder' ) . '"';
				}
				$client_designation .= '/>
				</div>';
			} else {
				$client_designation = '';
			}

			if ( sp_get_option( 'client_company_name_field' ) == 'true' ) {
				$client_company_name = '
				<!-- Company Name -->
				<div class="sp-tpro-form-field">';
				if ( sp_get_option( 'client_company_name_label' ) !== '' ) {
					$client_company_name .= '<label for="tpro_client_company_name">' . sp_get_option( 'client_company_name_label' ) . '</label><br>';
				}
				$client_company_name .= '<input type="text" name="tpro_client_company_name" id="tpro_client_company_name" ';
				if ( sp_get_option( 'client_company_name_required' ) == 'true' ) {
					$client_company_name .= 'required ';
				}
				if ( sp_get_option( 'client_company_name_placeholder' ) !== '' ) {
					$client_company_name .= 'placeholder="' . sp_get_option( 'client_company_name_placeholder' ) . '"';
				}
				$client_company_name .= '/>
				</div>';
			} else {
				$client_company_name = '';
			}

			if ( sp_get_option( 'client_location_field' ) == 'true' ) {
				$client_location = '
				<!-- Location -->
				<div class="sp-tpro-form-field">';
				if ( sp_get_option( 'client_location_label' ) !== '' ) {
					$client_location .= '<label for="tpro_client_location">' . sp_get_option( 'client_location_label' ) . '</label><br>';
				}
				$client_location .= '<input type="text" name="tpro_client_location" id="tpro_client_location" ';
				if ( sp_get_option( 'client_location_required' ) == 'true' ) {
					$client_location .= 'required ';
				}
				if ( sp_get_option( 'client_location_placeholder' ) !== '' ) {
					$client_location .= 'placeholder="' . sp_get_option( 'client_location_placeholder' ) . '"';
				}
				$client_location .= '/>
				</div>';
			} else {
				$client_location = '';
			}

			if ( sp_get_option( 'client_phone_field' ) == 'true' ) {
				$client_phone = '
				<!-- Phone -->
				<div class="sp-tpro-form-field">';
				$client_phone .= '<label for="tpro_client_phone">' . sp_get_option( 'client_phone_label' ) . '</label><br>';
				$client_phone .= '<input type="text" name="tpro_client_phone" id="tpro_client_phone" ';
				if ( sp_get_option( 'client_phone_required' ) == 'true' ) {
					$client_phone .= 'required ';
				}
				if ( sp_get_option( 'client_phone_placeholder' ) !== '' ) {
					$client_phone .= 'placeholder="' . sp_get_option( 'client_phone_placeholder' ) . '"';
				}
				$client_phone .= '/>
				</div>';
			} else {
				$client_phone = '';
			}

			if ( sp_get_option( 'client_website_field' ) == 'true' ) {
				$client_website = '
				<!-- Website -->
				<div class="sp-tpro-form-field">';
				if ( sp_get_option( 'client_website_label' ) !== '' ) {
					$client_website .= '<label for="tpro_client_website">' . sp_get_option( 'client_website_label' ) . '</label><br>';
				}
				$client_website .= '<input type="text" name="tpro_client_website" id="tpro_client_website" ';
				if ( sp_get_option( 'client_website_required' ) == 'true' ) {
					$client_website .= 'required ';
				}
				if ( sp_get_option( 'client_website_placeholder' ) !== '' ) {
					$client_website .= 'placeholder="' . sp_get_option( 'client_website_placeholder' ) . '"';
				}
				$client_website .= '/>
				</div>';
			} else {
				$client_website = '';
			}

			if ( sp_get_option( 'client_video_url_field' ) == 'true' ) {
				$client_video_url = '
				<!-- Video URL -->
				<div class="sp-tpro-form-field">';
				if ( sp_get_option( 'client_video_url_label' ) !== '' ) {
					$client_video_url .= '<label for="tpro_client_video_url">' . sp_get_option( 'client_video_url_label' ) . '</label><br>';
				}
				$client_video_url .= '<input type="text" name="tpro_client_video_url" id="tpro_client_video_url" ';
				if ( sp_get_option( 'client_video_url_required' ) == 'true' ) {
					$client_video_url .= 'required ';
				}
				if ( sp_get_option( 'client_video_url_placeholder' ) !== '' ) {
					$client_video_url .= 'placeholder="' . sp_get_option( 'client_video_url_placeholder' ) . '"';
				}
				$client_video_url .= '/>
				</div>';
			} else {
				$client_video_url = '';
			}

			if ( sp_get_option( 'client_image_field' ) == 'true' ) {
				$client_image = '
				<!-- Image -->
				<div class="sp-tpro-form-field">';
				if ( sp_get_option( 'client_image_label' ) !== '' ) {
					$client_image .= '<label for="tpro_client_image">' . sp_get_option( 'client_image_label' ) . '</label><br>';
				}
				$client_image .= '<input type="file" name="tpro_client_image" id="tpro_client_image" ';
				if ( sp_get_option( 'client_image_required' ) == 'true' ) {
					$client_image .= 'required ';
				}
				$client_image .= 'accept="image/jpeg,image/jpg,image/png,">
				</div>';
			} else {
				$client_image = '';
			}

			if ( sp_get_option( 'client_category_field' ) == 'true' ) {
				$client_testimonial_cat = '
				<!-- Category -->
				<div class="sp-tpro-form-field">';
				if ( sp_get_option( 'client_category_label' ) !== '' ) {
					$client_testimonial_cat .= '<label for="tpro_client_testimonial_cat">' . sp_get_option( 'client_category_label' ) . '</label><br>';
				}

				$client_selected_categorise = sp_get_option( 'client_selected_category' );
				if ( isset( $client_selected_categorise ) ) {
					$client_testimonial_cat .= '<select name="tpro_client_testimonial_cat[]" id="tpro_client_testimonial_cat" class="chosen-select" data-placeholder="' . sp_get_option( 'client_category_placeholder' ) . '" ';
					if ( sp_get_option( 'client_category_multiple' ) == 'true' ) {
						$client_testimonial_cat .= 'multiple="multiple" ';
					}
					$client_testimonial_cat .= 'data-depend-id="tpro_client_testimonial_cat">';
					foreach ( $client_selected_categorise as $cat_id ) {
						$term                   = get_term( $cat_id );
						$client_testimonial_cat .= '<option value="' . $term->term_id . '">' . $term->name . '</option>';
					}
					$client_testimonial_cat .= '</select>';

				} else {
					$terms = get_terms( 'testimonial_cat', array(
						'hide_empty' => 0,
					) );
					if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
						$client_testimonial_cat .= '<select name="tpro_client_testimonial_cat[]" id="tpro_client_testimonial_cat" class="chosen-select" data-placeholder="' . sp_get_option( 'client_category_placeholder' ) . '" ';
						if ( sp_get_option( 'client_category_multiple' ) == 'true' ) {
							$client_testimonial_cat .= 'multiple="multiple" ';
						}
						$client_testimonial_cat .= 'data-depend-id="tpro_client_testimonial_cat">';
						foreach ( $terms as $term ) {
							$client_testimonial_cat .= '<option value="' . $term->term_id . '">' . $term->name . '</option>';
						}
						$client_testimonial_cat .= '</select>';
					};
				}

				$client_testimonial_cat .= '</div>';
			} else {
				$client_testimonial_cat = '';
			}

			if ( sp_get_option( 'client_title_field' ) == 'true' ) {
				$client_testimonial_title = '
				<!-- Title -->
				<div class="sp-tpro-form-field">';
				if ( sp_get_option( 'client_title_label' ) !== '' ) {
					$client_testimonial_title .= '<label for="tpro_testimonial_title">' . sp_get_option( 'client_title_label' ) . '</label><br>';
				}
				$client_testimonial_title .= '<input type="text" name="tpro_testimonial_title" id="tpro_testimonial_title" ';
				if ( sp_get_option( 'client_title_required' ) == 'true' ) {
					$client_testimonial_title .= 'required ';
				}
				if ( sp_get_option( 'client_title_placeholder' ) !== '' ) {
					$client_testimonial_title .= 'placeholder="' . sp_get_option( 'client_title_placeholder' ) . '"';
				}
				$client_testimonial_title .= '/>
				</div>';
			} else {
				$client_testimonial_title = '';
			}

			if ( sp_get_option( 'client_testimonial_field' ) == 'true' ) {
				$client_testimonial = '
				<!-- Testimonial -->
				<div class="sp-tpro-form-field">';
				if ( sp_get_option( 'client_testimonial_label' ) !== '' ) {
					$client_testimonial .= '<label for="tpro_client_testimonial">' . sp_get_option( 'client_testimonial_label' ) . '</label><br>';
				}
				$client_testimonial .= '<textarea id="tpro_client_testimonial" name="tpro_client_testimonial" ';
				if ( sp_get_option( 'client_testimonial_required' ) == 'true' ) {
					$client_testimonial .= 'required ';
				}
				if ( sp_get_option( 'client_testimonial_placeholder' ) !== '' ) {
					$client_testimonial .= 'placeholder="' . sp_get_option( 'client_testimonial_placeholder' ) . '"';
				}
				$client_testimonial .= '></textarea>
				</div>';
			} else {
				$client_testimonial = '';
			}

			if ( sp_get_option( 'client_rating_field' ) == 'true' ) {
				$client_star_rating = '
				<!-- Rating -->
				<div class="sp-tpro-form-field sp-tpro-rating-field">';
				if ( sp_get_option( 'client_rating_label' ) !== '' ) {
					$client_star_rating .= '<label for="tpro_client_rating">' . sp_get_option( 'client_rating_label' ) . '</label><br>';
				}
				$client_star_rating .= '<div class="sp-tpro-client-rating">
							<input type="radio" name="tpro_client_rating" id="_tpro_rating_5" value="five_star">
							<label for="_tpro_rating_5" title="' . sp_get_option( 'client_rating_five' ) . '"><i class="fa fa-star"></i></label>
	
							<input type="radio" name="tpro_client_rating" id="_tpro_rating_4" value="four_star">
							<label for="_tpro_rating_4" title="' . sp_get_option( 'client_rating_four' ) . '"><i class="fa fa-star"></i></label>
	
							<input type="radio" name="tpro_client_rating" id="_tpro_rating_3" value="three_star">
							<label for="_tpro_rating_3" title="' . sp_get_option( 'client_rating_three' ) . '"><i class="fa fa-star"></i></label>
	
							<input type="radio" name="tpro_client_rating" id="_tpro_rating_2" value="two_star">
							<label for="_tpro_rating_2" title="' . sp_get_option( 'client_rating_two' ) . '"><i class="fa fa-star"></i></label>
	
							<input type="radio" name="tpro_client_rating" id="_tpro_rating_1" value="one_star">
							<label for="_tpro_rating_1" title="' . sp_get_option( 'client_rating_one' ) . '"><i class="fa fa-star"></i></label>
						</div>
				</div>';
			} else {
				$client_star_rating = '';
			}

			if ( sp_get_option( 'client_social_profile_field' ) == 'true' ) {
				$client_social_profile = '
				<!-- Social Profile -->
				<div class="sp-tpro-form-field">';
				if ( sp_get_option( 'client_social_profile_label' ) !== '' ) {
					$client_social_profile .= '<label for="tpro_social_profile">' . sp_get_option( 'client_social_profile_label' ) . '</label>';
				}
				$client_social_profile .= '<input type="checkbox" class="tpro-social-profile-check" name="tpro_social_profile_check" value="1">
				<div class="tpro-social-profile-links" style="display: none;">';
				if ( sp_get_option( 'client_social_profile_facebook' ) == 'true' ) {
					$client_social_profile .= '
					<div class="tpro-social-profile-link">';
					if ( sp_get_option( 'client_social_profile_facebook_label' ) !== '' ) {
						$client_social_profile .= '<label for="tpro_social_profile_facebook">' . sp_get_option( 'client_social_profile_facebook_label' ) . '</label><br>';
					}
					$client_social_profile .= '<input type="text" name="tpro_social_profile_facebook" id="tpro_social_profile_facebook" 
placeholder="' . sp_get_option( 'client_social_profile_facebook_placeholder' ) . '"><span><i class="fa fa-facebook"></i></span>
					</div>';
				}
				if ( sp_get_option( 'client_social_profile_twitter' ) == 'true' ) {
					$client_social_profile .= '
					<div class="tpro-social-profile-link">';
					if ( sp_get_option( 'client_social_profile_twitter_label' ) !== '' ) {
						$client_social_profile .= '<label for="tpro_social_profile_twitter">' . sp_get_option( 'client_social_profile_twitter_label' ) . '</label><br>';
					}
					$client_social_profile .= '<input type="text" name="tpro_social_profile_twitter" id="tpro_social_profile_twitter" 
placeholder="' . sp_get_option( 'client_social_profile_twitter_placeholder' ) . '"><span><i class="fa fa-twitter"></i></span>
					</div>';
				}
				if ( sp_get_option( 'client_social_profile_google_plus' ) == 'true' ) {
					$client_social_profile .= '
					<div class="tpro-social-profile-link">';
					if ( sp_get_option( 'client_social_profile_google_plus_label' ) !== '' ) {
						$client_social_profile .= '<label for="tpro_social_profile_google_plus">' . sp_get_option( 'client_social_profile_google_plus_label' ) . '</label><br>';
					}
					$client_social_profile .= '<input type="text" name="tpro_social_profile_google_plus" id="tpro_social_profile_google_plus" placeholder="' . sp_get_option( 'client_social_profile_google_plus_placeholder' ) . '"><span><i class="fa fa-google-plus"></i></span>
					</div>';
				}
				if ( sp_get_option( 'client_social_profile_linkedin' ) == 'true' ) {
					$client_social_profile .= '
					<div class="tpro-social-profile-link">';
					if ( sp_get_option( 'client_social_profile_linkedin_label' ) !== '' ) {
						$client_social_profile .= '<label for="tpro_social_profile_linkedin">' . sp_get_option( 'client_social_profile_linkedin_label' ) . '</label><br>';
					}
					$client_social_profile .= '<input type="text" name="tpro_social_profile_linkedin" id="tpro_social_profile_linkedin" placeholder="' . sp_get_option( 'client_social_profile_linkedin_placeholder' ) . '"><span><i class="fa fa-linkedin"></i></span>
					</div>';
				}
				if ( sp_get_option( 'client_social_profile_instagram' ) == 'true' ) {
					$client_social_profile .= '
					<div class="tpro-social-profile-link">';
					if ( sp_get_option( 'client_social_profile_instagram_label' ) !== '' ) {
						$client_social_profile .= '<label for="tpro_social_profile_instagram">' . sp_get_option( 'client_social_profile_instagram_label' ) . '</label><br>';
					}
					$client_social_profile .= '<input type="text" name="tpro_social_profile_instagram" id="tpro_social_profile_instagram" placeholder="' . sp_get_option( 'client_social_profile_instagram_placeholder' ) . '"><span><i class="fa fa-instagram"></i></span>
					</div>';
				}
				if ( sp_get_option( 'client_social_profile_youtube' ) == 'true' ) {
					$client_social_profile .= '
					<div class="tpro-social-profile-link">';
					if ( sp_get_option( 'client_social_profile_youtube_label' ) !== '' ) {
						$client_social_profile .= '<label for="tpro_social_profile_youtube">' . sp_get_option( 'client_social_profile_youtube_label' ) . '</label><br>';
					}
					$client_social_profile .= '<input type="text" name="tpro_social_profile_youtube" id="tpro_social_profile_youtube" placeholder="' . sp_get_option( 'client_social_profile_youtube_placeholder' ) . '"><span><i class="fa fa-youtube"></i></span>
					</div>';
				}
				if ( sp_get_option( 'client_social_profile_pinterest' ) == 'true' ) {
					$client_social_profile .= '
					<div class="tpro-social-profile-link">';
					if ( sp_get_option( 'client_social_profile_pinterest_label' ) !== '' ) {
						$client_social_profile .= '<label for="tpro_social_profile_pinterest">' . sp_get_option( 'client_social_profile_pinterest_label' ) . '</label><br>';
					}
					$client_social_profile .= '<input type="text" name="tpro_social_profile_pinterest" id="tpro_social_profile_pinterest" placeholder="' . sp_get_option( 'client_social_profile_pinterest_placeholder' ) . '"><span><i class="fa fa-pinterest-p"></i></span>
					</div>';
				}
				if ( sp_get_option( 'client_social_profile_skype' ) == 'true' ) {
					$client_social_profile .= '
					<div class="tpro-social-profile-link">';
					if ( sp_get_option( 'client_social_profile_skype_label' ) !== '' ) {
						$client_social_profile .= '<label for="tpro_social_profile_skype">' . sp_get_option( 'client_social_profile_skype_label' ) . '</label><br>';
					}
					$client_social_profile .= '<input type="text" name="tpro_social_profile_skype" id="tpro_social_profile_skype" placeholder="' . sp_get_option( 'client_social_profile_skype_placeholder' ) . '"><span><i class="fa fa-skype"></i></span>
					</div>';
				}
				if ( sp_get_option( 'client_social_profile_stumbleupon' ) == 'true' ) {
					$client_social_profile .= '
					<div class="tpro-social-profile-link">';
					if ( sp_get_option( 'client_social_profile_stumbleupon_label' ) !== '' ) {
						$client_social_profile .= '<label for="tpro_social_profile_stumbleupon">' . sp_get_option( 'client_social_profile_stumbleupon_label' ) . '</label><br>';
					}
					$client_social_profile .= '<input type="text" name="tpro_social_profile_stumbleupon" id="tpro_social_profile_stumbleupon" placeholder="' . sp_get_option( 'client_social_profile_stumbleupon_placeholder' ) . '"><span><i class="fa fa-stumbleupon"></i></span>
					</div>';
				}
				if ( sp_get_option( 'client_social_profile_reddit' ) == 'true' ) {
					$client_social_profile .= '
					<div class="tpro-social-profile-link">';
					if ( sp_get_option( 'client_social_profile_reddit_label' ) !== '' ) {
						$client_social_profile .= '<label for="tpro_social_profile_reddit">' . sp_get_option( 'client_social_profile_reddit_label' ) . '</label><br>';
					}
					$client_social_profile .= '<input type="text" name="tpro_social_profile_reddit" id="tpro_social_profile_reddit" placeholder="' . sp_get_option( 'client_social_profile_reddit_placeholder' ) . '"><span><i class="fa fa-reddit"></i></span>
					</div>';
				}
				if ( sp_get_option( 'client_social_profile_dribbble' ) == 'true' ) {
					$client_social_profile .= '
					<div class="tpro-social-profile-link">';
					if ( sp_get_option( 'client_social_profile_dribbble_label' ) !== '' ) {
						$client_social_profile .= '<label for="tpro_social_profile_dribbble">' . sp_get_option( 'client_social_profile_dribbble_label' ) . '</label><br>';
					}
					$client_social_profile .= '<input type="text" name="tpro_social_profile_dribbble" id="tpro_social_profile_dribbble" placeholder="' . sp_get_option( 'client_social_profile_dribbble_placeholder' ) . '"><span><i class="fa fa-dribbble"></i></span>
					</div>';
				}
				if ( sp_get_option( 'client_social_profile_snapchat' ) == 'true' ) {
					$client_social_profile .= '
					<div class="tpro-social-profile-link">';
					if ( sp_get_option( 'client_social_profile_snapchat_label' ) !== '' ) {
						$client_social_profile .= '<label for="tpro_social_profile_snapchat">' . sp_get_option( 'client_social_profile_snapchat_label' ) . '</label><br>';
					}
					$client_social_profile .= '<input type="text" name="tpro_social_profile_snapchat" id="tpro_social_profile_snapchat" placeholder="' . sp_get_option( 'client_social_profile_snapchat_placeholder' ) . '"><span><i class="fa fa-snapchat"></i></span>
					</div>';
				}
				$client_social_profile .= '</div>
				</div>';
			} else {
				$client_social_profile = '';
			}

			$sorter_data = sp_get_option( 'fields_sorter' );
			$enabled     = $sorter_data['enabled'];

			if ( $enabled ) {
				foreach ( $enabled as $key => $value ) {

					switch ( $key ) {

						case 'name':
							$outline .= $client_name;
							break;
						case 'email':
							$outline .= $client_email;
							break;
						case 'designation':
							$outline .= $client_designation;
							break;
						case 'company_name':
							$outline .= $client_company_name;
							break;
						case 'location':
							$outline .= $client_location;
							break;
						case 'phone':
							$outline .= $client_phone;
							break;
						case 'website':
							$outline .= $client_website;
							break;
						case 'video-url':
							$outline .= $client_video_url;
							break;
						case 'image':
							$outline .= $client_image;
							break;
						case 'category':
							$outline .= $client_testimonial_cat;
							break;
						case 'title':
							$outline .= $client_testimonial_title;
							break;
						case 'testimonial':
							$outline .= $client_testimonial;
							break;
						case 'rating':
							$outline .= $client_star_rating;
							break;
						case 'social-profile':
							$outline .= $client_social_profile;
							break;
					}

				}
			}

			if ( sp_get_option( 'google_recaptcha' ) == true && sp_get_option( 'captcha_site_key' ) !== '' && sp_get_option( 'captcha_secret_key' ) !== '' ) {
				$outline .= '<div class="sp-tpro-form-field">
				<div class="g-recaptcha" data-sitekey="' . sp_get_option( 'captcha_site_key' ) . '"></div>';
				if ( ! empty( $captcha_error_msg ) ) {
					$outline .= '<span class="sp-tpro-form-error-msg">' . $captcha_error_msg . '</span>';
				}
				$outline .= '</div>';
			}

			$outline .= '<div class="sp-tpro-form-submit-button">
				<input type="submit" value="' . sp_get_option( 'submit_button_text' ) . '" id="submit" name="submit"/>
			</div>
			<input type="hidden" name="action" value="testimonial_form"/>';

			if ( ! empty( $validation_msg ) ) {
				$outline .= '<div class="sp-tpro-form-validation-msg">' . $validation_msg . '</div>';
			}

			$outline .= '</form>
	</div> <!-- END tp-fronted-form -->';

			return $outline;

		}

	}

	new TPRO_Form_Render();
}
