<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }  // if direct access

/**
 * Scripts and styles
 */
class SP_TPRO_Front_Scripts{

	/**
	 * @var null
	 * @since 1.0
	 */
	protected static $_instance = null;

	/**
	 * @return SP_TPRO_Front_Scripts
	 * @since 1.0
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Initialize the class
	 */
	public function __construct() {

		add_action( 'wp_enqueue_scripts', array( $this, 'front_scripts' ) );
	}

	/**
	 * Plugin Scripts and Styles
	 */
	function front_scripts() {
		// CSS Files
		wp_enqueue_style( 'slick', SP_TPRO_URL . 'public/assets/css/slick.css', array(), SP_TPRO_VERSION );
		wp_enqueue_style( 'font-awesome', SP_TPRO_URL . 'public/assets/css/font-awesome.min.css', array(), SP_TPRO_VERSION );
		wp_enqueue_style( 'magnific-popup', SP_TPRO_URL . 'public/assets/css/magnific-popup.css', array(), SP_TPRO_VERSION );
		wp_register_style( 'tpro-chosen', SP_TPRO_URL . 'public/assets/css/chosen.css', array(), SP_TPRO_VERSION );
		wp_register_style( 'tpro-remodal', SP_TPRO_URL . 'public/assets/css/remodal.css', array(), SP_TPRO_VERSION );
		wp_register_style( 'tpro-remodal-default-theme', SP_TPRO_URL . 'public/assets/css/remodal-default-theme.css', array(), SP_TPRO_VERSION );
		wp_enqueue_style( 'tpro-style', SP_TPRO_URL . 'public/assets/css/style.css', array(), SP_TPRO_VERSION );
		wp_enqueue_style( 'tpro-custom', SP_TPRO_URL . 'public/assets/css/custom.css', array(), SP_TPRO_VERSION );
		wp_enqueue_style( 'tpro-responsive', SP_TPRO_URL . 'public/assets/css/responsive.css', array(), SP_TPRO_VERSION );

		include SP_TPRO_PATH . '/includes/custom-css.php';
		wp_add_inline_style( 'tpro-custom', $custom_css );

		//JS Files
		wp_register_script( 'tpro-slick-min-js', SP_TPRO_URL . 'public/assets/js/slick.min.js', array( 'jquery' ), SP_TPRO_VERSION, true );
		wp_register_script( 'tpro-isotope-js', SP_TPRO_URL . 'public/assets/js/jquery.isotope.min.js', array( 'jquery' ), SP_TPRO_VERSION, true );
		wp_enqueue_script( 'validate-js', SP_TPRO_URL . 'public/assets/js/jquery.validate.min.js', array( 'jquery' ), SP_TPRO_VERSION, true );
		wp_enqueue_script( 'magnific-popup-js', SP_TPRO_URL . 'public/assets/js/jquery.magnific-popup.min.js', array( 'jquery' ), SP_TPRO_VERSION, true );
		wp_register_script( 'tpro-remodal-js', SP_TPRO_URL . 'public/assets/js/remodal.js', array( 'jquery' ),
			SP_TPRO_VERSION, true );
		wp_register_script( 'tpro-curtail-min-js', SP_TPRO_URL . 'public/assets/js/jquery.curtail.min.js', array( 'jquery' ),
			SP_TPRO_VERSION, true );
		wp_register_script( 'tpro-chosen-jquery', SP_TPRO_URL . 'public/assets/js/chosen.jquery.min.js', array( 'jquery' ), SP_TPRO_VERSION, true );
		wp_register_script( 'tpro-chosen-config', SP_TPRO_URL . 'public/assets/js/chosen-config.js', array( 'jquery'
		), SP_TPRO_VERSION, true );
		wp_enqueue_script( 'recaptcha-js', '//www.google.com/recaptcha/api.js', array( 'jquery' ), SP_TPRO_VERSION, true );
		wp_enqueue_script( 'jquery-masonry', array( 'jquery' ), SP_TPRO_VERSION, true );
		wp_enqueue_script( 'tpro-scripts', SP_TPRO_URL . 'public/assets/js/scripts.js', array( 'jquery' ), SP_TPRO_VERSION, true );
		wp_register_script( 'tpro-slick-active', SP_TPRO_URL . 'public/assets/js/sp-slick-active.js', array( 'jquery' ), SP_TPRO_VERSION, true );
		wp_register_script( 'tpro-slick-ticker-active', SP_TPRO_URL . 'public/assets/js/sp-slick-ticker-active.js', array( 'jquery' ), SP_TPRO_VERSION, true );
		wp_register_script( 'tpro-filter-config', SP_TPRO_URL . 'public/assets/js/filter-config.js', array( 'jquery' ), SP_TPRO_VERSION, true );
		wp_register_script( 'tpro-read-more-config', SP_TPRO_URL . 'public/assets/js/read-more-config.js', array( 'jquery' ), SP_TPRO_VERSION, true );

	}

}
new SP_TPRO_Front_Scripts();