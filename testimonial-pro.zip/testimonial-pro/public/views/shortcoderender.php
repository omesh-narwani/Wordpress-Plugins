<?php
/**
 * This file render the shortcode to the frontend
 * @package testimonial-pro
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Testimonial Pro - Shortcode Render class
 * @since 2.0
 */
if (! class_exists('TPRO_Shortcode_Render')) {
    class TPRO_Shortcode_Render {

        public $tpro_five_star = '<i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    ';
        public $tpro_four_star = '
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star-o" aria-hidden="true"></i>
                    ';
        public $tpro_three_star = '
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star-o" aria-hidden="true"></i>
                    <i class="fa fa-star-o" aria-hidden="true"></i>
                    ';
        public $tpro_two_star = '
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star-o" aria-hidden="true"></i>
                    <i class="fa fa-star-o" aria-hidden="true"></i>
                    <i class="fa fa-star-o" aria-hidden="true"></i>
                    ';
        public $tpro_one_star = '
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star-o" aria-hidden="true"></i>
                    <i class="fa fa-star-o" aria-hidden="true"></i>
                    <i class="fa fa-star-o" aria-hidden="true"></i>
                    <i class="fa fa-star-o" aria-hidden="true"></i>
                    ';

        /**
         * @var TPRO_Shortcode_Render single instance of the class
         *
         * @since 2.0
         */
        protected static $_instance = null;


        /**
         * TPRO_Shortcode_Render Instance
         *
         * @since 2.0
         * @static
         * @return self Main instance
         */
        public static function instance() {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

        /**
         * TPRO_Shortcode_Render constructor.
         */
        public function __construct() {
            add_shortcode('testimonial_pro', array( $this, 'shortcode_render'));
        }

        /**
         * @param $attributes
         *
         * @return string
         * @since 2.0
         */
        public function shortcode_render( $attributes ) {
            extract( shortcode_atts( array(
                'id' => '',
            ), $attributes, 'testimonial_pro' ) );

            $post_id = $attributes['id'];


            $shortcode_data               = get_post_meta($post_id, 'sp_tpro_shortcode_options', true);
            $layout                       = $shortcode_data['layout'];
            $testimonial_margin           = $shortcode_data['testimonial_margin'];
            $section_title                = $shortcode_data['section_title'];
            $theme_style                  = $shortcode_data['theme_style'];
            $pagination                   = $shortcode_data['pagination'];
            $pagination_thumb             = $shortcode_data['pagination'] == true ? 'true' : 'false';
            $pagination_style             = $shortcode_data['pagination_style'];
            $pagination_text_color        = $shortcode_data['pagination_text_color'];
            $pagination_active_text_color = $shortcode_data['pagination_active_text_color'];
            $pagination_color             = $shortcode_data['pagination_color'];
            $pagination_active_color      = $shortcode_data['pagination_active_color'];

            $number_of_testimonials                  = $shortcode_data['number_of_testimonials'];
            $number_of_testimonials_desktop          = $shortcode_data['number_of_testimonials_desktop'];
            $number_of_testimonials_small_desktop    = $shortcode_data['number_of_testimonials_small_desktop'];
            $number_of_testimonials_tablet           = $shortcode_data['number_of_testimonials_tablet'];
            $number_of_testimonials_mobile           = $shortcode_data['number_of_testimonials_mobile'];
            $rtl_mode                                = $shortcode_data['rtl_mode'];
            $rtl_mode_thumb                          = $shortcode_data['rtl_mode'] == true ? 'true' : 'false';
            $slider_draggable                        = $shortcode_data['slider_draggable'];
            $slider_draggable_thumb                  = $shortcode_data['slider_draggable'] == true ? 'true' : 'false';
            $slider_swipe                            = $shortcode_data['slider_swipe'];
            $slider_swipe_thumb                      = $shortcode_data['slider_swipe'] == true ? 'true' : 'false';
            $slider_auto_play                        = $shortcode_data['slider_auto_play'];
            $slider_auto_play_thumb                  = $shortcode_data['slider_auto_play'] == true ? 'true' : 'false';
            $slider_auto_play_speed                  = $shortcode_data['slider_auto_play_speed'];
            $slider_scroll_speed                     = $shortcode_data['slider_scroll_speed'];
            $number_of_slides_to_scroll              = $shortcode_data['number_of_slides_to_scroll'];
            $slider_pause_on_hover                   = $shortcode_data['slider_pause_on_hover'];
            $slider_pause_on_hover_thumb             = $shortcode_data['slider_pause_on_hover'] == true ? 'true' : 'false';
            $slider_infinite                         = $shortcode_data['slider_infinite'];
            if($shortcode_data['slider_animation'] == 'slide'){
                $slider_fade_effect = false;
            } elseif($shortcode_data['slider_animation'] == 'fade'){
                $slider_fade_effect = true;
            }
            if($shortcode_data['slider_animation'] == 'slide'){
                $slider_fade_effect_thumb = 'false';
            } elseif($shortcode_data['slider_animation'] == 'fade'){
                $slider_fade_effect_thumb = 'true';
            }
            $navigation                              = $shortcode_data['navigation'];
            $navigation_thumb                        = $shortcode_data['navigation'] == true ? 'true' : 'false';
            $navigation_position                     = $shortcode_data['navigation_position'];
            $navigation_style                        = $shortcode_data['navigation_style'];
            $navigation_bg_color                     = $shortcode_data['navigation_bg_color'];
            $navigation_arrow_color                  = $shortcode_data['navigation_arrow_color'];
            $navigation_arrow_color_two              = $shortcode_data['navigation_arrow_color_two'];
            $navigation_hover_bg_color               = $shortcode_data['navigation_hover_bg_color'];
            $navigation_hover_arrow_color            = $shortcode_data['navigation_hover_arrow_color'];
            $navigation_hover_arrow_color_two        = $shortcode_data['navigation_hover_arrow_color_two'];
            $navigation_border_color                 = $shortcode_data['navigation_border_color'];
            $navigation_hover_border_color           = $shortcode_data['navigation_hover_border_color'];
            $testimonial_title                       = $shortcode_data['testimonial_title'];
            $testimonial_title_margin                = $shortcode_data['testimonial_title_margin'];
            $testimonial_text                        = $shortcode_data['testimonial_text'];
            $testimonial_text_margin                 = $shortcode_data['testimonial_text_margin'];
            $client_image_margin                     = $shortcode_data['client_image_margin'];
            $client_image_margin_tow                 = $shortcode_data['client_image_margin_tow'];
            $testimonial_client_name                 = $shortcode_data['testimonial_client_name'];
            $testimonial_client_name_margin          = $shortcode_data['testimonial_client_name_margin'];
            $testimonial_client_rating               = $shortcode_data['testimonial_client_rating'];
            $testimonial_client_rating_alignment     = $shortcode_data['testimonial_client_rating_alignment'];
            $testimonial_client_rating_alignment_two = $shortcode_data['testimonial_client_rating_alignment_two'];
            $testimonial_client_rating_margin        = $shortcode_data['testimonial_client_rating_margin'];
            $client_designation_company_margin       = $shortcode_data['client_designation_company_margin'];
            $client_designation                      = $shortcode_data['client_designation'];
            $client_company_name                     = $shortcode_data['client_company_name'];
            $testimonial_characters_limit            = $shortcode_data['testimonial_characters_limit'];
            $testimonial_read_more_text              = $shortcode_data['testimonial_read_more_text'];
            $testimonial_read_less_text              = $shortcode_data['testimonial_read_less_text'];
            $testimonial_read_more_ellipsis          = $shortcode_data['testimonial_read_more_ellipsis'];
            $thumbnail_slider                        = $shortcode_data['thumbnail_slider'] == true ? 'true' : 'false';
            $identity_linking_website                = $shortcode_data['identity_linking_website'] == true ? 'true' : 'false';
            $slider_ticker_mode                = $shortcode_data['slider_ticker_mode'] == true ? 'true' : 'false';
            $testimonial_read_more                = $shortcode_data['testimonial_read_more'] == true ? 'true' : 'false';

            $testimonial_client_location_margin = $shortcode_data['testimonial_client_location_margin'];
            $testimonial_client_phone_margin    = $shortcode_data['testimonial_client_phone_margin'];
            $testimonial_client_email_margin    = $shortcode_data['testimonial_client_email_margin'];
            $testimonial_client_date_margin     = $shortcode_data['testimonial_client_date_margin'];
            $testimonial_client_website_margin  = $shortcode_data['testimonial_client_website_margin'];
            $testimonial_inner_padding          = $shortcode_data['testimonial_inner_padding'];
            $testimonial_info_inner_padding     = $shortcode_data['testimonial_info_inner_padding'];
            $pagination_margin                  = $shortcode_data['pagination_margin'];
            $grid_pagination_margin             = $shortcode_data['grid_pagination_margin'];
            $filter_margin                      = $shortcode_data['filter_margin'];
            $social_profile_margin              = $shortcode_data['social_profile_margin'];
            $navigation_icons                   = $shortcode_data['navigation_icons'];
            $website_link_target                   = $shortcode_data['website_link_target'];

            $client_image        = $shortcode_data['client_image'];
            $client_image_width  = $shortcode_data['client_image_width'];
            $client_image_height = $shortcode_data['client_image_height'];
            $client_image_crop   = $shortcode_data['client_image_crop'];

            if ( $layout == 'filter_grid' ) {
                $layout_mode = "fitRows";
            } elseif ( $layout == 'filter_masonry' ) {
                $layout_mode = "masonry";
            }

            /**
             * Typography
             */
            $section_title_typography                  = $shortcode_data['section_title_typography'];
            $testimonial_title_typography              = $shortcode_data['testimonial_title_typography'];
            $testimonial_title_typography_two          = $shortcode_data['testimonial_title_typography_two'];
            $testimonial_title_typography_three        = $shortcode_data['testimonial_title_typography_three'];
            $testimonial_title_typography_four         = $shortcode_data['testimonial_title_typography_four'];
            $testimonial_text_typography               = $shortcode_data['testimonial_text_typography'];
            $testimonial_text_typography_two           = $shortcode_data['testimonial_text_typography_two'];
            $testimonial_text_typography_three         = $shortcode_data['testimonial_text_typography_three'];
            $testimonial_text_typography_four          = $shortcode_data['testimonial_text_typography_four'];
            $client_name_typography                    = $shortcode_data['client_name_typography'];
            $client_name_typography_two                = $shortcode_data['client_name_typography_two'];
            $client_designation_company_typography     = $shortcode_data['client_designation_company_typography'];
            $client_designation_company_typography_two = $shortcode_data['client_designation_company_typography_two'];
            $client_location_typography                = $shortcode_data['client_location_typography'];
            $client_location_typography_two            = $shortcode_data['client_location_typography_two'];
            $client_phone_typography                   = $shortcode_data['client_phone_typography'];
            $client_phone_typography_two               = $shortcode_data['client_phone_typography_two'];
            $client_email_typography                   = $shortcode_data['client_email_typography'];
            $client_email_typography_two               = $shortcode_data['client_email_typography_two'];
            $testimonial_date_typography               = $shortcode_data['testimonial_date_typography'];
            $testimonial_date_typography_two           = $shortcode_data['testimonial_date_typography_two'];
            $client_website_typography                 = $shortcode_data['client_website_typography'];
            $client_website_typography_two             = $shortcode_data['client_website_typography_two'];
            $filter_typography                         = $shortcode_data['filter_typography'];


            include SP_TPRO_PATH . '/admin/views/variant/section_title.php';
            include SP_TPRO_PATH . '/admin/views/variant/title.php';
            include SP_TPRO_PATH . '/admin/views/variant/text.php';
            include SP_TPRO_PATH . '/admin/views/variant/client-name.php';
            include SP_TPRO_PATH . '/admin/views/variant/designation-company.php';
            include SP_TPRO_PATH . '/admin/views/variant/location.php';
            include SP_TPRO_PATH . '/admin/views/variant/phone.php';
            include SP_TPRO_PATH . '/admin/views/variant/email.php';
            include SP_TPRO_PATH . '/admin/views/variant/date.php';
            include SP_TPRO_PATH . '/admin/views/variant/website.php';
            include SP_TPRO_PATH . '/admin/views/variant/filter.php';

            /**
             * Google font link enqueue
             */
            $custom_id         = uniqid();
            $enqueue_fonts     = array();
            $tpro_typography   = array();
            $tpro_typography[] = $shortcode_data['section_title_typography'];
            $tpro_typography[] = $shortcode_data['testimonial_title_typography'];
            $tpro_typography[] = $shortcode_data['testimonial_title_typography_two'];
            $tpro_typography[] = $shortcode_data['testimonial_title_typography_three'];
            $tpro_typography[] = $shortcode_data['testimonial_title_typography_four'];
            $tpro_typography[] = $shortcode_data['testimonial_text_typography'];
            $tpro_typography[] = $shortcode_data['testimonial_text_typography_two'];
            $tpro_typography[] = $shortcode_data['testimonial_text_typography_three'];
            $tpro_typography[] = $shortcode_data['testimonial_text_typography_four'];
            $tpro_typography[] = $shortcode_data['client_name_typography'];
            $tpro_typography[] = $shortcode_data['client_name_typography_two'];
            $tpro_typography[] = $shortcode_data['client_designation_company_typography'];
            $tpro_typography[] = $shortcode_data['client_designation_company_typography_two'];
            $tpro_typography[] = $shortcode_data['client_location_typography'];
            $tpro_typography[] = $shortcode_data['client_location_typography_two'];
            $tpro_typography[] = $shortcode_data['client_phone_typography'];
            $tpro_typography[] = $shortcode_data['client_phone_typography_two'];
            $tpro_typography[] = $shortcode_data['client_email_typography'];
            $tpro_typography[] = $shortcode_data['client_email_typography_two'];
            $tpro_typography[] = $shortcode_data['testimonial_date_typography'];
            $tpro_typography[] = $shortcode_data['testimonial_date_typography_two'];
            $tpro_typography[] = $shortcode_data['client_website_typography'];
            $tpro_typography[] = $shortcode_data['client_website_typography_two'];
            $tpro_typography[] = $shortcode_data['filter_typography'];
            if ( ! empty( $tpro_typography ) ) {
                foreach ( $tpro_typography as $font ) {
                    if ( isset( $font['font'] ) && $font['font'] == 'google' ) {
                        $variant         = ( isset( $font['variant'] ) && $font['variant'] !== 'regular' ) ? ':' . $font['variant'] : '';
                        $enqueue_fonts[] = $font['family'] . $variant;
                    }
                }
            }
            if ( ! empty( $enqueue_fonts ) ) {
                wp_enqueue_style( 'sp-tpro-google-fonts' . $custom_id, esc_url( add_query_arg( 'family', urlencode( implode( '|', $enqueue_fonts ) ), '//fonts.googleapis.com/css' ) ), array(), SP_TPRO_VERSION, false );
            }

            // Enqueue Script
            if ($layout == 'slider') {
                wp_enqueue_script('tpro-slick-min-js');
                if ($thumbnail_slider == 'false') {
                    if ($shortcode_data['slider_ticker_mode'] == 'true') {
                        wp_enqueue_script('tpro-slick-ticker-active');
                    } else {
                        wp_enqueue_script('tpro-slick-active');
                    }
                }
            } elseif ($layout == 'filter_grid' || $layout == 'filter_masonry') {
                wp_enqueue_script('tpro-isotope-js');
                wp_enqueue_script('tpro-filter-config');
            }

            if ($shortcode_data['testimonial_read_more'] == 'true' && $shortcode_data['testimonial_read_more_link_action'] == 'expand' ) {
                wp_enqueue_script('tpro-curtail-min-js');
                wp_enqueue_script('tpro-read-more-config');
                $tpro_read_more_config = compact('testimonial_characters_limit', 'testimonial_read_more_text', 'testimonial_read_less_text', 'testimonial_read_more_ellipsis');
            } elseif ($shortcode_data['testimonial_read_more'] == 'true' && $shortcode_data['testimonial_read_more_link_action'] == 'popup') {
                wp_enqueue_style('tpro-remodal');
                wp_enqueue_style('tpro-remodal-default-theme');
                wp_enqueue_script('tpro-remodal-js');
            }

            if ($layout == 'slider' && $thumbnail_slider == 'false' ) {
                $tpro_config = compact('number_of_testimonials', 'number_of_testimonials_desktop', 'number_of_testimonials_small_desktop', 'number_of_testimonials_tablet', 'number_of_testimonials_mobile', 'rtl_mode', 'slider_draggable', 'slider_swipe', 'slider_auto_play', 'slider_auto_play_speed', 'slider_scroll_speed', 'number_of_slides_to_scroll', 'slider_pause_on_hover', 'slider_infinite', 'pagination', 'navigation', 'navigation_icons', 'slider_fade_effect');
            } elseif ($layout == 'filter_grid' || $layout == 'filter_masonry' ) {
                $tpro_filter_config = compact('layout_mode');
            }

            $outline = '';

            // Style
            include SP_TPRO_PATH . '/public/views/content/style.php';

            if ( $shortcode_data['display_testimonials_from'] == 'specific_testimonials' && ! empty( $shortcode_data['specific_testimonial'] ) ) {
                $specific_testimonial_ids = $shortcode_data['specific_testimonial'];
            } else {
                $specific_testimonial_ids = null;
            }

            if ( $layout == 'grid' && $shortcode_data['grid_pagination'] == 'true' || $layout == 'masonry' && $shortcode_data['grid_pagination'] == 'true' || $layout == 'list' && $shortcode_data['grid_pagination'] == 'true' ) {
                if ( is_front_page() ) {
                    $paged = ( get_query_var( 'page' ) ) ? get_query_var( 'page' ) : 1;
                } else {
                    $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
                }
                $args = array(
                    'post_type'      => 'spt_testimonial',
                    'orderby'        => $shortcode_data['testimonial_order_by'],
                    'order'          => $shortcode_data['testimonial_order'],
                    'posts_per_page' => $shortcode_data['number_of_total_testimonials'],
                    'post__in'       => $specific_testimonial_ids,
                    'paged'          => $paged
                );
            } else {
                $args = array(
                    'post_type'      => 'spt_testimonial',
                    'orderby'        => $shortcode_data['testimonial_order_by'],
                    'order'          => $shortcode_data['testimonial_order'],
                    'posts_per_page' => $shortcode_data['number_of_total_testimonials'],
                    'post__in'       => $specific_testimonial_ids,
                );
            }

            if ($shortcode_data['display_testimonials_from'] == 'category' && ! empty($shortcode_data['category_list'])) {
                $args['tax_query'][] = array(
                    'taxonomy' => 'testimonial_cat',
                    'field'    => 'term_id',
                    'terms'    => $shortcode_data['category_list'],
                    'operator' => $shortcode_data['category_operator'],
                );
            }

            $post_query = new WP_Query($args);


            if ($thumbnail_slider == 'true') {

                $outline .= '<div id="sp-testimonial-pro-wrapper-' . $post_id . '" class="sp-testimonial-pro-wrapper sp-tpro-thumbnail-slider sp_tpro_nav_position_' . $shortcode_data['navigation_position'] . '">';

                if ($shortcode_data['testimonial_read_more'] == 'true' && $shortcode_data['testimonial_read_more_link_action'] == 'expand') {
                    $outline .= '<div class="sp-tpro-rm-config">' . json_encode($tpro_read_more_config) . '</div>';
                }

                if ($section_title == 'true') {
                    $outline .= '<h2 class="sp-testimonial-pro-section-title">' . get_the_title($post_id) . '</h2>';
                }

                $outline .= '<script>

            jQuery(document).ready(function() {
                jQuery("#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section-thumb").slick({
                  slidesToShow: 5,
                  slidesToScroll: 1,
                  asNavFor: "#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section-content",
                  arrows: false,
                  dots: false,
                  centerMode: true,
                  centerPadding: 0,
                  focusOnSelect: true,
                  pauseOnFocus: false,
                  autoplay: ' . $slider_auto_play_thumb . ',
                  autoplaySpeed: ' . $slider_auto_play_speed . ',
                  speed: ' . $slider_scroll_speed . ',
                  pauseOnHover: ' . $slider_pause_on_hover_thumb . ',
                  swipe: ' . $slider_swipe_thumb . ',
                  draggable: ' . $slider_draggable_thumb . ',
                  rtl: ' . $rtl_mode_thumb . ',
                });
                jQuery("#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section-content").slick({
                  slidesToShow: 1,
                  slidesToScroll: 1,
                  arrows: ' . $navigation_thumb . ',
                  prevArrow: "<div class=\'slick-prev\'><i class=\'fa fa-'.$navigation_icons.'-left\'></i></div>",
                  nextArrow: "<div class=\'slick-next\'><i class=\'fa fa-'.$navigation_icons.'-right\'></i></div>",
                  dots: ' . $pagination_thumb . ',
                  fade: ' . $slider_fade_effect_thumb . ',
                  pauseOnFocus: false,
                  asNavFor: "#sp-testimonial-pro-' . $post_id . '.sp-testimonial-pro-section-thumb",
                  autoplay: ' . $slider_auto_play_thumb . ',
                  autoplaySpeed: ' . $slider_auto_play_speed . ',
                  speed: ' . $slider_scroll_speed . ',
                  pauseOnHover: ' . $slider_pause_on_hover_thumb . ',
                  swipe: ' . $slider_swipe_thumb . ',
                  draggable: ' . $slider_draggable_thumb . ',
                  rtl: ' . $rtl_mode_thumb . ',
                });

            });

        </script>';


                $outline .= '<div id="sp-testimonial-pro-' . $post_id . '" class="sp-testimonial-pro-section sp-testimonial-pro-section-thumb">';

                if ( $post_query->have_posts() ) {
                    while ( $post_query->have_posts() ) : $post_query->the_post();

                        $outline .= '<div class="sp-testimonial-pro-item" itemscope itemtype="http://schema.org/Review">';

                        $outline .= '<div itemprop="itemReviewed" itemscope itemtype="http://schema.org/Thing">
                            <meta itemprop="name" content="Testimonials">
                        </div>';

                        if ( $client_image == 'true' ) {
                            $tpro_thumb   = get_post_thumbnail_id();
                            $tpro_img_url = wp_get_attachment_url( $tpro_thumb );
                            $tpro_image   = aq_resize( $tpro_img_url, $client_image_width, $client_image_height, $client_image_crop );

                            if ( has_post_thumbnail( $post_query->post->ID ) ) {
                                $outline .= '<div class="tpro-client-image tpro-image-style-' . $shortcode_data['client_image_style']
                                            . '" itemprop="image">';
                                if ( $tpro_image == ! '' ) {
                                    $outline .= '<img src="' . $tpro_image . '">';
                                } else {
                                    $outline .= '<img src="' . $tpro_img_url . '">';
                                }
                                $outline .= '</div>';
                            }
                        }

                        $outline .= '</div>'; //sp-testimonial-pro-item

                    endwhile;
                }
                $outline .= '</div>'; //sp-testimonial-pro


                $outline .= '<div id="sp-testimonial-pro-' . $post_id . '" class="sp-testimonial-pro-section sp-testimonial-pro-read-more tpro-readmore-'.$shortcode_data['testimonial_read_more_link_action'].'-'.$testimonial_read_more.' sp-testimonial-pro-section-content tpro-pagination-style-' . $pagination_style . ' tpro-style-' . $theme_style . ' tpro-navigation-' . $navigation_style . '">';

                if ( $post_query->have_posts() ) {
                    while ( $post_query->have_posts() ) : $post_query->the_post();

                        $outline .= '<div class="sp-testimonial-pro-item" itemscope itemtype="http://schema.org/Review">';

                        $testimonial_data  = get_post_meta( get_the_ID(), 'sp_tpro_meta_options', true );
                        $tpro_rating_star = (isset($testimonial_data['tpro_rating']) ? $testimonial_data['tpro_rating']: '');
                        $tpro_designation = (isset($testimonial_data['tpro_designation']) ? $testimonial_data['tpro_designation']: '');
                        $tpro_name = (isset($testimonial_data['tpro_name']) ? $testimonial_data['tpro_name']: '');
                        $tpro_company_name = (isset($testimonial_data['tpro_company_name']) ? $testimonial_data['tpro_company_name']: '');
                        $tpro_website = (isset($testimonial_data['tpro_website']) ? $testimonial_data['tpro_website']: '');
                        $tpro_location = (isset($testimonial_data['tpro_location']) ? $testimonial_data['tpro_location']: '');
                        $tpro_phone = (isset($testimonial_data['tpro_phone']) ? $testimonial_data['tpro_phone']: '');
                        $tpro_email = (isset($testimonial_data['tpro_email']) ? $testimonial_data['tpro_email']: '');

                        if ( $testimonial_title == 'true' ) {
                            $outline .= '<div class="tpro-testimonial-title"><h3>' . get_the_title() . '</h3></div>';
                        }

                        if ( $testimonial_text == 'true' ) {
                            $outline .= '<div class="tpro-client-testimonial" itemprop="reviewBody">';

                            $full_content  = nl2br(get_the_content());
                            $short_content = substr( $full_content, 0, $shortcode_data['testimonial_characters_limit'] );
                            $count         = strlen( $full_content );

                            if($shortcode_data['testimonial_content_type'] == 'full_content' ||
                               $shortcode_data['testimonial_read_more'] == 'true' && $shortcode_data['testimonial_read_more_link_action'] == 'expand'){
                                $outline .= '<p class="tpro-testimonial-text">'.$full_content.'</p>';
                            }else {
                                $outline .= '<p class="tpro-testimonial-text">'.$short_content.$testimonial_read_more_ellipsis.'</p>';
                            }

                            if ( $count >= $shortcode_data['testimonial_characters_limit'] && $shortcode_data['testimonial_read_more'] == 'true' && $shortcode_data['testimonial_content_type'] == 'content_with_limit') {
                                if ( $shortcode_data['testimonial_read_more_link_action'] == 'expand' ) {
                                    $outline .= '<a href="#" class="tpro-read-more">' . $testimonial_read_more_text . '</a>';
                                } elseif ( $count >= $shortcode_data['testimonial_characters_limit'] && $shortcode_data['testimonial_read_more_link_action'] == 'popup' ) {
                                    $outline .= '<a href="#" data-remodal-target="sp-tpro-testimonial-id-' . get_the_ID() . '" class="tpro-read-more">' . $testimonial_read_more_text . '</a>';
                                }
                            }
                            $outline .= '</div>';
                        }

                        if ( $testimonial_client_name == 'true' ) {
                            $outline .= '<div itemprop="author" itemscope itemtype="http://schema.org/Person">';
                            $outline .= '<meta itemprop="name" content="' . $tpro_name . '">';
                            $outline .= '<h2 class="tpro-client-name">' . $tpro_name . '</h2>';
                            $outline .= '</div>';
                        }

                        if ( $testimonial_client_rating == 'true' && $tpro_rating_star !== '' ) {
                            include SP_TPRO_PATH . '/public/views/content/rating.php';
                        }

                        if ( $client_designation == 'true' && $tpro_designation !== '' || $client_company_name == 'true' &&
                                                                                          $tpro_company_name !== ''
                        ) {
                            $outline .= '<div class="tpro-client-designation-company">';
                            if($identity_linking_website == 'true' && $tpro_website !== ''){
                                $outline .= '<a target="'.$website_link_target.'" href="' . esc_url( $tpro_website ) . '">';
                            }
                            if ( $client_designation == 'true' && $tpro_designation !== '' ) {
                                $outline .= $tpro_designation;
                            }
                            if ( $client_designation == 'true' && $tpro_designation !== '' && $client_company_name == 'true' && $tpro_company_name !== '' ) {
                                $outline .= ' - ';
                            }
                            if ( $client_company_name == 'true' && $tpro_company_name !== '' ) {
                                $outline .= $tpro_company_name;
                            }
                            if($identity_linking_website == 'true' && $tpro_website !== ''){
                                $outline .= '</a>';
                            }
                            $outline .= '</div>';
                        }
                        if ( $shortcode_data['testimonial_client_location'] == 'true' && $tpro_location !== '' ) {
                            $outline .= '<div class="tpro-client-location">' . $tpro_location . '</div>';
                        }
                        if ( $shortcode_data['testimonial_client_phone'] == 'true' && $tpro_phone !== '' ) {
                            $outline .= '<div class="tpro-client-phone">' . $tpro_phone . '</div>';
                        }
                        if ( $shortcode_data['testimonial_client_email'] == 'true' && $tpro_email !== '' ) {
                            $outline .= '<div class="tpro-client-email">' . $tpro_email . '</div>';
                        }
                        if ( $shortcode_data['testimonial_client_date'] == 'true' ) {
                            $outline .= '<div class="tpro-testimonial-date">' . get_the_date( $shortcode_data['testimonial_client_date_format'] ) . '</div>';
                        }
                        if ( $shortcode_data['testimonial_client_website'] == 'true' && $tpro_website !== '' ) {
                            $outline .= '<div class="tpro-client-website"><a target="'.$website_link_target.'" href="' . esc_url( $tpro_website ) . '">' . $tpro_website . '</a></div>';
                        }

                        include SP_TPRO_PATH . '/public/views/content/social-profile.php';

                        // Modal Start
                        if ( $shortcode_data['testimonial_read_more'] == 'true' && $shortcode_data['testimonial_read_more_link_action'] == 'popup' ) {
                            include SP_TPRO_PATH . '/public/views/content/popup.php';
                        }
                        // Modal End

                        $outline .= '</div>'; //sp-testimonial-pro-item


                    endwhile;
                }

                $outline .= '</div>';
                $outline .= '</div>';


            } else {
                $outline .= '<div id="sp-testimonial-pro-wrapper-' . $post_id . '" class="sp-testimonial-pro-wrapper sp_tpro_nav_position_' . $shortcode_data['navigation_position'] . '">';

                if ( $layout == 'slider' ) {
                    $outline .= '<div class="sp-tpro-config">' . json_encode( $tpro_config ) . '</div>';
                } elseif ( $layout == 'filter_grid' || $layout == 'filter_masonry' ) {
                    $outline .= '<div class="sp-tpro-config">' . json_encode( $tpro_filter_config ) . '</div>';
                }
                if ( $shortcode_data['testimonial_read_more'] == 'true' && $shortcode_data['testimonial_read_more_link_action'] == 'expand' ) {
                    $outline .= '<div class="sp-tpro-rm-config">' . json_encode( $tpro_read_more_config ) . '</div>';
                }

                if ( $section_title == 'true' ) {
                    $outline .= '<h2 class="sp-testimonial-pro-section-title">' . get_the_title( $post_id ) . '</h2>';
                }

                $outline .= '<div id="sp-testimonial-pro-' . $post_id . '" class="sp-testimonial-pro-section tpro-layout-'.$layout.'-'.$slider_ticker_mode.' sp-testimonial-pro-read-more tpro-readmore-'.$shortcode_data['testimonial_read_more_link_action'].'-'.$testimonial_read_more.' ';

                if ( $layout == 'masonry' ) {
                    $outline .= 'sp_testimonial_pro_masonry ';
                } elseif ( $layout == 'filter_grid' || $layout == 'filter_masonry' ) {
                    $outline .= 'sp_testimonial_pro_filter ';
                }
                $outline .= 'tpro-pagination-style-' . $pagination_style . ' tpro-style-' . $theme_style . ' 
            tpro-navigation-' . $navigation_style . '">';


                if ( $layout == 'filter_grid' || $layout == 'filter_masonry' ) {
                    if ( ! is_tax() ) {

                        $terms = get_terms( array(
                            'taxonomy'   => 'testimonial_cat',
                            'hide_empty' => true,
                        ) );
                        $count = count( $terms );

                        if ( $count > 0 ) {

                            $outline .= '<div class="sp-tpro-filter"><ul class="sp-tpro-items-filter">';
                            $outline .= '<li><a href="#" class="active"  data-filter="*">' . esc_html__( 'All', 'testimonial-pro' ) . '</a></li>';

                            if ( isset( $shortcode_data['category_list'] ) && $shortcode_data['category_list'] == ! '' ) {
                                foreach ( $shortcode_data['category_list'] as $cat_id ) {
                                    $cat_list = get_term( $cat_id );
                                    $outline  .= '<li><a href="#" data-filter=".testimonial_cat-' . $cat_list->slug . '">'
                                                 . $cat_list->name . '</a></li>';
                                }
                            } else {
                                foreach ( $terms as $term ) {
                                    $outline .= '<li><a href="#" data-filter=".testimonial_cat-' . $term->slug . '">' . $term->name . '</a></li>';
                                }
                            }
                            $outline .= '</ul></div>';
                        }
                    }
                }


                if ( $layout == 'filter_grid' || $layout == 'filter_masonry' ) {
                    $outline .= '<div class="sp-tpro-isotope-items">';
                }
                if ( $post_query->have_posts() ) {
                    while ( $post_query->have_posts() ) : $post_query->the_post();

                        $testimonial_data  = get_post_meta( get_the_ID(), 'sp_tpro_meta_options', true );
                        $tpro_rating_star = (isset($testimonial_data['tpro_rating']) ? $testimonial_data['tpro_rating']: '');
                        $tpro_designation = (isset($testimonial_data['tpro_designation']) ? $testimonial_data['tpro_designation']: '');
                        $tpro_name = (isset($testimonial_data['tpro_name']) ? $testimonial_data['tpro_name']: '');
                        $tpro_company_name = (isset($testimonial_data['tpro_company_name']) ? $testimonial_data['tpro_company_name']: '');
                        $tpro_website = (isset($testimonial_data['tpro_website']) ? $testimonial_data['tpro_website']: '');
                        $tpro_location = (isset($testimonial_data['tpro_location']) ? $testimonial_data['tpro_location']: '');
                        $tpro_phone = (isset($testimonial_data['tpro_phone']) ? $testimonial_data['tpro_phone']: '');
                        $tpro_email = (isset($testimonial_data['tpro_email']) ? $testimonial_data['tpro_email']: '');

                        if ( $theme_style == 'theme-one' ) {
                            include SP_TPRO_PATH . '/public/views/templates/theme-one.php';
                        } elseif ( $theme_style == 'theme-two' ) {
                            include SP_TPRO_PATH . '/public/views/templates/theme-two.php';
                        } elseif ( $theme_style == 'theme-three' ) {
                            include SP_TPRO_PATH . '/public/views/templates/theme-three.php';
                        } elseif ( $theme_style == 'theme-four' ) {
                            include SP_TPRO_PATH . '/public/views/templates/theme-four.php';
                        } elseif ( $theme_style == 'theme-five' ) {
                            include SP_TPRO_PATH . '/public/views/templates/theme-five.php';
                        } elseif ( $theme_style == 'theme-six' ) {
                            include SP_TPRO_PATH . '/public/views/templates/theme-six.php';
                        } elseif ( $theme_style == 'theme-seven' ) {
                            include SP_TPRO_PATH . '/public/views/templates/theme-seven.php';
                        } elseif ( $theme_style == 'theme-eight' ) {
                            include SP_TPRO_PATH . '/public/views/templates/theme-eight.php';
                        } elseif ( $theme_style == 'theme-nine' ) {
                            include SP_TPRO_PATH . '/public/views/templates/theme-nine.php';
                        } elseif ( $theme_style == 'theme-ten' ) {
                            include SP_TPRO_PATH . '/public/views/templates/theme-ten.php';
                        }

                    endwhile;
                } else {
                    $outline .= '<h2 class="sp-not-found-any-testimonial">' . esc_html__( 'No testimonials found', 'testimonial-pro' ) . '</h2>';
                }
                if ( $layout == 'filter_grid' || $layout == 'filter_masonry' ) {
                    $outline .= '</div>';//sp-tpro-isotope-items
                }

                // Pagination
                if ( $post_query->max_num_pages > 1 ) {
                    if ( $layout == 'grid' && $shortcode_data['grid_pagination'] == 'true' || $layout == 'masonry' && $shortcode_data['grid_pagination'] == 'true' || $layout == 'list' && $shortcode_data['grid_pagination'] == 'true' ) {
                        $outline .= '<div class="tpro-col-xl-1 sp-tpro-pagination-area">';
                        if ( is_front_page() ) {
                            $paged_format = '?page=%#%';
                            $paged_query  = 'page';
                        } else {
                            $paged_format = '?paged=%#%';
                            $paged_query  = 'paged';
                        }
                        $big        = 999999999; // need an unlikely integer
                        $items      = paginate_links( array(
                            'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                            'format'    => $paged_format,
                            'prev_next' => true,
                            'current'   => max( 1, get_query_var( $paged_query ) ),
                            'total'     => $post_query->max_num_pages,
                            'type'      => 'array',
                            'prev_text' => '<i class="fa fa-angle-left"></i>',
                            'next_text' => '<i class="fa fa-angle-right"></i>'
                        ) );
                        $pagination = "<ul class=\"sp-tpro-pagination\">\n\t<li>";
                        $pagination .= join( "</li>\n\t<li>", $items );
                        $pagination .= "</li>\n</ul>\n";

                        $outline .= $pagination;
                        $outline .= '</div>';
                    }
                }


                $outline .= '</div>';
                $outline .= '</div>';

            }

            wp_reset_query();

            return $outline;

        }

    }

    new TPRO_Shortcode_Render();
}