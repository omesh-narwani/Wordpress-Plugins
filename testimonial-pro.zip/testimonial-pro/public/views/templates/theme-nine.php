<?php
/**
 * Theme Nine
 */

$outline .= '<div class="sp-testimonial-pro-item ';
if ( $layout == 'grid' || $layout == 'masonry' || $layout == 'filter_grid' || $layout == 'filter_masonry' ) {
	$outline .= '' . join( ' ', get_post_class( 'tpro-col-xl-' . $number_of_testimonials . ' tpro-col-lg-' . $number_of_testimonials_desktop . ' tpro-col-md-' . $number_of_testimonials_small_desktop . ' tpro-col-sm-' . $number_of_testimonials_tablet . ' tpro-col-xs-' . $number_of_testimonials_mobile . '' ) );
}
$outline .= '" itemscope itemtype="http://schema.org/Review">';

$outline .= '<div class="sp-testimonial-pro">';

$outline .= '<div itemprop="itemReviewed" itemscope itemtype="http://schema.org/Thing">
	<meta itemprop="name" content="Testimonials">
</div>';

if($shortcode_data['testimonial_info_position_two'] == 'bottom_right' || $shortcode_data['testimonial_info_position_two'] == 'bottom_left'){
	$outline .= '<div class="tpro-testimonial-content-area">';
	if ( $testimonial_title == 'true' ) {
		$outline .= '<div class="tpro-testimonial-title"><h3>' . get_the_title() . '</h3></div>';
	}

	if ( $testimonial_text == 'true' ) {
		$outline .= '<div class="tpro-client-testimonial" itemprop="reviewBody">';

		$full_content  = nl2br(get_the_content());
		$short_content = substr($full_content, 0, $shortcode_data['testimonial_characters_limit']);
		$count = strlen( $full_content );

		if($shortcode_data['testimonial_content_type'] == 'full_content' ||
		   $shortcode_data['testimonial_read_more'] == 'true' && $shortcode_data['testimonial_read_more_link_action'] == 'expand'){
			$outline .= '<p class="tpro-testimonial-text">'.$full_content.'</p>';
		}else {
			$outline .= '<p class="tpro-testimonial-text">'.$short_content.$testimonial_read_more_ellipsis.'</p>';
		}

		if( $count >= $shortcode_data['testimonial_characters_limit'] && $shortcode_data['testimonial_read_more'] == 'true' && $shortcode_data['testimonial_content_type'] == 'content_with_limit'){
			if($shortcode_data['testimonial_read_more_link_action'] == 'expand'){
				$outline .= '<a href="#" class="tpro-read-more"></a>';
			} elseif($count >= $shortcode_data['testimonial_characters_limit'] && $shortcode_data['testimonial_read_more_link_action'] == 'popup'){
				$outline .= '<a href="#" data-remodal-target="sp-tpro-testimonial-id-' . get_the_ID() . '" class="tpro-read-more">'.$testimonial_read_more_text.'</a>';
			}
		}
		$outline .= '</div>';
	}
	$outline .= '</div>';
}

$outline .= '<div class="tpro-testimonial-meta-area">';
if ( $client_image == 'true' && $shortcode_data['testimonial_info_position_two'] == 'bottom_left' || $client_image == 'true' && $shortcode_data['testimonial_info_position_two'] == 'top_left') {
	$tpro_thumb   = get_post_thumbnail_id();
	$tpro_img_url = wp_get_attachment_url( $tpro_thumb );
	$tpro_image   = aq_resize( $tpro_img_url, $client_image_width, $client_image_height, $client_image_crop );

	if ( has_post_thumbnail( $post_query->post->ID ) ) {
		$outline .= '<div class="tpro-client-image tpro-image-style-'.$shortcode_data['client_image_style']
		            .'" itemprop="image">';
		if(isset($testimonial_data['tpro_video_url']) && $testimonial_data['tpro_video_url'] !== ''){
			$outline .= '<a href="'.$testimonial_data['tpro_video_url'].'" class="sp-tpro-video">';
		}
		if ( $tpro_image == ! '' ) {
			$outline .= '<img src="' . $tpro_image . '">';
		} else {
			$outline .= '<img src="' . $tpro_img_url . '">';
		}
		if(isset($testimonial_data['tpro_video_url']) && $testimonial_data['tpro_video_url'] !== ''){
			$outline .= '<i class="fa fa-play-circle-o" aria-hidden="true"></i></a>';
		}
		$outline .= '</div>';
	}
}
$outline .= '<div class="tpro-testimonial-meta-text">';
if ( $testimonial_client_name == 'true' ) {
	$outline .= '<div itemprop="author" itemscope itemtype="http://schema.org/Person">';
	$outline .= '<meta itemprop="name" content="' . $tpro_name . '">';
	$outline .= '<h2 class="tpro-client-name">' . $tpro_name . '</h2>';
	$outline .= '</div>';
}

if ( $testimonial_client_rating == 'true' && $tpro_rating_star !== '' ) {
	include SP_TPRO_PATH . '/public/views/content/rating.php';
}

if ( $client_designation == 'true' && $tpro_designation !== '' || $client_company_name == 'true' &&
                                                                  $tpro_company_name !== ''
) {
	$outline .= '<div class="tpro-client-designation-company">';
	if($identity_linking_website == 'true' && $tpro_website !== ''){
		$outline .= '<a target="'.$website_link_target.'" href="' . esc_url( $tpro_website ) . '">';
	}
	if ( $client_designation == 'true' && $tpro_designation !== '' ) {
		$outline .= $tpro_designation;
	}
	if ( $client_designation == 'true' && $tpro_designation !== '' && $client_company_name == 'true' && $tpro_company_name !== '' ) {
		$outline .= ' - ';
	}
	if ( $client_company_name == 'true' && $tpro_company_name !== '' ) {
		$outline .= $tpro_company_name;
	}
	if($identity_linking_website == 'true' && $tpro_website !== ''){
		$outline .= '</a>';
	}
	$outline .= '</div>';
}
if ( $shortcode_data['testimonial_client_location'] == 'true' && $tpro_location !== '' ) {
	$outline .= '<div class="tpro-client-location">' . $tpro_location . '</div>';
}
if ( $shortcode_data['testimonial_client_phone'] == 'true' && $tpro_phone !== '' ) {
	$outline .= '<div class="tpro-client-phone">' . $tpro_phone . '</div>';
}
if ( $shortcode_data['testimonial_client_email'] == 'true' && $tpro_email !== '' ) {
	$outline .= '<div class="tpro-client-email">' . $tpro_email . '</div>';
}
if ( $shortcode_data['testimonial_client_date'] == 'true' ) {
	$outline .= '<div class="tpro-testimonial-date">' . get_the_date( $shortcode_data['testimonial_client_date_format'] ) . '</div>';
}
if ( $shortcode_data['testimonial_client_website'] == 'true' && $tpro_website !== '' ) {
	$outline .= '<div class="tpro-client-website"><a target="'.$website_link_target.'" href="' . esc_url( $tpro_website ) . '">' . $tpro_website . '</a></div>';
}

include SP_TPRO_PATH . '/public/views/content/social-profile.php';

$outline .= '</div>';//tpro-testimonial-meta-text

if ( $client_image == 'true' && $shortcode_data['testimonial_info_position_two'] == 'bottom_right' || $client_image == 'true' && $shortcode_data['testimonial_info_position_two'] == 'top_right') {
	$tpro_thumb   = get_post_thumbnail_id();
	$tpro_img_url = wp_get_attachment_url( $tpro_thumb );
	$tpro_image   = aq_resize( $tpro_img_url, $client_image_width, $client_image_height, $client_image_crop );

	if ( has_post_thumbnail( $post_query->post->ID ) ) {
		$outline .= '<div class="tpro-client-image tpro-image-style-'.$shortcode_data['client_image_style']
		            .'" itemprop="image">';
		if ( $tpro_image == ! '' ) {
			$outline .= '<img src="' . $tpro_image . '">';
		} else {
			$outline .= '<img src="' . $tpro_img_url . '">';
		}
		$outline .= '</div>';
	}
}
$outline .= '</div>';

if($shortcode_data['testimonial_info_position_two'] == 'top_right' || $shortcode_data['testimonial_info_position_two'] == 'top_left'){
	$outline .= '<div class="tpro-testimonial-content-area">';
	if ( $testimonial_title == 'true' ) {
		$outline .= '<div class="tpro-testimonial-title"><h3>' . get_the_title() . '</h3></div>';
	}

	if ( $testimonial_text == 'true' ) {
		$outline .= '<div class="tpro-client-testimonial" itemprop="reviewBody">';

		$full_content  = nl2br(get_the_content());
		$short_content = substr($full_content, 0, $shortcode_data['testimonial_characters_limit']);
		$count = strlen( $full_content );

		if($shortcode_data['testimonial_content_type'] == 'full_content' ||
		   $shortcode_data['testimonial_read_more'] == 'true' && $shortcode_data['testimonial_read_more_link_action'] == 'expand'){
			$outline .= '<p class="tpro-testimonial-text">'.$full_content.'</p>';
		}else {
			$outline .= '<p class="tpro-testimonial-text">'.$short_content.$testimonial_read_more_ellipsis.'</p>';
		}

		if( $count >= $shortcode_data['testimonial_characters_limit'] && $shortcode_data['testimonial_read_more'] == 'true' && $shortcode_data['testimonial_content_type'] == 'content_with_limit'){
			if($shortcode_data['testimonial_read_more_link_action'] == 'expand'){
				$outline .= '<a href="#" class="tpro-read-more"></a>';
			} elseif($count >= $shortcode_data['testimonial_characters_limit'] && $shortcode_data['testimonial_read_more_link_action'] == 'popup'){
				$outline .= '<a href="#" data-remodal-target="sp-tpro-testimonial-id-' . get_the_ID() . '" class="tpro-read-more">'.$testimonial_read_more_text.'</a>';
			}
		}
		$outline .= '</div>';
	}
	$outline .= '</div>';
}

$outline .= '</div>'; //sp-testimonial-pro

// Modal Start
if ( $shortcode_data['testimonial_read_more'] == 'true' && $shortcode_data['testimonial_read_more_link_action'] == 'popup' ) {
	include SP_TPRO_PATH . '/public/views/content/popup.php';
}
// Modal End

$outline .= '</div>'; //sp-testimonial-pro-item