<?php

namespace Rtwpvg\Helpers;

class Functions
{

    public static function generate_inline_style($styles = array()) {

        $generated = array();
        if (!empty($styles)) {
            foreach ($styles as $property => $value) {
                $generated[] = "{$property}: $value";
            }
        }
        return implode('; ', array_unique(apply_filters('rtwpvg_generate_inline_style', $generated)));
    }


    public static function get_gallery_image_html($attachment_id, $main_image = false, $loop_index = 0) {

        $gallery_thumbnail = wc_get_image_size('gallery_thumbnail');
        $thumbnail_size = apply_filters('woocommerce_gallery_thumbnail_size', array($gallery_thumbnail['width'], $gallery_thumbnail['height']));
        $image_size = apply_filters('woocommerce_gallery_image_size', $main_image ? 'woocommerce_single' : $thumbnail_size);
        $full_size = apply_filters('woocommerce_gallery_full_size', apply_filters('woocommerce_product_thumbnails_large_size', 'full'));
        // $thumbnail_src     = wp_get_attachment_image_src( $attachment_id, $thumbnail_size );
        $full_src = wp_get_attachment_image_src($attachment_id, $full_size);
        $default_src = wp_get_attachment_image_src($attachment_id, $image_size);
        $inner_html = wp_get_attachment_image($attachment_id, $image_size, false, array(
            'title' => get_post_field('post_title', $attachment_id),
            'alt' => get_post_field('post_title', $attachment_id),
            'data-caption' => get_post_field('post_excerpt', $attachment_id),
            'data-src' => $full_src[0],
            'data-large_image' => $full_src[0],
            'data-large_image_width' => $full_src[1],
            'data-large_image_height' => $full_src[2],
        ));


        $classes = apply_filters('rtwpvg_image_html_class', array(
            'rtwpvg-gallery-image',
        ), $attachment_id);


        $inner_html = apply_filters('rtwpvg_image_inner_html', $inner_html, $attachment_id);

        // If require thumbnail
        if (!$main_image) {
            $classes = apply_filters('rtwpvg_thumbnail_image_html_class', array(
                'rtwpvg-thumbnail-image',
            ), $attachment_id);

            $inner_html = apply_filters('rtwpvg_thumbnail_image_inner_html', $inner_html, $attachment_id);

        }

        return '<div class="' . esc_attr(implode(' ', array_unique($classes))) . '"><div>' . $inner_html . '</div></div>';
    }


    public static function locate_template($name) {
        // Look within passed path within the theme - this is priority.
        $template = array(
            trailingslashit(rtwpvg()->dirname()) . "$name.php"
        );

        if (!$template_file = locate_template($template)) {
            $template_file = rtwpvg()->get_template_file_path($name);
        }

        return apply_filters('rtwpvg_locate_template', $template_file, $name);
    }

    static function get_template($fileName, $args = null) {

        if (!empty($args) && is_array($args)) {
            extract($args); // @codingStandardsIgnoreLine
        }

        $located = self::locate_template($fileName);


        if (!file_exists($located)) {
            /* translators: %s template */
            self::doing_it_wrong(__FUNCTION__, sprintf(__('%s does not exist.', 'classified-listing'), '<code>' . $located . '</code>'), '1.0');

            return;
        }

        // Allow 3rd party plugin filter template file from their plugin.
        $located = apply_filters('rtwpvg_get_template', $located, $fileName, $args);

        do_action('rtwpvg_before_template_part', $fileName, $located, $args);

        include $located;

        do_action('rtwpvg_after_template_part', $fileName, $located, $args);

    }

    static public function get_template_html($template_name, $args = null) {
        ob_start();
        self::get_template($template_name, $args);

        return ob_get_clean();

    }


    static function doing_it_wrong($function, $message, $version) {
        // @codingStandardsIgnoreStart
        $message .= ' Backtrace: ' . wp_debug_backtrace_summary();

        _doing_it_wrong($function, $message, $version);

    }

}