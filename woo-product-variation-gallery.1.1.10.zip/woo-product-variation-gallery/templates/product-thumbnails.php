<?php
// Blank because we don't need thumbnails, but keep it