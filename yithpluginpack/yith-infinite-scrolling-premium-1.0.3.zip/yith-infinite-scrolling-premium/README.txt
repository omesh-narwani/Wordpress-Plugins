= 1.0.3 =

* Added: Compatibility with YITH WooCommerce Ajax Product Filter
* Updated: Plugin Core

= 1.0.2 =

* Added: Compatibility with WooCommerce 2.4
* Fixed: Plugin documentation link
* Updated: Plugin Core

= 1.0.1 =

* Initial release