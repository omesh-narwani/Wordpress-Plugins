<div id="YLC_msg_ylc.msg_id" class="chat-cnv-lineylc.class">
    <div title="ylc.date" class="chat-cnv-time">
        ylc.time
    </div>
    <div class="chat-avatar">
        <img src="ylc.avatar" />
    </div>
    <div class="chat-cnv-msg">
        <div class="chat-cnv-author">
            ylc.name
        </div>
        ylc.msg
    </div>
</div>
<div class="chat-clear"></div>
