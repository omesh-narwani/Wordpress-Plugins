<div class="sidebar-info macro">
    <select class="macro-select" style="width:100%;">
        <option value=""></option>
        ylc.macro_opts
    </select>
</div>