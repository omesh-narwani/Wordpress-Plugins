<div class="sidebar-info">
    <strong>ylc.name_title</strong>
    ylc.name
</div>
<div class="sidebar-info">
    <strong>ylc.ip_title</strong>
    ylc.ip_address
</div>
<div class="sidebar-info">
    <strong>ylc.info_title</strong>
    <a href="mailto:ylc.email">
        ylc.email
    </a>
</div>
<div class="sidebar-info">
    <strong>ylc.page_title</strong>
    <a id="YLC_active_page" href="ylc.href_current_page" target="_blank">
        ylc.current_page
    </a>
</div>