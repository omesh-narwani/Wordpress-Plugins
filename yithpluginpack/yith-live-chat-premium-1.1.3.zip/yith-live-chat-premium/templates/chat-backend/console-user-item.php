<li id="YLC_chat_user_ylc.id" data-id="ylc.id" data-cnv-id="ylc.cnv_id" data-name="ylc.username" data-count="0" data-chat="ylc.chat_with" class="ylc.class">
    <div class="user-avatar">
        <img src="ylc.avatar" />
    </div>
    <i class="fa fa-check-circle"></i>
    ylc.is_mobile
    <div class="chat-username">
        ylc.username
        <span class="chat-count"></span>
    </div>
    <div class="chat-meta">ylc.meta</div>
</li>