<div class="sidebar-info timer">
    <strong>
        ylc.timer_title
    </strong>
    <span id="YLC_timer">
    </span>
</div>