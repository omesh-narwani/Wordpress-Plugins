<button id="YLC_save" data-cnv-id="ylc.obj_user_data" class="button">
    <i class="fa fa-floppy-o"></i>
    ylc.button_text
</button>
