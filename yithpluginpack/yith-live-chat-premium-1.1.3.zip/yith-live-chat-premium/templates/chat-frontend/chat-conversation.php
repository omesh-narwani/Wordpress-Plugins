<div class="chat-cnv" id="YLC_cnv">
    <div class="chat-welc">
        ylc.welc
    </div>
</div>
<div class="chat-tools">
    <a id="YLC_tool_end_chat" href="javascript:void(0)">
        <i class="fa fa-times"></i>
        ylc.end_chat
    </a>

    <div id="YLC_popup_ntf"></div>
</div>
<div class="chat-cnv-reply">
    <div class="chat-cnv-input">
        <textarea id="YLC_cnv_reply" name="msg" class="chat-reply-input" placeholder="ylc.reply_ph"></textarea>
    </div>
</div>