<div class="chat-evaluation">
    ylc.eval_text
    <div id="YLC_popup_ntf" class="chat-ntf"></div>
    <a href="javascript:void(0)" id="YLC_good_btn" class="good">
        <i class="fa fa-thumbs-up"></i>
        ylc.good_text
    </a>
    <a href="javascript:void(0)" id="YLC_bad_btn" class="bad">
        <i class="fa fa-thumbs-down"></i>
        ylc.bad_text
    </a>
    ylc.transcript
</div>