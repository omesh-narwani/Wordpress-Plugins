<div id="YLC_chat" class="chat-widget" style="ylc.widget_styles;">
    <div id="YLC_chat_header" class="chat-header" style="ylc.header_styles;">
        <div class="chat-ico chat fa fa-comments"></div>
        <div class="chat-ico ylc-toggle fa fa-angle-ylc.arrow"></div>
        <div class="chat-title">
            ylc.title
        </div>
        <div class="chat-clear"></div>
    </div>
    <div id="YLC_chat_body" class="chat-body ylc.body_class">
        ylc.body
    </div>
</div>



