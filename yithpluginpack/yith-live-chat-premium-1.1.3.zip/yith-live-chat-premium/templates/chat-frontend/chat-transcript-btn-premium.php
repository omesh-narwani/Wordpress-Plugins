<div class="chat-evaluation">
    <div id="YLC_popup_ntf" class="chat-ntf"></div>
    <a href="javascript:void(0)" id="YLC_chat_request">
        ylc.chat_copy
    </a>
</div>