<div class="chat-checkbox">
    <input type="checkbox" name="request_chat" id="YLC_request_chat">
    <label for="YLC_request_chat">ylc.chat_copy</label>
</div>