== Changelog ==

= 1.0.3 =

* Added: Compatibility with Wordpress 4.4
* Added: Compatibility with WooCommerce 2.5 BETA 3
* Added: Option to show selected variation on popup
* Added: XML config file for WPML
* Added: Compatibility with Gravity Form Product Addons Plugin
* Fixed: Popup dimension on mobile device
* Updated: Plugin Core
* Updated: Language file

= 1.0.2 =

* Added: Compatibility with WooCommerce 2.4
* Updated: Plugin Core
* Updated: Language file

= 1.0.1 =

* Initial release