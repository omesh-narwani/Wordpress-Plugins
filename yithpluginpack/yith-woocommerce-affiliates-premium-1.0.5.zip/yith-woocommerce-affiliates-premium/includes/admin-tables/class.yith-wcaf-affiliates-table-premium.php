<?php
/**
 * Affiliate Table Premium class
 *
 * @author Your Inspiration Themes
 * @package YITH WooCommerce Affiliates
 * @version 1.0.0
 */

/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined( 'YITH_WCAF' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WCAF_Affiliates_Table_Premium' ) ) {
	/**
	 * WooCommerce Affiliates Table Premium
	 *
	 * @since 1.0.0
	 */
	class YITH_WCAF_Affiliates_Table_Premium extends YITH_WCAF_Affiliates_Table {
		/**
		 * Print column with affiliate ID
		 *
		 * @param $item mixed Current item row
		 * @return string Column content
		 * @since 1.0.0
		 */
		public function column_id( $item ) {
			$commission_url = esc_url( add_query_arg( array( 'page' => 'yith_wcaf_panel', 'tab' => 'commissions', '_user_id' => $item['user_id'] ), admin_url( 'admin.php' ) ) );
			$column = sprintf( '<a href="%s"><strong>#%s</strong></a>', $commission_url, $item['ID'] );

			return $column;
		}

		/**
		 * Print column with affiliate user details
		 *
		 * @param $item mixed Current item row
		 * @return string Column content
		 * @since 1.0.0
		 */
		public function column_affiliate ( $item ) {
			$column = '';

			$user = get_user_by( 'id', $item['user_id'] );
			$user_email = $item['user_email'];
			$payment_email = ! empty( $item['payment_email'] ) ? $item['payment_email'] : __( 'N/A', 'yith-wcaf' );

			$username = '';
			if ( $user->first_name || $user->last_name ) {
				$username .= esc_html( ucfirst( $user->first_name ) . ' ' . ucfirst( $user->last_name ) );
			}
			else {
				$username .= esc_html( ucfirst( $user->display_name ) );
			}

			$column .= sprintf( '%s<a href="%s">%s</a><small class="meta email"><a href="mailto:%s">%s</a></small><small class="meta">%s: %s</small>', get_avatar( $item['user_id'], 32 ), get_edit_user_link( $item['user_id'] ), $username, $user_email, $user_email, __( 'Payment', 'yith-wcaf' ), $payment_email );

			return $column;
		}

		/**
		 * Print column with affiliate refunds (total of refunded commissions)
		 *
		 * @param $item mixed Current item row
		 * @return string Column content
		 * @since 1.0.0
		 */
		public function column_refunds( $item ) {
			$column = '';
			$column .= wc_price( $item['refunds'] );

			return $column;
		}

		/**
		 * Print column with affiliate clicks
		 *
		 * @param $item mixed Current item row
		 * @return string Column content
		 * @since 1.0.0
		 */
		public function column_click( $item ) {
			$column = '';
			$column .= sprintf( '<a href="%s">%d</a>', esc_url( add_query_arg( array( 'page' => 'yith_wcaf_panel', 'tab' => 'clicks', '_user_id' => $item['user_id'] ), admin_url( 'admin.php' ) ) ), $item['click'] );

			return $column;
		}

		/**
		 * Print column with affiliate conversions
		 *
		 * @param $item mixed Current item row
		 * @return string Column content
		 * @since 1.0.0
		 */
		public function column_conversion( $item ) {
			$column = '';
			$column .= sprintf( '<a href="%s">%d</a>', esc_url( add_query_arg( array( 'page' => 'yith_wcaf_panel', 'tab' => 'clicks', '_user_id' => $item['user_id'], 'status' => 'converted' ), admin_url( 'admin.php' ) ) ), $item['conversion'] );

			return $column;
		}

		/**
		 * Print column with affiliate actions
		 *
		 * @param $item mixed Current item row
		 * @return string Column content
		 * @since 1.0.0
		 */
		public function column_actions( $item ) {
			$actions = array();
			$actions['view'] = sprintf( '<a class="button tips view" href="%s" data-tip="%s">%s</a>', get_edit_user_link( $item['user_id'] ), __( 'View', 'yith-wcaf' ), __( 'View', 'yith-wcaf' ) );

			$enabled = $item['enabled'];

			if( $enabled ){
				$switch_status_url = esc_url( add_query_arg( array( 'action' => 'yith_wcaf_change_status', 'affiliate_id' => $item['ID'], 'status' => 'disabled' ), admin_url( 'admin.php' ) ) );
				$actions['disable'] = sprintf( '<a class="button tips disable" href="%s" data-tip="%s">%s</a>', $switch_status_url, __( 'Switch to Disabled', 'yith-wcaf' ), __( 'Disable', 'yith-wcaf' ) );
			}
			else{
				$switch_status_url = esc_url( add_query_arg( array( 'action' => 'yith_wcaf_change_status', 'affiliate_id' => $item['ID'], 'status' => 'enabled' ), admin_url( 'admin.php' ) ) );
				$actions['disable'] = sprintf( '<a class="button tips enable" href="%s" data-tip="%s">%s</a>', $switch_status_url, __( 'Switch to Enabled', 'yith-wcaf' ), __( 'Enable', 'yith-wcaf' ) );
			}

			return implode( ' ', $actions );
		}

		/**
		 * Returns columns available in table
		 *
		 * @return array Array of columns of the table
		 * @since 1.0.0
		 */
		public function get_columns(){
			$columns = array(
				'cb'                    => '<input type="checkbox" />',
				'id'                    => __( 'ID', 'yith-wcaf' ),
				'token'                 => __( 'Token', 'yith-wcaf' ),
				'status'                => sprintf( '<span class="status_head tips" data-tip="%s">%s</span>', __( 'Approved', 'yith-wcaf' ), __( 'Approved', 'yith-wcaf' ) ),
				'affiliate'             => __( 'Affiliate', 'yith-wcaf' ),
				'rate'                  => __( 'Rate', 'yith-wcaf' ),
				'earnings'              => __( 'Earnings', 'yith-wcaf' ),
				'refunds'               => __( 'Refunds', 'yith-wcaf' ),
				'paid'                  => __( 'Paid', 'yith-wcaf' ),
				'balance'               => __( 'Balance', 'yith-wcaf' ),
				'click'                 => __( 'Click', 'yith-wcaf' ),
				'conversion'            => sprintf( '<span class="tips" data-tip="%s">%s</span>', __( 'Number of orders following a click', 'yith-wcaf' ), __( 'Conversion', 'yith-wcaf' ) ),
				'conv_rate'             => __( 'Conv. rate', 'yith-wcaf' ),
				'actions'               => __( 'Actions', 'yith-wcaf' )
			);

			return $columns;
		}
	}
}