<?php
/**
 * Affiliate Handler Premium class
 *
 * @author Your Inspiration Themes
 * @package YITH WooCommerce Affiliates
 * @version 1.0.0
 */

/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined( 'YITH_WCAF' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WCAF_Affiliate_Handler_Premium' ) ) {
	/**
	 * WooCommerce Affiliate Handler Premium
	 *
	 * @since 1.0.0
	 */
	class YITH_WCAF_Affiliate_Handler_Premium extends YITH_WCAF_Affiliate_Handler {

		/**
		 * Single instance of the class for each token
		 *
		 * @var \YITH_WCAF_Affiliate_Handler_Premium
		 * @since 1.0.0
		 */
		protected static $instance = null;

		/**
		 * Constructor method
		 *
		 * @return \YITH_WCAF_Affiliate_Handler_Premium
		 * @since 1.0.0
		 */
		public function __construct() {
			parent::__construct();

			add_filter( 'yith_wcaf_general_settings', array( $this, 'filter_general_settings' ) );
		}

		/**
		 * Filter general settings, to add notification settings
		 *
		 * @param $settings mixed Original settings array
		 * @return mixed Filtered settings array
		 * @since 1.0.0
		 */
		public function filter_general_settings( $settings ) {
			$settings_options = $settings['settings'];
			$before_index = 'referral-registration-form';
			$before_index_position = array_search( $before_index, array_keys( $settings_options ) );

			$settings_options_chunk_1 = array_slice( $settings_options, 0, $before_index_position + 1 );
			$settings_options_chunk_2 = array_slice( $settings_options, $before_index_position + 1, count( $settings_options ) );

			$affiliate_settings = array(
				'referral-registration-auto-enable' => array(
					'title' => __( 'Auto enable affiliates', 'yith-wcaf' ),
					'type' => 'checkbox',
					'desc' => __( 'Auto enable affiliates on registration', 'yith-wcaf' ),
					'id' => 'yith_wcaf_referral_registration_auto_enable',
					'default' => 'yes'
				),
			);

			$settings['settings'] = array_merge(
				$settings_options_chunk_1,
				$affiliate_settings,
				$settings_options_chunk_2
			);

			$settings_options = $settings['settings'];

			$before_index = 'referral-registration-show-surname-field';
			$before_index_position = array_search( $before_index, array_keys( $settings_options ) );

			$settings_options_chunk_1 = array_slice( $settings_options, 0, $before_index_position + 1 );
			$settings_options_chunk_2 = array_slice( $settings_options, $before_index_position + 1, count( $settings_options ) );

			$affiliate_settings = array(
				'referral-registration-notify-admin' => array(
					'title' => __( 'Notify admin', 'yith-wcaf' ),
					'type' => 'checkbox',
					'desc' => sprintf( '%s <a href="%s">%s</a>', __( 'Notify admin of a new affiliate registration; customize email on', 'yith-wcaf' ), esc_url( add_query_arg( array( 'page' => 'wc-settings', 'tab' => 'email', 'section' => 'yith_wcaf_new_affiliate_email' ), admin_url( 'admin.php' ) ) ), __( 'WooCommerce Settings Page', 'yith-wcaf' ) ),
					'id' => 'yith_wcaf_referral_registration_notify_admin',
					'default' => 'yes'
				),
			);

			$settings['settings'] = array_merge(
				$settings_options_chunk_1,
				$affiliate_settings,
				$settings_options_chunk_2
			);

			return $settings;
		}

		/* === FORM HANDLER METHODS === */

		/**
		 * Flag a registered user as an affiliates
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function become_an_affiliate() {
			if( isset( $_REQUEST['become_an_affiliate'] ) && $_REQUEST['become_an_affiliate'] == 1 ){
				if( is_user_logged_in() ){
					$auto_enable = 'yes' == get_option( 'yith_wcaf_referral_registration_auto_enable' );
					$customer_id = get_current_user_id();
					$affiliates = $this->get_affiliates( array( 'user_id' => $customer_id ) );
					$affiliate = isset( $affiliates[0] ) ? $affiliates[0] : false;

					if( ! $affiliate ){
						$id = $this->add( array( 'user_id' => $customer_id, 'enabled' => $auto_enable, 'token' => $this->get_default_user_token( $customer_id ) ) );

						if( $id ){
							wc_add_notice( __( 'Your request has been processed correctly', 'yith-wcaf' ) );

							// trigger new affiliate action
							do_action( 'yith_wcaf_new_affiliate', $id );
						}
						else{
							wc_add_notice( __( 'An error occurred while trying to create the affiliate; try later.', 'yith-wcaf' ), 'error' );
						}
					}
					else{
						wc_add_notice( __( 'You have already affiliated with us!', 'yith-wcaf' ), 'error' );
					}
				}

				wp_redirect( esc_url( remove_query_arg( 'become_an_affiliate' ) ) );
				die();
			}
		}

		/**
		 * Register a user as an affiliate (register form action handling)
		 *
		 * @param $customer_id int Customer ID
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function register_affiliate( $customer_id ) {
			// retrieve options
			$enabled_form = get_option( 'yith_wcaf_referral_registration_form_options' );
			$auto_enable = 'yes' == get_option( 'yith_wcaf_referral_registration_auto_enable' );

			// retrieve post data
			$first_name = ! empty( $_POST['first_name'] ) ? trim( $_POST['first_name'] ) : false;
			$last_name = ! empty( $_POST['last_name'] ) ? trim( $_POST['last_name'] ) : false;
			$payment_email = ! empty( $_POST['payment_email'] ) ? trim( $_POST['payment_email'] ) : false;

			if(
				( ! empty( $_POST['register_affiliate'] ) && isset( $_POST['register_affiliate'] ) && wp_verify_nonce( $_POST['register_affiliate'], 'yith-wcaf-register-affiliate' ) ) ||
				( ! empty( $_POST['register'] ) && isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'woocommerce-register' ) && $enabled_form == 'any' )
			){
				$id = $this->add( array( 'user_id' => $customer_id, 'enabled' => $auto_enable, 'payment_email' => $payment_email, 'token' => $this->get_default_user_token( $customer_id ) ) );

				if( $first_name || $last_name ){
					wp_update_user( array_merge(
						array( 'ID' => $customer_id ),
						( $first_name ) ? array( 'first_name' => $first_name ) : array(),
						( $last_name ) ? array( 'last_name' => $last_name ) : array()
					) );
				}

				// trigger new affiliate action
				do_action( 'yith_wcaf_new_affiliate', $id );
			}
		}

		/* === PANEL HANDLING METHODS === */

		/**
		 * Print Affiliate panel
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function print_affiliate_panel() {
			// define variables to be used in template
			$affiliates_table = new YITH_WCAF_Affiliates_Table_Premium();
			$affiliates_table->prepare_items();

			include( YITH_WCAF_DIR . 'templates/admin/affiliate-panel.php' );
		}

		/**
		 * Returns single instance of the class
		 *
		 * @return \YITH_WCAF_Affiliate_Handler_Premium
		 * @since 1.0.0
		 */
		public static function get_instance(){
			if( is_null( self::$instance ) ){
				self::$instance = new self;
			}

			return self::$instance;
		}
	}
}

/**
 * Unique access to instance of YITH_WCAF_Affiliate_Handler class
 *
 * @return \YITH_WCAF_Affiliate_Handler_Premium
 * @since 1.0.0
 */
function YITH_WCAF_Affiliate_Handler_Premium(){
	return YITH_WCAF_Affiliate_Handler_Premium::get_instance();
}