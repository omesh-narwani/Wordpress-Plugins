<?php
/**
 * Affiliate Premium class
 *
 * @author  Your Inspiration Themes
 * @package YITH WooCommerce Affiliates
 * @version 1.0.0
 */

/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined( 'YITH_WCAF' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WCAF_Affiliate_Premium' ) ) {
	/**
	 * WooCommerce Affiliate Premium
	 *
	 * @since 1.0.0
	 */
	class YITH_WCAF_Affiliate_Premium extends YITH_WCAF_Affiliate {

		/**
		 * Single instance of the class for each token
		 *
		 * @var mixed
		 * @since 1.0.0
		 */
		protected static $instances = array();

		/**
		 * Referral history enabled
		 *
		 * @var string
		 * @since 1.0.0
		 */
		protected $_history_cookie_enabled = 'no';

		/**
		 * Referral token variable name
		 *
		 * @var string
		 * @since 1.0.0
		 */
		protected $_history_cookie_name = 'yith_wcaf_referral_history';

		/**
		 * Referral token variable name
		 *
		 * @var string
		 * @since 1.0.0
		 */
		protected $_history_cookie_exp = WEEK_IN_SECONDS;

		/**
		 * Whether persistent commission calculation is enabled
		 *
		 * @var string
		 * @since 1.0.0
		 */
		protected $_persistent_calculation = 'no';

		/**
		 * Affiliate changes hostory
		 *
		 * @var array
		 * @since 1.0.0
		 */
		protected $_history;

		/**
		 * Constructor method
		 *
		 * @return \YITH_WCAF_Affiliate_Premium
		 * @since 1.0.0
		 */
		public function __construct( $token = null ) {
			parent::__construct( $token );

			// register checkout handling
			add_action( 'woocommerce_checkout_order_processed', array( $this, 'register_history' ), 10, 1 );

			// filter plugin options
			add_filter( 'yith_wcaf_general_settings', array( $this, 'filter_general_settings' ) );
		}

		/**
		 * Filter general settings, to add history settings
		 *
		 * @param $settings mixed Original settings array
		 * @return mixed Filtered settings array
		 * @since 1.0.0
		 */
		public function filter_general_settings( $settings ) {
			$settings_options = $settings['settings'];
			$before_index = 'cookie-referral-expiration';
			$before_index_position = array_search( $before_index, array_keys( $settings_options ) );

			$settings_options_chunk_1 = array_slice( $settings_options, 0, $before_index_position + 1 );
			$settings_options_chunk_2 = array_slice( $settings_options, $before_index_position + 1, count( $settings_options ) );

			$history_settings = array(
				'cookie-history-enable' => array(
					'title' => __( 'Enable history storage', 'yith-wcaf' ),
					'type' => 'checkbox',
					'desc' => __( 'Enable storage of referral changes', 'yith-wcaf' ),
					'id' => 'yith_wcaf_history_cookie_enable',
					'default' => 'yes'
				),

				'cookie-history-name' => array(
					'title' => __( 'Referral history name', 'yith-wcaf' ),
					'type' => 'text',
					'desc' => __( 'Select name for cookie that will store referral token history. This name should be as unique as possible, to avoid collision with other plugins: If you change this setting, all cookies created before will no longer be effective', 'yith-wcaf' ),
					'id' => 'yith_wcaf_history_cookie_name',
					'css' => 'min-width: 300px;',
					'default' => 'yith_wcaf_referral_history',
					'desc_tip' => true
				),

				'cookie-history-expire-needed' => array(
					'title' => __( 'Make history cookie expire', 'yith-wcaf' ),
					'type' => 'checkbox',
					'desc' => __( 'Check this option if you want to make history cookie expire', 'yith-wcaf' ),
					'id' => 'yith_wcaf_history_make_cookie_expire',
					'default' => 'yes'
				),

				'cookie-history-expiration' => array(
					'title' => __( 'Referral history exp.', 'yith-wcaf' ),
					'type' => 'number',
					'desc' => __( 'Number of seconds htat have to pass before referral history cookie expires', 'yith-wcaf' ),
					'id' => 'yith_wcaf_history_cookie_expire',
					'css' => 'min-width: 100px;',
					'default' => WEEK_IN_SECONDS,
					'custom_attributes' => array(
						'min' => 1,
						'max' => 9999999999999,
						'step' => 1
					),
					'desc_tip' => true
				),
			);

			$settings['settings'] = array_merge(
				$settings_options_chunk_1,
				$history_settings,
				$settings_options_chunk_2
			);

			return $settings;
		}

		/* === HELPER METHODS === */

		/**
		 * Return current referrer history
		 *
		 * @return mixed Current token history; false if none set
		 * @since 1.0.0
		 */
		public function get_history() {
			if ( ! empty( $this->_history ) ) {
				return $this->_history;
			}

			return false;
		}

		/* === INIT METHODS === */

		/**
		 * Init class attributes for admin options
		 *
		 * @return void
		 * @since 1.0.0
		 */
		protected function _retrieve_options() {
			parent::_retrieve_options();

			$make_cookie_expire = get_option( 'yith_wcaf_history_make_cookie_expire', 'yes' );
			$cookie_expire = get_option( 'yith_wcaf_history_cookie_expire', $this->_ref_cookie_exp );

			$this->_history_cookie_enabled = get_option( 'yith_wcaf_history_cookie_enable', $this->_history_cookie_enabled );
			$this->_history_cookie_name    = get_option( 'yith_wcaf_history_cookie_name', $this->_history_cookie_name );
			$this->_history_cookie_exp     = ( $make_cookie_expire == 'yes' ) ? $cookie_expire : ( 15 * YEAR_IN_SECONDS );
			$this->_persistent_calculation = get_option( 'yith_wcaf_commission_persistent_calculation', $this->_persistent_calculation );
		}

		/**
		 * Init class attribute for token
		 *
		 * @param $token string Token to be used, instead of retrieved one
		 *
		 * @return void
		 * @since 1.0.0
		 */
		protected function _retrieve_token( $token ) {
			if( is_null( $token ) ){
				if( isset( $_GET[ $this->_ref_name ] ) && $_GET[ $this->_ref_name ] != '' ){
					$token = $_GET[ $this->_ref_name ];

					// sets cookie for referrer id
					setcookie( $this->_ref_cookie_name, $_GET[ $this->_ref_name ], time() + intval( $this->_ref_cookie_exp ), COOKIEPATH, COOKIE_DOMAIN, false, true );

					if( $this->_history_cookie_enabled == 'yes' ) {
						// sets cookie for referrer history
						$history = isset( $_COOKIE[ $this->_history_cookie_name ] ) ? explode( ',', $_COOKIE[ $this->_history_cookie_name ] ) : array( $token );
						if ( end( $history ) != $token ) {
							array_push( $history, $token );
						}

						$this->_history = $history;

						$history = implode( ',', $history );

						setcookie( $this->_history_cookie_name, $history, time() + intval( $this->_history_cookie_exp ), COOKIEPATH, COOKIE_DOMAIN, false, true );
					}

					// sets token origin as query-string
					$this->_token_origin = 'query-string';
				}
				elseif( isset( $_COOKIE[ $this->_ref_cookie_name ] ) ){
					$token = $_COOKIE[ $this->_ref_cookie_name ];

					if( isset( $_COOKIE[ $this->_history_cookie_name ] ) ){
						$this->_history = explode( ',', $_COOKIE[ $this->_history_cookie_name ] );
					}

					// sets token origin as cookie
					$this->_token_origin = 'cookie';
				}
				else{
					$token = false;
					$this->_history = false;
					$this->_token_origin = false;
				}

				if( $this->_persistent_calculation == 'yes' && is_user_logged_in() && $persistent_token = get_user_meta( get_current_user_id(), '_yith_wcaf_persistent_token', true ) ){
					$token = ( ! $token ) ? $persistent_token : $token;

					if( $token == $persistent_token ) {
						$this->_token_origin = 'persistent';
					}
				}
			}
			else{
				$this->_token_origin = 'constructor';
			}

			if( ! YITH_WCAF_Affiliate_Handler()->is_valid_token( $token ) ){
				$token = false;
			}

			$this->_token = $token;
		}

		/* === CHECKOUT HANDLING METHODS === */

		/**
		 * Register affiliates history within order metas
		 *
		 * @param $order_id int Order id
		 * @return void
		 * @since 1.0.0
		 */
		public function register_history( $order_id ) {
			if ( $this->_history_cookie_enabled == 'yes' ) {
				update_post_meta( $order_id, '_yith_wcaf_referral_history', $this->_history );
			}

			// delete token cookie
			$this->delete_history_cookie_after_process();
		}

		/**
		 * Delete cookie after an order is processed with current token
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function delete_history_cookie_after_process() {
			if ( $this->_history_cookie_enabled == 'yes' ) {
				setcookie( $this->_history_cookie_name, '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN, false, true );
			}
		}

		/**
		 * Returns single instance of the class
		 *
		 * @return \YITH_WCAF_Affiliate_Premium
		 * @since 1.0.0
		 */
		public static function get_instance( $token = null ) {

			/*
			 * When creating class from token, an instance is correctly set to token index
			 * Otherwise, if class loads automatically token from REQUEST, instance will be stored under 0 index
			 */

			if ( ! isset( self::$instances[ $token ] ) || is_null( self::$instances[ $token ] ) ) {
				self::$instances[ $token ] = new self;
			}

			return self::$instances[ $token ];
		}
	}
}

/**
 * Unique access to instance of YITH_WCAF_Affiliate class
 *
 * @param $token string Unique affiliate token
 *
 * @return \YITH_WCAF_Affiliate
 * @since 1.0.0
 */
function YITH_WCAF_Affiliate_Premium( $token = null ) {
	return YITH_WCAF_Affiliate_Premium::get_instance( $token );
}