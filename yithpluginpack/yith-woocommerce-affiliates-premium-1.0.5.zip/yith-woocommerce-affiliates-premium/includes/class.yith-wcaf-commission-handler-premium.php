<?php
/**
 * Commission Handler Premium class
 *
 * @author Your Inspiration Themes
 * @package YITH WooCommerce Affiliates
 * @version 1.0.0
 */

/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined( 'YITH_WCAF' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WCAF_Commission_Handler_Premium' ) ) {
	/**
	 * WooCommerce Commission Handler Premium
	 *
	 * @since 1.0.0
	 */
	class YITH_WCAF_Commission_Handler_Premium extends YITH_WCAF_Commission_Handler {

		/**
		 * Single instance of the class for each token
		 *
		 * @var \YITH_WCAF_Commission_Handler_Premium
		 * @since 1.0.0
		 */
		protected static $instance = null;

		/**
		 * Constructor method
		 *
		 * @return \YITH_WCAF_Commission_Handler_Premium
		 * @since 1.0.0
		 */
		public function __construct() {
			parent::__construct();

			add_filter( 'yith_wcaf_general_settings', array( $this, 'filter_general_settings' ) );

			// handle panel button actions
			add_action( 'admin_action_yith_wcaf_change_commission_status', array( $this, 'handle_switch_status_panel_actions' ) );
			add_action( 'admin_action_yith_wcaf_pay_commission', array( $this, 'handle_payments_panel_actions' ) );
		}

		/**
		 * Filter general settings, to add notification settings
		 *
		 * @param $settings mixed Original settings array
		 * @return mixed Filtered settings array
		 * @since 1.0.0
		 */
		public function filter_general_settings( $settings ) {
			$settings_options = $settings['settings'];
			$before_index = 'commission-exclude-discount';
			$before_index_position = array_search( $before_index, array_keys( $settings_options ) );

			$settings_options_chunk_1 = array_slice( $settings_options, 0, $before_index_position + 1 );
			$settings_options_chunk_2 = array_slice( $settings_options, $before_index_position + 1, count( $settings_options ) );

			$premium_settings = array(
				'commission-pending-notify-admin' => array(
					'title' => __( 'Notify admin', 'yith-wcaf' ),
					'type' => 'checkbox',
					'desc' => sprintf( '%s <a href="%s">%s</a>', __( 'Notify admin when a commission switches to pending; customize email on', 'yith-wcaf' ), esc_url( add_query_arg( array( 'page' => 'wc-settings', 'tab' => 'email', 'section' => 'yith_wcaf_admin_pending_commission_email' ), admin_url( 'admin.php' ) ) ), __( 'WooCommerce Settings Page', 'yith-wcaf' ) ),
					'id' => 'yith_wcaf_commission_pending_notify_admin',
					'default' => 'yes'
				),

				'commission-persistent-calculation' => array(
					'title' => __( 'Calculate commissions permanently', 'yith-wcaf' ),
					'type' => 'checkbox',
					'desc' => __( 'Register referral token within customer and credit commissions to the affiliate for any future customer purchase', 'yith-wcaf' ),
					'id' => 'yith_wcaf_commission_persistent_calculation',
					'default' => 'no'
				),

				'commission-persistent-percentage' => array(
					'title' => __( 'Persistent commissions rate', 'yith-wcaf' ),
					'type' => 'number',
					'desc' => __( 'Percentage of first commission rate applied for next purchases (please, use values greater than 100 carefully; no check on final commission amount is performed)', 'yith-wcaf' ),
					'id' => 'yith_wcaf_persistent_rate',
					'css' => 'max-width: 50px;',
					'default' => 0,
					'custom_attributes' => array(
						'min' => 0,
						'max' => 500,
						'step' => 'any'
					)
				),
			);

			$settings['settings'] = array_merge(
				$settings_options_chunk_1,
				$premium_settings,
				$settings_options_chunk_2
			);

			$settings['settings']['commission-general-rate']['desc'] = sprintf( '%s "<a href="%s">%s</a>" %s', __( 'General rate to apply to affiliates;', 'yith-wcaf' ), esc_url( add_query_arg( array( 'page' => 'yith_wcaf_panel', 'tab' => 'rates' ), admin_url( 'admin.php' ) ) ), __( 'Rate Panel', 'yith-wcaf' ), __( ' can be used to specify rates per user/product', 'yith-wcaf' ) );

			return $settings;
		}

		/* === PANEL COMMISSION METHODS === */

		/**
		 * Print commission panel
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function print_commission_panel() {
			// define variables to use in template
			$commission_id = isset( $_REQUEST['commission_id'] ) ? $_REQUEST['commission_id'] : false;

			if( ! empty( $commission_id ) && $this->commission_exists( intval( $commission_id ) ) ) {
				// retrieve commission
				$commission = $this->get_commission( $commission_id );

				// retrieve user
				$user_info = get_userdata( $commission['user_id'] );
				$user = get_user_by( 'id', $commission['user_id'] );

				// retrieve order
				$order = wc_get_order( $commission['order_id'] );
				$items = $order->get_items( 'line_item' );
				$item = isset( $items[ $commission['line_item_id'] ] ) ? $items[ $commission['line_item_id'] ] : false;

				// retrieve product
				$product = wc_get_product( $commission['product_id'] );

				// retrieve notes
				$commission_notes = $this->get_commission_notes( $commission_id );

				// retrieve refunds
				$refunds = $this->get_commission_refunds( $commission_id );
				$total_refunded = $this->get_total_commission_refund( $commission_id );

				// retrieve payments
				$active_payments = YITH_WCAF_Payment_Handler()->get_commission_payments( $commission_id, 'active' );
				$inactive_payments = YITH_WCAF_Payment_Handler()->get_commission_payments( $commission_id, 'inactive' );

				// retrieve available action
				$available_commission_actions = array();

				$available_status_change = $this->get_available_status_change( $commission_id );
				if( ! empty( $available_status_change ) ){
					if( in_array( 'pending-payment', $available_status_change ) && ! in_array( $commission['status'], $this->payment_status ) ){
						$available_gateways = YITH_WCAF_Payment_Handler_Premium()->get_available_gateways();

						if( ! empty( $available_gateways ) ){
							foreach( $available_gateways as $id => $gateway ){
								$payment_label = sprintf( __( 'Pay via %s', 'yith-wcaf' ), $gateway['label'] );
								$available_commission_actions[ 'pay_via_' . $id ] = $payment_label;
							}
						}
					}

					foreach( $available_status_change  as $status ){
						if( in_array( $status, YITH_WCAF_Commission_Handler()->get_dead_status() ) ){
							continue;
						}

						// avoid direct ( pending-payment -> pending ) status change
						if( $commission['status'] == 'pending-payment' && $status == 'pending' ){
							continue;
						}

						$readable_status = YITH_WCAF_Commission_Handler()->get_readable_status( $status );
						$available_commission_actions[ 'switch-to-' . $status ] = sprintf( __( 'Switch to %s', 'yith-wcaf' ), $readable_status );
					}
				}

				// require rate panel template
				include( YITH_WCAF_DIR . 'templates/admin/commission-panel-detail.php' );
			}
			else{
				// prepare user rates table items
				$commissions_table = new YITH_WCAF_Commissions_Table_Premium();
				$commissions_table->prepare_items();

				// require rate panel template
				include( YITH_WCAF_DIR . 'templates/admin/commission-panel-table.php' );
			}
		}

		/**
		 * Handle actions of status changes from the panel
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function handle_switch_status_panel_actions() {
			$commission_id = isset( $_REQUEST['commission_id'] ) ? $_REQUEST['commission_id'] : 0;
			$new_status = isset( $_REQUEST['status'] ) && in_array( $_REQUEST['status'], $this->_available_commission_status ) ? $_REQUEST['status'] : '';
			$redirect = esc_url_raw( add_query_arg( array( 'page' => 'yith_wcaf_panel', 'tab' => 'commissions' ), admin_url( 'admin.php' ) ) );

			if( ! $commission_id || ! $new_status ){
				wp_redirect( $redirect );
				die();
			}

			$res = $this->change_commission_status( $commission_id, $new_status );
			$redirect = esc_url_raw( add_query_arg( array( 'commission_status_change' => $res ), $redirect ) );

			wp_redirect( $redirect );
			die();
		}

		/**
		 * Handle actions of payment from the panel
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function handle_payments_panel_actions() {
			$commission_id = isset( $_REQUEST['commission_id'] ) ? $_REQUEST['commission_id'] : 0;
			$gateway = isset( $_REQUEST['gateway'] ) && in_array( $_REQUEST['gateway'], array_keys( YITH_WCAF_Payment_Handler_Premium()->get_available_gateways() ) ) ? $_REQUEST['gateway'] : '';
			$redirect = esc_url_raw( add_query_arg( array( 'page' => 'yith_wcaf_panel', 'tab' => 'commissions' ), admin_url( 'admin.php' ) ) );

			if( ! $commission_id || ! $gateway ){
				wp_redirect( $redirect );
				die();
			}

			$commission = YITH_WCAF_Commission_Handler()->get_commission( $commission_id );
			$available_status_change = YITH_WCAF_Commission_Handler()->get_available_status_change( $commission_id );

			if( in_array( 'pending-payment', $available_status_change ) && ! in_array( $commission['status'], $this->payment_status ) ){
				$this->change_commission_status( $commission_id, 'pending-payment', __( 'Payment registered; awaiting for IPN confirmation', 'yith-wcaf' ) );

				$res = YITH_WCAF_Payment_Handler()->register_payment( $commission_id, true, $gateway );

				if( ! $res['status'] ){
					$errors = is_array( $res['messages'] ) ? implode( ',', $res['messages'] ) : $res['messages'];
					$redirect = esc_url_raw( add_query_arg( array( 'commission_payment_failed' => urlencode( $errors ) ), $redirect ) );
				}
				else{
					$redirect = esc_url_raw( add_query_arg( array( 'commission_paid' => $commission_id ), $redirect ) );
				}
			}
			else{
				$redirect = esc_url_raw( add_query_arg( array( 'commission_unpaid' => $commission_id ), $redirect ) );
			}

			wp_redirect( $redirect );
			die();
		}

		/**
		 * Process bulk action for current view
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function process_bulk_actions() {
			if( ! empty( $_REQUEST[ 'commissions' ] ) ) {
				$current_action = isset( $_REQUEST['action'] ) ? $_REQUEST['action'] : '';
				$current_action = ( empty( $current_action ) && isset( $_REQUEST['action2'] ) ) ? $_REQUEST['action2'] : $current_action;
				$redirect = esc_url_raw( add_query_arg( array( 'page' => 'yith_wcaf_panel', 'tab' => 'commissions' ), admin_url( 'admin.php' ) ) );

				switch( $current_action ){
					case 'switch-to-pending':
						foreach( $_REQUEST[ 'commissions' ] as $commission_id ){
							$res = YITH_WCAF_Commission_Handler()->change_commission_status( $commission_id, 'pending' );
							$redirect = esc_url_raw( add_query_arg( 'commission_status_change', $res, $redirect ) );
						}
						break;
					case 'switch-to-not-confirmed':
						foreach( $_REQUEST[ 'commissions' ] as $commission_id ){
							$res = YITH_WCAF_Commission_Handler()->change_commission_status( $commission_id, 'not-confirmed' );
							$redirect = esc_url_raw( add_query_arg( 'commission_status_change', $res, $redirect ) );
						}
						break;
					case 'switch-to-cancelled':
						foreach( $_REQUEST[ 'commissions' ] as $commission_id ){
							$res = YITH_WCAF_Commission_Handler()->change_commission_status( $commission_id, 'cancelled' );
							$redirect = esc_url_raw( add_query_arg( 'commission_status_change', $res, $redirect ) );
						}
						break;
					case 'switch-to-refunded':
						foreach( $_REQUEST[ 'commissions' ] as $commission_id ){
							$res = YITH_WCAF_Commission_Handler()->change_commission_status( $commission_id, 'refunded' );
							$redirect = esc_url_raw( add_query_arg( 'commission_status_change', $res, $redirect ) );
						}
						break;
					default:
						// handles payment actions
						$matches = array();

						if( $current_action == 'pay' || preg_match( '^pay_via_([a-zA-Z_-]*)$^', $current_action, $matches ) ){
							$gateway = isset( $matches[1] ) ? $matches[1] : false;
							$proceed_with_payment = $gateway ? true : false;
							$to_pay = array();
							$cannot_be_paid = array();

							// filters non pending commissions
							foreach( $_REQUEST[ 'commissions' ] as $commission_id ){
								$commission = $this->get_commission( $commission_id );
								$available_status_change = $this->get_available_status_change( $commission_id );

								if( in_array( 'pending-payment', $available_status_change ) && ! in_array( $commission['status'], $this->payment_status ) ){
									$this->change_commission_status( $commission_id, 'pending-payment', __( 'Payment registered; awaiting for IPN confirmation', 'yith-wcaf' ) );
									$to_pay[] = $commission_id;
								}
								else{
									$cannot_be_paid[] = $commission_id;
								}
							}

							// pay filtered commissions
							$res = YITH_WCAF_Payment_Handler()->register_payment( $to_pay, $proceed_with_payment, $gateway );

							if( ! $res['status'] ){
								$errors = is_array( $res['messages'] ) ? implode( ',', $res['messages'] ) : $res['messages'];
								$redirect = esc_url_raw( add_query_arg( array( 'commission_payment_failed' => urlencode( $errors ) ), $redirect ) );
							}
							else{
								$redirect = esc_url_raw( add_query_arg( array( 'commission_paid' => implode( ',', $to_pay ), 'commission_unpaid' => implode( ',', $cannot_be_paid ) ), $redirect ) );
							}

						}

						break;
				}

				if( isset( $_GET['commission_id'] ) ){
					return;
				}

				wp_redirect( $redirect );
				die();
			}
		}

		/**
		 * Add metabox to order edit page
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function add_order_metabox() {
			parent::add_order_metabox();

			add_meta_box( 'yith_wcaf_order_referral_history', __( 'Referral History', 'yith-wcaf' ), array( $this, 'print_referral_history_metabox' ), 'shop_order', 'side' );
		}

		/**
		 * Print referral history order metabox
		 *
		 * @param $post \WP_Post Current order post object
		 * @return void
		 * @since 1.0.0
		 */
		public function print_referral_history_metabox( $post ) {
			// define variables to be used on template
			$referral_history = get_post_meta( $post->ID, '_yith_wcaf_referral_history', true );
			$referral_history_users = array();

			if( $referral_history ){
				foreach( $referral_history as $referral ){
					$user = array();
					$affiliate = YITH_WCAF_Affiliate_Handler()->get_affiliate_by_token( $referral );

					if( ! $affiliate ){
						continue;
					}

					$referral = $affiliate['user_id'];
					$user_data = get_userdata( $referral );

					if( ! $user_data ){
						return;
					}

					$user['user_email'] = $user_data->user_email;

					$user['username'] = '';
					if ( $user_data->first_name || $user_data->last_name ) {
						$user['username'] .= esc_html( ucfirst( $user_data->first_name ) . ' ' . ucfirst( $user_data->last_name ) );
					}
					else {
						$user['username'] .= esc_html( ucfirst( $user_data->display_name ) );
					}

					$referral_history_users[] = $user;
				}
			}

			include( YITH_WCAF_DIR . 'templates/admin/referral-history-metabox.php' );
		}

		/**
		 * Returns single instance of the class
		 *
		 * @return \YITH_WCAF_Commission_Handler_Premium
		 * @since 1.0.0
		 */
		public static function get_instance(){
			if( is_null( self::$instance ) ){
				self::$instance = new self;
			}

			return self::$instance;
		}
	}
}

/**
 * Unique access to instance of YITH_WCAF_Commission_Handler_Premium class
 *
 * @return \YITH_WCAF_Commission_Handler_Premium
 * @since 1.0.0
 */
function YITH_WCAF_Commission_Handler_Premium(){
	return YITH_WCAF_Commission_Handler_Premium::get_instance();
}