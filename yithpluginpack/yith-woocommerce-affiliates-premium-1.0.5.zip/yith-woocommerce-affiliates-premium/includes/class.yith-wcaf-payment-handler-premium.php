<?php
/**
 * Payment Handler Premium class
 *
 * @author  Your Inspiration Themes
 * @package YITH WooCommerce Affiliates
 * @version 1.0.0
 */

/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined( 'YITH_WCAF' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WCAF_Payment_Handler_Premium' ) ) {
	/**
	 * WooCommerce Payment Handler Premium
	 *
	 * @since 1.0.0
	 */
	class YITH_WCAF_Payment_Handler_Premium extends YITH_WCAF_Payment_Handler {
		/**
		 * Single instance of the class for each token
		 *
		 * @var \YITH_WCAF_Payment_Handler_Premium
		 * @since 1.0.0
		 */
		protected static $instance = null;

		/**
		 * Registered gateways
		 *
		 * @var mixed
		 * @since 1.0.0
		 */
		private $_available_gateways = array();

		/**
		 * Constructor method
		 *
		 * @return \YITH_WCAF_Payment_Handler_Premium
		 * @since 1.0.0
		 */
		public function __construct() {
			parent::__construct();
			$this->init_available_gateways();

			// scheduled events actions
			add_action( 'yith_wcaf_commission_status_pending', array( $this, 'pay_on_threshold_reached' ), 15, 1 );
			add_action( 'wp', array( $this, 'pay_affiliates_setup_schedule' ) );
			add_action( 'pay_affiliates_action_schedule', array( $this, 'pay_affiliates_do_schedule' ) );
			add_action( 'update_option_yith_wcaf_payment_date', array( $this, 'pay_affiliates_delete_schedule' ) );

			// add commissions panel handling
			add_action( 'admin_action_yith_wcaf_complete_payment', array( $this, 'handle_payments_panel_actions' ) );

			add_filter( 'yith_wcaf_general_settings', array( $this, 'filter_general_settings' ) );
		}

		/**
		 * Filter general settings, to add notification settings
		 *
		 * @param $settings mixed Original settings array
		 * @return mixed Filtered settings array
		 * @since 1.0.0
		 */
		public function filter_general_settings( $settings ) {
			$settings_options = $settings['settings'];
			$before_index = 'commission-options-end';
			$before_index_position = array_search( $before_index, array_keys( $settings_options ) );

			$settings_options_chunk_1 = array_slice( $settings_options, 0, $before_index_position + 1 );
			$settings_options_chunk_2 = array_slice( $settings_options, $before_index_position + 1, count( $settings_options ) );

			$gateways = $this->get_available_gateways();
			$gateway_options = array();
			$gateway_options['none'] = __( 'None', 'yith-wcaf' );

			if( ! empty( $gateways ) ){
				foreach( $gateways as $id=> $gateway ){
					$gateway_options[ $id ] = $gateway['label'];
				}
			}

			$payment_settings = array(
				'payment-options' => array(
					'title' => __( 'Payment', 'yith-wcaf' ),
					'type' => 'title',
					'desc' => '',
					'id' => 'yith_wcaf_payment_options'
				),

				'payment-type' => array(
					'title' => __( 'Payment type', 'yith-wcaf' ),
					'type' => 'select',
					'desc' => __( 'Choose payment mode to pay commissions to your affiliates', 'yith-wcaf' ),
					'id' => 'yith_wcaf_payment_type',
					'options' => array(
						'manually' => __( 'Manually', 'yith-wcaf' ),
						'automatically_on_threshold' => __( 'Automatically when reaching a threshold', 'yith-wcaf' ),
						'automatically_on_date' => __( 'Automatically on a specific month date', 'yith-wcaf' ),
						'automatically_on_both' => __( 'Automatically on a specific month date, if a specific threshold is reached', 'yith-wcaf' ),
					),
					'default' => 'manually',
					'desc_tip' => true
				),

				'payment-default-gateway' => array(
					'title' => __( 'Default gateway', 'yith-wcaf' ),
					'type' => 'select',
					'desc' => __( 'Choose a gateway to execute automatic payments; if you select "none" payments will only be registered but no payment requests will be issued to the gateway', 'yith-wcaf' ),
					'id' => 'yith_wcaf_payment_default_gateway',
					'options' => $gateway_options,
					'default' => 'none',
					'desc_tip' => true,
					'css' => 'min-width: 300px'
				),

				'payment-date' => array(
					'title' => __( 'Payment date', 'yith-wcaf' ),
					'type' => 'number',
					'desc' => __( 'Choose a day of the month for commission payments', 'yith-wcaf' ),
					'id' => 'yith_wcaf_payment_date',
					'css' => 'max-width: 50px;',
					'default' => 15,
					'custom_attributes' => array(
						'min' => 1,
						'max' => 28,
						'step' => 1
					),
					'desc_tip' => true
				),

				'payment-threshold' => array(
					'title' => __( 'Payment threshold', 'yith-wcaf' ),
					'type' => 'number',
					'desc' => __( 'Choose a minimum amount that an affiliate must earn before a payment is issued', 'yith-wcaf' ),
					'id' => 'yith_wcaf_payment_threshold',
					'css' => 'min-width: 50px;',
					'custom_attributes' => array(
						'min' => 0,
						'max' => 500,
						'step' => 'any'
					),
					'default' => '50',
					'desc_tip' => true
				),

				'payment-pending-notify-admin' => array(
					'title' => __( 'Notify admin', 'yith-wcaf' ),
					'type' => 'checkbox',
					'desc' => sprintf( '%s <a href="%s">%s</a>', __( 'Notify admin when a new payment is issued; customize email on', 'yith-wcaf' ), esc_url( add_query_arg( array( 'page' => 'wc-settings', 'tab' => 'email', 'section' => 'yith_wcaf_admin_paid_commission_email' ), admin_url( 'admin.php' ) ) ), __( 'WooCommerce Settings Page', 'yith-wcaf' ) ),
					'id' => 'yith_wcaf_payment_pending_notify_admin',
					'default' => 'yes'
				),

				'payment-options-end' => array(
					'type'  => 'sectionend',
					'id'    => 'yith_wcaf_payment_options'
				),
			);

			$settings['settings'] = array_merge(
				$settings_options_chunk_1,
				$payment_settings,
				apply_filters( 'yith_wcaf_gateway_options', array() ),
				$settings_options_chunk_2
			);

			return $settings;
		}

		/* === HELPER METHODS === */

		/**
		 * Register payments for a bunch of commissions; will create different mass pay foreach affiliate referred by commissions
		 *
		 * @param $commissions_id       array|int Array of commissions to pay IDs, or single commission id
		 * @param $proceed_with_payment bool Whether to call gateways to pay, or just register payments
		 *
		 * @return mixed Array with payment status, when \$proceed_with_payment is enabled; false otherwise
		 */
		public function register_payment( $commissions_id, $proceed_with_payment = true, $gateway = false ) {
			// if no commission passed, return
			if ( empty( $commissions_id ) ) {
				return array(
					'status'   => false,
					'messages' => __( 'You have to select at least one commission', 'yith-wcaf' )
				);
			}

			// if single commission id provided, convert it to array
			if ( ! is_array( $commissions_id ) ) {
				$commissions_id = (array) $commissions_id;
			}

			$payments = array();
			$to_pay   = array();

			foreach ( $commissions_id as $id ) {
				$commission = YITH_WCAF_Commission_Handler()->get_commission( $id );

				// if can't find commission, continue
				if ( ! $commission ) {
					continue;
				}

				$affiliate_id = $commission['affiliate_id'];
				$affiliate    = YITH_WCAF_Affiliate_Handler()->get_affiliate_by_id( $affiliate_id, true );

				// if can't find affiliate, continue
				if ( ! $affiliate ) {
					continue;
				}

				$payment_email = $affiliate['payment_email'];

				// if there is no payment registered for the affiliate, set one
				if ( ! isset( $payments[ $affiliate_id ] ) ) {
					$payments[ $affiliate_id ]                  = array();
					$payments[ $affiliate_id ]['affiliate_id']  = $affiliate_id;
					$payments[ $affiliate_id ]['payment_email'] = $payment_email;
					$payments[ $affiliate_id ]['gateway']       = $gateway ? $gateway : '';
					$payments[ $affiliate_id ]['amount']        = 0;
					$payments[ $affiliate_id ]['commissions']   = array();
				}

				$payments[ $affiliate_id ]['commissions'][] = $commission;
				$payments[ $affiliate_id ]['amount'] += doubleval( $commission['amount'] );
			}

			// register payments
			if ( ! empty( $payments ) ) {
				foreach ( $payments as $payment ) {
					$commissions  = $payment['commissions'];
					$payment_args = $payment;
					unset( $payment_args['commissions'] );

					$payment_id = $this->add( $payment_args, $commissions );

					$proceed_with_payment = apply_filters( 'yith_wcaf_proceed_with_payment', $proceed_with_payment, $payment_id, $payment );

					if ( $payment_id && $proceed_with_payment ) {
						$to_pay[] = $payment_id;
					}
				}
			}

			// proceed with payments
			if ( ! empty( $to_pay ) ) {
				return $this->pay( $gateway, $to_pay );
			}

			return array(
				'status'   => true,
				'messages' => __( 'Payment correctly registered', 'yith-wcaf' )
			);
		}

		/**
		 * Register payment for all pending commission of an affiliate; will create different mass pay foreach affiliate referred by commissions
		 *
		 * @param $affiliate_id         int Affiliate id
		 * @param $proceed_with_payment bool Whether to call gateways to pay, or just register payments
		 *
		 * @return mixed Array with payment status, when \$proceed_with_payment is enabled; false otherwise
		 */
		public function pay_all_affiliate_commissions( $affiliate_id, $proceed_with_payment = true, $gateway = false ) {
			$commissions = YITH_WCAF_Commission_Handler()->get_commissions( array(
				'affiliate_id' => $affiliate_id,
				'status'       => 'pending'
			) );

			if ( empty( $commissions ) ) {
				return;
			}

			$commissions_ids = array();

			foreach ( $commissions as $commission ) {
				$commissions_ids[] = $commission['ID'];

				YITH_WCAF_Commission_Handler()->change_commission_status( $commission['ID'], 'pending-payment' );
			}

			$this->register_payment( $commissions_ids, $proceed_with_payment, $gateway );
		}

		/* === GATEWAYS HANDLING METHODS === */

		/**
		 * Init available gateways
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function init_available_gateways() {
			$this->_available_gateways = apply_filters(
				'yith_wcaf_available_gateways',
				array_merge(
					$this->_available_gateways,
					array(
						'paypal' => array(
							'path'     => YITH_WCAF_INC . 'gateways/class.yith-wcaf-paypal-gateway.php',
							'label'    => __( 'PayPal', 'yith-wcaf' ),
							'class'    => 'YITH_WCAF_Paypal_Gateway',
							'mass_pay' => true
						)
					)
				)
			);

			// include gateways files
			if ( ! empty( $this->_available_gateways ) ) {
				foreach ( $this->_available_gateways as $gateway_id => $gateway_info ) {
					require_once( apply_filters( 'yith_wcaf_gateway_inclusion_path', $gateway_info['path'] ) );

					if ( function_exists( $gateway_info['class'] ) ) {
						$gateway_class = $gateway_info['class'];
						$gateway_class();
					}
				}
			}
		}

		/**
		 * Pay a payment instance previously created
		 *
		 * @param $gateway           string A valid gateway slug
		 * @param $payment_instances int|array Payment id(s)
		 *
		 * @return bool|mixed Payment status; false on failure
		 */
		public function pay( $gateway, $payment_instances ) {
			// if not a registered gateway, return false
			if ( ! in_array( $gateway, array_keys( $this->_available_gateways ) ) ) {
				return array(
					'status'   => false,
					'messages' => __( 'No gateway found with the specified ID', 'yith-wcaf' )
				);
			}

			$gateway_class = $this->_available_gateways[ $gateway ]['class'];

			// if does not exist a singleton instance of the gateway, return false
			if ( ! function_exists( $gateway_class ) ) {
				return array(
					'status'   => false,
					'messages' => __( 'Gateway class doesn\'t match required structure; missing singleton access function', 'yith-wcaf' )
				);
			}

			// if does not exists method pay on gateway object, return false
			if ( ! method_exists( $gateway_class(), 'pay' ) ) {
				return array(
					'status'   => false,
					'messages' => __( 'Gateway class doesn\'t match required structure; missing pay() method', 'yith-wcaf' )
				);
			}

			// return payment status
			$res = $gateway_class()->pay( $payment_instances );

			if ( $res['status'] ) {
				do_action( 'yith_wcaf_payments_sent', (array) $payment_instances );
			}

			return $res;
		}

		/**
		 * Handle IPN notification (gateway should call specific action to trigger this method)
		 *
		 * @param $payment_detail mixed Payment details received by Gateway
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function handle_notification( $payment_detail ) {
			$request_id = $payment_detail['unique_id'];

			$payment = $this->get_payment( $request_id );

			if ( ! $payment ) {
				return;
			}

			$status = $payment['status'];

			if ( $status != 'pending' ) {
				return;
			}

			if ( $payment_detail['status'] == 'Completed' ) {
				$new_status = 'completed';
			} elseif ( in_array( $payment_detail['status'], array( 'Failed', 'Returned', 'Reversed', 'Blocked' ) ) ) {
				$new_status = 'cancelled';
			} else {
				$new_status = 'pending';
			}

			if ( $new_status != 'pending' ) {
				$this->change_payment_status( $request_id, $new_status );

				if ( $new_status == 'completed' ) {
					$this->update( $request_id, array_merge(
						array(
							'transaction_key' => $payment_detail['txn_id']
						),
						( $new_status != 'completed' ) ? array() : array(
							'completed_at' => current_time( 'mysql' )
						)
					) );
				}
			}
		}

		/**
		 * Returns a list of available gateways
		 *
		 * @return mixed List of available gateways
		 * @since 1.0.0
		 */
		public function get_available_gateways() {
			return $this->_available_gateways;
		}

		/**
		 * Returns readable version of gateway name
		 *
		 * @param $gateway string Gateway unique ID
		 *
		 * @return string Human friendly version of gateway name
		 * @since 1.0.0
		 */
		public function get_readable_gateway( $gateway ) {
			$label = '';
			if ( isset( $this->_available_gateways[ $gateway ] ) ) {
				$label = $this->_available_gateways[ $gateway ]['label'];
			}

			return apply_filters( "yith_wcaf_{$gateway}_payment_gateway_name", $label );
		}

		/* === SCHEDULED ACTIONS METHODS === */

		/**
		 * Setup scheduled events for affiliates payments
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function pay_affiliates_setup_schedule() {
			if ( empty( $this->_payment_date ) ) {
				return;
			}

			if ( ! wp_next_scheduled( 'pay_affiliates_action_schedule' ) ) {
				$day         = $this->_payment_date;
				$current_day = date( 'j' );

				if ( $day <= $current_day ) {
					$month = date( 'F', strtotime( '+1 month' ) );
				} else {
					$month = date( 'F' );
				}

				$timestamp = strtotime( $day . ' ' . $month );

				wp_schedule_single_event( $timestamp, 'pay_affiliates_action_schedule' );
			}
		}

		/**
		 * Execute necessary operations for affiliate payment, during scheduled action
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function pay_affiliates_do_schedule() {
			$this->pay_on_date_reached();
		}

		/**
		 * Delete schedule when date option is changed
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function pay_affiliates_delete_schedule() {
			wp_clear_scheduled_hook( 'pay_affiliates_action_schedule' );
		}

		/**
		 * When a commission switch to pending, check if threshold reached, and eventually pay affiliate commissions
		 *
		 * @param $commission_id int Commission id of the last commission
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function pay_on_threshold_reached( $commission_id ) {
			if ( $this->_payment_type != 'automatically_on_threshold' || empty( $this->_payment_threshold ) || empty( $this->_payment_default_gateway ) ) {
				return;
			}

			$pay     = $this->_payment_default_gateway != 'none';
			$gateway = $this->_payment_default_gateway != 'none' ? $this->_payment_default_gateway : false;

			$commission = YITH_WCAF_Commission_Handler()->get_commission( $commission_id );

			if ( ! $commission ) {
				return;
			}

			$affiliate = YITH_WCAF_Affiliate_Handler()->get_affiliate_by_id( $commission['affiliate_id'] );

			if ( ! $affiliate ) {
				return;
			}

			if ( $affiliate['balance'] > $this->_payment_threshold ) {
				$this->pay_all_affiliate_commissions( $affiliate['ID'], $pay, $gateway );
			}
		}

		/**
		 * Pay all pending commission for all affiliates (should be executed once a month; if also threshold is enabled, check it before pay affilaite)
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function pay_on_date_reached() {
			if ( ( $this->_payment_type != 'automatically_on_date' && $this->_payment_type != 'automatically_on_both' ) || empty( $this->_payment_date ) || empty( $this->_payment_default_gateway ) ) {
				return;
			}

			$pay     = $this->_payment_default_gateway != 'none';
			$gateway = $this->_payment_default_gateway != 'none' ? $this->_payment_default_gateway : false;

			$affiliates = YITH_WCAF_Affiliate_Handler()->get_affiliates();

			if ( ! $affiliates ) {
				return;
			}

			foreach ( $affiliates as $affiliate ) {
				if ( $this->_payment_type == 'automatically_on_both' && ( empty( $this->_payment_threshold ) || $affiliate['earnings'] <= $this->_payment_threshold ) ) {
					continue;
				}

				$this->pay_all_affiliate_commissions( $affiliate['ID'], $pay, $gateway );
			}
		}

		/* === PANEL PAYMENTS METHODS === */

		/**
		 * Print payment panel
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function print_payment_panel() {
			// define variables to use in template
			$payment_id = isset( $_REQUEST['payment_id'] ) ? $_REQUEST['payment_id'] : false;

			if ( ! empty( $payment_id ) && $payment = $this->get_payment( $payment_id ) ) {
				// update payment email, if required
				if ( isset( $_POST['_payment_email'] ) && is_email( $_POST['_payment_email'] ) ) {
					$payment_email = trim( $_POST['_payment_email'] );

					$this->update( $payment_id, array( 'payment_email' => $payment_email ) );
					$payment['payment_email'] = $payment_email;
				}

				// retrieve affiliate user
				$user_info = get_userdata( $payment['user_id'] );
				$user      = get_user_by( 'id', $payment['user_id'] );

				$user_name = '';
				if ( $user_info->first_name || $user_info->last_name ) {
					$user_name .= esc_html( ucfirst( $user_info->first_name ) . ' ' . ucfirst( $user_info->last_name ) );
				} else {
					$user_name .= esc_html( ucfirst( $user_info->display_name ) );
				}

				$user_email = $user_info->user_email;

				// retrieve gateway specifications and commissions
				$payment_label     = $this->get_readable_gateway( $payment['gateway'] );
				$payment_trans_key = isset( $payment['transaction_key'] ) ? $payment['transaction_key'] : __( 'N/A', 'yith-wcaf' );
				$commissions       = $this->get_payment_commissions( $payment_id );

				// retrieve notes
				$payment_notes = $this->get_commission_notes( $payment_id );

				// retrieve available payment actions
				$available_payment_actions = array();
				$gateways = $this->get_available_gateways();

				if( $payment['status'] == 'on-hold' && ! empty( $gateways ) ) {
					foreach( $gateways as $id => $gateway ){
						$available_payment_actions[ 'pay_via_' . $id ] =  sprintf( __( 'Pay via %s', 'yith-wcaf' ), $gateway['label'] );
					}
				}

				// require rate panel template
				include( YITH_WCAF_DIR . 'templates/admin/payment-panel-detail.php' );
			} else {
				// prepare user rates table items
				$payments_table = new YITH_WCAF_Payments_Table_Premium();
				$payments_table->prepare_items();

				// require rate panel template
				include( YITH_WCAF_DIR . 'templates/admin/payment-panel-table.php' );
			}
		}

		/**
		 * Process bulk action for current view
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function process_bulk_actions() {
			if ( ! empty( $_REQUEST['payments'] ) ) {
				$current_action = isset( $_REQUEST['action'] ) ? $_REQUEST['action'] : '';
				$current_action = ( empty( $current_action ) && isset( $_REQUEST['action2'] ) ) ? $_REQUEST['action2'] : $current_action;
				$redirect       = esc_url_raw( add_query_arg( array(
					'page' => 'yith_wcaf_panel',
					'tab'  => 'payments'
				), admin_url( 'admin.php' ) ) );

				switch( $current_action ){
					case 'switch-to-completed':
						foreach( $_REQUEST['payments'] as $payment_id ){
							$res = $this->change_payment_status( $payment_id, 'completed' );
							$redirect = esc_url_raw( add_query_arg( 'commission_status_change', $res, $redirect ) );
						}
						break;
					case 'switch-to-on-hold':
						foreach( $_REQUEST['payments'] as $payment_id ){
							$res = $this->change_payment_status( $payment_id, 'on-hold' );
							$redirect = esc_url_raw( add_query_arg( 'commission_status_change', $res, $redirect ) );
						}
						break;
					default:
						// handles payment actions
						$matches = array();

						if ( preg_match( '^pay_via_([a-zA-Z_-]*)$^', $current_action, $matches ) ) {
							// group payments by gateway
							$to_pay  = array();
							$gateway = $matches[1];

							if ( in_array( $gateway, array_keys( $this->_available_gateways ) ) ) {
								foreach ( $_REQUEST['payments'] as $payment_id ) {
									$payment = $this->get_payment( $payment_id );

									if ( ! $payment || $payment['status'] != 'on-hold' ) {
										continue;
									}

									if ( ! isset( $to_pay[ $gateway ] ) ) {
										$to_pay[ $gateway ] = array();
									}

									$to_pay[ $gateway ][] = $payment_id;
								}
							}

							if ( ! empty( $to_pay ) ) {
								foreach ( $to_pay as $gateway => $payment_instances ) {
									$payments = implode( '_', $payment_instances );
									$res      = $this->pay( $gateway, $payment_instances );

									if ( ! $res['status'] ) {
										$errors   = is_array( $res['messages'] ) ? implode( ',', $res['messages'] ) : $res['messages'];
										$redirect = add_query_arg( array(
											'payment_failed'            => true,
											"payment_error_{$payments}" => urlencode( $errors )
										), $redirect );
									} else {
										$redirect = add_query_arg( array(
											'payment_success'             => true,
											"payment_success_{$payments}" => true
										), $redirect );
									}
								}
							}
						}
						break;
				}

				if( isset( $_GET['payment_id'] ) ){
					$redirect = add_query_arg( 'payment_id', intval( $_GET['payment_id'] ), $redirect );
				}

				wp_redirect( esc_url_raw( $redirect ) );
				die();
			}
		}

		/**
		 * Process action to complete payments on payment panel
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function handle_payments_panel_actions() {
			$payment_id = isset( $_REQUEST['payment_id'] ) ? $_REQUEST['payment_id'] : 0;
			$gateway_id = isset( $_REQUEST['gateway'] ) ? $_REQUEST['gateway'] : '';
			$redirect   = esc_url_raw( add_query_arg( array(
				'page' => 'yith_wcaf_panel',
				'tab'  => 'payments'
			), admin_url( 'admin.php' ) ) );

			if ( ! $payment_id || ! $gateway_id || ! in_array( $gateway_id, array_keys( $this->_available_gateways ) ) ) {
				wp_redirect( $redirect );
				die();
			}

			$payment = $this->get_payment( $payment_id );

			if ( ! $payment ) {
				wp_redirect( $redirect );
				die();
			}

			$res = $this->pay( $gateway_id, $payment_id );

			if ( ! $res['status'] ) {
				$errors   = is_array( $res['messages'] ) ? implode( ',', $res['messages'] ) : $res['messages'];
				$redirect = esc_url_raw( add_query_arg( array(
					'payment_failed'              => true,
					"payment_error_{$payment_id}" => urlencode( $errors )
				), $redirect ) );
			} else {
				$redirect = esc_url_raw( add_query_arg( array(
					'payment_success'               => true,
					"payment_success_{$payment_id}" => true
				), $redirect ) );
			}

			wp_redirect( $redirect );
			die();
		}

		/**
		 * Returns single instance of the class
		 *
		 * @return \YITH_WCAF_Payment_Handler_Premium
		 * @since 1.0.0
		 */
		public static function get_instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self;
			}

			return self::$instance;
		}
	}
}

/**
 * Unique access to instance of YITH_WCAF_Payment_Handler_Premium class
 *
 * @return \YITH_WCAF_Payment_Handler_Premium
 * @since 1.0.0
 */
function YITH_WCAF_Payment_Handler_Premium() {
	return YITH_WCAF_Payment_Handler_Premium::get_instance();
}