<?php
/**
 * This file belongs to the YIT Plugin Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( !defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

/**
 * Main class
 *
 * @class   YITH_WC_Anti_Fraud_Premium
 * @package Yithemes
 * @since   1.0.0
 * @author  Your Inspiration Themes
 */

if ( !class_exists( 'YITH_WC_Anti_Fraud_Premium' ) ) {

    class YITH_WC_Anti_Fraud_Premium extends YITH_WC_Anti_Fraud {

        /**
         * @var array
         */
        protected $_email_types = array();

        /**
         * Returns single instance of the class
         *
         * @return \YITH_WC_Anti_Fraud_Premium
         * @since 1.0.0
         */
        public static function get_instance() {

            if ( is_null( self::$instance ) ) {

                self::$instance = new self;

            }

            return self::$instance;

        }

        /**
         * Constructor
         *
         * @since   1.0.0
         * @return  mixed
         * @author  Alberto Ruggiero
         */
        public function __construct() {

            parent::__construct();

            // register plugin to licence/update system
            add_action( 'wp_loaded', array( $this, 'register_plugin_for_activation' ), 99 );
            add_action( 'admin_init', array( $this, 'register_plugin_for_updates' ) );

            if ( get_option( 'ywaf_enable_plugin' ) == 'yes' ) {

                $this->includes_premium();

                $this->rules = $this->get_ywaf_rules_premium( $this->rules );

                $this->_email_types = array(
                    'paypal_check' => array(
                        'class' => 'YWAF_PayPal_Verify',
                        'file'  => 'class-ywaf-paypal-email-premium.php',
                        'hide'  => true,
                    ),
                );

                add_action( 'init', array( $this, 'register_ywaf_post_status_premium' ) );
                add_action( 'ywaf_add_to_blacklist', array( $this, 'ywaf_add_to_blacklist' ), 10, 3 );
                add_action( 'ywaf_paypal_cron', array( $this, 'ywaf_paypal_cron' ) );

                add_filter( 'wc_order_statuses', array( $this, 'add_ywaf_order_status_premium' ) );
                add_filter( 'ywaf_after_check_status', array( $this, 'ywaf_set_order_status' ), 10, 3 );
                add_filter( 'ywaf_paypal_check', array( $this, 'ywaf_check_paypal' ), 10, 2 );
                add_filter( 'ywaf_check_blacklist', array( $this, 'ywaf_check_blacklist' ), 10, 2 );
                add_filter( 'yith_wcet_email_template_types', array( $this, 'add_yith_wcet_template' ) );

                if ( is_admin() ) {

                    add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts_admin_premium' ) );
                    add_filter( 'woocommerce_admin_order_actions', array( $this, 'ywaf_table_action' ), 10, 2 );
                    add_filter( 'ywaf_paypal_status', array( $this, 'ywaf_paypal_status' ), 10, 1 );
                    add_filter( 'woocommerce_email_classes', array( $this, 'ywaf_paypal_mail' ) );
                    add_filter( 'woocommerce_get_sections_email', array( $this, 'ywaf_paypal_mail_hide' ) );

                }
                else {

                    add_action( 'woocommerce_before_my_account', array( $this, 'ywaf_verify_paypal_code' ) );
                    add_action( 'woocommerce_before_customer_login_form', array( $this, 'ywaf_verify_paypal_code' ) );
                    add_action( 'woocommerce_view_order', array( $this, 'ywaf_view_order' ), 5, 1 );
                    add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts_frontend' ) );

                }

            }

        }

        /**
         * Files inclusion
         *
         * @since   1.0.0
         * @return  void
         * @author  Alberto Ruggiero
         */
        private function includes_premium() {

            include_once( 'includes/rules/class-ywaf-proxy-premium.php' );
            include_once( 'includes/rules/class-ywaf-suspicious-email-premium.php' );
            include_once( 'includes/rules/class-ywaf-risk-country-premium.php' );
            include_once( 'includes/rules/class-ywaf-high-amount-premium.php' );
            include_once( 'includes/rules/class-ywaf-many-attempts-premium.php' );
            include_once( 'includes/rules/class-ywaf-ip-multiple-details-premium.php' );
            include_once( 'includes/rules/class-ywaf-blacklist-premium.php' );
            include_once( 'includes/rules/class-ywaf-paypal-premium.php' );
            include_once( 'includes/class-ywaf-ajax-premium.php' );

            if ( is_admin() ) {

                include_once( 'templates/admin/class-yith-wc-custom-textarea.php' );
                include_once( 'templates/admin/class-yith-wc-custom-checklist.php' );
                include_once( 'templates/admin/class-yith-wc-custom-country-select.php' );
                include_once( 'includes/class-ywaf-metabox-premium.php' );

            }

        }

        /**
         * Get premium Anti-Fraud rules
         *
         * @since   1.0.0
         *
         * @param   $rules
         *
         * @return  array
         * @author  Alberto Ruggiero
         */
        public function get_ywaf_rules_premium( $rules ) {

            $premium_rules = array(
                'YWAF_Proxy'               => array(
                    'rule'   => new YWAF_Proxy(),
                    'active' => get_option( 'ywaf_rules_proxy_enable' ),
                ),
                'YWAF_Suspicious_Email'    => array(
                    'rule'   => new YWAF_Suspicious_Email(),
                    'active' => get_option( 'ywaf_rules_suspicious_email_enable' ),
                ),
                'YWAF_Risk_Country'        => array(
                    'rule'   => new YWAF_Risk_Country(),
                    'active' => get_option( 'ywaf_rules_risk_country_enable' ),
                ),
                'YWAF_High_Amount'         => array(
                    'rule'   => new YWAF_High_Amount(),
                    'active' => get_option( 'ywaf_rules_high_amount_enable' ),
                ),
                'YWAF_Many_Attempts'       => array(
                    'rule'   => new YWAF_Many_Attempts(),
                    'active' => get_option( 'ywaf_rules_many_attempts_enable' ),
                ),
                'YWAF_IP_Multiple_Details' => array(
                    'rule'   => new YWAF_IP_Multiple_Details(),
                    'active' => get_option( 'ywaf_rules_ip_multiple_details_enable' ),
                ),
            );

            return array_merge( $rules, $premium_rules );

        }

        /**
         * Register the post status
         *
         * @since   1.0.0
         * @return  void
         * @author  Alberto Ruggiero
         */
        public function register_ywaf_post_status_premium() {

            register_post_status( 'wc-ywaf-failed', array(
                'label'                     => __( 'Fraud risk check not passed', 'yith-woocommerce-anti-fraud' ),
                'public'                    => true,
                'exclude_from_search'       => false,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                'label_count'               => _n_noop( 'Fraud risk check not passed <span class="count">(%s)</span>', 'Fraud risk check not passed <span class="count">(%s)</span>', 'yith-woocommerce-anti-fraud' )
            ) );

            register_post_status( 'wc-ywaf-paypal-wait', array(
                'label'                     => __( 'Waiting for PayPal verification', 'yith-woocommerce-anti-fraud' ),
                'public'                    => true,
                'exclude_from_search'       => false,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                'label_count'               => _n_noop( 'Waiting for PayPal verification <span class="count">(%s)</span>', 'Waiting for PayPal verification <span class="count">(%s)</span>', 'yith-woocommerce-anti-fraud' )
            ) );

            register_post_status( 'wc-ywaf-paypal-fail', array(
                'label'                     => __( 'PayPal verification failed', 'yith-woocommerce-anti-fraud' ),
                'public'                    => true,
                'exclude_from_search'       => false,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                'label_count'               => _n_noop( 'PayPal verification failed <span class="count">(%s)</span>', 'PayPal verification failed <span class="count">(%s)</span>', 'yith-woocommerce-anti-fraud' )
            ) );

        }

        /**
         * Add custom order status
         *
         * @since   1.0.0
         *
         * @param   $order_statuses
         *
         * @return  array
         * @author  Alberto Ruggiero
         *
         */
        public function add_ywaf_order_status_premium( $order_statuses ) {

            $order_statuses['wc-ywaf-failed']      = __( 'Fraud risk check not passed', 'yith-woocommerce-anti-fraud' );
            $order_statuses['wc-ywaf-paypal-wait'] = __( 'Waiting for PayPal verification', 'yith-woocommerce-anti-fraud' );
            $order_statuses['wc-ywaf-paypal-fail'] = __( 'PayPal verification failed', 'yith-woocommerce-anti-fraud' );

            return $order_statuses;

        }

        /**
         * Set custom order status
         *
         * @since   1.0.0
         *
         * @param   $order_status
         * @param   $risk_score
         * @param   $order_id
         *
         * @return  array
         * @author  Alberto Ruggiero
         *
         */
        public function ywaf_set_order_status( $order_status, $risk_score, $order_id ) {

            switch ( true ) {

                case  $risk_score >= $this->risk_thresholds['high']:

                    $order_status['status'] = 'wc-ywaf-failed';
                    $order_status['note']   = __( 'Fraud risk check not passed. Fraud risk is high!', 'yith-woocommerce-anti-fraud' );
                    break;

                case $risk_score >= $this->risk_thresholds['medium'] && $risk_score < $this->risk_thresholds['high']:

                    $order_status['status'] = 'wc-on-hold';
                    $order_status['note']   = __( 'Fraud risk check passed with medium fraud risk.', 'yith-woocommerce-anti-fraud' );

                    break;

                default:

                    $order_status['status'] = get_post_meta( $order_id, 'ywaf_prev_order_status', true );
                    $order_status['note']   = __( 'Fraud risk check passed with low fraud risk', 'yith-woocommerce-anti-fraud' );

                    break;

            }

            return $order_status;

        }

        /**
         * Check if billing email is in blacklist
         *
         * @since   1.0.0
         *
         * @param   $result
         * @param   $order
         *
         * @return  bool
         * @author  Alberto Ruggiero
         */
        public function ywaf_check_blacklist( $result, WC_Order $order ) {

            if ( get_option( 'ywaf_email_blacklist_enable' ) == 'yes' ) {

                $blacklist = new YWAF_Blacklist();

                if ( $blacklist->get_fraud_risk( $order ) === true ) {


                    $result = true;

                }

            }

            return $result;

        }

        /**
         * Add billing email in blacklist
         *
         * @since   1.0.0
         *
         * @param   $blacklist
         * @param   $order
         * @param   $risk_score
         *
         * @return  bool
         * @author  Alberto Ruggiero
         */
        public function ywaf_add_to_blacklist( $blacklist, WC_Order $order, $risk_score ) {

            if ( !$blacklist && get_option( 'ywaf_email_blacklist_enable' ) == 'yes' && get_option( 'ywaf_email_blacklist_auto_add' ) == 'yes' ) {

                if ( $risk_score >= $this->risk_thresholds['high'] ) {

                    $blacklist = new YWAF_Blacklist();
                    $blacklist->add_to_blacklist( $order->billing_email );

                }

            }

        }

        /**
         * Check if paypal email is verified
         *
         * @since   1.0.0
         *
         * @param   $order
         * @param   $result
         *
         * @return  bool
         * @author  Alberto Ruggiero
         */
        public function ywaf_check_paypal( $result, WC_Order $order ) {

            if ( ( get_option( 'ywaf_paypal_enable' ) == 'yes' ) && ( get_post_meta( $order->id, '_payment_method', true ) == 'paypal' ) ) {

                $paypal = new YWAF_PayPal();

                if ( $paypal->get_fraud_risk( $order ) === true ) {

                    $result = false;

                }

            }

            return $result;

        }

        /**
         * Custom status for PayPal verification pending
         *
         * @since   1.0.0
         *
         * @param   $value
         *
         * @return  string
         * @author  Alberto Ruggiero
         */
        public function ywaf_paypal_status( $value ) {

            global $post;

            if ( $post->post_status == 'wc-ywaf-paypal-wait' ) {

                $tip   = __( 'Waiting for PayPal verification.', 'yith-woocommerce-anti-fraud' );
                $value = sprintf( '<mark class="paypal tips" data-tip="%s">%s</mark>', $tip, $tip );

            }

            if ( $post->post_status == 'wc-ywaf-paypal-fail' ) {

                $tip   = __( 'PayPal verification failed.', 'yith-woocommerce-anti-fraud' );
                $value = sprintf( '<mark class="paypal-failed tips" data-tip="%s">%s</mark>', $tip, $tip );

            }

            return $value;

        }

        /**
         * Add the YWAF_PayPal_Verify class to WooCommerce mail classes
         *
         * @since   1.0.0
         *
         * @param   $email_classes
         *
         * @return  array
         * @author  Alberto Ruggiero
         */
        public function ywaf_paypal_mail( $email_classes ) {

            foreach ( $this->_email_types as $type => $email_type ) {
                $email_classes[$email_type['class']] = include( "includes/{$email_type['file']}" );
            }

            return $email_classes;
        }

        /**
         * Hides custom email settings from WooCommerce panel
         *
         * @since   1.0.0
         *
         * @param   $sections
         *
         * @return  array
         * @author  Alberto ruggiero
         */
        public function ywaf_paypal_mail_hide( $sections ) {
            foreach ( $this->_email_types as $type => $email_type ) {
                $class_name = strtolower( $email_type['class'] );
                if ( isset( $sections[$class_name] ) && $email_type['hide'] == true ) {
                    unset( $sections[$class_name] );
                }
            }

            return $sections;
        }

        /**
         * Send PayPal verification email
         *
         * @since   1.0.0
         *
         * @param   $order
         *
         * @return  void
         * @author  Alberto Ruggiero
         */
        public function ywaf_paypal_mail_send( WC_Order $order ) {

            $paypal_email = get_post_meta( $order->id, 'Payer PayPal address', true );
            $wc_email     = WC_Emails::instance();
            $email        = $wc_email->emails['YWAF_PayPal_Verify'];

            $email->trigger( $order, $paypal_email );

        }

        /**
         * Daily check of orders waiting paypal verification
         *
         * @since   1.0.0
         * @return  void
         * @author  Alberto Ruggiero
         */
        public function ywaf_paypal_cron() {

            $args = array(
                'post_type'      => 'shop_order',
                'post_status'    => array( 'wc-ywaf-paypal-wait' ),
                'posts_per_page' => - 1,

            );

            add_filter( 'posts_where', array( $this, 'ywaf_paypal_waiting_where' ) );
            $resend_query = new WP_Query( $args );
            remove_filter( 'posts_where', array( $this, 'ywaf_paypal_waiting_where' ) );

            if ( $resend_query->have_posts() ) {

                while ( $resend_query->have_posts() ) {

                    $resend_query->the_post();

                    $order = wc_get_order( $resend_query->post->ID );

                    $this->ywaf_paypal_mail_send( $order );

                }
            }

            wp_reset_query();
            wp_reset_postdata();

            add_filter( 'posts_where', array( $this, 'ywaf_paypal_cancel_where' ) );
            $cancel_query = new WP_Query( $args );
            remove_filter( 'posts_where', array( $this, 'ywaf_paypal_cancel_where' ) );

            if ( $cancel_query->have_posts() ) {

                while ( $cancel_query->have_posts() ) {

                    $cancel_query->the_post();

                    $order = wc_get_order( $cancel_query->post->ID );
                    $order->update_status( 'wc-ywaf-paypal-fail', 'PayPal verification failed. The email address is not verified.' );

                    update_post_meta( $order->id, 'ywaf_risk_factor', array(
                        'score'        => 100,
                        'failed_rules' => array( 'YWAF_PayPal' )
                    ) );

                    delete_post_meta( $order->id, 'ywaf_prev_order_status' );

                    $this->ywaf_add_to_blacklist( false, $order, 100 );

                }

            }

            wp_reset_query();
            wp_reset_postdata();


        }

        /**
         * Set custom where condition
         *
         * @since   1.0.0
         *
         * @param   $where
         *
         * @return  string
         * @author  Alberto Ruggiero
         */
        public function ywaf_paypal_waiting_where( $where = '' ) {

            $resend_days = get_option( 'ywaf_paypal_resend_days' );
            $cancel_days = get_option( 'ywaf_paypal_cancel_days' );

            $where .= " AND post_date > '" . date( 'Y-m-d', strtotime( '-' . $cancel_days . ' days' ) ) . "'" . " AND post_date <= '" . date( 'Y-m-d', strtotime( '-' . $resend_days . ' days' ) ) . "'";

            return $where;

        }

        /**
         * Set custom where condition
         *
         * @since   1.0.0
         *
         * @param   $where
         *
         * @return  string
         * @author  Alberto Ruggiero
         */
        public function ywaf_paypal_cancel_where( $where = '' ) {

            $cancel_days = get_option( 'ywaf_paypal_cancel_days' );

            $where .= " AND post_date <= '" . date( 'Y-m-d', strtotime( '-' . $cancel_days . ' days' ) ) . "'";

            return $where;

        }

        /**
         * If is active YITH WooCommerce Email Templates, add YWAF to list
         *
         * @since   1.0.0
         *
         * @param   $templates
         *
         * @return  array
         * @author  Alberto Ruggiero
         */
        public function add_yith_wcet_template( $templates ) {

            $templates[] = array(
                'id'   => 'yith-anti-fraud',
                'name' => 'YITH WooCommerce Anti-Fraud',
            );

            return $templates;

        }

        /**
         * ADMIN FUNCTIONS
         */

        /**
         * Enqueue script file
         *
         * @since   1.0.0
         * @return  void
         * @author  Alberto Ruggiero
         */
        public function enqueue_scripts_admin_premium() {

            $suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

            wp_enqueue_script( 'ywaf-admin-knob', YWAF_ASSETS_URL . '/js/jquery.knob' . $suffix . '.js', array( 'jquery' ) );
            wp_enqueue_script( 'ywaf-admin-premium', YWAF_ASSETS_URL . '/js/ywaf-admin-premium' . $suffix . '.js', array( 'jquery', 'ywaf-admin-knob' ) );

            wp_enqueue_style( 'ywaf-admin-premium', YWAF_ASSETS_URL . '/css/ywaf-admin-premium.css' );

        }

        /**
         * Add fraud check button to order table
         *
         * @since   1.0.0
         *
         * @param   $actions
         * @param   $the_order
         *
         * @return  array
         * @author  Alberto Ruggiero
         */
        public function ywaf_table_action( $actions, $the_order ) {

            if ( $the_order->post->post_status != 'wc-ywaf-paypal-wait' && $the_order->post->post_status != 'wc-ywaf-paypal-fail' && $the_order->post->post_status != 'wc-cancelled' && $the_order->post->post_status != 'wc-ywaf-failed' ) {

                $risk_factor  = get_post_meta( $the_order->id, 'ywaf_risk_factor', true );
                $button_label = ( $risk_factor ) ? __( 'Repeat fraud risk check', 'yith-woocommerce-anti-fraud' ) : __( 'Start fraud risk check', 'yith-woocommerce-anti-fraud' );
                $query_args   = array(
                    'action'   => 'ywaf_fraud_risk_check',
                    'order_id' => $the_order->id,
                    '_wpnonce' => wp_create_nonce( 'ywaf-check-fraud-risk' ),
                    'repeat'   => ( $risk_factor ) ? 'true' : 'false'
                );
                $ajax_url     = add_query_arg( $query_args, str_replace( array( 'https:', 'http:' ), '', admin_url( 'admin-ajax.php' ) ) );

                $actions['ywaf-check'] = array(
                    'url'    => $ajax_url,
                    'name'   => $button_label,
                    'action' => 'ywaf-check'

                );
            }

            return $actions;

        }

        /**
         * FRONTEND FUNCTIONS
         */

        /**
         * Enqueue script file
         *
         * @since   1.0.0
         * @return  void
         * @author  Alberto Ruggiero
         */
        public function enqueue_scripts_frontend() {

            $suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

            wp_enqueue_script( 'ywaf-frontend-premium', YWAF_ASSETS_URL . '/js/ywaf-frontend-premium' . $suffix . '.js', array( 'jquery' ) );

            $query_args = array(
                'action'   => 'ywaf_resend_email',
                '_wpnonce' => wp_create_nonce( 'ywaf-resend-email' )
            );
            $ajax_url   = add_query_arg( $query_args, str_replace( array( 'https:', 'http:' ), '', admin_url( 'admin-ajax.php' ) ) );

            wp_localize_script( 'ywaf-frontend-premium', 'ywaf_ajax_url', $ajax_url );


        }

        /**
         * Verify paypal email address and proceed to anti-fraud check
         *
         * @since   1.0.0
         * @return  void
         * @author  Alberto Ruggiero
         */
        public function ywaf_verify_paypal_code() {

            if ( isset( $_GET['ywaf_pvk'] ) && get_option( 'ywaf_paypal_enable' ) == 'yes' ) {

                $params     = explode( ',', base64_decode( $_GET['ywaf_pvk'] ) );
                $order_id   = str_replace( '#', '', base64_decode( $params[0] ) );
                $email      = base64_decode( $params[1] );
                $order_date = base64_decode( $params[2] );
                $order      = wc_get_order( $order_id );

                if ( $order && $order->order_date == $order_date ) {

                    if ( $order->post->post_status == 'wc-ywaf-paypal-wait' ) {

                        $stored_email = get_post_meta( $order->id, 'Payer PayPal address', true );

                        if ( $email == $stored_email ) {

                            $paypal = new YWAF_PayPal();
                            $paypal->add_to_verified( $email );

                            $this->set_fraud_check( $order->id );

                            wc_add_notice( __( 'PayPal email address has been successfully checked!', 'yith-woocommerce-anti-fraud' ), 'success' );
                            wc_print_notices();

                        }

                    }

                }

            }

        }

        /**
         * Show info for order status
         *
         * @since   1.0.0
         *
         * @param   $order_id
         *
         * @return  void
         * @author  Alberto Ruggiero
         */
        public function ywaf_view_order( $order_id ) {

            $order = wc_get_order( $order_id );

            switch ( $order->post->post_status ) {

                case 'wc-ywaf-paypal-wait':

                    ?>

                    <h2>
                        <?php _e( 'Order Status', 'yith-woocommerce-anti-fraud' ); ?>
                    </h2>
                    <p>
                        <?php _e( 'In order to complete the order, you have to complete your verification process by clicking on the link we sent to your PayPal email address.', 'yith-woocommerce-anti-fraud' ) ?>
                    </p>
                    <p>
                        <?php _e( 'If you have not received the verification email, you can ask for a new by clicking the following button', 'yith-woocommerce-anti-fraud' ) ?>
                    </p>
                    <p>
                        <input type="hidden" id="ywcc_order_id" value="<?php echo $order->id; ?>" />
                        <button type="button" class="button button-primary ywaf-resend-email"><?php _e( 'Re-send email', 'yith-woocommerce-anti-fraud' ) ?></button>
                    </p>
                    <?php

                    break;

                case 'wc-ywaf-paypal-fail':

                    ?>

                    <h2>
                        <?php _e( 'Order Status', 'yith-woocommerce-anti-fraud' ); ?>
                    </h2>
                    <p>
                        <?php _e( 'We could not verify your PayPal email address and therefore your order has been cancelled. If you think an error has occurred, contact our customer service.', 'yith-woocommerce-anti-fraud' ) ?>
                    </p>

                    <?php

                    break;

                case 'wc-ywaf-failed':

                    ?>

                    <h2>
                        <?php _e( 'Order Status', 'yith-woocommerce-anti-fraud' ); ?>
                    </h2>
                    <p>
                        <?php _e( 'The order has not passed anti-fraud tests, therefore it has been cancelled. If you think an error has occurred, contact our customer service.', 'yith-woocommerce-anti-fraud' ) ?>
                    </p>

                    <?php

                    break;

                default:

            }

        }

        /**
         * YITH FRAMEWORK
         */

        /**
         * Register plugins for activation tab
         *
         * @since   2.0.0
         * @return  void
         * @author  Andrea Grillo <andrea.grillo@yithemes.com>
         */
        public function register_plugin_for_activation() {
            if ( !class_exists( 'YIT_Plugin_Licence' ) ) {
                require_once 'plugin-fw/licence/lib/yit-licence.php';
                require_once 'plugin-fw/licence/lib/yit-plugin-licence.php';
            }
            YIT_Plugin_Licence()->register( YWAF_INIT, YWAF_SECRET_KEY, YWAF_SLUG );
        }

        /**
         * Register plugins for update tab
         *
         * @since   2.0.0
         * @return  void
         * @author  Andrea Grillo <andrea.grillo@yithemes.com>
         */
        public function register_plugin_for_updates() {
            if ( !class_exists( 'YIT_Upgrade' ) ) {
                require_once( 'plugin-fw/lib/yit-upgrade.php' );
            }
            YIT_Upgrade()->register( YWAF_SLUG, YWAF_INIT );
        }

    }

}

