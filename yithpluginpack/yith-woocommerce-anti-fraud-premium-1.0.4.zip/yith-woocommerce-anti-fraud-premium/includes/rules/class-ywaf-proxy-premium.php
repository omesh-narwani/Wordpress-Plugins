<?php
/**
 * This file belongs to the YIT Plugin Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( !class_exists( 'YWAF_Proxy' ) ) {

    /**
     * Proxy rules class
     *
     * @class   YWAF_Proxy
     * @package Yithemes
     * @since   1.0.0
     * @author  Your Inspiration Themes
     *
     */
    class YWAF_Proxy extends YWAF_Rules {

        /**
         * Constructor
         *
         * @since   1.0.0
         * @return  mixed
         * @author  Alberto Ruggiero
         */
        public function __construct() {

            $message = __( 'Order placed from behind a proxy.', 'yith-woocommerce-anti-fraud' );
            $points  = get_option( 'ywaf_rules_proxy_weight', 10 );

            parent::__construct( $message, $points );

        }

        /**
         * Check if order comes from behind a proxy.
         *
         * @since   1.0.0
         *
         * @param   $order
         *
         * @return  bool
         * @author  Alberto Ruggiero
         */
        public function get_fraud_risk( WC_Order $order ) {

            $fraud_risk = false;
            $ip_address = get_post_meta( $order->id, '_customer_ip_address', true );
            $dnsbls     = apply_filters( 'ywaf_proxy_dnsbls', array(
                'dnsbl-1.uceprotect.net',
                'dnsbl-2.uceprotect.net',
                'dnsbl-3.uceprotect.net',
                'dnsbl.dronebl.org',
                'dnsbl.sorbs.net',
                'bl.spamcop.net',
                'sbl.spamhaus.org',
                'xbl.spamhaus.org',
                'zen.spamhaus.org',
                'pbl.spamhaus.org'
            ) );

            $reverse_ip = implode( ".", array_reverse( explode( ".", $ip_address ) ) );

            foreach ( $dnsbls as $host ) {

                if ( checkdnsrr( $reverse_ip . "." . $host . ".", "A" ) ) {
                    $fraud_risk = true;
                }

            }

            return $fraud_risk;

        }

    }
}