﻿=== YITH WooCommerce Anti-Fraud ===

Contributors: yithemes
Tags: woocommerce, products, themes, yit, yith, yithemes, e-commerce, shop, anti-fraud, fraud risk,
Requires at least: 4.0
Tested up to: 4.4.1
Stable tag: 1.0.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= 1.0.4 =

* Added: compatibility with WooCommerce 2.5

= 1.0.3 =

* Added: filter "ywaf_proxy_dnsbls" to manage dnsbls for the rule control proxy
* Added: default woocommerce geolocation service set as backup in case of failure of IP-api.com

= 1.0.1 =

* Updated: Plugin core framework

= 1.0.0 =

* Initial release