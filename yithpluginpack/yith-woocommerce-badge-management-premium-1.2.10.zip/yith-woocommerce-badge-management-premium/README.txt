=== YITH WooCommerce Badge Management Premium ===
== Changelog ==

= 1.2.10 =

* Tweak: hidden badges in YITH WooCommerce Frequently Bought Together form
* Tweak: hidden badges in YITH WooCommerce Save for Later section

= 1.2.9 =

* Tweak: fixed minor bugs

= 1.2.8 =

* Added: possibility to set badges for price rules of YITH WooCommerce Dynamic Pricing and Discount Premium 1.0.3
* Tweak: fixed hidden badges in Single Product Page
* Tweak: fixed badge style W3C

= 1.2.7 =

* Added: support to WordPress 4.4.1
* Added: support to WooCommerce 2.5
* Tweak: hided badges in WooCommerce mini-cart
* Tweak: fixed minor bug

= 1.2.6 =

* Added: support to WooCommerce 2.5 BETA 3
* Tweak: fixed css bug with YITH WooCommerce Frequently Bought Together
* Tweak: fixed minor bug

= 1.2.5 =

* Added: support to WordPress 4.4
* Added: support to WooCommerce 2.4.12
* Added: possibility to show/hide badges in sidebars
* Added: possibility to show/hide WooCommerce default "On Sale" badge when the product has another badge.
* Added: advanced badge management for variable product (that have same discount percentage)

= 1.2.4 =

* Added: Bulk Actions to add badge to products
* Added: Badge column in product list
* Tweak: fixed option to hide badges in single product page

= 1.2.3 =

* Added: automatic Out of Stock badges
* Added: compatibility with YITH WooCommerce Multi Vendor version 1.7.4 or greater
* Tweak: fix minor bug about showing badges on products

= 1.2.2 =

* Tweak: now you can schedule badge showing in product edit page

= 1.2.1 =

* Fixed: minor bugs

= 1.2.0 =

* Added: WPML Compatibility to localize all elements of the badges

= 1.1.10 =

* Fixed: minor bugs

= 1.1.9 =

* Fixed: removed badges in cart and checkout
* Fixed: minor bugs

= 1.1.8 =

* Added: Support to WordPress 4.3
* Fixed: WPML css badge text bug

= 1.1.7 =

* Added: Support to WooCommerce 2.4.4

= 1.1.6 =

* Added: Support to WordPress 4.2.4
* Added: Support to WooCommerce 2.4.2
* Fixed: WPML deprecated functions

= 1.1.5 =

* Added: WPML Compatibility
* Added: Compatibility with more themes
* Fixed: Bug with widget sidebar on header

= 1.1.4 =

* Added: Support to WooCommerce shortcodes
* Fixed: Compatibility with more themes

= 1.1.3 =

* Fixed: badge display in widget top related product

= 1.1.2 =

* Fixed: Wrong admin css handle

= 1.1.1 =

* Added: Support to WooCommce 2.3.9
* Updated: Default language file
* Updated: Plugin framework
* Fixed: Can't make a badge issue
* Fixed: Hide on sale option not working

= 1.1.0 =

* Initial release