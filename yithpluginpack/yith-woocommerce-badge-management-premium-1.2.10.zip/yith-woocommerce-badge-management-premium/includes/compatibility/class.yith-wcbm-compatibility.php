<?php
if ( !defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

/**
 * Compatibility Class
 *
 * @class   YITH_WCBM_Compatibility
 * @package Yithemes
 * @since   1.2.8
 * @author  Yithemes
 *
 */
class YITH_WCBM_Compatibility {

    /**
     * Single instance of the class
     *
     * @var \YITH_WCBM_Compatibility
     */
    protected static $instance;

    /**
     * @type array
     */
    private $_plugins;

    /**
     * Returns single instance of the class
     *
     * @return \YITH_WCBM_Compatibility
     */
    public static function get_instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * Constructor
     *
     * @access public
     * @since  1.0.0
     */
    public function __construct() {
        $this->_plugins = array(
            'dynamic-pricing' => 'Dynamic_Pricing'
        );
        $this->_load();
    }

    private function _load() {
        foreach ( $this->_plugins as $slug => $class_slug ) {
            $filename  = YITH_WCBM_COMPATIBILITY_PATH . '/class.yith-wcbm-' . $slug . '-compatibility.php';
            $classname = 'YITH_WCBM_' . $class_slug . '_Compatibility';

            $var = str_replace( '-', '_', $slug );
            if ( $this->has_plugin( $slug ) && file_exists( $filename ) ) {
                require_once( $filename );
                if ( function_exists( $classname ) ) {
                    $this->$var = $classname();
                }
            }
        }
    }

    /**
     * Check if user has a plugin
     *
     * @param string $slug
     *
     * @author Leanza Francesco <leanzafrancesco@gmail.com>
     * @return bool
     */
    public function has_plugin( $slug ) {
        switch ( $slug ) {
            case 'dynamic-pricing':
                return defined( 'YITH_YWDPD_PREMIUM' ) && YITH_YWDPD_PREMIUM && defined( 'YITH_YWDPD_VERSION' ) && version_compare( YITH_YWDPD_VERSION, '1.0.3', '>=' );
                break;
            default:
                return false;
        }
    }
}

/**
 * Unique access to instance of YITH_WCBM_Compatibility class
 *
 * @return YITH_WCBM_Compatibility
 * @since 1.2.8
 */
function YITH_WCBM_Compatibility() {
    return YITH_WCBM_Compatibility::get_instance();
}