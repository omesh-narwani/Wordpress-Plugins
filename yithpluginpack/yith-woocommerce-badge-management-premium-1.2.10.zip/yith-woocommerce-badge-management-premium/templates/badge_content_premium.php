<?php

$position_css = "";

$pos_top    = ( is_numeric( $pos_top ) ) ? ( $pos_top . "px" ) : $pos_top;
$pos_bottom = ( is_numeric( $pos_bottom ) ) ? ( $pos_bottom . "px" ) : $pos_bottom;
$pos_left   = ( is_numeric( $pos_left ) ) ? ( $pos_left . "px" ) : $pos_left;
$pos_right  = ( is_numeric( $pos_right ) ) ? ( $pos_right . "px" ) : $pos_right;

$position_css .= "top: " . $pos_top . ";";
$position_css .= "bottom: " . $pos_bottom . ";";
$position_css .= "left: " . $pos_left . ";";
$position_css .= "right: " . $pos_right . ";";

//--wpml-------------
$text     = yith_wcbm_wpml_string_translate( 'yith-wcbm', sanitize_title( $text ), $text );
$css_text = yith_wcbm_wpml_string_translate( 'yith-wcbm', sanitize_title( $css_text ), $css_text );
//-------------------


switch ( $type ) {
    case 'text':
    case 'custom':
        ?>
        <div class='yith-wcbm-badge yith-wcbm-badge-<?php echo $id_badge ?>'>
            <?php echo $text ?>
        </div><!--yith-wcbm-badge-->
        <?php
        break;

    case 'image':
        //if the badge was created by free version
        if ( strlen( $image_url ) < 6 ) {
            $image_url = YITH_WCBM_ASSETS_URL . '/images/image-badge/' . $image_url;
        }
        $text = '<img src="' . $image_url . '" alt="" />';
        ?>
        <div class='yith-wcbm-badge yith-wcbm-badge-<?php echo $id_badge ?>'>
            <?php echo $text ?>
        </div><!--yith-wcbm-badge-->
        <?php
        break;

    case 'css':
        ?>
        <div class="yith-wcbm-badge yith-wcbm-css-badge-<?php echo $id_badge ?>">
            <div class="yith-wcbm-css-s1"></div>
            <div class="yith-wcbm-css-s2"></div>
            <div class="yith-wcbm-css-text"><?php echo $css_text ?></div>
        </div>
        <?php
        break;
    case 'advanced':
        global $product;
        if ( $product->is_on_sale() ) {
            $id_advanced_badge = $id_badge;
            include( YITH_WCBM_TEMPLATE_PATH . '/advanced_sale_badges.php' );
        }
        break;
}


?>


