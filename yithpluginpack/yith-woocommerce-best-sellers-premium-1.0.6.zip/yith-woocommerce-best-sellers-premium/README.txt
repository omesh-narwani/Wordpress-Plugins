== Changelog ==

= 1.0.6 =

* Tweak: fixed minor bugs

= 1.0.5 =

* Added: support to WooCommerce 2.5 BETA 3

= 1.0.4 =

* Added: compatibility with YITH Themes

= 1.0.3 =

* Added: Italian Language
* Fixed: minor bug

= 1.0.2 =

* Added: Possibility to choose the number of bestsellers visible in widget
* Improved: transient use

= 1.0.1 =

* Fixed: minor bug

= 1.0.0 =

* Initial release