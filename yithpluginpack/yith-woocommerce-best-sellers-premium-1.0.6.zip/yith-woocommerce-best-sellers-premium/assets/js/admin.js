jQuery(function($){
	$( '.yith-chosen' ).chosen( { width: '100%' } );
});