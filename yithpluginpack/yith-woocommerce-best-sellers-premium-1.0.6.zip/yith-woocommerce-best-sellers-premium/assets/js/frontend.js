jQuery( function ( $ ) {
    var slider = $( '.yith-wcbsl-bestsellers-slider' );
    slider.yith_fl_slider();
    /*slider.each( function () {
        $( this ).yith_fl_slider();
    } );*/
} );