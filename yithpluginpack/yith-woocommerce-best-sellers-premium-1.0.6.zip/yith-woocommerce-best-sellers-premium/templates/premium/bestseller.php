<?php
/**
 * Template of Best Seller
 *
 * @author  Yithemes
 * @package YITH WooCommerce Best Sellers
 * @version 1.0.0
 */


$bs = wc_get_product( $id );

$last_qty = 0;
if ( isset( $last_best_sellers[ $id ] ) ) {
    $last_qty = absint( $last_best_sellers[ $id ] );
}

$show_indicator = get_option( 'yith-wcbsl-show-bestseller-indicator', 'yes' ) == 'yes';

if ( $bs ) : ?>
    <div class="yith-wcbsl-bestseller-wrapper">
        <a href="<?php echo get_permalink( $bs->post->ID ); ?>">
            <div class="yith-wcbsl-bestseller-container">
                <span class="yith-wcbsl-bestseller-position"><?php echo $loop ?></span>

                <?php
                if ( $show_indicator ) {
                    $indicator_class   = 'equal';
                    $indicator_content = '=';
                    if ( $qty > $last_qty ) {
                        $indicator_class   = 'up dashicons dashicons-arrow-up-alt2';
                        $indicator_content = '';
                    } elseif ( $qty < $last_qty ) {
                        $indicator_class   = 'down dashicons dashicons-arrow-down-alt2';
                        $indicator_content = '';
                    }
                    echo "<span class='yith-wcbsl-bestseller-indicator yith-wcbsl-bestseller-indicator-{$indicator_class}'>{$indicator_content}</span>";
                }
                ?>


                <?php if ( current_user_can( 'manage_options' ) ): ?>
                    <span class="yith-wcbsl-bestseller-quantity">
                        <strong><?php echo number_format_i18n( $qty ) ?></strong><br/>
                        <?php echo _n( 'sale', 'sales', $qty, 'yith-wcbsl' ) ?>
                    </span>
                <?php endif; ?>

                <div class="yith-wcbsl-bestseller-thumb-wrapper">
                    <?php
                    $thumb_id = get_post_thumbnail_id( $id );
                    if ( $thumb_id ) {
                        $image_title = esc_attr( get_the_title( $thumb_id ) );
                        $image_link   = wp_get_attachment_url( $thumb_id );
                        $resized_link = wp_get_attachment_image_src( $thumb_id, 'shop_catalog' );
                        $image_link = !empty( $resized_link ) ? $resized_link[ 0 ] : $image_link;

                        echo "<img src='{$image_link}' title='{$image_title}' alt='{$image_title}' />";
                    } ?>
                </div>
                <div class="yith-wcbsl-bestseller-content-wrapper">
                    <h3><?php echo $bs->post->post_title; ?></h3>

                    <span class="price"> <?php echo $bs->get_price_html(); ?></span>
                </div>
            </div>
        </a>
    </div>
<?php endif; ?>

