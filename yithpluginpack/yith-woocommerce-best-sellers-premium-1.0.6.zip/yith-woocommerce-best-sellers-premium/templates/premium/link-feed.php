<?php
/**
 * Template of link for feed
 *
 * @author  Yithemes
 * @package YITH WooCommerce Best Sellers
 * @version 1.0.0
 */
?>
<div class="yith-wcbsl-feed-container">
    <a href="<?php echo $link ?>" class="yith-wcbsl-link-feed">
        <span class="yith-wcbsl-link-feed dashicons dashicons-rss"></span>
    </a>
</div>
