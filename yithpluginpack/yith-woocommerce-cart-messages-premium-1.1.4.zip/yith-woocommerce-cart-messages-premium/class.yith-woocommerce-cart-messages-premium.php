<?php
if ( !defined( 'ABSPATH' ) || !defined( 'YITH_YWCM_VERSION' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Implements features of FREE version of Yit WooCommerce Cart Messages
 *
 * @class   YWCM_Cart_Messages
 * @package Yithemes
 * @since   1.0.0
 * @author  Your Inspiration Themes
 */
if ( !class_exists( 'YWCM_Cart_Messages_Premium' ) ) {

    class YWCM_Cart_Messages_Premium extends YWCM_Cart_Messages {

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0
         * @author Emanuela Castorina
         */
        public function __construct() {

            parent::__construct();

            // register plugin to licence/update system
            add_action( 'wp_loaded', array( $this, 'register_plugin_for_activation' ), 99 );
            add_action( 'admin_init', array( $this, 'register_plugin_for_updates' ) );

            //save referer of visitors
            add_action( 'init', array( $this, 'save_referer_host' ), 1 );
            add_filter('yith_ywcm_is_valid_message', array($this, 'is_valid_user'), 10, 2);
            add_filter('yith_ywcm_is_valid_message', array($this, 'is_valid_page'), 10, 3);

            if ( get_option( 'ywcm_show_in_single_product' ) == 'yes' ) {
                add_action( 'woocommerce_before_single_product', array( $this, 'print_messages' ) );
            }
            if ( get_option( 'ywcm_show_in_shop_page' ) == 'yes' ) {
                add_action( 'woocommerce_archive_description', array( $this, 'print_messages' ) );
            }

            add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles_scripts' ) );
            add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_styles_scripts' ) );

        }

        /**
         * Enqueue style scripts
         *
         * Enqueue style and scripts files
         *
         * @since    1.0
         * @author   Emanuela Castorina <emanuela.castorina@yithemes.com>
         * @return  void
         */

        public function enqueue_styles_scripts() {
            wp_enqueue_style( 'yith_ywcm', YITH_YWCM_ASSETS_URL.'/css/style.css' );
            $custom_css = require_once( YITH_YWCM_TEMPLATE_PATH.'/layouts/css_layout.php');
            wp_add_inline_style( 'yith_ywcm', $custom_css );

        }
        /**
         * Enqueue style scripts in administrator
         *
         * Enqueue style and scripts files
         *
         * @since    1.0
         * @author   Emanuela Castorina <emanuela.castorina@yithemes.com>
         * @return  void
         */

        public function admin_enqueue_styles_scripts() {
            wp_enqueue_style( 'yith_ywcm', YITH_YWCM_ASSETS_URL.'/css/admin.css' );

        }

        /**
         * Get Minimum Amount Args
         *
         * Return an array with the args to print into message or false if the message can't be print
         *
         * @since    1.0
         * @author   Emanuela Castorina <emanuela.castorina@yithemes.com>
         * @return   mixed array || bool if the message can't be print
         */

        public function get_minimum_amount_args( $message ) {

            $args = array();

            $args['text']   = get_post_meta( $message->ID, '_ywcm_message_minimum_amount_text', true );

            if( $args['text'] =='' ) return false;

            $total_cart = $this->cart_total();

            $minimum_amount = get_post_meta( $message->ID, '_ywcm_message_minimum_amount', true);
            $threshold_amount = get_post_meta( $message->ID, '_ywcm_minimum_amount_threshold_amount', true);

            if( $minimum_amount == '' || $total_cart >= $minimum_amount  ){
                return false;
            }

            if( $threshold_amount != '' && $total_cart < $threshold_amount  ){
                return false;
            }

            $remain_amount =  wc_price($minimum_amount - $total_cart);

            $args['text'] = str_replace('{remaining_amount}', $remain_amount, $args['text']);

            $args['button'] = $this->get_button_options( $message->ID );
            $args['slug'] = $message->post_name;

            return $args;

        }

        /**
         * Get Referer Args
         *
         * Return an array with the args to print into message or false if the message can't be print
         *
         * @since    1.0
         * @author   Emanuela Castorina <emanuela.castorina@yithemes.com>
         * @return   mixed array || bool if the message can't be print
         */

        public function get_referer_args( $message ) {

            $args = array();

            if ( ! isset( $_SESSION['yit_woocomerce_cart_message_referer_host'] ) ) {
                return false;
            }

            $args['text']   = get_post_meta( $message->ID, '_ywcm_message_referer_text', true );

            if( $args['text'] =='' ){
                return false;
            }

            // get the referer
            $referer_host = $_SESSION['yit_woocomerce_cart_message_referer_host'];
            $referer     = get_post_meta( $message->ID, '_ywcm_message_referer', true );
            $referer     = strpos( $referer, '://' ) === false ? 'http://' . $referer : $referer;
            $ref_urlhost = parse_url( $referer, PHP_URL_HOST );
            //check the referer
            if ( $referer_host !== $ref_urlhost ) {
                return false;
            }


            $args['button'] = $this->get_button_options( $message->ID );
            $args['slug'] = $message->post_name;
            return $args;

        }

        /**
         * Deadline
         *
         * Return an array with the args to print into message or false if the message can't be print
         *
         * @since    1.0
         * @author   Emanuela Castorina <emanuela.castorina@yithemes.com>
         * @return   mixed array || bool if the message can't be print
         */

        public function get_deadline_args( $message ) {

            $args = array();

            $args['text'] = get_post_meta( $message->ID, '_ywcm_message_deadline_text', true );
            if ( $args['text'] == '' ) {
                return false;
            }

            $deadline_hour = get_post_meta( $message->ID, '_ywcm_message_deadline_hour', true );
            $deadline_days = get_post_meta( $message->ID, '_ywcm_message_deadline_days', true );
            if ( $deadline_hour == '' && $deadline_days == '' ) {
                return false;
            }

            $now             = current_time( 'timestamp' );
            $now_day_of_week = date( 'w', $now );

            if ( !in_array( $now_day_of_week, $deadline_days ) ) {
                return false;
            }


            $now_minutes = (int) date( 'G',  current_time( 'timestamp' )  ) * 60 + (int) date('i',  current_time( 'timestamp' ) );
            $deadline_hour_minutes = $deadline_hour * 60;

            if( $now_minutes >= $deadline_hour_minutes) return false;

            $minutes_remaining = $deadline_hour_minutes - $now_minutes;
            $hours_to_show = floor( $minutes_remaining / 60 );
            $minutes_to_show = $minutes_remaining % 60;

            $time_remain = '';
            if ( $hours_to_show > 0 )   $time_remain .= sprintf( _n( '%d hour', '%d hours', $hours_to_show, 'yith-woocommerce-cart-messages' ), $hours_to_show );
            if ( $minutes_to_show > 0 ) $time_remain .= ( $time_remain ? ' ' : '' ) . sprintf( _n( '%d minute', '%d minutes', $minutes_to_show, 'yith-woocommerce-cart-messages'), $minutes_to_show );

            $args['text'] = str_replace('{time_remain}', $time_remain, $args['text']);
            $args['button'] = $this->get_button_options( $message->ID );
            $args['slug'] = $message->post_name;
            return $args;

        }

        /**
         * Save Referer
         *
         * Store the referer host in the client session
         *
         * @return   void
         * @since    1.0
         * @author   Emanuela Castorina <emanuela.castorina@yithemes.com>
         */

        public function save_referer_host() {

            //return false is there's a direct request or there aren't referer_messages()
            if( ! isset( $_SERVER['HTTP_REFERER'] ) || ! $this->have_referer_messages() ) {
                return false;
            }

            //start the session if is not active
            if ( !session_id() ) {
                session_start();
            }

            $referer_host = parse_url( $_SERVER['HTTP_REFERER'], PHP_URL_HOST );

            if ( $referer_host && $referer_host != parse_url( site_url(), PHP_URL_HOST ) ) {
                $_SESSION['yit_woocomerce_cart_message_referer_host'] = $referer_host;
            }
        }

        /**
         * Have referer messages
         *
         * Check if there are referer messages
         *
         * @since    1.0
         * @author   Emanuela Castorina <emanuela.castorina@yithemes.com>
         * @return   bool
         */

        public function have_referer_messages(){

            foreach ( $this->messages as $message ){
                $message_type = get_post_meta( $message->ID, '_ywcm_message_type', true );
                if( $message_type == 'referer' ){
                    return true;
                }
            }

            return false;
        }

        /**
         * Cart total
         *
         * Return the total of cart
         *
         * @since    1.0
         * @author   Emanuela Castorina <emanuela.castorina@yithemes.com>
         * @return   float
         */

        public function cart_total(){
            if ( ! WC()->cart->prices_include_tax ) {
                // if prices don't include tax, just return the subtotal excluding tax
                return WC()->cart->subtotal_ex_tax;
            } else {
                // if prices do include tax, add the tax amount back in
                return WC()->cart->subtotal;
            }
        }

        /**
         * Is a valid message
         *
         * return a boolean if the message is valid or is expired
         *
         * @since    1.0
         * @author   Emanuela Castorina <emanuela.castorina@yithemes.com>
         * @return   bool
         */

        function is_valid_user( $value, $message_id ) {
            if( ! $value ) return false;
            $user_type = get_post_meta( $message_id, '_ywcm_message_user', true );
            if( $user_type == 'all' || ( is_user_logged_in() &&  $user_type == 'customers') || ( ! is_user_logged_in() &&  $user_type == 'guests') ) return true;

            return false;
        }

        /**
         * Is a valid page
         *
         * return a boolean if the message is valid for this page
         *
         * @since    1.0
         * @author   Emanuela Castorina <emanuela.castorina@yithemes.com>
         * @return   bool
         */

        function is_valid_page( $value, $message_id ) {
            if ( !$value ) {
                return false;
            }
            $pages = get_post_meta( $message_id, '_ywcm_message_pages', true );
            if ( !empty( $pages ) && in_array( $this->get_woocommerce_page(), $pages ) ) {
                return true;
            }

            return false;
        }

        /**
         * Register plugins for activation tab
         *
         * @return void
         * @since    2.0.0
         * @author   Andrea Grillo <andrea.grillo@yithemes.com>
         */

        public function register_plugin_for_activation() {
            if ( ! class_exists( 'YIT_Plugin_Licence' ) ) {
                require_once ( YITH_YWCM_DIR . 'plugin-fw/licence/lib/yit-licence.php' );
                require_once ( YITH_YWCM_DIR . 'plugin-fw/licence/lib/yit-plugin-licence.php' );
            }
            YIT_Plugin_Licence()->register( YITH_YWCM_INIT, YITH_YWCM_SECRET_KEY, YITH_YWCM_SLUG );
        }

        /**
         * Register plugins for update tab
         *
         * @return void
         * @since    2.0.0
         * @author   Andrea Grillo <andrea.grillo@yithemes.com>
         */

        public function register_plugin_for_updates() {
            if( ! class_exists( 'YIT_Upgrade' ) ) {
                require_once 'plugin-fw/lib/yit-upgrade.php';
            }
            YIT_Upgrade()->register( YITH_YWCM_SLUG, YITH_YWCM_INIT );
        }

        /**
         * get_woocommerce_page
         *
         * return the current page of wocommerce
         *
         * @return   Array
         * @since    1.0
         * @author   Emanuela Castorina
         */
        function get_woocommerce_page(){

            if( is_cart() ){
                return 'cart';
            }

            if( is_shop() ){
                return 'shop';
            }

            if( is_product() ){
                return 'single-product';
            }

            if( is_checkout() ){
                return 'checkout';
            }

            return '';


        }
    }
}

