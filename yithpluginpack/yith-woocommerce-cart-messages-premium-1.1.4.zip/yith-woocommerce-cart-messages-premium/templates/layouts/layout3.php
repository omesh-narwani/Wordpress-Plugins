<div id="yit-cart-message-<?php echo $slug ?>" class="yith-cart-message yith-cart-message-layout3">
    <div class="icon-wrapper"></div><div class="content"><?php echo  $text.' '.$button  ?></div>
</div>