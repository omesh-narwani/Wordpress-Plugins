<?php

if ( !defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

/**
 * Implements features of YITH WooCommerce Catalog Mode plugin
 *
 * @class   YITH_WC_Catalog_Mode
 * @package Yithemes
 * @since   1.0.0
 * @author  Your Inspiration Themes
 */
class YITH_WC_Catalog_Mode_Premium extends YITH_WC_Catalog_Mode {

    /**
     * Constructor
     *
     * Initialize plugin and registers actions and filters to be used
     *
     * @since   1.0.0
     * @return  mixed
     * @author  Alberto Ruggiero
     */
    public function __construct() {
        if ( !function_exists( 'WC' ) ) {
            return;
        }

        parent::__construct();

        $this->includes();

        if ( is_admin() ) {

            add_action( 'ywctm_exclusions', array( YWCTM_Exclusions_Table(), 'output' ) );
            add_action( 'ywctm_custom_url', array( YWCTM_Custom_Url_Table(), 'output' ) );

            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_premium_scripts_admin' ) );
            add_action( 'woocommerce_admin_field_icon', 'YITH_Icon_List::output' );
        }

        if ( get_option( 'ywctm_enable_plugin' ) == 'yes' && !( current_user_can( 'administrator' ) && is_user_logged_in() && get_option( 'ywctm_admin_view' ) == 'no' ) ) {

            if ( !is_admin() || $this->is_quick_view() ) {
                add_filter( 'woocommerce_product_tabs', array( $this, 'add_inquiry_form_tab' ) );
                add_filter( 'woocommerce_product_tabs', array( $this, 'disable_reviews_tab' ), 98 );
                add_filter( 'woocommerce_get_price_html', array( $this, 'show_product_price' ), 10, 2 );

                add_action( 'woocommerce_single_product_summary', array( $this, 'hide_product_price_single' ), 5 );
                add_action( 'woocommerce_single_product_summary', array( $this, 'show_custom_button' ), 20 );
                add_action( 'woocommerce_after_shop_loop_item', array( $this, 'show_custom_button_loop' ), 20 );
                add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_premium_styles' ) );
                add_action( 'wp_head', array( $this, 'custom_button_css' ) );
            }

        }

        add_filter( 'yit_get_contact_forms', array( $this, 'yit_get_contact_forms' ) );
        add_filter( 'wpcf7_get_contact_forms', array( $this, 'wpcf7_get_contact_forms' ) );
        add_filter( 'gravity_get_contact_forms', array( $this, 'gravity_get_contact_forms' ) );

        add_filter( 'wpcf7_mail_components', array( $this, 'wpcf7_mail_components' ), 10, 2 );
        add_filter( 'gform_pre_send_email', array( $this, 'gform_pre_send_email' ), 10, 2 );

        // register plugin to licence/update system
        add_action( 'wp_loaded', array( $this, 'register_plugin_for_activation' ), 99 );
        add_action( 'admin_init', array( $this, 'register_plugin_for_updates' ) );

        // compatibility with quick view
        add_action( 'yith_load_product_quick_view_custom_action', array( $this, 'check_quick_view' ) );
    }

    /**
     * Files inclusion
     *
     * @since   1.0.0
     * @return  void
     * @author  Alberto Ruggiero
     */
    private function includes() {

        include_once( 'includes/class-yith-icon.php' );

        if ( is_admin() ) {
            include_once( 'includes/admin/class-yith-custom-table.php' );
            include_once( 'includes/admin/meta-boxes/class-ywctm-meta-box.php' );
            include_once( 'templates/admin/exclusions-table.php' );
            include_once( 'templates/admin/custom-url-table.php' );
            include_once( 'templates/admin/icon-list.php' );
        }

    }

    /**
     * ADMIN FUNCTIONS
     */

    /**
     * Enqueue script file
     *
     * @since   1.0.0
     * @return  void
     * @author  Alberto Ruggiero
     */
    public function enqueue_premium_scripts_admin() {

        $suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
        wp_enqueue_script( 'ywctm-admin', YWCTM_ASSETS_URL . 'js/ywctm-admin' . $suffix . '.js', array( 'jquery' ) );
        wp_enqueue_style( 'ywctm-style', YWCTM_ASSETS_URL . 'css/yith-catalog-mode-premium-admin.css' );

    }

    /**
     * Get list of forms by YIT Contact Form plugin
     *
     * @since   1.0.0
     *
     * @param   $array
     *
     * @return  array
     * @author  Alberto Ruggiero
     */
    public function yit_get_contact_forms( $array = array() ) {
        if ( !function_exists( 'YIT_Contact_Form' ) ) {
            return array( '' => __( 'Plugin not activated or not installed', 'yith-woocommerce-catalog-mode' ) );
        }

        $posts = get_posts( array( 'post_type' => YIT_Contact_Form()->contact_form_post_type ) );

        foreach ( $posts as $post ) {
            $array[$post->post_name] = $post->post_title;
        }

        if ( $array == array() ) {
            return array( '' => __( 'No contact form found', 'yith-woocommerce-catalog-mode' ) );
        }

        return $array;
    }

    /**
     * Get list of forms by Contact Form 7 plugin
     *
     * @since   1.0.0
     *
     * @param   $array
     *
     * @return  array
     * @author  Alberto Ruggiero
     */
    public function wpcf7_get_contact_forms( $array = array() ) {
        if ( !function_exists( 'wpcf7_contact_form' ) ) {
            return array( '' => __( 'Plugin not activated or not installed', 'yith-woocommerce-catalog-mode' ) );
        }

        $posts = WPCF7_ContactForm::find();

        foreach ( $posts as $post ) {
            $array[$post->id()] = $post->title();
        }

        if ( $array == array() ) {
            return array( '' => __( 'No contact form found', 'yith-woocommerce-catalog-mode' ) );
        }

        return $array;
    }

    /**
     * Get list of forms by Gravity Forms plugin
     *
     * @since   1.0.7
     *
     * @param   $array
     *
     * @return  array
     * @author  Alberto Ruggiero
     */
    public function gravity_get_contact_forms( $array = array() ) {
        if ( !function_exists( 'gravity_form' ) ) {
            return array( '' => __( 'Plugin not activated or not installed', 'yith-woocommerce-catalog-mode' ) );
        }

        $posts = RGFormsModel::get_forms( null, 'title' );

        foreach ( $posts as $post ) {
            $array[$post->id] = $post->title;
        }

        if ( $array == array() ) {
            return array( '' => __( 'No contact form found', 'yith-woocommerce-catalog-mode' ) );
        }

        return $array;
    }

    /**
     * FRONTEND FUNCTIONS
     */

    /**
     * Enqueue css file
     *
     * @since   1.0.0
     * @return  void
     * @author  Alberto Ruggiero
     */
    public function enqueue_premium_styles() {

        wp_enqueue_style( 'ywctm-premium-style', YWCTM_ASSETS_URL . 'css/yith-catalog-mode-premium.css' );

    }

    /**
     * Removes reviews tab from single page product
     *
     * @since   1.0.0
     *
     * @param   $tabs
     *
     * @return  array
     * @author  Alberto Ruggiero
     */
    public function disable_reviews_tab( $tabs ) {

        if ( ( get_option( 'ywctm_disable_review' ) == 'unregistered' && !is_user_logged_in() ) || get_option( 'ywctm_disable_review' ) == 'all' ) {
            unset( $tabs['reviews'] );
        }

        return $tabs;
    }

    /**
     * Append Product page permalink to mail body (WPCF7)
     *
     * @since   1.0.8
     *
     * @param   $components
     * @param   $contact_form
     *
     * @return  mixed
     * @author  Alberto Ruggiero
     */
    public function wpcf7_mail_components( $components, $contact_form ) {

        if ( get_option( 'ywctm_inquiry_product_permalink' ) == 'yes' ) {

            $form_atts = $contact_form->get_properties();

            $field_label = __( 'Related product', 'yith-woocommerce-catalog-mode' );
            $field_value = get_option( 'siteurl' ) . $_SERVER['REQUEST_URI'];

            if ( !$form_atts['mail']['use_html'] ) {

                $field_data = "{$field_label}: {$field_value}\n\n";

            }
            else {
                ob_start();

                ?>

                <p>
                    <?php echo $field_label; ?>: <a href="<?php echo $field_value ?>"><?php echo $field_value ?></a>
                </p>

                <?php

                $field_data = ob_get_clean();

            }

            $components['body'] = $field_data . $components['body'];

        }

        return $components;

    }

    /**
     * Append Product page permalink to mail body (Gravity Forms)
     *
     * @since   1.0.8
     *
     * @param   $components
     * @param   $mail_format
     *
     * @return  mixed
     * @author  Alberto Ruggiero
     */
    public function gform_pre_send_email( $components, $mail_format ) {

        if ( get_option( 'ywctm_inquiry_product_permalink' ) == 'yes' ) {

            $field       = '';
            $lead        = '';
            $field_label = __( 'Related product', 'yith-woocommerce-catalog-mode' );
            $field_value = get_option( 'siteurl' ) . $_SERVER['REQUEST_URI'];


            if ( $mail_format != 'html' ) {

                $field_data = "{$field_label}: {$field_value}\n\n";

            }
            else {

                ob_start();

                ?>
                <table width="99%" border="0" cellpadding="1" cellspacing="0" bgcolor="#EAEAEA">
                    <tr>
                        <td>
                            <table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#FFFFFF">
                                <tr bgcolor="<?php echo apply_filters( 'gform_email_background_color_label', '#EAF2FA', $field, $lead ); ?>">
                                    <td colspan="2">
                                        <font style="font-family: sans-serif; font-size:12px;"><strong><?php echo $field_label ?></strong></font>
                                    </td>
                                </tr>
                                <tr bgcolor="<?php echo apply_filters( 'gform_email_background_color_data', '#FFFFFF', $field, $lead ); ?>">
                                    <td width="20">&nbsp;</td>
                                    <td>
                                        <a href="<?php echo $field_value ?>" style="font-family: sans-serif; font-size:12px;"><?php echo $field_value ?></a>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                <br />
                <?php

                $field_data = ob_get_clean();

            }

            $components['message'] = $field_data . $components['message'];

        }

        return $components;

    }

    /**
     * Add inquiry form tab to single page product
     *
     * @since   1.0.0
     *
     * @param   $tabs
     *
     * @return  array
     * @author  Alberto Ruggiero
     */
    public function add_inquiry_form_tab( $tabs = array() ) {

        if ( get_option( 'ywctm_inquiry_form_type' ) != 'none' && ( function_exists( 'YIT_Contact_Form' ) || function_exists( 'wpcf7_contact_form' ) || function_exists( 'gravity_form' ) ) ) {

            global $post;

            $show_yit_contact_form = ( get_option( 'ywctm_inquiry_form_type' ) == 'yit-contact-form' && get_option( 'ywctm_inquiry_yit_contact_form_id' ) != '' );
            $show_contact_form_7   = ( get_option( 'ywctm_inquiry_form_type' ) == 'contact-form-7' && get_option( 'ywctm_inquiry_contact_form_7_id' ) != '' );
            $show_gravity_forms    = ( get_option( 'ywctm_inquiry_form_type' ) == 'gravity-forms' && get_option( 'ywctm_inquiry_gravity_forms_id' ) != '' );

            if ( $show_yit_contact_form || $show_contact_form_7 || $show_gravity_forms ) {

                $tabs['inquiry_form'] = array(
                    'title'    => apply_filters( 'ywctm_inquiry_form_title', __( 'Inquiry form', 'yith-woocommerce-catalog-mode' ) ),
                    'priority' => 40,
                    'callback' => array( $this, 'get_inquiry_form' )
                );
            }
        }

        return $tabs;
    }

    /**
     * Inquiry form tab template
     *
     * @since   1.0.0
     * @return  string
     * @author  Alberto ruggiero
     */
    public function get_inquiry_form() {

        switch ( get_option( 'ywctm_inquiry_form_type' ) ) {
            case 'yit-contact-form':
                $shortcode = '[contact_form name="' . get_option( 'ywctm_inquiry_yit_contact_form_id' ) . '"]';
                break;
            case 'contact-form-7':
                $shortcode = '[contact-form-7 id="' . get_option( 'ywctm_inquiry_contact_form_7_id' ) . '"]';
                break;
            case 'gravity-forms':
                $shortcode = '[gravityform  id=' . get_option( 'ywctm_inquiry_gravity_forms_id' ) . ']';
                break;
        }

        echo do_shortcode( $shortcode );

    }

    /**
     * Add a custom button in product details page
     *
     * @since   1.0.0
     * @return  string
     * @author  Alberto Ruggiero
     */
    public function show_custom_button() {

        if ( get_option( 'ywctm_custom_button' ) == 'yes' && $this->check_add_to_cart_single() ) {

            $this->get_custom_button_template();

        }

    }

    /**
     * Add a custom button in loop
     *
     * @since   1.0.4
     * @return  string
     * @author  Alberto Ruggiero
     */
    public function show_custom_button_loop() {

        if ( get_option( 'ywctm_custom_button_loop' ) == 'yes' && $this->check_add_to_cart_single() ) {

            $this->get_custom_button_template();

        }

    }

    /**
     * Get custom button template
     *
     * @since   1.0.4
     * @return  string
     * @author  Alberto Ruggiero
     */
    public function get_custom_button_template() {

        global $post;

        if ( get_post_meta( $post->ID, '_ywctm_custom_url_enabled', true ) == 'yes' ) {

            $protocol = get_post_meta( $post->ID, '_ywctm_custom_url_protocol', true );
            $link     = get_post_meta( $post->ID, '_ywctm_custom_url_link', true );

        }
        else {

            $protocol = get_option( 'ywctm_button_url_type' );
            $link     = get_option( 'ywctm_button_url' );

        }

        $button_text     = get_option( 'ywctm_button_text' );
        $button_url_type = $protocol == 'generic' ? '' : $protocol . ':';
        $button_url      = $link == '' ? '#' : $link;
        $icon            = get_option( 'ywctm_button_icon' );

        ?>
        <div class="ywctm-custom-button-container">
            <p>
                <a class="button ywctm-custom-button" href="<?php printf( '%s%s', $button_url_type, $button_url ); ?>">
                    <?php
                    switch ( $icon['select'] ) :
                        case 'icon':
                            ?>
                            <span class="icon-form" <?php echo YITH_Icon()->get_icon_data( $icon['icon'] ) ?>></span>
                            <?php break;
                        case 'custom':
                            ?>
                            <span class="custom-icon"><img src="<?php echo esc_url( $icon['custom'] ); ?>"></span>
                            <?php break;
                    endswitch; ?>
                    <span class="inquiry-title"><?php echo $button_text; ?></span>
                </a>
            </p>
        </div>
        <?php

    }

    /**
     * Set custom css for custom button
     *
     * @since   1.0.0
     * @return  string
     * @author  Alberto Ruggiero
     */
    public function custom_button_css() {

        $button_color       = get_option( 'ywctm_button_color' );
        $button_hover_color = get_option( 'ywctm_button_hover' );

        if ( $button_color != '' || $button_hover_color != '' ) : ?>
            <style type="text/css">
                <?php if ( $button_color != '' ) : ?>
                .ywctm-custom-button {
                    color: <?php echo $button_color; ?> !important;
                }

                <?php endif;
                if ( $button_hover_color != '') :?>
                .ywctm-custom-button:hover {
                    color: <?php echo $button_hover_color; ?> !important;
                }

                <?php endif; ?>
            </style>
        <?php endif;
    }

    /**
     * Hides product price from single product page
     *
     * @since   1.0.0
     *
     * @param   $action
     *
     * @return  void
     * @author  Alberto Ruggiero
     */
    public function hide_product_price_single( $action = 'woocommerce_single_product_summary' ) {

        if ( $action == '' ) {
            $action = 'woocommerce_single_product_summary';
        }

        $priority = has_action( $action, 'woocommerce_template_single_price' );

        if ( $this->check_product_price_single( $priority ) ) {

            remove_action( $action, 'woocommerce_template_single_price', $priority );
            $inline_js = "$( '.single_variation_wrap .single_variation' ).hide();";

            if ( $this->is_quick_view() ) {
                add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'hide_price_quick_view' ) );
            }
            else {
                wc_enqueue_js( $inline_js );
            }
        }
    }

    /**
     * Hide price for product in quick view
     *
     * @since   1.0.7
     * @return  mixed
     * @author  Francesco Licandro
     */
    public function hide_price_quick_view() {
        ob_start();
        ?>
        <style>
            .single_variation_wrap .single_variation {
                display: none !important;
            }
        </style>
        <?php
        echo ob_get_clean();
    }

    /**
     * Checks if product price needs to be hidden
     *
     * @since   1.0.2
     *
     * @param   $priority
     * @param   $product_id
     *
     * @return  bool
     * @author  Alberto Ruggiero
     */
    public function check_product_price_single( $priority = true, $product_id = false ) {

        $hide             = false;
        $alternative_text = '';

        if ( get_option( 'ywctm_enable_plugin' ) == 'yes' && $this->check_user_admin_enable() && get_option( 'ywctm_hide_price' ) == 'yes' ) {

            $ywctm_hide_price_users = ( get_option( 'ywctm_hide_price_users' ) != 'unregistered' ) ? true : false;
            $user_logged            = is_user_logged_in();

            if ( !( !$ywctm_hide_price_users && $user_logged ) ) {

                global $post;

                $post_id = ( $product_id ) ? $product_id : $post->ID;

                $exclude_catalog  = get_post_meta( $post_id, '_ywctm_exclude_hide_price', true );
                $enable_exclusion = get_option( 'ywctm_exclude_hide_price' );
                $alternative_text = get_option( 'ywctm_exclude_price_alternative_text' );

                if ( $priority ) {

                    if ( ( $enable_exclusion == '' || $enable_exclusion == 'no' ) ) {

                        $hide = true;

                    }
                    else {

                        if ( ( $exclude_catalog == '' || $exclude_catalog == 'no' ) ) {

                            $hide = true;

                        }
                    }
                }

                $reverse_criteria = get_option( 'ywctm_exclude_hide_price_reverse' );

                if ( $reverse_criteria == 'yes' ) {

                    $hide = !$hide;

                }

            }

        }

        if ( $hide && $alternative_text != '' ) {
            $hide = false;
        }

        return $hide;

    }

    /**
     * Check for which users will not see the price
     *
     * @since   1.0.0
     *
     * @param   $price
     * @param   $product
     *
     * @return  string
     * @author  Alberto Ruggiero
     */
    public function show_product_price( $price, $product ) {

        if ( get_option( 'ywctm_hide_price' ) == 'yes' ) {

            $ywctm_hide_price_users = ( get_option( 'ywctm_hide_price_users' ) != 'unregistered' ) ? true : false;
            $user_logged            = is_user_logged_in();

            if ( !( !$ywctm_hide_price_users && $user_logged ) ) {

                $price = $this->set_price_label( $price, $product );

            }

        }

        return $price;

    }

    /**
     * Hides price, if not excluded, and shows alternative text if set
     *
     * @since   1.0.0
     *
     * @param   $price
     * @param   $product
     *
     * @return  string
     * @author  Alberto Ruggiero
     */
    public function set_price_label( $price, $product ) {

        $exclude_catalog  = get_post_meta( $product->id, '_ywctm_exclude_hide_price', true );
        $enable_exclusion = get_option( 'ywctm_exclude_hide_price' );
        $alternative_text = get_option( 'ywctm_exclude_price_alternative_text' );

        if ( $enable_exclusion == '' || $enable_exclusion == 'no' ) {

            $remove = true;

        }
        else {

            if ( $exclude_catalog == '' || $exclude_catalog == 'no' ) {

                $remove = true;

            }
            else {

                $remove = false;

            }

        }

        $reverse_criteria = get_option( 'ywctm_exclude_hide_price_reverse' );

        if ( $reverse_criteria == 'yes' ) {

            $remove = !$remove;

        }

        if ( $remove ) {

            return ( $alternative_text != '' ) ? $alternative_text : '';

        }
        else {

            return $price;

        }

    }

    /**
     * Hides product price and add to cart in YITH Quick View
     *
     * @since   1.0.7
     * @return  mixed
     * @author  Francesco Licandro
     */
    public function check_quick_view() {
        $this->hide_product_price_single( 'yith_wcqv_product_summary' );
        $this->hide_add_to_cart_single( 'yith_wcqv_product_summary' );
    }

    /**
     * YITH FRAMEWORK
     */

    /**
     * Register plugins for activation tab
     *
     * @since   2.0.0
     * @return  void
     * @author  Andrea Grillo <andrea.grillo@yithemes.com>
     */
    public function register_plugin_for_activation() {
        if ( !class_exists( 'YIT_Plugin_Licence' ) ) {
            require_once 'plugin-fw/licence/lib/yit-licence.php';
            require_once 'plugin-fw/licence/lib/yit-plugin-licence.php';
        }
        YIT_Plugin_Licence()->register( YWCTM_INIT, YWCTM_SECRET_KEY, YWCTM_SLUG );
    }

    /**
     * Register plugins for update tab
     *
     * @since   2.0.0
     * @return  void
     * @author  Andrea Grillo <andrea.grillo@yithemes.com>
     */
    public function register_plugin_for_updates() {
        if ( !class_exists( 'YIT_Upgrade' ) ) {
            require_once( 'plugin-fw/lib/yit-upgrade.php' );
        }
        YIT_Upgrade()->register( YWCTM_SLUG, YWCTM_INIT );
    }

}