<?php
/**
 * This file belongs to the YIT Plugin Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( !defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

$product_permalink = '';
$no_form_plugin    = '';
$inquiry_form      = '';
$yit_contact_form  = '';
$contact_form_7    = '';
$gravity_forms     = '';
$active_plugins    = array(
    'none' => __( 'None', 'yith-woocommerce-catalog-mode' ),
);
$query_args        = array(
    'page' => isset( $_GET['page'] ) ? $_GET['page'] : '',
    'tab'  => 'exclusions',
);
$exclusions_url    = esc_url( add_query_arg( $query_args, admin_url( 'admin.php' ) ) );

if ( function_exists( 'YIT_Contact_Form' ) ) {
    $active_plugins['yit-contact-form'] = __( 'YIT Contact Form', 'yith-woocommerce-catalog-mode' );
}

if ( function_exists( 'wpcf7_contact_form' ) ) {
    $active_plugins['contact-form-7'] = __( 'Contact Form 7', 'yith-woocommerce-catalog-mode' );
}

if ( function_exists( 'gravity_form' ) ) {
    $active_plugins['gravity-forms'] = __( 'Gravity Forms', 'yith-woocommerce-catalog-mode' );
}

if ( function_exists( 'YIT_Contact_Form' ) || function_exists( 'wpcf7_contact_form' ) || function_exists( 'gravity_form' ) ) {

    $inquiry_form      = array(
        'name'    => __( 'Form Plugin', 'yith-woocommerce-catalog-mode' ),
        'type'    => 'select',
        'desc'    => __( 'Choose from which activated plugin you want to display the inquiry form in product page', 'yith-woocommerce-catalog-mode' ),
        'options' => $active_plugins,
        'default' => 'none',
        'id'      => 'ywctm_inquiry_form_type'
    );
    $yit_contact_form  = array(
        'name'    => '',
        'type'    => 'select',
        'desc'    => __( 'Choose the form to display', 'yith-woocommerce-catalog-mode' ),
        'options' => apply_filters( 'yit_get_contact_forms', array() ),
        'id'      => 'ywctm_inquiry_yit_contact_form_id',
        'class'   => 'yit-contact-form'
    );
    $contact_form_7    = array(
        'name'    => '',
        'type'    => 'select',
        'desc'    => __( 'Choose the form to display', 'yith-woocommerce-catalog-mode' ),
        'options' => apply_filters( 'wpcf7_get_contact_forms', array() ),
        'id'      => 'ywctm_inquiry_contact_form_7_id',
        'class'   => 'contact-form-7'
    );
    $gravity_forms     = array(
        'name'    => '',
        'type'    => 'select',
        'desc'    => __( 'Choose the form to display', 'yith-woocommerce-catalog-mode' ),
        'options' => apply_filters( 'gravity_get_contact_forms', array() ),
        'id'      => 'ywctm_inquiry_gravity_forms_id',
        'class'   => 'gravity-forms'
    );
    $product_permalink = array(
        'name'    => __( 'Product Permalink', 'yith-woocommerce-catalog-mode' ),
        'type'    => 'checkbox',
        'desc'    => __( 'Add the product permalink to the email body (it works only with Contact Form 7 and Gravity Forms).', 'yith-woocommerce-catalog-mode' ),
        'id'      => 'ywctm_inquiry_product_permalink',
        'default' => 'no',
    );

}
else {

    $no_form_plugin = __( 'To use this feature, YIT Contact Form, Contact Form 7 or Gravity Forms must be installed and activated.', 'yith-woocommerce-catalog-mode' );

}

return array(
    'premium-settings' => array(
        'ywctm_general_title' => array(
            'name' => __( 'General Settings', 'yith-woocommerce-catalog-mode' ),
            'type' => 'title',
        ),
        'ywctm_enable_plugin' => array(
            'name'    => __( 'Enable YITH WooCommerce Catalog Mode', 'yith-woocommerce-catalog-mode' ),
            'type'    => 'checkbox',
            'desc'    => '',
            'id'      => 'ywctm_enable_plugin',
            'default' => 'yes',
        ),
        'ywctm_general_end'   => array(
            'type' => 'sectionend',
        ),

        'ywctm_catalog_mode_title'                         => array(
            'name' => __( 'Catalog Mode Settings', 'yith-woocommerce-catalog-mode' ),
            'type' => 'title',
        ),
        'ywctm_catalog_mode_hide_price'                    => array(
            'name'    => __( 'Price and "Add to cart" button', 'yith-woocommerce-catalog-mode' ),
            'type'    => 'checkbox',
            'desc'    => __( 'Hide', 'yith-woocommerce-catalog-mode' ),
            'id'      => 'ywctm_hide_price',
            'default' => 'no',
        ),
        'ywctm_catalog_mode_price_alternative_text'        => array(
            'type'    => 'text',
            'desc'    => __( 'Insert a text that will replace the product price (optional)', 'yith-woocommerce-catalog-mode' ),
            'id'      => 'ywctm_exclude_price_alternative_text',
            'default' => '',
        ),
        'ywctm_catalog_mode_variable_products_atc'         => array(
            'type'          => 'checkbox',
            'desc'          => __( 'Hide product variations', 'yith-woocommerce-catalog-mode' ),
            'id'            => 'ywctm_hide_variations',
            'default'       => 'no',
            'checkboxgroup' => 'start',
        ),
        'ywctm_catalog_mode_exclude_products_full'         => array(
            'type'          => 'checkbox',
            'desc'          => sprintf( __( 'Show price and "Add to cart" options in items of the %s"Exclusion List"%s (Exclusion)', 'yith-woocommerce-catalog-mode' ), '<a href="' . $exclusions_url . '">', '</a>' ),
            'id'            => 'ywctm_exclude_hide_price',
            'default'       => 'no',
            'checkboxgroup' => ''

        ),
        'ywctm_catalog_mode_exclude_products_reverse_full' => array(
            'type'          => 'checkbox',
            'desc'          => sprintf( __( 'Hide price only in items of the %s"Exclusion List"%s (Reverse Exclusion)', 'yith-woocommerce-catalog-mode' ), '<a href="' . $exclusions_url . '">', '</a>' ),
            'id'            => 'ywctm_exclude_hide_price_reverse',
            'default'       => 'no',
            'checkboxgroup' => '',
            'class'         => 'ywctm-full'
        ),
        'ywctm_catalog_mode_exclude_products_reverse_atc'  => array(
            'type'          => 'checkbox',
            'desc'          => sprintf( __( 'Hide "Add to cart" button only in items of the %s"Exclusion List"%s (Reverse Exclusion)', 'yith-woocommerce-catalog-mode' ), '<a href="' . $exclusions_url . '">', '</a>' ),
            'id'            => 'ywctm_exclude_hide_add_to_cart_reverse',
            'default'       => 'no',
            'checkboxgroup' => 'end',
            'class'         => 'ywctm-reverse-full ywctm-full'
        ),
        'ywctm_catalog_mode_disable_add_to_cart_single'    => array(
            'name'          => __( '"Add to cart" button', 'yith-woocommerce-catalog-mode' ),
            'type'          => 'checkbox',
            'desc'          => __( 'Hide in product detail page', 'yith-woocommerce-catalog-mode' ),
            'id'            => 'ywctm_hide_add_to_cart_single',
            'default'       => 'no',
            'checkboxgroup' => 'start'
        ),
        'ywctm_catalog_mode_disable_add_to_cart_loop'      => array(
            'type'          => 'checkbox',
            'desc'          => __( 'Hide in other shop pages', 'yith-woocommerce-catalog-mode' ),
            'id'            => 'ywctm_hide_add_to_cart_loop',
            'default'       => 'no',
            'checkboxgroup' => ''

        ),
        'ywctm_catalog_mode_variable_products'             => array(
            'name'          => __( 'Variable products', 'yith-woocommerce-catalog-mode' ),
            'type'          => 'checkbox',
            'desc'          => __( 'Hide product variations', 'yith-woocommerce-catalog-mode' ),
            'id'            => 'ywctm_hide_variations',
            'default'       => 'no',
            'checkboxgroup' => '',
            'class'         => 'ywctm-variations'
        ),
        'ywctm_catalog_mode_exclude_products'              => array(
            'type'          => 'checkbox',
            'desc'          => sprintf( __( 'Show "Add to cart" in items of the  %s"Exclusion List" %s(Exclusion)', 'yith-woocommerce-catalog-mode' ), '<a href="' . $exclusions_url . '">', '</a>' ),
            'id'            => 'ywctm_exclude_hide_add_to_cart',
            'default'       => 'no',
            'checkboxgroup' => ''

        ),
        'ywctm_catalog_mode_exclude_products_reverse'      => array(
            'type'          => 'checkbox',
            'desc'          => sprintf( __( 'Hide "Add to cart" button only in items of the %s"Exclusion List"%s (Reverse Exclusion)', 'yith-woocommerce-catalog-mode' ), '<a href="' . $exclusions_url . '">', '</a>' ),
            'id'            => 'ywctm_exclude_hide_add_to_cart_reverse',
            'default'       => 'no',
            'checkboxgroup' => 'end',
            'class'         => 'ywctm-reverse-atc ywctm-atc'
        ),
        'ywctm_catalog_mode_hide_price_users'              => array(
            'name'    => __( 'Affected users', 'yith-woocommerce-catalog-mode' ),
            'type'    => 'select',
            'desc'    => __( 'Users who will not see the price and the "Add to cart" button', 'yith-woocommerce-catalog-mode' ),
            'options' => array(
                'all'          => __( 'All users', 'yith-woocommerce-catalog-mode' ),
                'unregistered' => __( 'Unregistered users only', 'yith-woocommerce-catalog-mode' )
            ),
            'default' => 'all',
            'id'      => 'ywctm_hide_price_users'
        ),
        'ywctm_catalog_mode_admin_view'                    => array(
            'name'    => __( 'Admin View', 'yith-woocommerce-catalog-mode' ),
            'type'    => 'checkbox',
            'desc'    => __( 'Enable Catalog Mode also for administrators', 'yith-woocommerce-catalog-mode' ),
            'id'      => 'ywctm_admin_view',
            'default' => 'yes',
        ),
        'ywctm_catalog_mode_section_end'                   => array(
            'type' => 'sectionend',
        ),

        'ywctm_form_section_title'     => array(
            'name' => __( 'Inquiry Form', 'yith-woocommerce-catalog-mode' ),
            'type' => 'title',
            'desc' => $no_form_plugin,
        ),
        'ywctm_form_inquiry_form'      => $inquiry_form,
        'ywctm_form_yit_contact_form'  => $yit_contact_form,
        'ywctm_form_contact_form_7'    => $contact_form_7,
        'ywctm_form_gravity_forms'     => $gravity_forms,
        'ywctm_form_product_permalink' => $product_permalink,
        'ywctm_form_section_end'       => array(
            'type' => 'sectionend',
        ),

        'ywctm_button_section_title'             => array(
            'name' => __( 'Custom Button', 'yith-woocommerce-catalog-mode' ),
            'type' => 'title',
            'desc' => __( 'To use a custom button, you have to hide the "Add to cart" button and/or the price', 'yith-woocommerce-catalog-mode' ),
        ),
        'ywctm_button_enable_custom_button'      => array(
            'name'          => __( 'Custom button', 'yith-woocommerce-catalog-mode' ),
            'type'          => 'checkbox',
            'desc'          => __( 'Show in product detail page', 'yith-woocommerce-catalog-mode' ),
            'id'            => 'ywctm_custom_button',
            'default'       => 'no',
            'checkboxgroup' => 'start'
        ),
        'ywctm_button_enable_custom_button_loop' => array(
            'name'          => __( 'Custom button', 'yith-woocommerce-catalog-mode' ),
            'type'          => 'checkbox',
            'desc'          => __( 'Show in shop pages', 'yith-woocommerce-catalog-mode' ),
            'id'            => 'ywctm_custom_button_loop',
            'default'       => 'no',
            'checkboxgroup' => 'end'
        ),
        'ywctm_button_custom_button_text'        => array(
            'name'    => __( 'Button text', 'yith-woocommerce-catalog-mode' ),
            'type'    => 'text',
            'default' => '',
            'id'      => 'ywctm_button_text',
        ),
        'ywctm_button_custom_button_color'       => array(
            'name'    => __( 'Color', 'yith-woocommerce-catalog-mode' ),
            'type'    => 'color',
            'default' => '#000000',
            'desc'    => __( 'Color of the text (Optional)', 'yith-woocommerce-catalog-mode' ),
            'id'      => 'ywctm_button_color',
        ),
        'ywctm_button_custom_button_hover'       => array(
            'name'    => __( 'Hover Color', 'yith-woocommerce-catalog-mode' ),
            'type'    => 'color',
            'default' => '#FF0000',
            'desc'    => __( 'Color of the text on mouse hover (Optional)', 'yith-woocommerce-catalog-mode' ),
            'id'      => 'ywctm_button_hover',
        ),
        'ywctm_button_custom_button_icon'        => array(
            'name'    => __( 'Icon', 'yith-woocommerce-catalog-mode' ),
            'type'    => 'icon',
            'desc'    => __( 'Show optional icon', 'yith-woocommerce-catalog-mode' ),
            'options' => array(
                'select' => array(
                    'none'   => __( 'None', 'yith-woocommerce-catalog-mode' ),
                    'icon'   => __( 'Theme Icon', 'yith-woocommerce-catalog-mode' ),
                    'custom' => __( 'Custom Icon', 'yith-woocommerce-catalog-mode' )
                ),
                'icon'   => YIT_Plugin_Common::get_icon_list(),
            ),
            'id'      => 'ywctm_button_icon',
            'default' => array(
                'select' => 'none',
                'icon'   => 'retinaicon-font:retina-the-essentials-082',
                'custom' => ''
            )
        ),
        'ywctm_button_custom_button_url_type'    => array(
            'name'    => __( 'URL Protocol Type', 'yith-woocommerce-catalog-mode' ),
            'type'    => 'select',
            'desc'    => __( 'Specify the type of the URL (Optional)', 'yith-woocommerce-catalog-mode' ),
            'options' => array(
                'generic' => __( 'Generic URL', 'yith-woocommerce-catalog-mode' ),
                'mailto'  => __( 'E-mail address', 'yith-woocommerce-catalog-mode' ),
                'tel'     => __( 'Phone number', 'yith-woocommerce-catalog-mode' ),
                'skype'   => __( 'Skype contact', 'yith-woocommerce-catalog-mode' ),
            ),
            'default' => 'generic',
            'id'      => 'ywctm_button_url_type'
        ),
        'ywctm_button_custom_button_url'         => array(
            'name'    => __( 'URL Link', 'yith-woocommerce-catalog-mode' ),
            'type'    => 'text',
            'desc'    => __( 'Specify the URL (Optional)', 'yith-woocommerce-catalog-mode' ),
            'id'      => 'ywctm_button_url',
            'default' => '',
        ),
        'ywctm_button_section_end'               => array(
            'type' => 'sectionend',
        ),

        'ywctm_other_section_title'          => array(
            'name' => __( 'Other Settings', 'yith-woocommerce-catalog-mode' ),
            'type' => 'title',
            'desc' => '',
        ),
        'ywctm_other_disable_review'         => array(
            'name'    => __( 'Product Reviews', 'yith-woocommerce-catalog-mode' ),
            'type'    => 'select',
            'desc'    => '',
            'id'      => 'ywctm_disable_review',
            'default' => 'no',
            'options' => array(
                'no'           => __( 'Enabled', 'yith-woocommerce-catalog-mode' ),
                'all'          => __( 'Disabled for all users', 'yith-woocommerce-catalog-mode' ),
                'unregistered' => __( 'Disabled only for unregistered users', 'yith-woocommerce-catalog-mode' )
            )
        ),
        'ywctm_other_disable_cart_in_header' => array(
            'name'    => __( 'Disable shop', 'yith-woocommerce-catalog-mode' ),
            'type'    => 'checkbox',
            'desc'    => __( 'Hide and disable "Cart" page, "Checkout" page and all "Add to Cart" buttons', 'yith-woocommerce-catalog-mode' ),
            'id'      => 'ywctm_hide_cart_header',
            'default' => 'no',
        ),
        'ywctm_other_section_end'            => array(
            'type' => 'sectionend',
        )
    )

);