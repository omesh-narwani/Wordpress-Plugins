/*Select2 for ajax category search*/

var  ywcca_resize_thickbox = function( w, h ) {

    w   =   w || 400;
    h   =   h || 350;


    var myWidth = w,
        myHeight = h;


    var tbWindow = jQuery('#TB_window'),
        tbFrame = jQuery('#TB_iframeContent'),
        wpadminbar = jQuery('#wpadminbar'),
        width = jQuery(window).width(),
        height = jQuery(window).height(),

        adminbar_height = 0;

    if (wpadminbar.length) {
        adminbar_height = parseInt(wpadminbar.css('height'), 10);
    }

    var TB_newWidth = ( width < (myWidth + 50)) ? ( width - 50) : myWidth;
    var TB_newHeight = ( height < (myHeight + 45 + adminbar_height)) ? ( height - 45 - adminbar_height) : myHeight;

    tbWindow.css({
        'marginLeft': -(TB_newWidth / 2),
        'marginTop' : -(TB_newHeight / 2),
        'top'       : '50%',
        'width'     : TB_newWidth,
        'height'    : TB_newHeight
    });

    tbFrame.css({
        'padding': '10px',
        'width'  : TB_newWidth - 20,
        'height' : TB_newHeight - 50
    });
}
jQuery( document ).ready( function( $ ) {

 var  getEnhancedSelectFormatString = function() {
        var formatString = {
            formatMatches: function( matches ) {
                if ( 1 === matches ) {
                    return ywcca_admin_i18n.i18n_matches_1;
                }

                return ywcca_admin_i18n.i18n_matches_n.replace( '%qty%', matches );
            },
            formatNoMatches: function() {
                return ywcca_admin_i18n.i18n_no_matches;
            },
            formatAjaxError: function( jqXHR, textStatus, errorThrown ) {
                return ywcca_admin_i18n.i18n_ajax_error;
            },
            formatInputTooShort: function( input, min ) {
                var number = min - input.length;

                if ( 1 === number ) {
                    return ywcca_admin_i18n.i18n_input_too_short_1;
                }

                return ywcca_admin_i18n.i18n_input_too_short_n.replace( '%qty%', number );
            },
            formatInputTooLong: function( input, max ) {
                var number = input.length - max;

                if ( 1 === number ) {
                    return ywcca_admin_i18n.i18n_input_too_long_1;
                }

                return ywcca_admin_i18n.i18n_input_too_long_n.replace( '%qty%', number );
            },
            formatSelectionTooBig: function( limit ) {
                if ( 1 === limit ) {
                    return ywcca_admin_i18n.i18n_selection_too_long_1;
                }

                return ywcca_admin_i18n.i18n_selection_too_long_n.replace( '%qty%', limit );
            },
            formatLoadMore: function( pageNumber ) {
                return ywcca_admin_i18n.i18n_load_more;
            },
            formatSearching: function() {
                return ywcca_admin_i18n.i18n_searching;
            }
        };

        return formatString;
    }



 var  loadEnhancedSelect= function() {


        $( ':input.ywcca_enhanced_select' ).filter( ':not(.enhanced)' ).each( function() {
            loadSelect2($( this ));
        });

    }

    $('body').on('ywcca-enhanced-select-init', function () {


        loadEnhancedSelect();

    }).trigger( 'ywcca-enhanced-select-init' );

    $(document).on('widget-updated', function (e, widget) {

        loadEnhancedSelect();

    });


    $(document).on('widget-added', function (e, widget) {

        var input_hidden = widget.find('input.ywcca_enhanced_select.enhanced');
        input_hidden.removeClass('enhanced');

        var select2container = widget.find('div.select2-container');
        select2container.remove();

        if( input_hidden.length > 0 ) {

            input_hidden.each(function(){
                loadSelect2($(this));
            });

        }


    });

    function loadSelect2(widget){

        var select2_args = {
            allowClear:  widget.data( 'allow_clear' ) ? true : false,
            placeholder: widget.data( 'placeholder' ),
            minimumInputLength: widget.data( 'minimum_input_length' ) ? widget.data( 'minimum_input_length' ) : '3',
            escapeMarkup: function( m ) {
                return m;
            },
            ajax: {
                method: 'GET',
                url:         ywcca_admin_i18n.ajax_url,
                dataType:    'json',
                quietMillis: 250,
                data: function( term, page ) {

                    return {
                        term:     term,
                        action:   widget.data( 'action' ) ,
                        security: ywcca_admin_i18n.search_categories_nonce,
                        plugin: ywcca_admin_i18n.plugin_nonce
                    };
                },
                results: function( data, page ) {

                    var terms = [];
                    if ( data ) {
                        $.each( data, function( id, text ) {
                            terms.push( { id: id, text: text } );
                        });
                    }
                    return { results: terms };
                },
                cache: true
            }
        };

        if ( widget.data( 'multiple' ) === true ) {
            select2_args.multiple = true;
            select2_args.initSelection = function( element, callback ) {
                var data     = $.parseJSON( element.attr( 'data-selected' ) );
                var selected = [];

                $( element.val().split( "," ) ).each( function( i, val ) {
                    selected.push( { id: val, text: data[ val ] } );
                });
                return callback( selected );
            };
            select2_args.formatSelection = function( data ) {
                return '<div class="selected-option" data-id="' + data.id + '">' + data.text + '</div>';
            };
        } else {
            select2_args.multiple = false;
            select2_args.initSelection = function( element, callback ) {

                var data = {id: element.val(), text: element.attr( 'data-selected' )};
                return callback( data );
            };
        }

        select2_args = $.extend( select2_args, getEnhancedSelectFormatString() );


        widget.select2( select2_args ).addClass( 'enhanced' );

    }



    var style1_count_select      =   $('#ywcca_style_1_count'),
        style1_rect_bg           =   $('#ywcca_style1_back_rect_count'),
        style1_rect_bd           =   $('#ywcca_style1_border_rect_count'),
        style1_round_bg          =   $('#ywcca_style1_back_round_count'),
        style1_round_bd           =   $('#ywcca_style1_border_round_count'),

        style2_count_select      =   $('#ywcca_style_2_count'),
        style2_rect_bg           =   $('#ywcca_style2_back_rect_count'),
        style2_rect_bd           =   $('#ywcca_style2_border_rect_count'),
        style2_round_bg          =   $('#ywcca_style2_back_round_count'),
        style2_round_bd          =   $('#ywcca_style2_border_round_count'),

        style3_count_select      =   $('#ywcca_style_3_count'),
        style3_rect_bg           =   $('#ywcca_style3_back_rect_count'),
        style3_rect_bd           =   $('#ywcca_style3_border_rect_count'),
        style3_round_bg          =   $('#ywcca_style3_back_round_count'),
        style3_round_bd          =   $('#ywcca_style3_border_round_count'),

        style4_count_select      =   $('#ywcca_style_4_count'),
        style4_rect_bg           =   $('#ywcca_style4_back_rect_count'),
        style4_rect_bd           =   $('#ywcca_style4_border_rect_count'),
        style4_round_bg          =   $('#ywcca_style4_back_round_count'),
        style4_round_bd          =   $('#ywcca_style4_border_round_count');

        style1_rect_bg.parents( 'tr' ).hide();
        style1_rect_bd.parents( 'tr' ).hide();
        style1_round_bg.parents( 'tr').hide();
        style1_round_bd.parents( 'tr').hide();

        style2_rect_bg.parents( 'tr' ).hide();
        style2_rect_bd.parents( 'tr' ).hide();
        style2_round_bg.parents( 'tr').hide();
        style2_round_bd.parents( 'tr').hide();

        style3_rect_bg.parents( 'tr' ).hide();
        style3_rect_bd.parents( 'tr' ).hide();
        style3_round_bg.parents( 'tr').hide();
        style3_round_bd.parents( 'tr').hide();

        style4_rect_bg.parents( 'tr' ).hide();
        style4_rect_bd.parents( 'tr' ).hide();
        style4_round_bg.parents( 'tr').hide();
        style4_round_bd.parents( 'tr').hide();


        if( style1_count_select.val() == 'rect' ){
            style1_rect_bg.parents( 'tr' ).show();
            style1_rect_bd.parents( 'tr' ).show();
        }
        else if( style1_count_select.val() == 'round' ){
            style1_round_bg.parents( 'tr').show();
            style1_round_bd.parents( 'tr').show();
        }

        if( style2_count_select.val() == 'rect' ){
            style2_rect_bg.parents( 'tr' ).show();
            style2_rect_bd.parents( 'tr' ).show();
        }
        else if( style2_count_select.val() == 'round' ){
            style2_round_bg.parents( 'tr').show();
            style2_round_bd.parents( 'tr').show();
        }

        if( style3_count_select.val() == 'rect' ){
            style3_rect_bg.parents( 'tr' ).show();
            style3_rect_bd.parents( 'tr' ).show();
        }
        else if( style3_count_select.val() == 'round' ){
            style3_round_bg.parents( 'tr').show();
            style3_round_bd.parents( 'tr').show();
        }
        if( style4_count_select.val() == 'rect' ){
            style4_rect_bg.parents( 'tr' ).show();
            style4_rect_bd.parents( 'tr' ).show();
        }
        else if( style4_count_select.val() == 'round' ){
            style4_round_bg.parents( 'tr').show();
            style4_round_bd.parents( 'tr').show();
        }


        style1_count_select.on( 'change', function(){

            var t=  $(this);

            if( t.val() =='rect'){
                style1_rect_bg.parents( 'tr' ).show();
                style1_rect_bd.parents( 'tr' ).show();
                style1_round_bg.parents( 'tr').hide();
                style1_round_bd.parents( 'tr').hide();
            }
            else if (t.val() == 'round' ){
                style1_rect_bg.parents( 'tr' ).hide();
                style1_rect_bd.parents( 'tr' ).hide();
                style1_round_bg.parents( 'tr').show();
                style1_round_bd.parents( 'tr').show();
            }
            else
            {
                style1_rect_bg.parents( 'tr' ).hide();
                style1_rect_bd.parents( 'tr' ).hide();
                style1_round_bg.parents( 'tr').hide();
                style1_round_bd.parents( 'tr').hide();
            }

        } );

        style2_count_select.on( 'change', function(){

            var t=  $(this);

            if( t.val() =='rect'){
                style2_rect_bg.parents( 'tr' ).show();
                style2_rect_bd.parents( 'tr' ).show();
                style2_round_bg.parents( 'tr').hide();
                style2_round_bd.parents( 'tr').hide();
            }
            else if (t.val() == 'round' ){
                style2_rect_bg.parents( 'tr' ).hide();
                style2_rect_bd.parents( 'tr' ).hide();
                style2_round_bg.parents( 'tr').show();
                style2_round_bd.parents( 'tr').show();
            }
            else
            {
                style2_rect_bg.parents( 'tr' ).hide();
                style2_rect_bd.parents( 'tr' ).hide();
                style2_round_bg.parents( 'tr').hide();
                style2_round_bd.parents( 'tr').hide();
            }

        } );

        style3_count_select.on( 'change', function(){

            var t=  $(this);

            if( t.val() =='rect'){
                style3_rect_bg.parents( 'tr' ).show();
                style3_rect_bd.parents( 'tr' ).show();
                style3_round_bg.parents( 'tr').hide();
                style3_round_bd.parents( 'tr').hide();
            }
            else if (t.val() == 'round' ){
                style3_rect_bg.parents( 'tr' ).hide();
                style3_rect_bd.parents( 'tr' ).hide();
                style3_round_bg.parents( 'tr').show();
                style3_round_bd.parents( 'tr').show();
            }
            else
            {
                style3_rect_bg.parents( 'tr' ).hide();
                style3_rect_bd.parents( 'tr' ).hide();
                style3_round_bg.parents( 'tr').hide();
                style3_round_bd.parents( 'tr').hide();
            }

        } );

        style4_count_select.on( 'change', function(){

            var t=  $(this);

            if( t.val() =='rect'){
                style4_rect_bg.parents( 'tr' ).show();
                style4_rect_bd.parents( 'tr' ).show();
                style4_round_bg.parents( 'tr').hide();
                style4_round_bd.parents( 'tr').hide();
            }
            else if (t.val() == 'round' ){
                style4_rect_bg.parents( 'tr' ).hide();
                style4_rect_bd.parents( 'tr' ).hide();
                style4_round_bg.parents( 'tr').show();
                style4_round_bd.parents( 'tr').show();
            }
            else
            {
                style4_rect_bg.parents( 'tr' ).hide();
                style4_rect_bd.parents( 'tr' ).hide();
                style4_round_bg.parents( 'tr').hide();
                style4_round_bd.parents( 'tr').hide();
            }

        } );

});
