<?php

if( !defined( 'ABSPATH' ) )
    exit;

if( ! function_exists( 'json_search_categories') ) {

    function json_search_categories( $x = '', $taxonomy_types = array('product_cat') ) {

        if ( isset( $_GET['plugin'] ) && YWCCA_SLUG == $_GET['plugin'] ) {

            global $wpdb;
            $term = (string)urldecode( stripslashes( strip_tags( $_GET['term'] ) ) );
            $term = "%" . $term . "%";
            $query_cat = $wpdb->prepare("SELECT {$wpdb->terms}.term_id,{$wpdb->terms}.name, {$wpdb->terms}.slug
                          FROM {$wpdb->terms} INNER JOIN {$wpdb->term_taxonomy} ON {$wpdb->terms}.term_id = {$wpdb->term_taxonomy}.term_id
                          WHERE {$wpdb->term_taxonomy}.taxonomy IN ( %s ) AND {$wpdb->terms}.name LIKE %s",implode(',', $taxonomy_types), $term );

            $to_json = array();
            $product_categories = $wpdb->get_results(  $query_cat  );

            foreach ( $product_categories as $product_category ) {

                $to_json[$product_category->term_id] = "#" . $product_category->term_id . "-" . $product_category->name;
            }

            echo json_encode( $to_json );
            die();
        }

    }
}

if( !function_exists( 'json_search_posts' ) ){

    function json_search_posts( $x='', $post_type=array('post') ){

        if( isset( $_GET['plugin'] ) && YWCCA_SLUG == $_GET['plugin'] ){

            global $wpdb;

            $term = (string)urldecode( stripslashes( strip_tags( $_GET['term'] ) ) );
            $term = "%" . $term . "%";

            $query =    $wpdb->prepare("SELECT {$wpdb->posts}.ID, {$wpdb->posts}.post_title
                                        FROM {$wpdb->posts} WHERE {$wpdb->posts}.post_type IN (%s) AND {$wpdb->posts}.post_title LIKE %s", implode(",", $post_type),$term );

            $posts  =    $wpdb->get_results( $query );

            $to_json = array();

            foreach ( $posts as $post ) {

                $to_json[$post->ID] = $post->post_title;
            }

            echo json_encode( $to_json );
            die();
        }
    }
}

if( !function_exists( 'json_search_wc_categories' ) ){

    function json_search_wc_categories(){
        json_search_categories();

    }
}

add_action( 'wp_ajax_yith_json_search_wc_categories',  'json_search_wc_categories', 10 );

if( !function_exists( 'json_search_wp_categories' ) ){

    function json_search_wp_categories(){
        json_search_categories('', array('category') );

    }
}
add_action( 'wp_ajax_yith_json_search_wp_categories',  'json_search_wp_categories', 10 );


if( !function_exists( 'json_search_wp_posts' ) ){
    function json_search_wp_posts(){
        json_search_posts();

    }
}
add_action( 'wp_ajax_yith_json_search_wp_posts', 'json_search_wp_posts', 10 );


if( !function_exists( 'json_search_wp_pages' ) ){
    function json_search_wp_pages(){
        json_search_posts('', array('page') );

    }
}

add_action( 'wp_ajax_yith_json_search_wp_pages', 'json_search_wp_pages', 10 );


if( !function_exists( 'yith_get_navmenu' ) ){

    function yith_get_navmenu(){

        $nav_menus  =   wp_get_nav_menus();
        $options    =   array();

        foreach( $nav_menus as $menu )
            $options[$menu->term_id]    =   $menu->name;

        return $options;
    }
}