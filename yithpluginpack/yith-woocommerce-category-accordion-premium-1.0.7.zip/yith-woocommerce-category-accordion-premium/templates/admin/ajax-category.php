<?php
if( !defined( 'ABSPATH' ) )
    exit;

if( !class_exists( 'YWCCA_Ajax_Category' ) ){

    class YWCCA_Ajax_Category{


        public static function output( $option ){

            $placeholder    =   isset( $option['placeholder'] ) ? $option['placeholder'] : '';
            $multiple       =   isset( $option['multiple'] ) ?  $option['multiple'] : 'false';
            $action         =   isset( $option['ajax_action'] ) ? $option['ajax_action'] : '';
            $taxonomy       =   isset( $option['taxonomy'] )    ?   $option['taxonomy'] :   '';
            $category_ids =  explode( ',', get_option( $option['id']  ) ) ;

            $json_ids   =   array();

            foreach( $category_ids as $category_id ){

                $cat_name   =   get_term_by( 'id', $category_id, $taxonomy );
                if( !empty( $cat_name ) )
                   $json_ids[ $category_id ] = '#'.$cat_name->term_id.'-'.$cat_name->name;
            }

        ?>

            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="<?php echo esc_attr( $option['id'] ); ?>"><?php echo esc_html( $option['title'] ); ?></label>
                </th>
                <td class="forminp forminp-<?php echo sanitize_title( $option['type'] ) ?>">
                    <input type="hidden" style="width:80%;" class="ywcca_enhanced_select" id="<?php echo esc_attr( $option['id'] );?>" name="<?php echo esc_attr( $option['id'] );?>" data-placeholder="<?php echo $placeholder; ?>" data-action="<?php echo $action;?>" data-multiple="<?php echo $multiple;?>" data-selected="<?php echo esc_attr( json_encode( $json_ids ) ); ?>"
                           value="<?php echo implode( ',', array_keys( $json_ids ) ); ?>" />
                    <span class="description"><?php echo esc_html( $option['desc'] );?></span>
                </td>

            </tr>
<?php
        }
    }
}