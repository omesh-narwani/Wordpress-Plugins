<?php
if( !defined( 'ABSPATH' ) )
    exit;

if( !class_exists( 'YWCCA_Ajax_Post' ) ){

    class YWCCA_Ajax_Post{


        public static function output( $option ){

            $placeholder    =   isset( $option['placeholder'] ) ? $option['placeholder'] : '';
            $multiple       =   isset( $option['multiple'] ) ?  $option['multiple'] : 'false';
            $action         =   isset( $option['ajax_action'] ) ? $option['ajax_action'] : '';
          //  $taxonomy       =   isset( $option['taxonomy'] )    ?   $option['taxonomy'] :   '';
            $post_ids =  explode( ',', get_option( $option['id']  ) ) ;

            $json_ids   =   array();

            foreach( $post_ids as $post_id ){

                $post_name   =   get_post( $post_id );
                if( !empty( $post_name ) )
                    $json_ids[ $post_id ] = $post_name->post_title;
            }

            ?>

            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="<?php echo esc_attr( $option['id'] ); ?>"><?php echo esc_html( $option['title'] ); ?></label>
                </th>
                <td class="forminp forminp-<?php echo sanitize_title( $option['type'] ) ?>">
                    <input type="hidden" style="width:80%;" class="ywcca_enhanced_select" id="<?php echo esc_attr( $option['id'] );?>" name="<?php echo esc_attr( $option['id'] );?>" data-placeholder="<?php echo $placeholder; ?>" data-action="<?php echo $action;?>" data-multiple="<?php echo $multiple;?>" data-selected="<?php echo esc_attr( json_encode( $json_ids ) ); ?>"
                           value="<?php echo implode( ',', array_keys( $json_ids ) ); ?>" />
                    <span class="description"><?php echo esc_html( $option['desc'] );?></span>
                </td>

            </tr>
        <?php
        }
    }
}