== Changelog ==

= 1.0.7 = 14/12/2015

* Added: Compatibility with WooThumbs Awesome Product Imagery plugin
* Added: Compatibility with YITH WooCommerce Gift Card

= 1.0.6 = 09/12/2015

* Added: Compatibility with WooCommerce Thumbnail Input Quantities plugin
* Added: Compatibility with Wordpress 4.4
* Fixed: Change product image in loop when variation is selected
* Updated: Plugin Core

= 1.0.5 = 18/09/2015

* Fixed: Add to cart variation out-of-stock in shop page

= 1.0.4 = 17/09/2015

* Added: Blur effect for product attributes. Activate it on plugin settings page.
* Added: Compatibility with YITH Infinite Scrolling
* Added: Out of stock label in shop if selected variation is out of stock
* Added: ITA Translation
* Fixed: Default variation on shop page
* Fixed: Replace fragments after add to cart action
* Updated: Core plugin

= 1.0.3 = 12/08/2015

* Added: Compatibility with WooCommerce 2.4
* Added: WP 4.2.4 compatibility
* Added: Option for choose the form position in archive shop page
* Fixed: Multiple view cart on shop page
* Updated: Core plugin

= 1.0.2 = 25/06/2015

* Added: Ajax Navigation compatibility
* Fixed: Minor bugs

= 1.0.1 = 23/06/2015

* Updated: plugin core
* Fixed: minor bugs
* Fixed: js error

= 1.0.0 =

* Initial release