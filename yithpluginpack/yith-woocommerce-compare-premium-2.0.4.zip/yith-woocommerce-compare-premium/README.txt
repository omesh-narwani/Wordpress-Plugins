== Changelog ==

= 2.0.4 =

* Added: Compatibility with WooCommerce 2.5 RC.
* Added: Translation on slovak language
* Fixed: Multiple custom product attributes have same values.
* Fixed: Save option with WooCommerce version 2.3.x
* Updated: Plugin template yith-compare-related.php
* Updated: Plugin template yith-compare-table.php
* Updated: Change all ajax call from admin-ajax to wc-ajax.
* Updated: Plugin Core

= 2.0.3 =

* Added: Ability to compare also custom product attributes 
* Added: Shortocode to add compare table with custom products
* Added: Admin tab where you can build your own compare shortcode
* Added: Choose to highlights the attributes that have different value
* Updated: yith-compare-table template to version 2.0.3
* Updated: Chnaged textdomain to yith-wcmp to yith-woocommerce-compare
* Updated: Language file
* Updated: PLugin Core

= 2.0.2 =

* Added: Compatibility with WooCommerce 2.4.x
* Added: Compatibility with WordPress 4.3
* Updated: PLugin Core

= 2.0.1 =

* Fixed: product without category and category navigation
* Updated: main plugin js

= 2.0.0 =

* Initial release