=== YITH WooCommerce Coupon Email System ===

Contributors: yithemes
Tags: woocommerce, products, themes, yit, yith, e-commerce, shop, coupon, email, reward, birthday, discount
Requires at least: 4.0
Tested up to: 4.4.2
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= 1.1.0 =

* Fixed: coupon expiry date based on website timezone
* Fixed: birthday coupon based on website timezone

= 1.0.9 =

* Added: compatibility with WooCommerce 2.5

= 1.0.8 =

* Removed: jQuery UI calendar, in favor of a formatted input, to avoid display problems

= 1.0.7 =

* Fixed: get send status on test email

= 1.0.6 =

* New feature: birth date format
* Tweak: filters for adding custom date formats
* Fixed: birth date field compatibility with themes' widgets

= 1.0.5 =

* New feature: compatibility with YITH WooCommerce Multi Vendor
* New feature: Automated removal of expired coupons created by the plugin
* Updated: language file
* Tweak: birthday field on WooCommerce registration form
* Fixed: "coupon on a specific number of days from the last purchase" bug
* Added: new file class-ywces-custom-send.php
* Added: new file class-yith-wc-custom-textarea.php
* Added: new file class-yith-wc-custom-product-select.php
* Added: new file class-ywces-custom-collapse.php.php
* Added: new file class-ywces-custom-coupon.php
* Added: new file class-ywces-custom-mailskin.php
* Added: new file class-ywces-custom-table.php
* Removed: old file custom-send.php
* Removed: old file custom-textarea.php
* Removed: old file custom-select.php.php
* Removed: old file custom-collapse.php
* Removed: old file custom-coupon.php
* Removed: old file custom-mailskin.php
* Removed: old file custom-table.php

= 1.0.4 =

* Updated: changed text domain from ywces to yith-woocommerce-coupon-email-system
* Updated: changed all language file for the new text domain
* Fixed: static coupon assignment bug

= 1.0.3 =

* Updated: plugin core framework

= 1.0.2 =

* Fixed: messages on required fields

= 1.0.1 =

* New feature: compatibility with YITH WooCommerce Email Templates
* Updated: Plugin core framework
* Fixed: minor bugs

= 1.0.0 =

* Initial release