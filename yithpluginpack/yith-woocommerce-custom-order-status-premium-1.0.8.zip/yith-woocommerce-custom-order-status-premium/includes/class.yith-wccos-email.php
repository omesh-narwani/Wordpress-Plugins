<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WCCOS_Email' ) ) {
    class YITH_WCCOS_Email extends WC_Emails {
        var $from_name, $from_email, $custom_message, $display_order_info, $order;

        function __construct($order, $status_name, $status_slug, $heading, $subject, $from_name, $from_email, $custom_message, $display_order_info, $custom_email_address='') {
            $this->id               = "{$status_slug}_email";
            $this->title            = $status_name ;
            $this->description      = sprintf( __( "This email is sent when order status is set to %s", 'yith-wccos' ), $status_name);

            $this->heading          = stripslashes($heading);
            $this->subject          = stripslashes($subject);

            //Set the email type to html for current requirements, plain text template is also available if needed later
            $this->email_type = 'html';

            $this->from_name = stripslashes($from_name);
            $this->from_email = $from_email;

            $this->display_order_info = $display_order_info;
            $this->custom_email_address = $custom_email_address;

            $this->order = $order;

            $this->custom_message = stripslashes(nl2br( $this->apply_shortcode( $custom_message, $order->id ) ) );

            parent::__construct();
        }

        function apply_shortcode( $content , $order_id){
            $order = new WC_Order( $order_id );
            
            $shortcode = array(
                '{customer_first_name}'    => $order->billing_first_name,
                '{customer_last_name}'     => $order->billing_last_name,
                '{order_date}'             => date_i18n( wc_date_format(), strtotime( $order->order_date ) ),
                '{order_number}'           => $order->get_order_number(),
                '{order_value}'            => $order->order_total,
                '{billing_address}'        => $order->get_formatted_billing_address(),
                '{shipping_address}'       => $order->get_formatted_shipping_address()
                );

            $cont = strtr( $content, $shortcode );
            return $cont;
        }

        function get_from_address() {
            return sanitize_email( $this->from_email );
        }

        function get_from_name() {
            return wp_specialchars_decode(stripslashes($this->from_name), ENT_QUOTES);
        }

        public function get_content_html() {
            ob_start();
            extract(array(
                'order'         => $this->order,
                'email_heading' => $this->heading,
                'custom_message'   => $this->custom_message,
                'display_order_info'=> $this->display_order_info
            ) );
            include YITH_WCCOS_TEMPLATE_PATH . '/custom_status_email_template.php';
            return ob_get_clean();
        }
    }

}