=== Version 1.0.4 ===

* Added: Compatibility with YITH WooCommerce One Click Checkout
* Added: Compatibility with YITH WooCommerce Stripe
* Added: Compatibility with WPML
* Added: Option for choose the default my account tab
* Updated: Language file .pot
* Updated: Plugin Core

=== Version 1.0.3 ===

* Added: Compatibility to WooCommerce 2.5 RC.
* Fixed: Avatar issue on woocommerce review section.
* Fixed: Avatar missing on admin wordpress settings.
* Updated: Language file .pot
* Updated: Plugin Core

=== Version 1.0.2 ===

* Fixed: Missing stripslashes for custom endpoint content.

=== Version 1.0.1 ===

* Fixed: Custom content for dashboard endpoint overwrite other endpoints.
* Updated: Plugin Core

=== Version 1.0.0 ===

 * Initial Release