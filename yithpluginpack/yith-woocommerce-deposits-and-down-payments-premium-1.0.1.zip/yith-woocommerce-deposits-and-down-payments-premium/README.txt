=== YITH WooCommerce Deposits and Down Payments ===

Contributors: yithemes
Tags:  deposits, deposits and down payments, down payments, down payment, deposit, woocommerce deposits, woocommerce down payments, rate, amount, full payment, balance, backorder, sales, woocommerce, wp e-commerce
Requires at least: 4.0.0
Tested up to: 4.3.1
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Documentation: http://yithemes.com/docs-plugins/yith-woocommerce-deposits-and-down-payments

== Changelog ==

= 1.0.1 =

* Initial release