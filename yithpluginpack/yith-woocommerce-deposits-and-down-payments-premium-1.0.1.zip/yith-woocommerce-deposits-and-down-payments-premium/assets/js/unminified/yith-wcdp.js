jQuery(document).ready(function($){
    var payment_type_radio = $('input[name="payment_type"]'),
        deposit_shipping = $('.yith-wcdp-deposit-shipping');

    $( '.variations_form' ).on( 'found_variation', function(ev, variation){
        var t = $(this),
            deposit_options = t.find( '.yith-wcdp-single-add-to-cart-fields'),
            deposit_full_price_placeholder = deposit_options.find('.full-price'),
            deposit_price_placeholder = deposit_options.find('.deposit-price'),
            deposit_type = deposit_options.data('deposit-type'),
            deposit_amount = deposit_options.data('deposit-amount'),
            deposit_rate = deposit_options.data('deposit-rate'),
            price_template = deposit_options.data('price-template'),
            deposit_shipping = t.find('.yith-wcdp-deposit-shipping'),
            deposit_shipping_form = t.find('.yith-wcdp-shipping-form'),
            full_price = 0,
            full_price_html = '',
            deposit_price = 0,
            deposit_price_html = '';

        if( deposit_options.length ) {
            full_price = variation.display_price.toFixed(2);
            full_price_html = '( ' + price_template.replace('0', full_price) + ' )';

            if (deposit_type == 'amount') {
                deposit_price = Math.min( full_price, deposit_amount ).toFixed(2);
            }
            else {
                deposit_price = full_price * deposit_rate / 100;
                deposit_price = Math.min( full_price, deposit_price ).toFixed(2);
            }

            deposit_price_html = '( ' + price_template.replace('0', deposit_price) + ' )';

            deposit_full_price_placeholder.html(full_price_html);
            deposit_price_placeholder.html(deposit_price_html);

            if (deposit_shipping.length) {
                $.ajax({
                    beforeSend: function () {
                        deposit_shipping.block({
                            message   : null,
                            overlayCSS: {
                                background: '#fff',
                                opacity   : 0.6
                            }
                        });
                    },
                    complete  : function () {
                        deposit_shipping.unblock();
                    },
                    data      : {
                        product_id: variation.variation_id,
                        qty       : t.find('input[name="quantity"]').val(),
                        action    : yith_wcdp.actions.calculate_shipping
                    },
                    dataType  : 'json',
                    method    : 'post',
                    success   : function (data) {
                        deposit_shipping_form.find('table').html(data.template);
                    },
                    url       : yith_wcdp.ajax_url
                })
            }
        }
    }).find('select:eq(0)').change();

    if( payment_type_radio.length ) {
        payment_type_radio.on('change', function () {
            var t = $(this),
                val = t.val(),
                parent = t.parents('.yith-wcdp'),
                deposit_shipping = parent.find('.yith-wcdp-deposit-shipping');

            if (val == 'deposit') {
                deposit_shipping.slideDown();
            }
            else {
                deposit_shipping.slideUp();
            }
        }).change();
    }
    else if( deposit_shipping.length ){
        deposit_shipping.slideDown();
    }
});