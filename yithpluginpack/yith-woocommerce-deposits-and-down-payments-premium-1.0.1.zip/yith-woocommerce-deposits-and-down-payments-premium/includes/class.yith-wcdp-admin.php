<?php
/**
 * Admin class
 *
 * @author Your Inspiration Themes
 * @package YITH WooCommerce Deposits and Down Payments
 * @version 1.0.0
 */

/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined( 'YITH_WCDP' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WCDP_Admin' ) ) {
	/**
	 * WooCommerce Deposits and Down Payments Admin
	 *
	 * @since 1.0.0
	 */
	class YITH_WCDP_Admin {

		/**
		 * Single instance of the class
		 *
		 * @var \YITH_WCDP_Admin
		 * @since 1.0.0
		 */
		protected static $instance;

		/**
		 * Docs url
		 *
		 * @var string Official documentation url
		 * @since 1.0.0
		 */
		public $doc_url = 'http://yithemes.com/docs-plugins/yith-woocommerce-deposits-and-down-payments/';

		/**
		 * Premium landing url
		 *
		 * @var string Premium landing url
		 * @since 1.0.0
		 */
		public $premium_landing_url = 'http://yithemes.com/themes/plugins/yith-woocommerce-deposits-and-down-payments/';

		/**
		 * Live demo url
		 * @var string Live demo url
		 * @since 1.0.0
		 */
		public $live_demo_url = 'http://plugins.yithemes.com/yith-woocommerce-deposits-and-down-payments/';

		/**
		 * List of available tab for deposit panel
		 *
		 * @var array
		 * @access public
		 * @since 1.0.0
		 */
		public $available_tabs = array();

		/**
		 * Constructor method
		 *
		 * @return \YITH_WCDP_Admin
		 * @since 1.0.0
		 */
		public function __construct() {
			// sets available tab
			$this->available_tabs = apply_filters( 'yith_wcdp_available_admin_tabs', array(
				'settings' => __( 'Settings', 'yith-wcdp' ),
				'premium' => __( 'Premium Version', 'yith-wcdp' )
			) );

			// register plugin panel
			add_action( 'admin_menu', array( $this, 'register_panel' ), 5 );
			add_action( 'yith_wcdp_premium_tab', array( $this, 'print_premium_tab' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );

			// register product tabs
			add_filter( 'woocommerce_product_data_tabs', array( $this, 'register_product_tabs' ) );
			add_action( 'woocommerce_product_data_panels', array( $this, 'print_product_deposit_tabs' ) );

			// save tabs options
			add_action( 'woocommerce_process_product_meta_simple', array( $this, 'save_product_deposit_tabs' ), 10, 1 );
			add_action( 'woocommerce_process_product_meta_variable', array( $this, 'save_product_deposit_tabs' ), 10, 1 );
			add_action( 'woocommerce_process_product_meta_grouped', array( $this, 'save_product_deposit_tabs' ), 10, 1 );

			// admin order view handling
			add_filter( 'request', array( $this, 'filter_order_list' ), 10, 1 );
			add_filter( 'manage_shop_order_posts_columns', array( $this, 'shop_order_columns' ), 15 );
			add_action( 'manage_shop_order_posts_custom_column', array( $this, 'render_shop_order_columns' ) );
			add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ), 30 );
			add_filter( 'woocommerce_order_get_items', array( $this, 'filter_order_items' ), 10, 2 );
			add_filter( 'woocommerce_hidden_order_itemmeta', array( $this, 'hide_order_item_meta' ) );
			add_action( 'woocommerce_before_order_itemmeta', array( $this, 'print_full_payment_order_itemmeta' ), 10, 2 );

			// register plugin links & meta row
			add_filter( 'plugin_action_links_' . YITH_WCDP_INIT, array( $this, 'action_links' ) );
			add_filter( 'plugin_row_meta', array( $this, 'add_plugin_meta' ), 10, 2 );
		}

		/* === HELPER METHODS === */

		/**
		 * Return array of screen ids for affiliate plugin
		 *
		 * @return mixed Array of available screens
		 * @since 1.0.0
		 */
		public function get_screen_ids() {
			$base = sanitize_title( __( 'YIT Plugins', 'yith-plugin-fw' ) );

			$screen_ids = array(
				$base . '_page_yith_wcdp_panel'
			);

			return apply_filters( 'yith_wcdp_screen_ids', $screen_ids );
		}

		/* === PANEL METHODS === */

		/**
		 * Register panel
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function register_panel() {
			$args = array(
				'create_menu_page' => true,
				'parent_slug'   => '',
				'page_title'    => __( 'Deposits and Down Payments', 'yith-wcdp' ),
				'menu_title'    => __( 'Deposits and Down Payments', 'yith-wcdp' ),
				'capability'    => 'manage_options',
				'parent'        => '',
				'parent_page'   => 'yit_plugin_panel',
				'page'          => 'yith_wcdp_panel',
				'admin-tabs'    => $this->available_tabs,
				'options-path'  => YITH_WCDP_DIR . 'plugin-options'
			);

			/* === Fixed: not updated theme  === */
			if( ! class_exists( 'YIT_Plugin_Panel_WooCommerce' ) ) {
				require_once( YITH_WCDP_DIR . 'plugin-fw/lib/yit-plugin-panel-wc.php' );
			}

			$this->_panel = new YIT_Plugin_Panel_WooCommerce( $args );
		}

		/**
		 * Print premium tab
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function print_premium_tab() {
			include( YITH_WCDP_DIR . 'templates/admin/deposits-premium-panel.php' );
		}

		/**
		 * Enqueue admin side scripts
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function enqueue() {
			// enqueue scripts
			$screen = get_current_screen();
			$path = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? 'unminified/' : '';
			$suffix = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? '' : '.min';

			$scripts_screens = array_merge(
				$this->get_screen_ids(),
				array(
					'edit-shop_order',
					'shop_order',
					'product'
				)
			);

			if( in_array( $screen->id, $scripts_screens ) ) {
				wp_register_script( 'yith-wcdp', YITH_WCDP_URL . 'assets/js/admin/' . $path . 'yith-wcdp' . $suffix . '.js', array( 'jquery' ), false, true );
				do_action( 'yith_wcdp_before_admin_script_enqueue' );
				wp_enqueue_script( 'yith-wcdp' );

				wp_register_style( 'yith-wcdp', YITH_WCDP_URL . 'assets/css/admin/yith-wcdp.css' );
				do_action( 'yith_wcdp_before_admin_style_enqueue' );
				wp_enqueue_style( 'yith-wcdp' );
			}
		}

		/* == PRODUCT TABS METHODS === */

		/**
		 * Register product tabs for deposit plugin
		 *
		 * @param $tabs array Registered tabs
		 * @return array Filtered array of registered tabs
		 * @since 1.0.0
		 */
		public function register_product_tabs( $tabs ) {
			$tabs = array_merge(
				$tabs,
				array(
					'deposit' => array(
						'label' => __( 'Deposit', 'yith-wcdp' ),
						'target' => 'yith_wcdp_deposit_tab',
						'class' => array( 'hide_if_grouped', 'hide_if_external' )
					)
				)
			);

			return $tabs;
		}

		/**
		 * Print product tab for deposit plugin
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function print_product_deposit_tabs( $post_id ) {
			global $post;

			// define variables to use in template
			$enable_deposit = get_post_meta( $post->ID, '_enable_deposit', true );
			$enable_deposit = ! empty( $enable_deposit ) ? $enable_deposit : 'default';

			$force_deposit = get_post_meta( $post->ID, '_force_deposit', true );
			$force_deposit = ! empty( $force_deposit ) ? $force_deposit : 'default';

			include( YITH_WCDP_DIR . 'templates/admin/product-deposit-tab.php' );
		}

		/**
		 * Save deposit tab options
		 *
		 * @param $post_id int Current product id
		 * @return void
		 * @since 1.0.0
		 */
		public function save_product_deposit_tabs( $post_id ) {
			$enable_deposit = isset( $_POST['_enable_deposit'] ) ? trim( $_POST['_enable_deposit'] ) : 'default';
			$force_deposit = isset( $_POST['_force_deposit'] ) ? trim( $_POST['_force_deposit'] ) : 'default';

			update_post_meta( $post_id, '_enable_deposit', $enable_deposit );
			update_post_meta( $post_id, '_force_deposit', $force_deposit );
		}

		/* === PLUGIN LINK METHODS === */

		/**
		 * Get the premium landing uri
		 *
		 * @since   1.0.0
		 * @author  Andrea Grillo <andrea.grillo@yithemes.com>
		 * @return  string The premium landing link
		 */
		public function get_premium_landing_uri(){
			return defined( 'YITH_REFER_ID' ) ? $this->premium_landing_url . '?refer_id=' . YITH_REFER_ID : $this->premium_landing_url;
		}

		/**
		 * Add plugin action links
		 *
		 * @param mixed $links Plugins links array
		 *
		 * @return array Filtered link array
		 * @since 1.0.0
		 */
		public function action_links( $links ) {
			$plugin_links = array(
				'<a href="' . admin_url( 'admin.php?page=yith_wcdp_panel&tab=settings' ) . '">' . __( 'Settings', 'yith-wcdp' ) . '</a>'
			);

			if( ! defined( 'YITH_WCDP_PREMIUM_INIT' ) ){
				$plugin_links[] = '<a target="_blank" href="' . $this->get_premium_landing_uri() . '">' . __( 'Premium Version', 'yith-wcdp' ) . '</a>';
				$plugin_links[] = '<a target="_blank" href="' . $this->live_demo_url . '">' . __( 'Live Demo', 'yith-wcdp' ) . '</a>';
			}

			return array_merge( $links, $plugin_links );
		}

		/**
		 * Adds plugin row meta
		 *
		 * @param $plugin_meta array Array of unfiltered plugin meta
		 * @param $plugin_file string Plugin base file path
		 *
		 * @return array Filtered array of plugin meta
		 * @since 1.0.0
		 */
		public function add_plugin_meta( $plugin_meta, $plugin_file ){
			if ( $plugin_file == plugin_basename( YITH_WCDP_DIR . 'init.php' ) ) {
				// documentation link
				$plugin_meta['documentation'] = '<a target="_blank" href="' . $this->doc_url . '">' . __( 'Plugin Documentation', 'yith-wcdp' ) . '</a>';
			}

			return $plugin_meta;
		}

		/* === ORDER VIEW METHODS === */

		/**
		 * Only show parent orders
		 *
		 * @param  array $request Current request
		 * @return array          Modified request
		 * @since  1.0.0
		 */
		public function filter_order_list( $query ) {
			global $typenow;

			if ( 'shop_order' == $typenow ) {
				$query['post_parent'] = 0;
				$query = apply_filters( "yith_wcdp_{$typenow}_request", $query );
			}

			return $query;
		}

		/**
		 * Add and reorder order table column
		 *
		 * @param $order_columns array The order table column
		 * @return string The label value
		 * @since 1.0.0
		 */
		public function shop_order_columns( $order_columns ) {
			$suborder      = array( 'suborder' => _x( 'Suborders', 'Admin: column heading in "Orders" table', 'yith-wcdp' ) );
			$ref_pos       = array_search( 'order_title', array_keys( $order_columns ) );
			$order_columns = array_slice( $order_columns, 0, $ref_pos + 1, true ) + $suborder + array_slice( $order_columns, $ref_pos + 1, count( $order_columns ) - 1, true );

			return $order_columns;
		}

		/**
		 * Output custom columns for coupons
		 *
		 * @param  string $column
		 */
		public function render_shop_order_columns( $column ) {
			global $post, $the_order;

			if ( empty( $the_order ) || $the_order->id != $post->ID ) {
				$_the_order = wc_get_order( $post->ID );
			}
			else {
				$_the_order = $the_order;
			}

			$suborder_ids = YITH_WCDP_Suborders()->get_suborder( $_the_order->id );

			switch ( $column ) {
				case 'suborder' :
					if ( $suborder_ids ) {
						foreach ( $suborder_ids as $suborder_id ) {
							$suborder = wc_get_order( $suborder_id );
							$items = $suborder->get_items( 'line_item' );
							$order_uri = esc_url( 'post.php?post=' . absint( $suborder_id ) . '&action=edit' );
							$items_to_string = array();

							if( ! empty( $items ) ){
								foreach( $items as $item ){
									$items_to_string[] = $item['name'];
								}
							}

							$items_to_string = implode( ' | ', $items_to_string );

							printf( '<mark class="%s tips" data-tip="%s">%s</mark> <strong><a href="%s">#%s</a></strong> <small>(%s)</small><br/>',
								sanitize_title( $suborder->get_status() ),
								wc_get_order_status_name( $suborder->get_status() ),
								wc_get_order_status_name( $suborder->get_status() ),
								$order_uri,
								$suborder_id,
								$items_to_string
							);
						}
					}
					else {
						echo '<span class="na">&ndash;</span>';
					}

					break;
				case 'order_status' :

					$column = '';

					if( $suborder_ids ){
						$count_uncompleted = 0;
						foreach ( $suborder_ids as $suborder_id ) {

							$suborder = wc_get_order( $suborder_id );

							if( ! in_array( $suborder->get_status(), array( 'completed', 'processing', 'cancelled', 'refunded' ) ) ){
								$count_uncompleted++;
							}
						}

						if( $count_uncompleted ){
							$column .= '<span class="pending-count">' . $count_uncompleted . '</span>';
						}
					}

					echo $column;

					break;
			}
		}

		/**
		 * Add suborder metaboxes for Deposit order
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function add_meta_boxes() {
			global $post;

			if( ! $post ){
				return;
			}

			$has_suborder   = YITH_WCDP_Suborders()->get_suborder( absint( $post->ID ) );
			$is_suborder    = wp_get_post_parent_id( absint( $post->ID ) );

			if( $has_suborder ){
				$metabox_suborder_description = _x( 'Suborders', 'Admin: Single order page. Suborder details box', 'yith-wcdp' ) . ' <span class="tips" data-tip="' . esc_attr__( 'Note: from this box you can monitor the status of suborders concerning full payments.', 'yith-wcdp' ) . '">[?]</span>';
				add_meta_box( 'yith-wcdp-woocommerce-suborders', $metabox_suborder_description, array( $this, 'render_metabox_output' ), 'shop_order', 'side', 'core', array( 'metabox' => 'suborders' ) );
			}
			elseif( $is_suborder ){
				$metabox_parent_order_description = _x( 'Parent order', 'Admin: Single order page. Info box with parent order details', 'yith-wcdp' );
				add_meta_box( 'yith-wcdp-woocommerce-parent-order', $metabox_parent_order_description, array( $this, 'render_metabox_output' ), 'shop_order', 'side', 'high', array( 'metabox' => 'parent-order' ) );
			}
		}

		/**
		 * Output the suborder metaboxes
		 *
		 * @param $post     \WP_Post The post object
		 * @param $param    mixed Callback args
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function render_metabox_output( $post, $param ) {
			switch ( $param['args']['metabox'] ) {
				case 'suborders':
					$suborder_ids = YITH_WCDP_Suborders()->get_suborder( absint( $post->ID ) );
					echo '<ul class="suborders-list single-orders">';
					foreach ( $suborder_ids as $suborder_id ) {
						$suborder = wc_get_order( absint( $suborder_id ) );
						$items = $suborder->get_items( 'line_item' );
						$suborder_uri = esc_url( 'post.php?post=' . absint( $suborder_id ) . '&action=edit' );
						$items_to_string = array();

						if( ! empty( $items ) ){
							foreach( $items as $item ){
								$items_to_string[] = $item['name'];
							}
						}

						$items_to_string = implode( ' | ', $items_to_string );

						echo '<li class="suborder-info">';
						printf( '<mark class="%s tips" data-tip="%s">%s</mark> <strong><a href="%s">#%s</a></strong> <small>(%s)</small><br/>',
							sanitize_title( $suborder->get_status() ),
							wc_get_order_status_name( $suborder->get_status() ),
							wc_get_order_status_name( $suborder->get_status() ),
							$suborder_uri,
							$suborder_id,
							$items_to_string
						);
						echo '<li>';
					}
					echo '</ul>';
					break;

				case 'parent-order':
					$parent_order_id    = wp_get_post_parent_id( absint( $post->ID ) );
					$parent_order_uri   = esc_url( 'post.php?post=' . absint( $parent_order_id ) . '&action=edit' );
					printf( '<a href="%s">&#8592; %s</a>', $parent_order_uri,  _x( 'Back to main order', 'Admin: single order page. Link to parent order', 'yith-wcdp' ) );
					break;
			}
		}

		/**
		 * Filter order items to add label for deposit orders
		 *
		 * @param $items mixed Order items array
		 * @return mixed Filtered array of roder items
		 * @since 1.0.0
		 */
		public function filter_order_items( $items, $order ) {
			if( ! empty( $items ) ){
				foreach( $items as &$item ){
					if( isset( $item['item_meta']['_deposit'][0] ) && $item['item_meta']['_deposit'][0] ){
						$item['name'] = apply_filters( 'yith_wcdp_deposit_label', __( 'Deposit', 'yith-wcdp' ) ) . ': ' . $item['name'];
					}
					elseif( isset( $item['item_meta']['_full_payment'][0] ) && $item['item_meta']['_full_payment'][0] ){
						$item['name'] = apply_filters( 'yith_wcdp_full_payment_label', __( 'Balance', 'yith-wcdp' ) ) . ': ' . $item['name'];
					}
				}
			}



			return $items;
		}

		/**
		 * Hide plugin item meta, when not in debug mode
		 *
		 * @param $hidden_items mixed Array of meta to hide on admin side
		 * @return mixed Filtered array of meta to hide
		 * @since 1.0.0
		 */
		public function hide_order_item_meta( $hidden_items ) {
			if( ! ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ){
				$hidden_items = array_merge(
					$hidden_items,
					array(
						'_deposit',
						'_deposit_type',
						'_deposit_amount',
						'_deposit_rate',
						'_deposit_value',
						'_deposit_balance',
						'_deposit_shipping_method',
						'_full_payment',
						'_full_payment_id',
						'_deposit_id'
					)
				);
			}

			return $hidden_items;
		}

		/**
		 * Print Full Payment link to before order item meta section of order edit admin page
		 *
		 * @param $item_id int Current order item id
		 * @param $item mixed Current item data
		 * @return void
		 * @since 1.0.0
		 */
		public function print_full_payment_order_itemmeta( $item_id, $item ) {
			if( isset( $item['item_meta']['_deposit'][0] ) && $item['item_meta']['_deposit'][0] ){
				$suborder = wc_get_order( $item['item_meta']['_full_payment_id'][0] );

				if( ! $suborder ){
					return;
				}
				?>
				<div class="yith-wcdp-full-payment">
					<small><a href="<?php echo get_edit_post_link( $suborder->id )?>"><?php printf( '%s: #%d', __( 'Full payment order', 'yith-wcdp' ), $suborder->id ) ?></a></small>
				</div>
				<?php
			}
		}

		/**
		 * Returns single instance of the class
		 *
		 * @return \YITH_WCDP_Admin
		 * @since 1.0.0
		 */
		public static function get_instance(){
			if( is_null( self::$instance ) ){
				self::$instance = new self;
			}

			return self::$instance;
		}
	}
}

/**
 * Unique access to instance of YITH_WCDP_Admin class
 *
 * @return \YITH_WCDP_Admin
 * @since 1.0.0
 */
function YITH_WCDP_Admin(){
	return YITH_WCDP_Admin::get_instance();
}
