<?php
/**
 * Frontend class premium
 *
 * @author Your Inspiration Themes
 * @package YITH WooCommerce Deposits and Down Payments
 * @version 1.0.0
 */

/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined( 'YITH_WCDP' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WCDP_Frontend_Premium' ) ) {
	/**
	 * WooCommerce Deposits and Down Payments Frontend Premium
	 *
	 * @since 1.0.0
	 */
	class YITH_WCDP_Frontend_Premium extends YITH_WCDP_Frontend {

		/**
		 * Single instance of the class
		 *
		 * @var \YITH_WCDP_Frontend
		 * @since 1.0.0
		 */
		protected static $instance;

		/**
		 * Constructor.
		 *
		 * @return \YITH_WCDP_Frontend_Premium
		 * @since 1.0.0
		 */
		public function __construct() {
			parent::__construct();

			add_action( 'yith_wcdp_before_my_deposits_table', array( $this, 'print_expired_suborders_notice' ), 10, 1 );

			// Labels filters
			add_filter( 'yith_wcdp_pay_deposit_label', array( $this, 'filter_pay_deposit_label' ) );
			add_filter( 'yith_wcdp_pay_full_amount_label', array( $this, 'filter_pay_full_amount_label' ) );
			add_filter( 'yith_wcdp_partially_paid_status_label', array( $this, 'filter_partially_paid_status' ) );
			add_filter( 'yith_wcdp_full_price_filter', array( $this, 'filter_full_price_label' ) );
			add_filter( 'yith_wcdp_balance_filter', array( $this, 'filter_balance_label' ) );

			// On location balance orders note
			add_action( 'woocommerce_order_details_after_order_table', array( $this, 'print_on_location_notice' ), 10, 1 );

			// Additional product notes
			add_action( 'init', array( $this, 'add_additional_product_note' ), 15 );
		}

		/* === GENERAL FRONTEND METHODS === */

		/**
		 * Print fields before single add to cart, to let user add to cart deposit
		 *
		 * @param $echo bool Whether to return template, or echo it
		 * @return string Return template if param $echo is set to true
		 * @since 1.0.0
		 */
		public function print_single_add_deposit_to_cart_field( $echo = true ) {
			global $post;
			$template = '';

			if( ! is_product() ){
				return $template;
			}

			// retrieve product
			$product = wc_get_product( $post->ID );

			//product options
			$deposit_enabled = YITH_WCDP()->is_deposit_enabled_on_product( $product->id );

			$deposit_forced = YITH_WCDP()->is_deposit_mandatory( $product->id );

			$deposit_type = YITH_WCDP_Premium()->get_deposit_type( $product->id );
			$deposit_amount = YITH_WCDP_Premium()->get_deposit_amount( $product->id );
			$deposit_rate = YITH_WCDP_Premium()->get_deposit_rate( $product->id );
			$deposit_value = 0;

			if( $deposit_type == 'rate' ){
				$deposit_value = $product->get_price() * (double) $deposit_rate / 100;
			}
			elseif( $deposit_type == 'amount' ){
				$deposit_value = $deposit_amount;
			}

			$deposit_value = min( $deposit_value, $product->get_price() );

			if( ! $deposit_enabled ){
				return $template;
			}

			YITH_WCDP_Suborders()->create_support_cart();
			WC()->cart->add_to_cart( $product->id, 1 );
			WC()->cart->calculate_shipping();

			$deposit_shipping = get_option( 'yith_wcdp_general_deposit_shipping', 'let_user_choose' );
			$let_user_choose_shipping = $deposit_shipping == 'let_user_choose';

			$args = array(
				'deposit_enabled' => $deposit_enabled,
				'deposit_forced' => $deposit_forced,
				'deposit_type' => $deposit_type,
				'deposit_amount' => $deposit_amount,
				'deposit_rate' => $deposit_rate,
				'deposit_value' => $deposit_value,
				'needs_shipping' => WC()->cart->needs_shipping(),
				'show_shipping_form' => $let_user_choose_shipping
			);

			ob_start();

			yith_wcdp_get_template( 'single-add-deposit-to-cart.php', $args );

			$template = ob_get_clean();

			YITH_WCDP_Suborders()->restore_original_cart();

			if( $echo ){
				echo $template;
			}

			return $template;
		}

		/**
		 * Print notice to warning user some deposits have expired
		 *
		 * @param $order_id int Current order id
		 * @return void
		 * @since 1.0.0
		 */
		public function print_expired_suborders_notice( $order_id ) {
			$suborders = YITH_WCDP_Suborders()->get_suborder( $order_id );
			$expired_suborders = array();

			if( ! empty( $suborders ) ){
				foreach( $suborders as $suborder_id ){
					$has_expired = get_post_meta( $suborder_id, '_has_deposit_expired', true );

					if( $has_expired ){
						$expired_suborders[] = $suborder_id;
					}
				}
			}

			if( ! empty( $expired_suborders ) ){
				$orders_link = '';
				$first = true;

				foreach( $expired_suborders as $suborder_id ){
					if( ! $first ){
						$orders_link .= ', ';
					}

					// retrieve order url and append to orders_link string
					$view_order_url = apply_filters( 'woocommerce_get_view_order_url', wc_get_endpoint_url( 'view-order', $suborder_id, wc_get_page_permalink( 'myaccount' ) ) );
					$orders_link .= sprintf( '<a href="%s">#%d</a>', $view_order_url, $suborder_id );

					$first = false;
				}

				$message = sprintf( _n( 'This order contains expired deposit; full amount order %s was consequently switched to cancelled and it cannot be completed anymore', 'This order contains expired deposit; full amount orders %s were consequently switched to cancelled and they cannot be completed anymore', count( $expired_suborders ), 'yith-wcdp' ), $orders_link );
				$message = sprintf( '<div class="woocommerce-error">%s</div>', $message );

				echo $message;
			}
		}

		/**
		 * Print notice to let use know this full payment order should be paid on location
		 *
		 * @param $order \WC_Order Current order
		 * @return void
		 * @since 1.0.0
		 */
		public function print_on_location_notice( $order ) {
			if( $order->has_full_payment && $order->full_payment_needs_manual_payment && $order->get_status() == 'on-hold' ){
				$notice = get_option( 'yith_wcdp_deposit_labels_pay_in_loco', '' );
				$template = '';

				if( ! empty( $notice ) ){
					$template .= '<div id="yith_wcdp_on_location_notice" class="yith-wcdp-on-location-notice">';
					$template .= '<h2>' . __( 'Payment options', 'yith-wcdp' ) . '</h2>';
					$template .= '<p>' . $notice . '</p>';
					$template .= '</div>';

					echo $template;
				}
			}
		}

		/**
		 * Adds additional product deposit note to correct action
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function add_additional_product_note() {
			$position = get_option( 'yith_wcdp_deposit_labels_product_note_position', 'woocommerce_template_single_meta' );
			$action = 'woocommerce_product_meta_end';
			$priority = 10;

			switch( $position ){
				case 'none':
					return;
				case 'woocommerce_template_single_title':
					$action = 'woocommerce_single_product_summary';
					$priority = 7;
					break;
				case 'woocommerce_template_single_price':
					$action = 'woocommerce_single_product_summary';
					$priority = 15;
					break;
				case 'woocommerce_template_single_excerpt':
					$action = 'woocommerce_single_product_summary';
					$priority = 25;
					break;
				case 'woocommerce_template_single_add_to_cart':
					$action = 'woocommerce_single_product_summary';
					$priority = 35;
					break;
				case 'woocommerce_template_single_sharing':
					$action = 'woocommerce_single_product_summary';
					$priority = 55;
					break;
				case 'woocommerce_product_meta_end':
				default:
					break;
			}

			add_action( $action, array( $this, 'print_additional_product_note' ), $priority );
		}

		/**
		 * Print additional product deposit note
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function print_additional_product_note() {
			global $product;

			if( ! is_product() || ! $product ){
				return;
			}

			$enabled = get_post_meta( $product->id, '_enable_deposit', true );
			$enabled = ! empty( $enabled ) ? $enabled : 'default';
			$enabled = ( $enabled == 'default' ) ? get_option( 'yith_wcdp_general_deposit_enable', 'no' ) : $enabled;

			$general_note = get_option( 'yith_wcdp_deposit_labels_product_note', '' );
			$product_specific_note = get_post_meta( $product->id, '_product_note', true );

			if( $enabled != 'yes' || ( empty( $general_note ) && empty( $product_specific_note ) ) ){
				return;
			}

			echo $product_specific_note ? $product_specific_note : $general_note;
		}

		/* === LABELS METHODS === */

		/**
		 * Filter Pay Deposit label
		 *
		 * @param $label string Original label
		 * @return string Filtered label
		 * @since 1.0.0
		 */
		public function filter_pay_deposit_label( $label ) {
			return get_option( 'yith_wcdp_deposit_labels_pay_deposit', $label );
		}

		/**
		 * Filter Pay Full Amount label
		 *
		 * @param $label string Original label
		 * @return string Filtered label
		 * @since 1.0.0
		 */
		public function filter_pay_full_amount_label( $label ) {
			return get_option( 'yith_wcdp_deposit_labels_pay_full_amount', $label );
		}

		/**
		 * Filter Partially Paid status
		 *
		 * @param $status string Original label
		 * @return string Filtered label
		 * @since 1.0.0
		 */
		public function filter_partially_paid_status( $status ) {
			return get_option( 'yith_wcdp_deposit_labels_partially_paid_status', $status );
		}

		/**
		 * Filter Full Price label
		 *
		 * @param $label string Original label
		 * @return string Filtered label
		 * @since 1.0.0
		 */
		public function filter_full_price_label( $label ) {
			return get_option( 'yith_wcdp_deposit_labels_full_price_label', $label );
		}

		/**
		 * Filter Balance label
		 *
		 * @param $label string Original label
		 * @return string Filtered label
		 * @since 1.0.0
		 */
		public function filter_balance_label( $label ) {
			return get_option( 'yith_wcdp_deposit_labels_balance_label', $label );
		}

		/**
		 * Returns single instance of the class
		 *
		 * @return \YITH_WCDP_Frontend_Premium
		 * @since 1.0.0
		 */
		public static function get_instance(){
			if( is_null( self::$instance ) ){
				self::$instance = new self;
			}

			return self::$instance;
		}
	}
}

/**
 * Unique access to instance of YITH_WCDP_Frontend_Premium class
 *
 * @return \YITH_WCDP_Frontend_Premium
 * @since 1.0.0
 */
function YITH_WCDP_Frontend_Premium(){
	return YITH_WCDP_Frontend_Premium::get_instance();
}