<?php
/**
 * Frontend class
 *
 * @author Your Inspiration Themes
 * @package YITH WooCommerce Deposits and Down Payments
 * @version 1.0.0
 */

/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined( 'YITH_WCDP' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WCDP_Frontend' ) ) {
	/**
	 * WooCommerce Deposits and Down Payments Frontend
	 *
	 * @since 1.0.0
	 */
	class YITH_WCDP_Frontend {
		/**
		 * Single instance of the class
		 *
		 * @var \YITH_WCDP_Frontend
		 * @since 1.0.0
		 */
		protected static $instance;

		/**
		 * Template of single product page "Add deposit to cart"
		 *
		 * @var string
		 * @since 1.0.0
		 */
		protected $_single_product_add_deposit;

		/**
		 * Constructor.
		 *
		 * @return \YITH_WCDP_Frontend
		 * @since 1.0.0
		 */
		public function __construct() {
			// update add to cart for deposit
			add_action( 'template_redirect', array( $this, 'add_single_add_deposit_button' ) );
			add_action( 'woocommerce_before_shop_loop_item', array( $this, 'add_loop_add_deposit_button' ) );
			add_action( 'woocommerce_after_shop_loop_item', array( $this, 'remove_loop_add_deposit_button' ), 99 );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

			// update frontend to show deposit/balance amount
			add_filter( 'woocommerce_get_item_data', array( $this, 'add_deposit_item_data' ), 10, 2 );
			add_action( 'woocommerce_order_item_meta_end', array( $this, 'print_deposit_order_item' ), 10, 3 );
			add_filter( 'woocommerce_cart_item_name', array( $this, 'filter_cart_deposit_product_name'), 10, 2 );
			add_filter( 'woocommerce_order_item_name', array( $this, 'filter_order_deposit_product_name'), 10, 2 );

			// update my-account page
			add_filter( 'woocommerce_my_account_my_orders_query', array( $this, 'filter_my_account_my_orders_query' ) );
			add_filter( 'woocommerce_get_formatted_order_total', array( $this, 'filter_my_account_my_orders_total' ), 10, 2 );
			add_filter( 'woocommerce_my_account_my_orders_actions', array( $this, 'filter_my_account_my_orders_actions' ), 10, 2 );
			add_action( 'woocommerce_order_details_after_order_table', array( $this, 'print_full_amount_payments_orders' ), 10, 1 );
			add_action( 'woocommerce_order_item_meta_end', array( $this, 'print_quick_deposit_action' ), 10, 3 );
			add_filter( 'woocommerce_order_get_status', array( $this, 'filter_order_status' ), 10, 2 );
			add_filter( 'wc_order_statuses', array( $this, 'filter_order_status_labels' ) );
		}

		/* === GENERAL FRONTEND METHODS === */

		/**
		 * Enqueue frontend assets
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function enqueue_scripts() {
			$path = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? 'unminified/' : '';
			$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

			// include js required
			$template_name = 'deposit-and-down-payments.js';
			$locations = array(
				trailingslashit( WC()->template_path() ) . 'yith-wcdp/' . $template_name,
				trailingslashit( WC()->template_path() ) . $template_name,
				'yith-wcdp/' . $template_name,
				$template_name
			);

			$template_js = locate_template( $locations );

			if( ! $template_js ){
				$template_js = YITH_WCDP_URL . 'assets/js/' . $path . 'yith-wcdp' . $suffix . '.js';
			}
			else{
				$search     = array( get_stylesheet_directory(), get_template_directory() );
				$replace    = array( get_stylesheet_directory_uri(), get_template_directory_uri() );
				$template_js = str_replace( $search, $replace, $template_js );
			}

			wp_register_script( 'yith-wcdp', $template_js, array( 'jquery', 'wc-add-to-cart-variation', 'jquery-blockui' ), YITH_WCDP::YITH_WCDP_VERSION, true );

			$template_name = 'deposit-and-down-payments.css';
			$locations = array(
				trailingslashit( WC()->template_path() ) . 'yith-wcdp/' . $template_name,
				trailingslashit( WC()->template_path() ) . $template_name,
				'yith-wcdp/' . $template_name,
				$template_name
			);

			$template_css = locate_template( $locations );

			if( ! $template_css ){
				$template_css = YITH_WCDP_URL . 'assets/css/yith-wcdp.css';
			}
			else{
				$search     = array( get_stylesheet_directory(), get_template_directory() );
				$replace    = array( get_stylesheet_directory_uri(), get_template_directory_uri() );
				$template_css = str_replace( $search, $replace, $template_css );
			}

			wp_register_style( 'yith-wcdp', $template_css, false, YITH_WCDP::YITH_WCDP_VERSION );

			do_action( 'yith_wcdp_enqueue_frontend_script' );

			if( is_product() ){
				wp_enqueue_script( 'yith-wcdp' );
				wp_localize_script( 'yith-wcdp', 'yith_wcdp', array(
					'ajax_url' => admin_url( 'admin-ajax.php' ),
					'actions' => array(
						'calculate_shipping' => 'yith_wcdp_calculate_shipping'
					)
				) );
			}

			do_action( 'yith_wcdp_enqueue_frontend_style' );

			if( is_product() || is_cart() || is_checkout() ){
				wp_enqueue_style( 'yith-wcdp' );
			}
		}

		/**
		 * Add "Add deposit" option to single product page
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function add_single_add_deposit_button() {
			global $post;

			if( ! is_product() ){
				return;
			}

			// retrieve product and init add deposit template
			$product = wc_get_product( $post->ID );
			$this->_single_product_add_deposit = $this->print_single_add_deposit_to_cart_field( false );

			if( $product->is_type( 'variable' ) ){
				add_action( 'woocommerce_before_single_variation', array( $this, 'print_single_add_deposit_to_cart_template' ) );
			}
			elseif( $product->is_type( 'simple' ) ) {
				add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'print_single_add_deposit_to_cart_template' ) );
			}
		}

		/**
		 * Print fields before single add to cart, to let user add to cart deposit
		 *
		 * @param $echo bool Wheter to return template, or echo it
		 * @return string Return template if param $echo is set to true
		 * @since 1.0.0
		 */
		public function print_single_add_deposit_to_cart_field( $echo = true ) {
			global $post;
			$template = '';

			if( ! is_product() ){
				return $template;
			}

			// retrieve product
			$product = wc_get_product( $post->ID );

			//product options
			$deposit_enabled = YITH_WCDP()->is_deposit_enabled_on_product( $product->id );

			$deposit_forced = YITH_WCDP()->is_deposit_mandatory( $product->id );

			$deposit_amount = YITH_WCDP()->get_deposit_amount();
			$deposit_value = min( $deposit_amount, $product->get_price() );

			if( ! $deposit_enabled ){
				return $template;
			}

			YITH_WCDP_Suborders()->create_support_cart();
			WC()->cart->add_to_cart( $product->id, 1 );
			WC()->cart->calculate_shipping();

			$deposit_shipping = get_option( 'yith_wcdp_general_deposit_shipping', 'let_user_choose' );
			$let_user_choose_shipping = $deposit_shipping == 'let_user_choose';

			$args = array(
				'deposit_enabled' => $deposit_enabled,
				'deposit_forced' => $deposit_forced,
				'deposit_type' => 'amount',
				'deposit_amount' => $deposit_amount,
				'deposit_rate' => 0,
				'deposit_value' => $deposit_value,
				'needs_shipping' => WC()->cart->needs_shipping(),
				'show_shipping_form' => $let_user_choose_shipping
			);

			ob_start();

			yith_wcdp_get_template( 'single-add-deposit-to-cart.php', $args );

			$template = ob_get_clean();

			YITH_WCDP_Suborders()->restore_original_cart();

			if( $echo ){
				echo $template;
			}

			return $template;
		}

		/**
		 * Print template of single add deposit to cart
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function print_single_add_deposit_to_cart_template() {
			echo $this->_single_product_add_deposit;
		}

		/**
		 * Add "Add deposit to cart" loop button, for each product in the loop
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function add_loop_add_deposit_button() {
			global $product;

			$deposit_enabled = YITH_WCDP()->is_deposit_enabled_on_product();
			$deposit_forced = YITH_WCDP()->is_deposit_mandatory( $product->id );

			if( ! has_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' ) ){
				add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
			}

			if( $deposit_enabled ){
				add_action( 'woocommerce_after_shop_loop_item', array( $this, 'print_loop_add_deposit_to_cart_template' ), 15 );

				if( $deposit_forced ){
					remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
				}
			}
		}

		/**
		 * Remove "Add deposit to cart" button after single loop item processed (so next product may not show it)
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function remove_loop_add_deposit_button() {
			remove_action( 'woocommerce_after_shop_loop_item', array( $this, 'print_loop_add_deposit_to_cart_template' ), 15 );
		}

		/**
		 * Prints template of loop add deposit to cart
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function print_loop_add_deposit_to_cart_template() {
			global $product;

			if( ! $product ){
				return;
			}

			$args = array(
				'product_url' => esc_url( $product->get_permalink() . '#yith-wcdp-add-deposit-to-cart' )
			);

			yith_wcdp_get_template( 'loop-add-deposit-to-cart', $args );
		}

		/* === CART/CHECKOUT FRONTEND METHODS === */

		/**
		 * Adds item data to be shown on cart/checkout pages (this data won't be stored anywhere)
		 *
		 * @param $data mixed Data to show on templates
		 * @param $cart_item mixed Current cart item
		 * @return mixed Filtered array of cart item data
		 * @since 1.0.0
		 */
		public function add_deposit_item_data( $data, $cart_item ) {
			if ( isset( $cart_item['deposit'] ) && $cart_item['deposit'] ) {
				$full_amount =  $cart_item['deposit_value'] + $cart_item['deposit_balance'];

				$data = array_merge(
					$data,
					array(
						array(
							'display' => wc_price( $full_amount ),
							'name' => apply_filters( 'yith_wcdp_full_price_filter', __( 'Full price', 'yith-wcdp' ) ),
							'value' => $full_amount
						),
						array(
							'display' => wc_price( $cart_item['deposit_balance'] ),
							'name' => apply_filters( 'yith_wcdp_balance_filter', __( 'Balance', 'yith-wcdp' ) ),
							'value' => $cart_item['deposit_balance']
						)
					)
				);
			}

			return $data;
		}

		/**
		 * Print item data on cart / checkout views, to inform user about deposit & balance he's going to pay
		 *
		 * @param $item_id int Order item id
		 * @param $item mixed Order item assoc array
		 * @param $order \WC_Order Order object
		 * @return void
		 * @since 1.0.0
		 */
		public function print_deposit_order_item( $item_id, $item, $order ) {
			if ( isset( $item['item_meta']['_deposit'] ) && $item['item_meta']['_deposit'] ) {
				$full_amount = $item['item_meta']['_deposit_value'][0] + $item['item_meta']['_deposit_balance'][0];

				$template = '';

				$template .= '<small style="display: block;">' .  wp_kses_post( apply_filters( 'yith_wcdp_full_price_filter', __( 'Full price', 'yith-wcdp' ) ) ) . ': ' . wc_price( $full_amount ) . '</small>';
				$template .= '<small style="display: block;">' .  wp_kses_post( apply_filters( 'yith_wcdp_balance_filter', __( 'Balance', 'yith-wcdp' ) ) ) . ': ' . wc_price( $item['item_meta']['_deposit_balance'][0] ) . '</small>';

				echo $template;
			}
		}

		/**
		 * Filter product name on cart and checkout views, to show deposit label
		 *
		 * @param $product_name string Original product name
		 * @param $cart_item    mixed Cart item object
		 * @return string Filtered product name
		 * @since 1.0.0
		 */
		public function filter_cart_deposit_product_name( $product_name, $cart_item ) {
			if ( isset( $cart_item['deposit'] ) && $cart_item['deposit'] ) {
				if( is_cart() ){
					$product_name = preg_replace( '^(<a.*>)(.*)(<\/a>)$^', sprintf( '$1%s: $2$3',  apply_filters( 'yith_wcdp_deposit_label', __( 'Deposit', 'yith-wcdp' ) ) ), $product_name );
				}
				elseif( is_checkout() ){
					$product_name = apply_filters( 'yith_wcdp_deposit_label', __( 'Deposit', 'yith-wcdp' ) ) . ': ' . $product_name;
				}
			}

			return $product_name;
		}

		/**
		 * Filter product name on review-order view, to show deposit label
		 *
		 * @param $product_name string Original product name
		 * @param $order_item    mixed Order item object
		 * @return string Filtered product name
		 * @since 1.0.0
		 */
		public function filter_order_deposit_product_name( $product_name, $order_item ) {
			if ( isset( $order_item['item_meta']['_deposit'] ) && $order_item['item_meta']['_deposit'] ) {
				$product_name = preg_replace( '^(<a.*>)(.*)(<\/a>)$^', sprintf( '$1%s: $2$3',  apply_filters( 'yith_wcdp_deposit_label', __( 'Deposit', 'yith-wcdp' ) ) ), $product_name );
			}
			elseif( isset( $order_item['item_meta']['_full_payment'] ) && $order_item['item_meta']['_full_payment'] ){
				$product_name = preg_replace( '^(<a.*>)(.*)(<\/a>)$^', sprintf( '$1%s: $2$3',  apply_filters( 'yith_wcdp_full_payment_label', __( 'Full payment', 'yith-wcdp' ) ) ), $product_name );
			}

			return $product_name;
		}

		/**
		 * Filter order status label for partially paid orders
		 *
		 * @param $status string Current status
		 * @param $order \WC_Order Current order
		 * @return string Filtered status
		 * @since 1.0.0
		 */
		public function filter_order_status( $status, $order ) {
			if( $order->has_deposit && in_array( $status, array( 'completed', 'processing' ) ) ){
				$suborders = YITH_WCDP_Suborders()->get_suborder( $order->id );

				if( $suborders ){
					foreach( $suborders as $suborder_id ){
						$suborder = wc_get_order( $suborder_id );
						if( ! in_array( $suborder->get_status(), array( 'completed', 'processing' ) ) ){
							$status = 'partially-paid';
						}
					}
				}
			}

			return $status;
		}

		/**
		 * Filter order status labels to print "Partially paid" status
		 *
		 * @param $labels mixed Current available labels
		 * @return mixed Filtered labels
		 * @since 1.0.0
		 */
		public function filter_order_status_labels( $labels ) {
			$labels['wc-partially-paid'] = apply_filters( 'yith_wcdp_partially_paid_status_label', __( 'Partially Paid', 'yith-wcdp' ) );

			return $labels;
		}
		
		/* === MY ACCOUNT FRONTEND METHODS === */

		/**
		 * Filter "Recent orders" my-account section query
		 *
		 * @param $query_vars mixed Array of query var
		 *
		 * @return mixed Filtered query var
		 * @since  1.0.0
		 */
		public function filter_my_account_my_orders_query( $query_vars ) {
			$child_orders_ids = array();
			$child_orders = YITH_WCDP_Suborders()->get_child_orders();

			if( ! empty( $child_orders ) ){
				foreach( $child_orders as $order ){
					$child_orders_ids[] = $order->ID;
				}
			}

			$query_vars['exclude'] = $child_orders_ids;

			return $query_vars;
		}

		/**
		 * Filter order total price html, to show deposit info
		 *
		 * @param $total_html string Original HTML for order total
		 * @param $order \WC_Order Current order
		 * @return string Filtered total HTML
		 * @since 1.0.0
		 */
		public function filter_my_account_my_orders_total( $total_html, $order ) {
			if( isset( $order->has_deposit ) && $order->has_deposit ){
				$total_html = wc_price( $order->get_total() );

				$total = $order->get_total();
				$suborders = $order->full_payment_orders;
				if( ! empty( $suborders ) ){
					foreach( $suborders as $suborder_id ){
						$suborder = wc_get_order( $suborder_id );

						if( ! $suborder ){
							continue;
						}

						$total += $suborder->get_total();
					}
				}

				$total_html .= sprintf( ' (%s <strong>%s</strong>)', __( 'of', 'yith-wcdp' ), wc_price( $total ) );
			}

			return $total_html;
		}

		/**
		 * Filter order total price html, to show deposit info
		 *
		 * @param $total_html string Original HTML for order total
		 * @param $order \WC_Order Current order
		 * @return string Filtered total HTML
		 * @since 1.0.0
		 */
		public function filter_my_account_my_orders_actions( $actions, $order ) {
			if( isset( $order->has_deposit ) && $order->has_deposit ){
				$actions['view_full_amount_payments'] = array(
					'url'  => $order->get_view_order_url() . '#yith_wcdp_deposits_details',
					'name' => __( 'View Full Payment', 'yith-wcdb' )
				);
			}

			return $actions;
		}

		/**
		 * Prints full amount payments for an order (order-detail view)
		 *
		 * @param $order \WC_Order Current order
		 * @return void
		 * @since 1.0.0
		 */
		public function print_full_amount_payments_orders( $order ) {
			if( $order->has_deposit ){
				$deposits = array();
				$items = $order->get_items( 'line_item' );

				if( ! empty( $items ) ){
					foreach( $items as $item_id => $item ){
						if( isset( $item['item_meta']['_deposit'][0] ) && $item['item_meta']['_deposit'][0] ){

							$product = $order->get_product_from_item( $item );
							$suborder = wc_get_order( $item['item_meta']['_full_payment_id'][0] );

							if( ! $product || ! $suborder ){
								return;
							}

							$actions = array();

							if ( $suborder->needs_payment() ) {
								$actions['pay'] = array(
									'url'  => $suborder->get_checkout_payment_url(),
									'name' => __( 'Pay', 'woocommerce' )
								);
							}

							if ( in_array( $suborder->get_status(), apply_filters( 'woocommerce_valid_order_statuses_for_cancel', array( 'pending', 'failed' ), $suborder ) ) ) {
								$actions['cancel'] = array(
									'url'  => $suborder->get_cancel_order_url( wc_get_page_permalink( 'myaccount' ) ),
									'name' => __( 'Cancel', 'woocommerce' )
								);
							}

							$actions['view'] = array(
								'url'  => $suborder->get_view_order_url(),
								'name' => __( 'View', 'woocommerce' )
							);

							$actions = apply_filters( 'woocommerce_my_account_my_orders_actions', $actions, $suborder );

							$paid = $order->get_item_total( $item, true ) * $item['qty'];
							$paid += in_array( $suborder->get_status(), array( 'processing', 'completed' ) ) ? $suborder->get_total() : 0;
							$subtotal = $order->get_item_subtotal( $item, true ) * $item['qty'];
							$subtotal += in_array( $suborder->get_status(), array( 'processing', 'completed' ) ) ? $suborder->get_total() : 0;
							$to_pay = in_array( $suborder->get_status(), array( 'processing', 'completed' ) ) ? 0 : $suborder->get_total();

							$deposits[] = array(
								'product_url' => $product->get_permalink(),
								'product_name' => $item['name'],
								'order_status' => $suborder->get_status(),
								'order_paid' => $paid,
								'order_subtotal' => $subtotal,
								'order_discount' => $subtotal - $paid,
								'order_to_pay' => $to_pay,
								'actions' => $actions
							);
						}
					}
				}

				$args = array(
					'order'    => $order,
					'order_id' => $order->id,
					'deposits' => $deposits
				);

				yith_wcdp_get_template( 'my-deposits.php', $args );
			}
		}

		/**
		 * Print quick actions available for deposit items on view-order / thank-you pages
		 *
		 * @param $item_id int Current item id
		 * @param $item mixed Current item content
		 * @param $order \WC_Order Current wc order
		 * @return void
		 * @since 1.0.0
		 */
		public function print_quick_deposit_action( $item_id, $item, $order ) {
			if( isset( $item['item_meta']['_deposit'][0] ) && $item['item_meta']['_deposit'][0] ){
				$actions = array();
				$suborder = wc_get_order( $item['item_meta']['_full_payment_id'][0] );

				if( ! $suborder ){
					return;
				}

				if ( $suborder->needs_payment() ) {
					$actions['pay'] = array(
						'url'  => $suborder->get_checkout_payment_url(),
						'name' => __( 'Pay', 'woocommerce' )
					);
				}

				$actions['view'] = array(
					'url'  => $suborder->get_view_order_url(),
					'name' => __( 'View', 'woocommerce' )
				);

				$template = '<small style="display: block;">';
				foreach ( $actions as $key => $action ) {
					$template .= '<a href="' . esc_url( $action['url'] ) . '" class="button ' . sanitize_html_class( $key ) . '">' . esc_html( $action['name'] ) . '</a> ';
				}
				$template .= '</small>';

				echo $template;
			}
		}

		/**
		 * Returns single instance of the class
		 *
		 * @return \YITH_WCDP_Frontend
		 * @since 1.0.0
		 */
		public static function get_instance(){
			if( is_null( self::$instance ) ){
				self::$instance = new self;
			}

			return self::$instance;
		}
	}
}

/**
 * Unique access to instance of YITH_WCDP_Frontend class
 *
 * @return \YITH_WCDP_Frontend
 * @since 1.0.0
 */
function YITH_WCDP_Frontend(){
	return YITH_WCDP_Frontend::get_instance();
}