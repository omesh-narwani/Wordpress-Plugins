<?php
/**
 * Main premium class
 *
 * @author Your Inspiration Themes
 * @package YITH WooCommerce Deposits and Down Payments
 * @version 1.0.0
 */

/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined( 'YITH_WCDP' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WCDP_Premium' ) ) {
	/**
	 * WooCommerce Deposits and Down Payments Premium
	 *
	 * @since 1.0.0
	 */
	class YITH_WCDP_Premium extends YITH_WCDP {

		/**
		 * Single instance of the class
		 *
		 * @var \YITH_WCDP
		 * @since 1.0.0
		 */
		protected static $instance;

		/**
		 * Constructor.
		 *
		 * @return \YITH_WCDP_Premium
		 * @since 1.0.0
		 */
		public function __construct() {
			parent::__construct();

			// emails init
			add_filter( 'woocommerce_email_classes', array( $this, 'register_email_classes' ) );
			add_filter( 'woocommerce_email_actions', array( $this, 'register_email_actions' ) );
			add_filter( 'woocommerce_locate_core_template', array( $this, 'register_woocommerce_template' ), 10, 3 );
			add_filter( 'woocommerce_resend_order_emails_available', array( $this, 'enable_resend_notify_email' ) );
		}

		/**
		 * Install plugin
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function install() {
			YITH_WCDP_Suborders_Premium();

			// init frontend class
			if( ! is_admin() ){
				YITH_WCDP_Frontend_Premium();
			}

			// init handlers
			YITH_WCDP_Deposits_Handler();
		}

		/* === HELPER METHODS === */

		/**
		 * Retrieve deposit type
		 *
		 * @return string Deposit type (rate, amount)
		 * @since 1.0.0
		 */
		public function get_deposit_type( $product_id = false, $customer_id = false ) {
			global $product;

			$product_obj = ( ! $product_id ) ? $product : wc_get_product( $product_id );
			$customer_obj = ( ! $customer_id ) ? wp_get_current_user() : get_user_by( 'id', $customer_id );

			// set default value
			$deposit_type = get_option( 'yith_wcdp_general_deposit_type', 'amount' );

			// if no product or customer, return default value
			if( ! $product_obj || ! $customer_obj ){
				return $deposit_type;
			}

			// retrieve first customer role ( multiple roles are allowed only via code, so we retrieve only first one )
			$customer_role = isset( $customer_obj->roles[0] ) ? $customer_obj->roles[0] : false;

			// retrieve product categories
			$product_categories_raw = get_the_terms( $product_obj->id, 'product_cat' );
			$product_categories = array();

			if( ! empty( $product_categories_raw ) ){
				foreach( $product_categories_raw as $term ){
					$product_categories[] = $term->term_id;
				}
			}

			// retrieve options for deposits
			$role_specific_deposit = get_option( 'yith_wcdp_user_role_deposits' );
			$product_specific_deposit = get_option( 'yith_wcdp_product_deposits' );
			$category_specific_deposit = get_option( 'yith_wcdp_category_deposits' );

			$product_terms_with_deposits = array();
			if( ! empty( $category_specific_deposit ) ) {
				// retrieve product categories with specific deposit value set
				$product_terms_with_deposits = array_values(array_intersect(array_keys($category_specific_deposit), $product_categories));
			}

			// first, check user-role specific deposit type
			if( isset( $role_specific_deposit[ $customer_role ] ) ){
				$deposit_type = $role_specific_deposit[ $customer_role ]['type'];
			}
			// if no user-role specific deposit is set, check product specific deposit type
			elseif( isset( $product_specific_deposit[ $product_obj->id ] ) ){
				$deposit_type = $product_specific_deposit[ $product_obj->id ]['type'];
			}
			// if no product specific deposit type is set, check product-category specific deposit type
			elseif( ! empty( $product_terms_with_deposits ) ){
				$deposit_type = $category_specific_deposit[ $product_terms_with_deposits[ 0 ] ]['type'];
			}

			return $deposit_type;
		}

		/**
		 * Retrieve deposit amount (needed on amount deposit type)
		 *
		 * @return string Amount
		 * @since 1.0.0
		 */
		public function get_deposit_amount( $product_id = false, $customer_id = false ) {
			global $product;

			$product_obj = ( ! $product_id ) ? $product : wc_get_product( $product_id );
			$customer_obj = ( ! $customer_id ) ? wp_get_current_user() : get_user_by( 'id', $customer_id );

			// set default value
			$deposit_amount = get_option( 'yith_wcdp_general_deposit_amount', 0 );

			// if no product or customer, return default value
			if( ! $product_obj || ! $customer_obj ){
				return $deposit_amount;
			}

			// retrieve first customer role ( multiple roles are allowed only via code, so we retrieve only first one )
			$customer_role = isset( $customer_obj->roles[0] ) ? $customer_obj->roles[0] : false;

			// retrieve product categories
			$product_categories_raw = get_the_terms( $product_obj->id, 'product_cat' );
			$product_categories = array();

			if( ! empty( $product_categories_raw ) ){
				foreach( $product_categories_raw as $term ){
					$product_categories[] = $term->term_id;
				}
			}

			// retrieve options for deposits
			$role_specific_deposit = get_option( 'yith_wcdp_user_role_deposits' );
			$product_specific_deposit = get_option( 'yith_wcdp_product_deposits' );
			$category_specific_deposit = get_option( 'yith_wcdp_category_deposits' );

			$product_terms_with_deposits = array();
			if( ! empty( $category_specific_deposit ) ) {
				// retrieve product categories with specific deposit value set
				$product_terms_with_deposits = array_values(array_intersect(array_keys($category_specific_deposit), $product_categories));
			}

			// first, check user-role specific deposit amount
			if( isset( $role_specific_deposit[ $customer_role ] ) ){
				$deposit_amount = $role_specific_deposit[ $customer_role ]['value'];
			}
			// if no user-role specific deposit is set, check product specific deposit amount
			elseif( isset( $product_specific_deposit[ $product_obj->id ] ) ){
				$deposit_amount = $product_specific_deposit[ $product_obj->id ]['value'];
			}
			// if no product specific deposit amount is set, check product-category specific deposit amount
			elseif( ! empty( $product_terms_with_deposits ) ){
				$deposit_amount = $category_specific_deposit[ $product_terms_with_deposits[ 0 ] ]['value'];
			}

			return $deposit_amount;
		}

		/**
		 * Retrieve deposit rate (needed on rate deposit type)
		 *
		 * @return string Amount
		 * @since 1.0.0
		 */
		public function get_deposit_rate( $product_id = false, $customer_id = false ) {
			global $product;

			$product_obj = ( ! $product_id ) ? $product : wc_get_product( $product_id );
			$customer_obj = ( ! $customer_id ) ? wp_get_current_user() : get_user_by( 'id', $customer_id );

			// set default value
			$deposit_rate = get_option( 'yith_wcdp_general_deposit_rate', 0 );

			// if no product or customer, return default value
			if( ! $product_obj || ! $customer_obj ){
				return $deposit_rate;
			}

			// retrieve first customer role ( multiple roles are allowed only via code, so we retrieve only first one )
			$customer_role = isset( $customer_obj->roles[0] ) ? $customer_obj->roles[0] : false;

			// retrieve product categories
			$product_categories_raw = get_the_terms( $product_obj->id, 'product_cat' );
			$product_categories = array();

			if( ! empty( $product_categories_raw ) ){
				foreach( $product_categories_raw as $term ){
					$product_categories[] = $term->term_id;
				}
			}

			// retrieve options for deposits
			$role_specific_deposit = get_option( 'yith_wcdp_user_role_deposits' );
			$product_specific_deposit = get_option( 'yith_wcdp_product_deposits' );
			$category_specific_deposit = get_option( 'yith_wcdp_category_deposits' );

			$product_terms_with_deposits = array();
			if( ! empty( $category_specific_deposit ) ) {
				// retrieve product categories with specific deposit value set
				$product_terms_with_deposits = array_values(array_intersect(array_keys($category_specific_deposit), $product_categories));
			}

			// first, check user-role specific deposit amount
			if( isset( $role_specific_deposit[ $customer_role ] ) ){
				$deposit_rate = $role_specific_deposit[ $customer_role ]['value'];
			}
			// if no user-role specific deposit is set, check product specific deposit amount
			elseif( isset( $product_specific_deposit[ $product_obj->id ] ) ){
				$deposit_rate = $product_specific_deposit[ $product_obj->id ]['value'];
			}
			// if no product specific deposit amount is set, check product-category specific deposit amount
			elseif( ! empty( $product_terms_with_deposits ) ){
				$deposit_rate = $category_specific_deposit[ $product_terms_with_deposits[ 0 ] ]['value'];
			}

			return $deposit_rate;
		}

		/* === EMAIL METHODS === */

		/**
		 * Register email classes for deposits
		 *
		 * @param $classes mixed Array of email class instances
		 * @return mixed Filtered array of email class instances
		 * @since 1.0.0
		 */
		public function register_email_classes( $classes ){
			require_once( YITH_WCDP_INC . 'emails/class.yith-wcdp-emails.php' );

			$classes['YITH_WCDP_Customer_Deposit_Created_Email'] = include_once( YITH_WCDP_INC . 'emails/class.yith-wcdp-customer-deposit-created-email.php' );
			$classes['YITH_WCDP_Admin_Deposit_Created_Email'] = include_once( YITH_WCDP_INC . 'emails/class.yith-wcdp-admin-deposit-created-email.php' );
			$classes['YITH_WCDP_Customer_Deposit_Expiring_Email'] = include_once( YITH_WCDP_INC . 'emails/class.yith-wcdp-customer-deposit-expiring-email.php' );

			return $classes;
		}

		/**
		 * Register email action for deposists
		 *
		 * @param $emails mixed Array of registered actions
		 * @return mixed Filtered array of registered actions
		 * @since 1.0.0
		 */
		public function register_email_actions( $emails ) {
			$emails = array_merge(
				$emails,
				array(
					'yith_wcdp_deposits_created',
					'yith_wcdp_deposits_expiring'
				)
			);

			return $emails;
		}

		/**
		 * Adds notify email to re-send options
		 *
		 * @param $resend_emails mixed Enabled emails for resend
		 * @return mixed Filtered array of mails that can be sent again
		 * @since 1.0.0
		 */
		public function enable_resend_notify_email( $resend_emails ) {
			global $post;

			// check if global post define
			if( ! $post ){
				return $resend_emails;
			}

			// retrieve order object
			$order = wc_get_order( $post );

			// check if current global post is an order
			if( ! $order ){
				return $resend_emails;
			}

			// check if current order has a deposit
			if( ! $order->has_deposit ){
				return  $resend_emails;
			}

			// retrieve current order suborders
			$suborders = YITH_WCDP_Suborders_Premium()->get_suborder( $order->id );

			// check if order have suborders
			if( ! $suborders ){
				return $resend_emails;
			}

			// enable "re-send notify email" only if at least one suborder is not expired, and not completed or cancelled
			$resend_available = false;
			foreach( $suborders as $suborder_id ){
				$suborder = wc_get_order( $suborder_id );

				if( ! $suborder->has_expired && ! in_array( $suborder->get_status(), array( 'completed', 'processing', 'cancelled' ) ) ){
					$resend_available = true;
				}
			}

			// enable "re-send notify email"
			if( $resend_available ){
				$resend_emails[] = 'expiring_deposit';
			}

			return $resend_emails;
		}

		/**
		 * Locate default templates of woocommerce in plugin, if exists
		 *
		 * @param $core_file     string
		 * @param $template      string
		 * @param $template_base string
		 * @return string
		 * @since  1.0.0
		 */
		public function register_woocommerce_template( $core_file, $template, $template_base ) {
			$located = yith_wcdp_locate_template( $template );

			if( $located && file_exists( $located ) ){
				return $located;
			}
			else{
				return $core_file;
			}
		}

		/* === CHECKOUT PROCESS METHODS === */

		/**
		 * Update cart item when deposit is selected
		 *
		 * @param $cart_item mixed Current cart item
		 *
		 * @return mixed Filtered cart item
		 * @since 1.0.0
		 */
		public function update_cart_item( $cart_item ) {
			/**
			 * @var $product \WC_Product
			 */
			$product = $cart_item['data'];

			if( $this->is_deposit_enabled_on_product( $product ) ){
				$deposit_forced = $this->is_deposit_mandatory( $product->id );

				$deposit_type = $this->get_deposit_type( $product->id );
				$deposit_amount = $this->get_deposit_amount( $product->id );
				$deposit_rate = $this->get_deposit_rate( $product->id );
				$deposit_value = 0;

				if( $deposit_type == 'rate' ){
					$deposit_value = $product->get_price() * (double) $deposit_rate / 100;
				}
				elseif( $deposit_type == 'amount' ){
					$deposit_value = $deposit_amount;
				}

				$deposit_value = min( $deposit_value, $product->get_price() );

				if( isset( $_REQUEST['add-to-cart'] ) && ( $deposit_forced || ( isset( $_REQUEST['payment_type'] ) && $_REQUEST['payment_type'] == 'deposit' ) ) ){
					$cart_item['data']->price = $deposit_value;
					$cart_item['data']->virtual = 'yes';
				}
			}

			return $cart_item;
		}

		/**
		 * Add cart item data when deposit is selected, to store info to save with order
		 *
		 * @param $cart_item_data mixed Currently saved cart item data
		 * @param $product_id     int   Product id
		 *
		 * @return mixed Filtered cart item data
		 * @since 1.0.0
		 */
		public function update_cart_item_data( $cart_item_data, $product_id, $variation_id ) {
			$product_id = ! empty( $variation_id ) ? $variation_id : $product_id;
			$product = wc_get_product( $product_id );

			if( $this->is_deposit_enabled_on_product( $product_id ) ){
				$deposit_forced = $this->is_deposit_mandatory( $product_id );

				$deposit_type = $this->get_deposit_type( $product->id );
				$deposit_amount = $this->get_deposit_amount( $product->id );
				$deposit_rate = $this->get_deposit_rate( $product->id );
				$deposit_value = 0;

				if( $deposit_type == 'rate' ){
					$deposit_value = $product->get_price() * (double) $deposit_rate / 100;
				}
				elseif( $deposit_type == 'amount' ){
					$deposit_value = $deposit_amount;
				}

				$deposit_value = min( $deposit_value, $product->get_price() );

				$deposit_balance = max( $product->get_price() - $deposit_value, 0 );

				if( $deposit_forced || ( isset( $_REQUEST['payment_type'] ) && $_REQUEST['payment_type'] == 'deposit' ) ){
					$cart_item_data['deposit'] = true;
					$cart_item_data['deposit_type'] = $deposit_type;
					$cart_item_data['deposit_amount'] = $deposit_amount;
					$cart_item_data['deposit_rate'] = $deposit_rate;
					$cart_item_data['deposit_value'] = $deposit_value;
					$cart_item_data['deposit_balance'] = $deposit_balance;
					$cart_item_data['deposit_shipping_method'] = isset( $_POST['shipping_method'] ) ? $_POST['shipping_method'] : false;
				}
			}

			return $cart_item_data;
		}

		/**
		 * Returns single instance of the class
		 *
		 * @return \YITH_WCDP_Frontend
		 * @since 1.0.0
		 */
		public static function get_instance(){
			if( is_null( self::$instance ) ){
				self::$instance = new self;
			}

			return self::$instance;
		}
	}
}

/**
 * Unique access to instance of YITH_WCDP_Premium class
 *
 * @return \YITH_WCDP_Premium
 * @since 1.0.0
 */
function YITH_WCDP_Premium(){
	return YITH_WCDP_Premium::get_instance();
}