<?php
/**
 * Suborder class
 *
 * @author Your Inspiration Themes
 * @package YITH WooCommerce Deposits and Down Payments
 * @version 1.0.0
 */

/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined( 'YITH_WCDP' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WCDP_Suborders' ) ) {
	/**
	 * WooCommerce Deposits and Down Payments
	 *
	 * @since 1.0.0
	 */
	class YITH_WCDP_Suborders {

		/**
		 * Single instance of the class
		 *
		 * @var \YITH_WCDP_Suborders
		 * @since 1.0.0
		 */
		protected static $instance;

		/**
		 * Temp storage where to store real cart during plugin elaboration that requires a custom cart
		 *
		 * @var \WC_Cart
		 * @since 1.0.0
		 */
		protected $_cart;

		/**
		 * Temp storage where to store real applied coupon during plugin elaboration that requires a custom cart
		 *
		 * @var mixed
		 * @since 1.0.0
		 */
		protected $_coupons;

		/**
		 * Constructor.
		 *
		 * @return \YITH_WCDP_Suborders
		 * @since 1.0.0
		 */
		public function __construct() {
			add_action( 'woocommerce_checkout_order_processed', array( $this, 'create_balance_suborder' ), 10, 1 );
			add_filter( 'woocommerce_get_product_from_item', array( $this, 'woocommerce_get_product_from_item' ), 10, 3 );
			add_action( 'trashed_post', array( $this, 'trash_suborders' ) );
			add_action( 'untrashed_post', array( $this, 'untrash_suborders' ) );
		}

		/* === SUBORDER METHODS === */

		/**
		 * Create suborders during process checkout, to let user finalize all his/her deposit in a separate balance order
		 *
		 * @param $order_id int Processing order id
		 * @return bool Status of the operation
		 * @since 1.0.0
		 */
		public function create_balance_suborder( $order_id ) {
			// retrieve order
			$parent_order = wc_get_order( $order_id );
			$suborders = array();

			// if no order found, exit
			if( ! $parent_order ){
				return false;
			}

			// if order already process, exit
			$suborders_meta = get_post_meta( $parent_order->id, '_full_payment_orders', true );

			if( $suborders_meta ){
				return false;
			}

			// retrieve order items
			$items = $parent_order->get_items( 'line_item' );

			// if no items found, exit
			if( empty( $items ) ){
				return false;
			}

			// create support cart
			$this->create_support_cart();

			// retrieve deposit payment balance
			$deposit_shipping_preference = get_option( 'yith_wcdp_general_deposit_shipping', 'let_user_choose' );
			$deposit_admin_shipping_preference = get_option( 'yith_wcdp_general_deposit_shipping_admin_selection' );

			// cycle over order items
			foreach( $items as $item_id => $item ){

				$deposit = $parent_order->get_item_meta( $item_id, '_deposit', true );
				$deposit_balance = $parent_order->get_item_meta( $item_id, '_deposit_balance', true );
				$deposit_shipping_method = $parent_order->get_item_meta( $item_id, '_deposit_shipping_method', true );
				$product = $parent_order->get_product_from_item( $item );

				// if not a deposit, continue
				if( ! $deposit ){
					continue;
				}

				// set order item meta with deposit-related full payment order
				wc_add_order_item_meta( $item_id, '_full_payment_id', false );

				// skip processing for other reason
				if( apply_filters( 'yith_wcdp_skip_suborder_creation', false, $item_id, $item, $order_id, $parent_order, $product ) ){
					continue;
				}

				// set has_deposit meta
				update_post_meta( $parent_order->id, '_has_deposit', true );

				// if deposit, add elem to support cart (filters change price of the product to be added to the cart)
				add_filter( 'woocommerce_add_cart_item', array( $this, 'set_item_full_amount_price' ) );
				WC()->cart->add_to_cart( $product->id, $item['qty'], $product->is_type( 'variation' ) ? $product->get_variation_id() : '', $product->is_type( 'variation' ) ? $product->get_variation_attributes() : array(), array(
					'_deposit_balance' => $deposit_balance
				) );
				remove_filter( 'woocommerce_add_cart_item', array( $this, 'set_item_full_amount_price' ) );

				// set shipping method for suborder
				if( $deposit_shipping_preference == 'let_user_choose' && $deposit_shipping_method ){
					WC()->checkout()->shipping_methods = $deposit_shipping_method;
				}
				elseif( $deposit_shipping_preference == 'admin_choose' && $deposit_admin_shipping_preference ){
					WC()->checkout()->shipping_methods = (array) $deposit_admin_shipping_preference;
				}

				// create suborder
				$new_suborder_id = WC()->checkout()->create_order();

				if( ! $new_suborder_id || is_wp_error( $new_suborder_id ) ){
					continue;
				}

				// set new suborder post parent
				$res = wp_update_post( array(
					'ID' => $new_suborder_id,
					'post_parent' => $parent_order->id,
					'post_status' => apply_filters( 'yith_wcdp_suborder_status', 'pending', $new_suborder_id, $order_id, $item_id, $item, $product )
				) );

				// disable stock management for brand new order
				update_post_meta( $new_suborder_id, '_has_full_payment', true );

				// disable stock management for brand new order
				update_post_meta( $new_suborder_id, '_order_stock_reduced', true );

				// update created_via meta
				update_post_meta( $new_suborder_id, '_created_via', 'yith_wcdp_balance_order' );

				// add plugin version
				update_post_meta( $new_suborder_id, '_yith_wcdp_version', YITH_WCDP::YITH_WCDP_VERSION );

				// update new suborder totals
				$new_suborder = wc_get_order( $new_suborder_id );
				$new_suborder->calculate_shipping();
				$new_suborder->calculate_taxes();
				$new_suborder->calculate_totals();

				// set suborder customer note (remove email notification for this action only during this call)
				add_filter( 'woocommerce_email_enabled_customer_note', '__return_false' );
				$new_suborder->add_order_note( sprintf( '%s <a href="%s">#%d</a>', __( 'This order has been created to allow payment of the balance', 'yith-wcdp' ), $parent_order->get_view_order_url(), $parent_order->id ), true );
				remove_filter( 'woocommerce_email_enabled_customer_note', '__return_false' );

				// update new suborder items
				$new_suborder_items = $new_suborder->get_items( 'line_item' );
				if( ! empty( $new_suborder_items ) ){
					foreach( $new_suborder_items as $suborder_item_id => $suborder_item ){
						wc_add_order_item_meta( $suborder_item_id, '_deposit_id', $parent_order->id );
						wc_add_order_item_meta( $suborder_item_id, '_full_payment', true );
					}
				}

				// register suborder just created
				$suborders[] = $new_suborder_id;

				// set order item meta with deposit-related full payment order
				wc_update_order_item_meta( $item_id, '_full_payment_id', $new_suborder_id );

				// empty support cart, for next suborder
				WC()->cart->empty_cart();
			}

			// restore original cart
			$this->restore_original_cart();

			update_post_meta( $parent_order->id, '_full_payment_orders', $suborders );

			// send notification email
			if( ! empty( $suborders ) ){
				do_action( 'yith_wcdp_deposits_created', $parent_order->id );
			}

			return true;
		}

		/**
		 * Change item price, when adding it to temp cart, to let user pay only order balance
		 *
		 * @param $cart_item_data mixed Array of items added to temp cart
		 * @return mixed Filtered cart item data
		 * @since 1.0.0
		 */
		public function set_item_full_amount_price( $cart_item_data ) {
			if( ! isset( $cart_item_data['_deposit_balance'] ) ){
				return $cart_item_data;
			}

			$cart_item_data['data']->price = $cart_item_data['_deposit_balance'];

			return $cart_item_data;
		}

		/**
		 * Filter item product, when retrieving it from order item
		 *
		 * @param $product \WC_Product Product found
		 * @param $item mixed Order item
		 * @param $order \WC_Order Order object
		 * @return \WC_Product Filtered product
		 * @since 1.0.0
		 */
		public function woocommerce_get_product_from_item( $product, $item, $order ) {
			if( isset( $item['item_meta']['_deposit'] ) && $item['item_meta']['_deposit'] ){
				$product->price = $item['item_meta']['_deposit_value'];
				$product->virtual = 'yes';
				$product->downloadable = 'no';
			}

			return $product;
		}

		/**
		 * Trash suborders on parent order trashing
		 *
		 * @param $post_id int Trashed post id
		 * @return void
		 * @since 1.0.0
		 */
		public function trash_suborders( $post_id ) {
			$order = wc_get_order( $post_id );

			if( ! $order ){
				return;
			}

			$suborders = $this->get_suborder( $post_id );

			if( ! $suborders ){
				return;
			}

			foreach( $suborders as $suborder ){
				wp_trash_post( $suborder );
			}
		}

		/**
		 * Restore suborders on parent order restoring
		 *
		 * @param $post_id int Restore post id
		 * @return void
		 * @since 1.0.0
		 */
		public function untrash_suborders( $post_id ) {
			$order = wc_get_order( $post_id );

			if( ! $order ){
				return;
			}

			$suborders = $this->get_suborder( $post_id );

			if( ! $suborders ){
				return;
			}

			foreach( $suborders as $suborder ){
				wp_untrash_post( $suborder );
			}
		}

		/* === SUPPORT CART METHODS === */

		/**
		 * Create a support cart, used to temporarily replace actual cart and make shipping/tax calculation, suborders checkout
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function create_support_cart() {
			// save current cart
			$this->_cart = WC()->session->get( 'cart' );
			$this->_coupons = WC()->session->get( 'applied_coupons' );

			WC()->cart->empty_cart( true );
			WC()->cart->remove_coupons();
		}

		/**
		 * Restore original cart, saved in \YITH_WCDP_Suborders::_cart property
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function restore_original_cart() {
			// delete current cart
			WC()->cart->empty_cart( true );
			WC()->cart->remove_coupons();

			// reload cart
			WC()->session->set( 'cart', $this->_cart );
			WC()->session->set( 'applied_coupons', $this->_coupons );

			WC()->cart->get_cart_from_session();
		}

		/* === HELPER METHODS === */

		/**
		 * Check if order identified by $order_id has suborders, and eventually returns them
		 *
		 * @param $order_id int Id of the order to check
		 * @return mixed Array of suborders, if any
		 * @since 1.0.0
		 */
		public function get_suborder( $order_id ) {
			global $wpdb;

			$suborder_ids = array();

			if ( $order_id ) {
				$suborder_ids = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_parent=%d AND post_type=%s", absint( $order_id ), 'shop_order' ) );
			}

			return $suborder_ids;
		}

		/**
		 * Check if order identified by $order_id is a suborder (has post_parent)
		 *
		 * @param $order_id int Id of the order to check
		 * @return bool Whether order is a suborder or no
		 * @since 1.0.0
		 */
		public function is_suborder( $order_id ) {
			$order = wc_get_order( $order_id );

			if( ! $order ){
				return false;
			}

			return empty( $order->post_parent );
		}

		/**
		 * Get parent orders
		 *
		 * @return \WP_Post[] Array of found orders
		 * @since 1.0.0
		 */
		public function get_parent_orders() {
			$customer_orders = get_posts( apply_filters( 'yith_wcdp_add_parent_orders', array(
				'posts_per_page' => -1,
				'meta_query' => array(
					array(
						'key' => '_customer_user',
						'value' => get_current_user_id()
					),
					array(
						'key' => '_has_deposit'
					)
				),
				'post_type'   => wc_get_order_types( 'view-orders' ),
				'post_status' => array_keys( wc_get_order_statuses() ),
				'post_parent' => 0
			) ) );

			return $customer_orders;
		}

		/**
		 * Get child orders
		 *
		 * @return \WP_Post[] Array of found orders
		 * @since 1.0.0
		 */
		public function get_child_orders() {
			$customer_orders = get_posts( apply_filters( 'yith_wcdp_add_child_orders', array(
				'posts_per_page' => -1,
				'meta_query' => array(
					array(
						'key' => '_customer_user',
						'value' => get_current_user_id()
					),
					array(
						'key' => '_has_full_payment'
					)
				),
				'post_type'   => wc_get_order_types( 'view-orders' ),
				'post_status' => array_keys( wc_get_order_statuses() )
			) ) );

			return $customer_orders;
		}

		/**
		 * Returns single instance of the class
		 *
		 * @return \YITH_WCDP_Suborders
		 * @since 1.0.0
		 */
		public static function get_instance(){
			if( is_null( self::$instance ) ){
				self::$instance = new self;
			}

			return self::$instance;
		}
	}
}

/**
 * Unique access to instance of YITH_WCDP_suborders class
 *
 * @return \YITH_WCDP_Suborders
 * @since 1.0.0
 */
function YITH_WCDP_Suborders(){
	return YITH_WCDP_Suborders::get_instance();
}