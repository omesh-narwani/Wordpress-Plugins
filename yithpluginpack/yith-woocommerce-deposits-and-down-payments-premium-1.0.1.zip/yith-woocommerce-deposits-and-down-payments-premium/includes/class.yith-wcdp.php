<?php
/**
 * Main class
 *
 * @author Your Inspiration Themes
 * @package YITH WooCommerce Deposits and Down Payments
 * @version 1.0.0
 */

/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined( 'YITH_WCDP' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WCDP' ) ) {
	/**
	 * WooCommerce Deposits and Down Payments
	 *
	 * @since 1.0.0
	 */
	class YITH_WCDP {

		/**
		 * Plugin version
		 *
		 * @const string
		 * @since 1.0.0
		 */
		const YITH_WCDP_VERSION = '1.0.1';

		/**
		 * Single instance of the class
		 *
		 * @var \YITH_WCDP
		 * @since 1.0.0
		 */
		protected static $instance;

		/**
		 * Constructor.
		 *
		 * @return \YITH_WCDP
		 * @since 1.0.0
		 */
		public function __construct() {
			do_action( 'yith_wcdp_startup' );

			add_action( 'init', array( $this, 'install' ) );

			// load plugin-fw
			add_action( 'plugins_loaded', array( $this, 'plugin_fw_loader' ), 15 );

			// change checkout process
			add_filter( 'woocommerce_add_cart_item', array( $this, 'update_cart_item' ), 10, 3 );
			add_filter( 'woocommerce_add_cart_item_data', array( $this, 'update_cart_item_data' ), 10, 3 );
			add_filter( 'woocommerce_get_cart_item_from_session', array( $this, 'get_cart_item_from_session' ), 10, 2 );
			add_filter( 'woocommerce_add_order_item_meta', array( $this, 'update_order_item_data' ), 10, 2 );

			// ajax call handling
			add_action( 'wp_ajax_yith_wcdp_calculate_shipping', array( $this, 'ajax_calculate_shippings' ) );
			add_action( 'wp_ajax_nopriv_yith_wcdp_calculate_shipping', array( $this, 'ajax_calculate_shippings' ) );
		}

		/**
		 * Install plugin
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function install() {
			YITH_WCDP_Suborders();

			if( ! is_admin() ){
				YITH_WCDP_Frontend();
			}
		}

		/* === PLUGIN FW LOADER === */

		/**
		 * Loads plugin fw, if not yet created
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function plugin_fw_loader() {
			if ( ! defined( 'YIT_CORE_PLUGIN' ) ) {
				global $plugin_fw_data;
				if( ! empty( $plugin_fw_data ) ){
					$plugin_fw_file = array_shift( $plugin_fw_data );
					require_once( $plugin_fw_file );
				}
			}
		}

		/* === HELPER METHODS === */

		/**
		 * Return true if deposit is enabled on product
		 *
		 * @param $product_id int|bool Product id, if specified; false otherwise. If no product id is provided, global $product will be used
		 * @return bool Whether deposit is enabled for product
		 * @since 1.0.0
		 */
		public function is_deposit_enabled_on_product( $product_id = false ) {
			global $product;

			$product = ! $product_id ? $product : ( is_numeric( $product_id ) ? wc_get_product( $product_id ) : $product_id );

			// get global options
			$plugin_enabled = get_option( 'yith_wcdp_general_enable', 'yes' );

			// get product specific option
			$deposit_enabled = get_post_meta( $product->id, '_enable_deposit', true );
			$deposit_enabled = ! empty( $deposit_enabled ) ? $deposit_enabled : 'default';
			$deposit_enabled = ( $deposit_enabled == 'default' ) ? get_option( 'yith_wcdp_general_deposit_enable', 'no' ) : $deposit_enabled;

			return $plugin_enabled == 'yes' && $deposit_enabled == 'yes';
		}

		/**
		 * Return true in deposit is mandatory for a product
		 *
		 * @param $product_id int|bool Product id, if specified; false otherwise. If no product id is provided, global $product will be used
		 * @return bool Whether deposit is enabled for product
		 * @since 1.0.0
		 */
		public function  is_deposit_mandatory( $product_id = false ) {
			global $product;

			$product = ! $product_id ? $product : ( is_numeric( $product_id ) ? wc_get_product( $product_id ) : $product_id );

			// get product specific option
			$deposit_mandatory = get_post_meta( $product->id, '_force_deposit', true );
			$deposit_mandatory = ! empty( $deposit_mandatory ) ? $deposit_mandatory : 'default';
			$deposit_mandatory = ( $deposit_mandatory == 'default' ) ? get_option( 'yith_wcdp_general_deposit_force', 'no' ) : $deposit_mandatory;

			return $deposit_mandatory == 'yes';
		}

		/**
		 * Retrieve deposit amount (needed on amount deposit type)
		 *
		 * @return string Amount
		 * @since 1.0.0
		 */
		public function get_deposit_amount() {
			$deposit_amount = get_option( 'yith_wcdp_general_deposit_amount', 0 );

			return $deposit_amount;
		}

		/* === CHECKOUT PROCESS METHODS === */

		/**
		 * Update cart item when deposit is selected
		 *
		 * @param $cart_item mixed Current cart item
		 *
		 * @return mixed Filtered cart item
		 * @since 1.0.0
		 */
		public function update_cart_item( $cart_item ) {
			/**
			 * @var $product \WC_Product
			 */
			$product = $cart_item['data'];

			if( $this->is_deposit_enabled_on_product( $product ) ){
				$deposit_forced = $this->is_deposit_mandatory( $product->id );

				$deposit_amount = $this->get_deposit_amount();
				$deposit_value = min( $deposit_amount, $product->get_price() );

				if( isset( $_REQUEST['add-to-cart'] ) && ( $deposit_forced || ( isset( $_REQUEST['payment_type'] ) && $_REQUEST['payment_type'] == 'deposit' ) ) ){
					$cart_item['data']->price = $deposit_value;
					$cart_item['data']->virtual = 'yes';
				}
			}

			return $cart_item;
		}

		/**
		 * Add cart item data when deposit is selected, to store info to save with order
		 *
		 * @param $cart_item_data mixed Currently saved cart item data
		 * @param $product_id     int   Product id
		 *
		 * @return mixed Filtered cart item data
		 * @since 1.0.0
		 */
		public function update_cart_item_data( $cart_item_data, $product_id, $variation_id ) {
			$product_id = ! empty( $variation_id ) ? $variation_id : $product_id;
			$product = wc_get_product( $product_id );

			if( $this->is_deposit_enabled_on_product( $product_id ) ){
				$deposit_forced = $this->is_deposit_mandatory( $product_id );

				$deposit_amount = $this->get_deposit_amount();
				$deposit_value = $deposit_amount;

				$deposit_balance = max( $product->get_price() - $deposit_value, 0 );

				if( $deposit_forced || ( isset( $_REQUEST['payment_type'] ) && $_REQUEST['payment_type'] == 'deposit' ) ){
					$cart_item_data['deposit'] = true;
					$cart_item_data['deposit_type'] = 'amount';
					$cart_item_data['deposit_amount'] = $deposit_amount;
					$cart_item_data['deposit_rate'] = 0;
					$cart_item_data['deposit_value'] = $deposit_value;
					$cart_item_data['deposit_balance'] = $deposit_balance;
					$cart_item_data['deposit_shipping_method'] = isset( $_POST['shipping_method'] ) ? $_POST['shipping_method'] : false;
				}
			}

			return $cart_item_data;
		}

		/**
		 * Update cart item when retrieving cart from session
		 *
		 * @param $session_data mixed Session data to add to cart
		 * @param $values       mixed Values stored in session
		 *
		 * @return mixed Session data
		 * @since 1.0.0
		 */
		public function get_cart_item_from_session( $session_data, $values ) {
			if ( isset( $values['deposit'] ) && $values['deposit'] ) {

				$session_data['deposit'] = true;
				$session_data['deposit_type'] = isset( $values['deposit_type'] ) ? $values['deposit_type'] : '';
				$session_data['deposit_amount'] = isset( $values['deposit_amount'] ) ? $values['deposit_amount'] : '';
				$session_data['deposit_rate'] = isset( $values['deposit_rate'] ) ? $values['deposit_rate'] : '';
				$session_data['deposit_value'] = isset( $values['deposit_value'] ) ? $values['deposit_value'] : '';
				$session_data['deposit_balance'] = isset( $values['deposit_balance'] ) ? $values['deposit_balance'] : '';
				$session_data['deposit_shipping_method'] = isset( $values['deposit_shipping_method'] ) ? $values['deposit_shipping_method'] : '';

				if( isset( $values['deposit_value'] ) ) {
					$session_data['data']->price   = $values['deposit_value'];
					$session_data['data']->virtual = 'yes';
				}
			}


			return $session_data;
		}

		/**
		 * Store deposit cart item data as order item meta, on process checkout
		 *
		 * @param $item_id int   Currently created order item id
		 * @param $values  mixed Cart item data
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function update_order_item_data( $item_id, $values ) {
			if( isset( $values['deposit'] ) && $values['deposit'] ){
				wc_add_order_item_meta( $item_id, '_deposit', true );
				wc_add_order_item_meta( $item_id, '_deposit_type', $values['deposit_type'] );
				wc_add_order_item_meta( $item_id, '_deposit_amount', $values['deposit_amount'] );
				wc_add_order_item_meta( $item_id, '_deposit_rate', $values['deposit_rate'] );
				wc_add_order_item_meta( $item_id, '_deposit_value', $values['deposit_value'] );
				wc_add_order_item_meta( $item_id, '_deposit_balance', $values['deposit_balance'] );
				wc_add_order_item_meta( $item_id, '_deposit_shipping_method', $values['deposit_shipping_method'] );
			}
		}

		/* === AJAX METHODS === */

		/**
		 * Calculate shipping methods for currently selected product, and print them json-encoded for ajax requests
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function ajax_calculate_shippings() {
			if( ! isset( $_POST['product_id'] ) ){
				wp_send_json( array( 'template' => '' ) );
			}

			$product_id = $_POST['product_id'];
			$qty = isset( $_POST['qty'] ) ? $_POST['qty'] : 1;

			$product = wc_get_product( $product_id );

			if( ! $product ){
				wp_send_json( array( 'template' => '' ) );
			}

			$variation_id = $product->is_type( 'variation' ) ? $product->get_variation_id() : '';
			$variations  = $product->is_type( 'variation' ) ? $product->get_variation_attributes() : array();

			YITH_WCDP_Suborders()->create_support_cart();
			WC()->cart->add_to_cart( $product->id, $qty, $variation_id, $variations );
			WC()->cart->calculate_shipping();

			ob_start();
			wc_cart_totals_shipping_html();
			$shipping_template = ob_get_clean();

			YITH_WCDP_Suborders()->restore_original_cart();

			wp_send_json( array( 'template' => $shipping_template ) );
		}

		/**
		 * Returns single instance of the class
		 *
		 * @return \YITH_WCDP_Frontend
		 * @since 1.0.0
		 */
		public static function get_instance(){
			if( is_null( self::$instance ) ){
				self::$instance = new self;
			}

			return self::$instance;
		}
	}
}

/**
 * Unique access to instance of YITH_WCDP class
 *
 * @return \YITH_WCDP
 * @since 1.0.0
 */
function YITH_WCDP(){
	return YITH_WCDP::get_instance();
}