=== YITH WooCommerce Dynamic Pricing and Discounts  ===

Contributors: yithemes
Tags:
Requires at least: 3.5.1
Tested up to: 4.2
Stable tag: 1.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

YITH WooCommerce Dynamic Pricing and Discounts offers a powerful tool to directly modify prices and discounts of your store

== Description ==

An easy way to give new prices and offers!
With a simple click you can create dynamic offers to the customers of your shop: apply a discount percentage to the cart when it contains a certain number of products, or implement a small sale for each product added!

== Installation ==
Important: First of all, you have to download and activate WooCommerce plugin, which is mandatory for YITH WooCommerce Dynamic Pricing and Discounts to be working.

1. Unzip the downloaded zip file.
2. Upload the plugin folder into the `wp-content/plugins/` directory of your WordPress site.
3. Activate `YITH WooCommerce Dynamic Pricing and Discounts` from Plugins page.


= Configuration =
YITH WooCommerce Dynamic Pricing and Discounts will add a new tab called "Dynamic Pricing" in "YIT Plugins" menu item.
There, you will find all Yithemes plugins with quick access to plugin setting page.



== Changelog ==

= 1.0.3 =
Added: filter ywdpd_show_price_on_table_pricing on pricing table

= 1.0.2 =
Added: Compatibility with YITH WooCommerce Gift Cards Premium
Added: Support to WooCommerce 2.5 RC2
Updated: Plugin Core Framework
Updated: Table quantity for variations with min and max amount


= 1.0.1 =
Added: Support to WooCommerce 2.4.2
Updated: Plugin Core Framework

= 1.0.0 =
Initial release

