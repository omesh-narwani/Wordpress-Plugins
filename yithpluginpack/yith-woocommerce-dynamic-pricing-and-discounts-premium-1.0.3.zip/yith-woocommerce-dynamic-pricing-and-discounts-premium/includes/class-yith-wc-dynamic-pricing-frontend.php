<?php

if ( !defined( 'ABSPATH' ) || !defined( 'YITH_YWDPD_VERSION' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Implements frontend features of YITH WooCommerce Dynamic Pricing and Discounts
 *
 * @class   YITH_WC_Dynamic_Pricing_Frontend
 * @package YITH WooCommerce Dynamic Pricing and Discounts
 * @since   1.0.0
 * @author  Yithemes
 */
if ( !class_exists( 'YITH_WC_Dynamic_Pricing_Frontend' ) ) {

    class YITH_WC_Dynamic_Pricing_Frontend {

        /**
         * Single instance of the class
         *
         * @var \YITH_WC_Dynamic_Pricing_Frontend
         */
        protected static $instance;

        /**
         * The pricing rules
         *
         * @access public
         * @var string
         * @since 1.0.0
         */
        public $pricing_rules = array();



        /**
         * Returns single instance of the class
         *
         * @return \YITH_WC_Dynamic_Pricing_Frontend
         * @since 1.0.0
         */
        public static function get_instance() {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function __construct() {

            if ( YITH_WC_Dynamic_Pricing()->get_option('enabled') != 'yes' ){
                return;
            }

            //custom styles and javascripts
            add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles_scripts' ) );
            $this->pricing_rules = YITH_WC_Dynamic_Pricing()->get_pricing_rules();

            add_filter( 'woocommerce_cart_item_price', array( $this, 'replace_cart_item_price' ), 100, 3 );

            if ( ( !empty( $_REQUEST['add-to-cart'] ) && is_numeric( $_REQUEST['add-to-cart'] ) ) || ( isset( $_REQUEST['action'] ) && $_REQUEST['action'] == 'woocommerce_add_to_cart' ) ) {
                add_action( 'woocommerce_add_to_cart', array( $this, 'cart_process_discounts' ), 99 );
            }
            else {
                add_action( 'woocommerce_cart_loaded_from_session', array( $this, 'cart_process_discounts' ), 99 );
            }


            add_filter( 'woocommerce_get_price_html', array( &$this, 'get_price_html' ), 10, 2 );
            add_filter( 'woocommerce_get_price', array( $this, 'get_price' ), 10, 2 );

            if ( YITH_WC_Dynamic_Pricing()->get_option( 'show_quantity_table' ) == 'yes' ) {
                $this->table_quantity_init();
            }

        }

        /**
         * Process dynamic pricing in cart
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */

        public function cart_process_discounts( ){

            if ( empty( WC()->cart->cart_contents ) ){
                return;
            }

			WC()->cart->remove_coupon( YITH_WC_Dynamic_Discounts()->label_coupon );
			WC()->session->set('refresh_totals', true);

			//empty old discounts
            foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                if ( isset( WC()->cart->cart_contents[$cart_item_key]['ywdpd_discounts'] ) ) {
                    unset( WC()->cart->cart_contents[$cart_item_key]['ywdpd_discounts'] );
                }
            }


            //add processed pricing rules on each cart item
            foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                YITH_WC_Dynamic_Pricing()->get_applied_rules_to_product( $cart_item_key, $cart_item );
            }


            //apply the discount to each cart item
            foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                if ( isset( $cart_item['ywdpd_discounts'] ) ){
                   // print_r($cart_item);
                    YITH_WC_Dynamic_Pricing()->apply_discount( $cart_item, $cart_item_key );
                }
            }

			if( ! isset( $_REQUEST['remove_coupon'] ) )
				YITH_WC_Dynamic_Discounts()->apply_discount();

			if ( current_filter() == 'woocommerce_ajax_added_to_cart'  || defined( 'DOING_AJAX' )  ) {
                //WC()->cart->calculate_totals();
			}

        }


		/**
		 * Replace the price in the cart
		 *
		 * @since  1.0.0
		 * @author Emanuela Castorina
		 */
        public function replace_cart_item_price( $price, $cart_item, $cart_item_key ){

            if ( !isset( $cart_item['ywdpd_discounts'] ) ) {
                return $price;
            }
			$old_price = $price;

            foreach ( $cart_item['ywdpd_discounts'] as $discount ) {
                if ( isset( $discount['status'] ) && $discount['status'] == 'applied' ) {

                    if( wc_price( $cart_item['ywdpd_discounts']['default_price'] ) !=  WC()->cart->get_product_price( $cart_item['data'] ) ){
						$price = '<del>' . wc_price( $cart_item['ywdpd_discounts']['default_price'] ) . '</del> ' . WC()->cart->get_product_price( $cart_item['data'] );
                    }else{
                        return $price;
                    }
                }
            }

			$price = apply_filters('ywdpd_replace_cart_item_price', $price,  $old_price, $cart_item, $cart_item_key ) ;
            return $price;
        }


        /**
         * Show table quantity in the single product if there's a princing rule
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function show_table_quantity(){
            global $product;

            remove_filter( 'woocommerce_get_price', array( $this, 'get_price' ), 10, 2 );

            $valid_rules = YITH_WC_Dynamic_Pricing()->get_pricing_rules();


            if( empty( $valid_rules ) ){
                return;
            }

            foreach( $valid_rules as $rule ){

                $show_onsale       = ( isset( $rule['apply_on_sale'] ) ) ? 1 : 0;
                $show_table_price  = ( isset( $rule['show_table_price'] ) ) ? 1 : 0;
                if ( !$show_table_price || ( !$show_onsale && $product->is_on_sale() ) ) {
                    continue;
                }

                if( $rule['discount_mode'] == 'bulk' && $rule['show_table_price'] && $rule['apply_adjustment'] == 'same_product' && YITH_WC_Dynamic_Pricing_Helper()->valid_product_to_apply_bulk( $rule, $product->id ) ){
                    $args = array(
                        'rules'          => $rule['rules'],
                        'product'        => $product,
                        'note'           => $rule['table_note'],
                        'label_table'    => YITH_WC_Dynamic_Pricing()->get_option( 'show_quantity_table_label' ),
                        'label_quantity' => YITH_WC_Dynamic_Pricing()->get_option( 'show_quantity_table_label_quantity' ),
                        'label_price'    => YITH_WC_Dynamic_Pricing()->get_option( 'show_quantity_table_label_price' ),
                        'until'          => ( YITH_WC_Dynamic_Pricing()->get_option( 'show_quantity_table_schedule' ) == 'yes' && $rule['schedule_to'] != '' ) ? sprintf( __( 'Offer ends: %s', 'ywdpd' ), date_i18n( wc_date_format(), strtotime( $rule['schedule_to'] ) ) ) : ''
                    );
                    wc_get_template('yith_ywdpd_table_pricing.php', $args, '', YITH_YWDPD_TEMPLATE_PATH);
                }
            }

            add_filter( 'woocommerce_get_price', array( $this, 'get_price' ), 10, 2 );
        }


		function get_price_html(  $price, $product ){

			if ( is_admin() || is_cart() || is_checkout() || apply_filters('ywdpd_get_price_exclusion', false,  $price, $product ) ) {
				return $price;
			}

			remove_filter( 'woocommerce_get_price', array( $this, 'get_price' ), 10, 2 );

			$display_price         = $product->get_display_price();
			$display_regular_price = $product->get_display_price( $product->get_regular_price() );
			$discount              = YITH_WC_Dynamic_Pricing()->get_discount_price( $display_price, $product );
			$from                  = '';


			if ( $discount && $discount != $display_regular_price ) {

				if ( apply_filters( 'wc_dynamic_pricing_use_discount_format', true ) ) {

					if ( $product->is_type( 'variable' ) ) {
						$from = '<span class="from">' . _x( 'From:', 'min_price', 'ywdpd' ) . ' </span>';
					}

					$price = '<del>' . wc_price( $display_regular_price ) . '</del><ins> ' . $from . wc_price( $discount ) . '</ins>';
				}
				else {

					if ( $product->is_type( 'variable' ) ) {
						$from = '<span class="from">' . _x( 'From:', 'min_price', 'ywdpd' ) . ' </span>';
					}

					$price = $from . wc_price( $discount );
				}

				$price .= $product->get_price_suffix();
			}
			elseif ( $discount === 0 || $discount === 0.00 ) {

				if( ! is_admin() ){
					$price = $product->get_price_html_from_to( $display_regular_price, __( 'Free!', 'ywdpd' ) );
				}

			}

			if( ! is_admin() ){
				add_filter( 'woocommerce_get_price', array( $this, 'get_price' ), 10, 2 );
			}

			return apply_filters( 'yith_ywdpd_single_bulk_discount', $price, $product );


		}

		function get_price( $price, $product ){

			if( is_admin() || is_cart() || is_checkout() || defined('DOING_AJAX') || apply_filters('ywdpd_get_price_exclusion', false,  $price, $product ) ){
				return $price;
			}

			$discount = (string) YITH_WC_Dynamic_Pricing()->get_discount_price( $price, $product );

			return apply_filters('yith_ywdpd_get_price', $discount, $product) ;

		}

		/**
		 * Enqueue styles and scripts
		 *
		 * @access public
		 * @return void
		 * @since 1.0.0
		 */
		public function enqueue_styles_scripts() {
			wp_enqueue_style( 'yith_ywdpd_frontend', YITH_YWDPD_ASSETS_URL . '/css/frontend.css' );
		}

		/**
		 * Add action for single product page to display table pricing
		 *
		 * @since  1.0.0
		 * @author Emanuela Castorina
		 */
		function table_quantity_init(){
			//Table Pricing
			$position = YITH_WC_Dynamic_Pricing()->get_option('show_quantity_table_place');
			$priority_single_add_to_cart = has_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart' );
			$priority_single_excerpt = has_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt' );
			switch( $position ){
				case 'before_add_to_cart':
					if( $priority_single_add_to_cart ){
						add_action( 'woocommerce_single_product_summary', array( $this, 'show_table_quantity'), $priority_single_add_to_cart - 1 );
					}else{
						add_action( 'woocommerce_single_product_summary', array( $this, 'show_table_quantity'), 28 );
					}
					break;
				case 'after_add_to_cart':
					if( $priority_single_add_to_cart ){
						add_action( 'woocommerce_single_product_summary', array( $this, 'show_table_quantity'), $priority_single_add_to_cart + 1 );
					}else{
						add_action( 'woocommerce_single_product_summary', array( $this, 'show_table_quantity'), 32 );
					}
					break;
				case 'before_excerpt':
					if( $priority_single_excerpt ){
						add_action( 'woocommerce_single_product_summary', array( $this, 'show_table_quantity'), $priority_single_excerpt - 1 );
					}else{
						add_action( 'woocommerce_single_product_summary', array( $this, 'show_table_quantity'), 18 );
					}
					break;
				case 'after_excerpt':
					if( $priority_single_excerpt ){
						add_action( 'woocommerce_single_product_summary', array( $this, 'show_table_quantity'), $priority_single_excerpt + 1 );
					}else{
						add_action( 'woocommerce_single_product_summary', array( $this, 'show_table_quantity'), 22 );
					}
					break;
				case 'after_meta':
					$priority_after_meta = has_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta');
					if( $priority_after_meta ){
						add_action( 'woocommerce_single_product_summary', array( $this, 'show_table_quantity'), $priority_after_meta + 1 );
					}else{
						add_action( 'woocommerce_single_product_summary', array( $this, 'show_table_quantity'), 42 );
					}
				default:
					break;
			}


		}

	}
}

/**
 * Unique access to instance of YITH_WC_Dynamic_Pricing_Frontend class
 *
 * @return \YITH_WC_Dynamic_Pricing_Frontend
 */
function YITH_WC_Dynamic_Pricing_Frontend() {
    return YITH_WC_Dynamic_Pricing_Frontend::get_instance();
}

