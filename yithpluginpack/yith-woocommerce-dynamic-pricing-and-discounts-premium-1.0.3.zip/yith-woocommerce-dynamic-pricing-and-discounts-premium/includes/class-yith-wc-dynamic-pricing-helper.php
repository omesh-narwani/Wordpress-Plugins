<?php

if ( !defined( 'ABSPATH' ) || !defined( 'YITH_YWDPD_VERSION' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Helper function for YITH WooCommerce Dynamic Pricing and Discounts
 *
 * @class   YITH_WC_Dynamic_Pricing
 * @package YITH WooCommerce Dynamic Pricing and Discounts
 * @since   1.0.0
 * @author  Yithemes
 */
if ( !class_exists( 'YITH_WC_Dynamic_Pricing_Helper' ) ) {

    class YITH_WC_Dynamic_Pricing_Helper {

        /**
         * Single instance of the class
         *
         * @var \YITH_WC_Dynamic_Pricing_Helper
         */

        protected static $instance;

        public $product_counters = array();
        public $variation_counters = array();
        public $categories_counter = array();
        public $cart_categories = array();
        public $discounts_to_apply = array();

        /**
         * Returns single instance of the class
         *
         * @return \YITH_WC_Dynamic_Pricing_Helper
         * @since 1.0.0
         */
        public static function get_instance() {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function __construct() {
            add_action( 'woocommerce_cart_loaded_from_session', array( $this, 'load_counters' ), 98 );
        }


        public function load_counters(){
            if( empty( WC()->cart->cart_contents ) ){
                return;
            }

            $this->reset_counters();

            foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                $product_id   = $cart_item['product_id'];
                $variation_id = ( isset( $cart_item['variation_id'] ) && $cart_item['variation_id']!='' ) ? $cart_item['variation_id'] : false ;
                $quantity     = $cart_item['quantity'];

                if( $variation_id ){
                    $this->product_counters[$product_id]   = isset( $this->product_counters[$product_id] ) ?
                        $this->product_counters[$product_id] + $quantity : $quantity;

                    $this->variation_counters[$variation_id] = isset( $this->variation_counters[$variation_id] ) ?
                        $this->variation_counters[$variation_id] + $quantity : $quantity;
                }else{
                    $this->product_counters[$product_id]   = isset( $this->product_counters[$product_id] ) ?
                        $this->product_counters[$product_id] + $quantity : $quantity;
                }

                $categories = wp_get_post_terms( $product_id, 'product_cat' );
                foreach ( $categories as $category ) {
                    $this->categories_counter[$category->term_id] = isset( $this->categories_counter[$category->term_id] ) ?
                        $this->categories_counter[$category->term_id] + $quantity : $quantity;

                    $this->cart_categories[] = $category->term_id;
                }
            }
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        private function reset_counters( ){
            $this->categories_counter = array();
            $this->cart_categories = array();
            $this->product_counters = array();
            $this->variation_counters = array();
        }


        /**
         * Get all user role list for select field
         *
         * @access public
         * @return array
         */
        public function get_roles(){
            global $wp_roles;
            return array_merge(array('' => ''), $wp_roles->get_names());
        }


        /**
         * Validate date
         *
         * @access public
         * @return array
         */
        public function validate_schedule( $from, $to ){

            $now = time();

            if( $from != ''){
                $from = strtotime($from) ;
                if( $now < $from ){
                    return false;
                }
            }

            if( $to != '' ){
                $to = strtotime($to)+ 86399;
                if( $now > $to ){
                    return false;
                }
            }

            return true;
        }

        /**
         * Validate user
         *
         * @access public
         * @return array
         */
        public function validate_user( $type, $users_list ){

            if ( is_user_logged_in() ) {
                $current_user = wp_get_current_user();
                $intersect = array_intersect( $current_user->roles, $users_list );

                switch( $type ){
                    case 'role_list':

                        if ( !empty( $current_user->roles ) && is_array( $current_user->roles ) && !empty( $intersect ) ) {
                            return true;
                        }
                        break;
                    case 'role_list_excluded':
                        if ( !empty( $current_user->roles ) && is_array( $current_user->roles ) && empty( $intersect ) ) {
                            return true;
                        }
                        break;
                    case 'customers_list':
                        if ( in_array( $current_user->ID, $users_list ) ) {
                            return true;
                        }
                        break;
                    case 'customers_list_excluded':

                        if ( ! in_array( $current_user->ID, $users_list ) ) {
                            return true;
                        }
                        break;
                    default:
                }
            }


            return false;
        }


        /**
         * Validate product apply_to
         *
         * @access public
         * @return array
         */
        function validate_apply_to( $key_rule, $rule, $cart_item_key, $cart_item ){

            $is_valid = false;


            if( $this->is_in_exclusion_rule( $cart_item ) ){
                return false;
            }

            switch( $rule['apply_to'] ){
                case 'all_products':
                    $is_valid = true;
                    break;
                case 'products_list':
                    $product_list = $rule['apply_to_products_list'];
                    if( in_array( $cart_item['product_id'], $product_list ) ){
                        $is_valid = true;
                    }
                    break;
                case 'products_list_excluded':
                    $product_list = $rule['apply_to_products_list_excluded'];
                    if( ! in_array( $cart_item['product_id'], $product_list ) ){
                        $is_valid = true;
                    }
                    break;
                case 'categories_list':
                    $categories_list = $rule['apply_to_categories_list'];
                    $categories_of_item = wc_get_product_terms( $cart_item['product_id'], 'product_cat', array( 'fields' => 'ids' ) );
                    $intersect = array_intersect( $categories_of_item, $categories_list );
                    if( ! empty($intersect) ){
                        $is_valid = true;
                    }
                    break;
                case 'categories_list_excluded':
                    $categories_list = $rule['apply_to_categories_list_excluded'];
                    $categories_of_item = wc_get_product_terms( $cart_item['product_id'], 'product_cat', array( 'fields' => 'ids' ) );
                    $intersect = array_intersect( $categories_of_item, $categories_list );
                    if ( empty( $intersect ) ) {
                        $is_valid = true;
                    }
                    break;
                case 'vendor_list':
                    if( ! class_exists('YITH_Vendors') ){
                        break;
                    }                    $vendor_list = array_map('intval', $rule['apply_to_vendors_list']);
                    $vendor_of_item = wc_get_product_terms( $cart_item['product_id'], YITH_Vendors()->get_taxonomy_name(), array( 'fields' => 'ids' ) );
                    $intersect = array_intersect( $vendor_of_item, $vendor_list );
                    if ( ! empty( $intersect ) ) {
                        $is_valid = true;
                    }
                    break;
                case 'vendor_list_excluded':
                    if( ! class_exists('YITH_Vendors') ){
                        break;
                    }
                    $vendor_list = array_map('intval', $rule['apply_to_vendors_list_excluded']);
                    $vendor_of_item = wc_get_product_terms( $cart_item['product_id'], YITH_Vendors()->get_taxonomy_name(), array( 'fields' => 'ids' ) );
                    $intersect = array_intersect( $vendor_of_item, $vendor_list );
                    if ( empty( $intersect ) ) {
                        $is_valid = true;
                    }
                    break;

                default:
            }

            if( $is_valid ){

                $discount = array();
                $quantity = $this->check_quantity($rule, $cart_item);
                $product_id = ( isset( $cart_item['variation_id'] ) && $cart_item['variation_id'] != '' ) ? $cart_item['variation_id'] : $cart_item['product_id'];
                $product    = wc_get_product( $product_id );

                $discount['key']           = $key_rule;
                $discount['status']        = 'processing';
                $discount['exclusive']     = ( isset( $rule['apply_with_other_rules'] ) && $rule['apply_with_other_rules'] == 1 ) ? 0 : 1;
                $discount['onsale']        = ( isset( $rule['apply_on_sale'] ) ) ? 1 : 0;

                remove_filter( 'woocommerce_get_price', array( YITH_WC_Dynamic_Pricing_Frontend(), 'get_price' ), 10, 2 );
                $discount['default_price'] = ( WC()->cart->tax_display_cart == 'excl' ) ? $product->get_price_excluding_tax() : $product->get_price_including_tax();
                add_filter( 'woocommerce_get_price', array( YITH_WC_Dynamic_Pricing_Frontend(), 'get_price' ), 10, 2 );


                if( $rule['discount_mode'] == 'bulk'){
                    $discount['discount_mode'] = 'bulk';
                    foreach ( $rule['rules'] as $index => $r ) {

                        if ( ( $quantity >= $r['min_quantity'] && $r['max_quantity'] == '*' ) || ( $quantity <= $r['max_quantity'] && $quantity >= $r['min_quantity'] ) ) {
                            $discount['discount_amount'] = array(
                                'type' => $r['type_discount'],
                                'amount' => $r['discount_amount']
                            );
                            break;
                        }
                    }
                }elseif( $rule['discount_mode'] == 'special_offer'){

                    $discount['discount_mode'] = 'special_offer';
                    $quantity_to_check =  $rule['so-rule']['purchase'];
                    if( $rule['apply_adjustment'] == 'same_product' || $rule['apply_adjustment'] == 'all_products' ){
                        $quantity_to_check =  $rule['so-rule']['purchase'] + $rule['so-rule']['receive'];
                    }

                    if(  $quantity >= $quantity_to_check  ){

                        $repeat = ( isset($rule['so-rule']['repeat']) ) ? floor( $quantity/$rule['so-rule']['purchase']) : 0;
                        $qty_receive = ( $rule['apply_adjustment'] == 'same_product' || $rule['apply_adjustment'] == 'all_products' ) ?  $quantity : 0;

                        $discount['discount_amount'] = array(
                            'type'         => $rule['so-rule']['type_discount'],
                            'amount'       => $rule['so-rule']['discount_amount'],
                            'purchase'     => $rule['so-rule']['purchase'],
                            'receive'      => $rule['so-rule']['receive'],
                            'same_product' => 0,
                            'qty_purchase' => $quantity,
                            'qty_receive'  => $qty_receive,
                            'repeat'       => $repeat
                        );
                    }

                }

                if( ! isset( $discount['discount_amount']) ){
                    return false;
                }
                //check if the rule can be applied to current cart item
                if( $rule['apply_adjustment'] == 'same_product' ||  $rule['apply_adjustment'] == 'all_products'  || $this->valid_product_to_adjust( $rule, $cart_item['product_id']) ){
                    WC()->cart->cart_contents[$cart_item_key]['ywdpd_discounts'][$key_rule] = $discount;
                    WC()->cart->cart_contents[$cart_item_key]['ywdpd_discounts'][$key_rule]['discount_amount']['same_product'] = 1;
                }
                if( $rule['apply_adjustment'] != 'same_product' ){
                    foreach ( WC()->cart->cart_contents as $cart_item_key_adj => $cart_item_adj ) {
                        if( $discount['discount_mode'] == 'special_offer'){
                            $qty_receive = $this->check_quantity( $rule, $cart_item_adj );
                            $discount['discount_amount']['qty_receive'] = $qty_receive;
                        }

                        $this->process_rule_adjustment( $rule, $key_rule, $cart_item_key_adj, $cart_item_adj, $discount );
                    }
                }

            }



            return $is_valid;

        }

        function is_in_exclusion_rule( $cart_item ){

            $exclusion_rules = YITH_WC_Dynamic_Pricing()->get_exlusion_rules();
            $excluded = false;
            foreach( $exclusion_rules as $rule ){

                switch( $rule['apply_to'] ){
                    case 'all_products':
                        return true;
                        break;
                    case 'products_list':
                        $product_list = $rule['apply_to_products_list'];
                        if( in_array( $cart_item['product_id'], $product_list ) ){
                            $excluded = true;
                        }
                        break;
                    case 'products_list_excluded':
                        $product_list = $rule['apply_to_products_list_excluded'];
                        if( ! in_array( $cart_item['product_id'], $product_list ) ){
                            $excluded = true;
                        }
                        break;
                    case 'categories_list':
                        $categories_list = $rule['apply_to_categories_list'];
                        $categories_of_item = wc_get_product_terms( $cart_item['product_id'], 'product_cat', array( 'fields' => 'ids' ) );
                        $intersect = array_intersect( $categories_of_item, $categories_list );
                        if( ! empty($intersect) ){
                            $excluded = true;
                        }
                        break;
                    case 'categories_list_excluded':
                        $categories_list = $rule['apply_to_categories_list_excluded'];
                        $categories_of_item = wc_get_product_terms( $cart_item['product_id'], 'product_cat', array( 'fields' => 'ids' ) );
                        $intersect = array_intersect( $categories_of_item, $categories_list );
                        if ( empty( $intersect ) ) {
                            $excluded = true;
                        }
                        break;
                    case 'vendor_list':
                        if( ! class_exists('YITH_Vendors') ){
                            break;
                        }
                        $vendor_list = array_map('intval', $rule['apply_to_vendors_list']);
                        $vendor_of_item = wc_get_product_terms( $cart_item['product_id'], YITH_Vendors()->get_taxonomy_name(), array( 'fields' => 'ids' ) );
                        $intersect = array_intersect( $vendor_of_item, $vendor_list );
                        if ( ! empty( $intersect ) ) {
                            $excluded = true;
                        }
                        break;
                    case 'vendor_list_excluded':
                        if( ! class_exists('YITH_Vendors') ){
                            break;
                        }
                        $vendor_list = array_map('intval', $rule['apply_to_vendors_list_excluded']);
                        $vendor_of_item = wc_get_product_terms( $cart_item['product_id'], YITH_Vendors()->get_taxonomy_name(), array( 'fields' => 'ids' ) );
                        $intersect = array_intersect( $vendor_of_item, $vendor_list );
                        if ( empty( $intersect ) ) {
                            $excluded = true;
                        }
                        break;
                    default:
                }
            }
            return $excluded;
        }


        function process_rule_adjustment( $rule, $key_rule, $cart_item_key, $cart_item, $discount){
            if( isset( WC()->cart->cart_contents[$cart_item_key]['ywdpd_discounts'][$key_rule])){
                return false;
            }

            if( $this->valid_product_to_adjust( $rule, $cart_item['product_id'] ) ){
                WC()->cart->cart_contents[$cart_item_key]['ywdpd_discounts'][$key_rule] = $discount;
            }
        }

        function check_quantity( $rule, $cart_item ){

            $quantity = $cart_item['quantity'];

            if( $rule['discount_mode'] == 'bulk' || $rule['discount_mode'] == 'special_offer'){
                switch( $rule['quantity_based'] ){
                    case 'cart_line':
                        break;
                    case 'single_product':
                        if ( isset( $this->product_counters[$cart_item['product_id']] ) ) {
                            $quantity = $this->product_counters[$cart_item['product_id']];
                        }
                        break;
                    case 'single_variation_product':
                        if ( isset($cart_item['variation_id'] ) && $cart_item['variation_id']!='' && isset( $this->variation_counters[$cart_item['variation_id']] ) ) {
                            $quantity = $this->variation_counters[$cart_item['variation_id']];
                        }
                        break;
                    case 'cumulative':
                        $quantity = $this->get_cumulative_quantity($rule);
                        break;
                    default:
                }
            }

            return $quantity;
        }

        function get_cumulative_quantity( $rule ) {
            $quantity = 0;
            switch ( $rule['apply_to'] ) {
                case 'all_products':
                    foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                        $quantity += $cart_item['quantity'];
                    }
                    break;
                case 'products_list':
                    foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                        $product_list = $rule['apply_to_products_list'];
                        if ( in_array( $cart_item['product_id'], $product_list ) ) {
                            $quantity += $cart_item['quantity'];
                        }
                    }
                    break;
                case 'products_list_excluded':
                    foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                        $product_list = $rule['apply_to_products_list_excluded'];
                        if ( ! in_array( $cart_item['product_id'], $product_list ) ) {
                            $quantity += $cart_item['quantity'];
                        }
                    }
                    break;
                case 'categories_list':
                    foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                        $categories_list    = $rule['apply_to_categories_list'];
                        $categories_of_item = wc_get_product_terms( $cart_item['product_id'], 'product_cat', array( 'fields' => 'ids' ) );
                        $intersect          = array_intersect( $categories_of_item, $categories_list );
                        if ( ! empty( $intersect ) ) {
                            $quantity += $cart_item['quantity'];
                        }
                    }
                    break;
                case 'categories_list_excluded':
                    foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                        $categories_list    = $rule['apply_to_categories_list'];
                        $categories_of_item = wc_get_product_terms( $cart_item['product_id'], 'product_cat', array( 'fields' => 'ids' ) );
                        $intersect          = array_intersect( $categories_of_item, $categories_list );
                        if ( empty( $intersect ) ) {
                            $quantity += $cart_item['quantity'];
                        }
                    }
                    break;
                case 'vendor_list':
                    if( ! class_exists('YITH_Vendors') ){
                        break;
                    }
                    foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                        $vendor_list    = array_map( 'intval', $rule['apply_to_vendors_list'] );
                        $vendor_of_item = wc_get_product_terms( $cart_item['product_id'], YITH_Vendors()->get_taxonomy_name(), array( 'fields' => 'ids' ) );
                        $intersect      = array_intersect( $vendor_of_item, $vendor_list );
                        if ( ! empty( $intersect ) ) {
                            $quantity += $cart_item['quantity'];
                        }
                    }
                    break;
                case 'vendor_list_excluded':
                    if( ! class_exists('YITH_Vendors') ){
                        break;
                    }
                    foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                        $vendor_list    = array_map( 'intval', $rule['apply_to_vendors_list_excluded'] );
                        $vendor_of_item = wc_get_product_terms( $cart_item['product_id'], YITH_Vendors()->get_taxonomy_name(), array( 'fields' => 'ids' ) );
                        $intersect      = array_intersect( $vendor_of_item, $vendor_list );
                        if ( empty( $intersect ) ) {
                            $quantity += $cart_item['quantity'];
                        }
                    }
                    break;
                default:
            }

            return $quantity;
        }

        function valid_product_to_adjust( $rule, $product_id ){
            $is_valid = false;

            switch( $rule['apply_adjustment'] ){
                case 'all_products':
                    $is_valid = true;
                    break;
                case 'products_list':
                    $product_list = $rule['apply_adjustment_products_list'];
                    if( in_array( $product_id, $product_list ) ){
                        $is_valid = true;
                    }
                    break;
                case 'products_list_excluded':
                    $product_list = $rule['apply_adjustment_products_list_excluded'];
                    if( ! in_array( $product_id, $product_list ) ){
                        $is_valid = true;
                    }
                    break;
                case 'categories_list':
                    $categories_list = $rule['apply_adjustment_categories_list'];
                    $categories_of_item = wc_get_product_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
                    $intersect = array_intersect( $categories_of_item, $categories_list );
                    if( ! empty($intersect) ){
                        $is_valid = true;
                    }
                    break;
                case 'categories_list_excluded':
                    $categories_list = $rule['apply_adjustment_categories_list_excluded'];
                    $categories_of_item = wc_get_product_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
                    $intersect = array_intersect( $categories_of_item, $categories_list );
                    if ( empty( $intersect ) ) {
                        $is_valid = true;
                    }
                    break;
                case 'vendor_list':
                    if( ! class_exists('YITH_Vendors') ){
                        break;
                    }
                    $vendor_list = array_map('intval', $rule['apply_adjustment_vendor_list']);
                    $vendor_of_item = wc_get_product_terms( $product_id, YITH_Vendors()->get_taxonomy_name(), array( 'fields' => 'ids' ) );
                    $intersect = array_intersect( $vendor_of_item, $vendor_list );
                    if ( ! empty( $intersect ) ) {
                        $is_valid = true;
                    }
                    break;
                case 'vendor_list_excluded':
                    if( ! class_exists('YITH_Vendors') ){
                        break;
                    }
                    $vendor_list = array_map('intval', $rule['apply_adjustment_vendor_list_excluded']);
                    $vendor_of_item = wc_get_product_terms( $product_id, YITH_Vendors()->get_taxonomy_name(), array( 'fields' => 'ids' ) );
                    $intersect = array_intersect( $vendor_of_item, $vendor_list );
                    if ( empty( $intersect ) ) {
                        $is_valid = true;
                    }
                    break;
                default:
            }



            return $is_valid;


        }

        function valid_product_to_apply_bulk( $rule, $product_id ){
            $is_valid = false;

            switch( $rule['apply_to'] ){
                case 'all_products':
                    $is_valid = true;
                    break;
                case 'products_list':
                    $product_list = $rule['apply_to_products_list'];
                    if( in_array( $product_id, $product_list ) ){
                        $is_valid = true;
                    }
                    break;
                case 'products_list_excluded':
                    $product_list = $rule['apply_to_products_list_excluded'];
                    if( ! in_array( $product_id, $product_list ) ){
                        $is_valid = true;
                    }
                    break;
                case 'categories_list':
                    $categories_list = $rule['apply_to_categories_list'];
                    $categories_of_item = wc_get_product_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
                    $intersect = array_intersect( $categories_of_item, $categories_list );
                    if( ! empty($intersect) ){
                        $is_valid = true;
                    }
                    break;
                case 'categories_list_excluded':
                    $categories_list = $rule['apply_to_categories_list_excluded'];
                    $categories_of_item = wc_get_product_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
                    $intersect = array_intersect( $categories_of_item, $categories_list );
                    if ( empty( $intersect ) ) {
                        $is_valid = true;
                    }
                    break;
                case 'vendor_list':
                    if( ! class_exists('YITH_Vendors') ){
                        break;
                    }
                    $vendor_list = array_map('intval', $rule['apply_to_vendors_list']);
                    $vendor_of_item = wc_get_product_terms( $product_id, YITH_Vendors()->get_taxonomy_name(), array( 'fields' => 'ids' ) );
                    $intersect = array_intersect( $vendor_of_item, $vendor_list );
                    if ( ! empty( $intersect ) ) {
                        $is_valid = true;
                    }
                    break;
                case 'vendor_list_excluded':
                    if( ! class_exists('YITH_Vendors') ){
                        break;
                    }
                    $vendor_list = array_map('intval', $rule['apply_to_vendors_list_excluded']);
                    $vendor_of_item = wc_get_product_terms( $product_id, YITH_Vendors()->get_taxonomy_name(), array( 'fields' => 'ids' ) );
                    $intersect = array_intersect( $vendor_of_item, $vendor_list );
                    if ( empty( $intersect ) ) {
                        $is_valid = true;
                    }
                    break;
                default:
            }

            return $is_valid;

        }


        function valid_num_of_orders( $num ){

            $is_valid = false;
            if ( is_user_logged_in() ) {
                $current_user = wp_get_current_user();

                $args = array(
                    'numberposts'   => -1,
                    'post_type'     => 'shop_order',
                    'post_status'   => 'wc-completed',
                    'meta_key'      => '_customer_user',
                    'meta_value'    => $current_user->ID,

                );

                $orders = get_posts($args);

                if( count( $orders)  >= $num ){
                    return true;
                }
            }

            return $is_valid;
        }

        function valid_amount_spent( $limit ){

            $is_valid = false;
            if ( is_user_logged_in() ) {
                $current_user = wp_get_current_user();
                $args = array(
                    'numberposts'   => -1,
                    'post_type'     => 'shop_order',
                    'post_status'   => 'wc-completed',
                    'meta_key'      => '_customer_user',
                    'meta_value'    => $current_user->ID,
                );

                $orders = get_posts($args);
                $amount = 0;
                if( !empty($orders) ){
                    foreach( $orders as $order ){
                        $order_obj = wc_get_order( $order->ID );
                        $amount += $order_obj->get_total();
                        if( $amount >= $limit ){
                            return true;
                        }
                    }
                }
            }

            return $is_valid;
        }

        function valid_sum_item_quantity( $quantity ){
            $num_items =  WC()->cart->get_cart_contents_count();

            if( $num_items >= $quantity ){
                return true;
            }

            return false;
        }

        function valid_sum_item_quantity_less( $quantity ){
            $num_items =  WC()->cart->get_cart_contents_count();

            if( $num_items <= $quantity ){
                return true;
            }

            return false;
        }

        function valid_count_cart_items_less( $quantity ){
            $item_quantity = WC()->cart->get_cart_item_quantities();

            if( is_array( $item_quantity) ){
                if( count( $item_quantity ) <= $quantity ){
                    return true;
                }
            }
            return false;
        }

        function valid_count_cart_items_at_least( $quantity ){
            $item_quantity = WC()->cart->get_cart_item_quantities();

            if ( is_array( $item_quantity ) ) {
                if ( count( $item_quantity ) >= $quantity ) {
                    return true;
                }
            }
            return false;
        }

        function valid_subtotal_at_least( $limit ){
            $subtotal = WC()->cart->subtotal;
            if( $subtotal >= $limit ){
                return true;
            }

            return false;
        }

        function valid_subtotal_less( $limit ){
            $subtotal = WC()->cart->subtotal;
            if( $subtotal < $limit ){
                return true;
            }

            return false;
        }

        function validate_product_in_cart( $type, $product_list ){
            $is_valid = false;
            switch( $type ){
                case 'products_list':
                    foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                        if( in_array( $cart_item['product_id'], $product_list ) ){
                            $is_valid = true;
                        }
                    }
                    break;
                case 'products_list_and':
                    foreach( $product_list as $pl ){

                        if( $this->find_product_in_cart( $pl ) != '' ){
                            $is_valid = true;
                        }else{
                            $is_valid = false;
                        }
                    }

                    break;
                case 'products_list_excluded':
                    foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                        if( ! in_array( $cart_item['product_id'], $product_list ) ){
                            $is_valid = true;
                        }else{
                            $is_valid = false;
                            break;
                        }
                    }

                    break;
                case 'categories_list':
                    $categories_list = $product_list;
                    foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                        $categories_of_item = wc_get_product_terms( $cart_item['product_id'], 'product_cat', array( 'fields' => 'ids' ) );
                        $intersect = array_intersect( $categories_of_item, $categories_list );
                        if( ! empty($intersect) ){
                            $is_valid = true;
                        }
                    }
                    break;
                case 'categories_list_and':
                    $categories_list = $product_list;
                    foreach( $categories_list as $category_id ){
                        if( $this->find_category_in_cart( $category_id ) != '' ){
                            $is_valid = true;
                        }else{
                            $is_valid = false;
                        }
                    }
                    break;
                case 'categories_list_excluded':
                    $is_valid = true;
                    $categories_list = $product_list;
                    foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                        $categories_of_item = wc_get_product_terms( $cart_item['product_id'], 'product_cat', array( 'fields' => 'ids' ) );
                        $intersect          = array_intersect( $categories_of_item, $categories_list );
                        if ( !empty( $intersect ) ) {
                            $is_valid = false;
                        }
                    }

                    break;
                default:
            }

            return $is_valid;
        }

        function find_category_in_cart( $category_id ){
            $is_in_cart = '';
            foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                $categories_of_item = wc_get_product_terms( $cart_item['product_id'], 'product_cat', array( 'fields' => 'ids' ) );

                if( ! empty($categories_of_item)  && in_array( $category_id, $categories_of_item) ){
                    $is_in_cart = $cart_item_key;
                }
            }

            return $is_in_cart;

        }

        function find_product_in_cart( $produtc_id ){
            $is_in_cart = '';
            foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                if( $produtc_id == $cart_item['product_id'] ){
                    $is_in_cart = $cart_item_key;
                }
            }

            return $is_in_cart;
        }

    }
}


/**
 * Unique access to instance of YITH_WC_Dynamic_Pricing_Helper class
 *
 * @return \YITH_WC_Dynamic_Pricing_Helper
 */
function YITH_WC_Dynamic_Pricing_Helper() {
    return YITH_WC_Dynamic_Pricing_Helper::get_instance();
}

YITH_WC_Dynamic_Pricing_Helper();
