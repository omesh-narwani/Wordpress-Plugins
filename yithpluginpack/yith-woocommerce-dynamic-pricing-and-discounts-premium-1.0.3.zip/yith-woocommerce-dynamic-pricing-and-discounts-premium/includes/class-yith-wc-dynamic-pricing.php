<?php

if ( !defined( 'ABSPATH' ) || !defined( 'YITH_YWDPD_VERSION' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Implements features of YITH WooCommerce Dynamic Pricing and Discounts
 *
 * @class   YITH_WC_Dynamic_Pricing
 * @package YITH WooCommerce Dynamic Pricing and Discounts
 * @since   1.0.0
 * @author  Yithemes
 */
if ( !class_exists( 'YITH_WC_Dynamic_Pricing' ) ) {

    class YITH_WC_Dynamic_Pricing {

        /**
         * Single instance of the class
         *
         * @var \YITH_WC_Dynamic_Pricing
         */

        protected static $instance;

        /**
         * The name for the plugin options
         *
         * @access public
         * @var string
         * @since 1.0.0
         */
        public $plugin_options = 'yit_ywdpd_options';

        public $validated_rules = array();

        public $exlusion_rules = array();

        public $adjust_rules  = array();

        public $pricing_rules_options = array();

        public $cart_rules_options = array();


        /**
         * Returns single instance of the class
         *
         * @return \YITH_WC_Dynamic_Pricing
         * @since 1.0.0
         */
        public static function get_instance() {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function __construct() {

            $this->pricing_rules_options = include( YITH_YWDPD_DIR.'plugin-options/pricing-rules-options.php');
            $this->cart_rules_options = include( YITH_YWDPD_DIR.'plugin-options/cart-rules-options.php');

            /* plugin */
            add_action( 'plugins_loaded', array( $this, 'plugin_fw_loader' ), 15 );


        }

        /**
         * Return pricing rules filtered and validates
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        function get_pricing_rules(){
            $pricing_rules  = $this->filter_valid_rules(  $this->get_option( 'pricing-rules' ) );
            return $pricing_rules;
        }

        /**
         * Return pricing rules validates
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        function filter_valid_rules( $pricing_rules ){

            if ( !$pricing_rules || !is_array( $pricing_rules ) ) {
                return;
            }

            foreach( $pricing_rules as $key => $rule ){

                //check if the rule is active of the value of discount_amount is empty
                if( $rule['active'] != 'yes'){
                    continue;
                }

                //DATE SCHEDULE VALIDATION
                if ( isset($rule['schedule_from']) && isset($rule['schedule_to']) && ($rule['schedule_from'] != '' || $rule['schedule_to'] != '' )) {
                    if ( ! YITH_WC_Dynamic_Pricing_Helper()->validate_schedule( $rule['schedule_from'], $rule['schedule_to'] ) ) {
                        continue;
                    }
                }

                //USER VALIDATION
                if( isset($rule['user_rules']) &&  ( $rule['user_rules'] != 'everyone' && ! YITH_WC_Dynamic_Pricing_Helper()->validate_user( $rule['user_rules'], $rule['user_rules_'.$rule['user_rules']]) )){
                    continue;
                }

                //PRODUCTS VALIDATION (APPLY TO) check if the list of products or categories is empty
                if( isset($rule['apply_to']) && $rule['apply_to'] != 'all_products' &&  isset($rule['apply_to_'.$rule['apply_to']]) && ! is_array( $rule['apply_to_'.$rule['apply_to']] ) ){
                    continue;
                }
                //PRODUCTS VALIDATION (ADJUSTMENT) check if the list of products or categories is empty
                if( isset($rule['apply_adjustment']) && ( $rule['apply_adjustment'] != 'all_products' && $rule['apply_adjustment'] != 'same_product' ) && ! is_array( $rule['apply_adjustment_'.$rule['apply_adjustment']] ) ){
                    continue;
                }

                //DISCOUNT RULES VALIDATION
                if ( isset( $rule['discount_mode'] )  && $rule['discount_mode'] == 'bulk' ) {
                    foreach ( $rule['rules'] as $index => $discount_rule ) {

                        if ( $discount_rule['min_quantity'] == '' || $discount_rule['min_quantity'] == 0 ) {
                            $rule['rules'][$index]['min_quantity'] = 1;
                        }

                        if ( $discount_rule['max_quantity'] == '' ) {
                            $rule['rules'][$index]['max_quantity'] = '*';
                        }

                        if ( $discount_rule['type_discount'] == 'percentage' && $discount_rule['discount_amount'] > 1 ) {
                            $rule['rules'][$index]['discount_amount'] = $discount_rule['discount_amount'] / 100;
                        }
                    }
                }
                elseif (  isset( $rule['discount_mode'] )  && $rule['discount_mode'] == 'special_offer' ) {
                    $special_offer = $rule['so-rule'];

                    if ( $special_offer['purchase'] == '' || $special_offer['purchase'] == 0 ) {
                        $rule['so-rule']['purchase'] = 1;
                    }

                    if ( $special_offer['receive'] == '' ) {
                        $rule['so-rule']['receive'] = '*';
                    }

                    if ( $special_offer['type_discount'] == 'percentage' &&  $special_offer['discount_amount'] > 1 ) {
                        $rule['so-rule']['discount_amount'] = $special_offer['discount_amount'] / 100;
                    }
                }

                $this->validated_rules[$key] = $rule;

            }

            return $this->validated_rules;
        }

        /**
         * Add applied rules to single cart item
         *
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        function get_applied_rules_to_product( $cart_item_key, $cart_item ) {

            if ( empty( $cart_item ) ) {
                return false;
            }

            foreach ( $this->validated_rules as $key_rule => $rule ) {

                //check apply_to
                if ( !YITH_WC_Dynamic_Pricing_Helper()->validate_apply_to( $key_rule, $rule, $cart_item_key, $cart_item ) ) {
                    continue;
                }

            }
        }


        /**
         * Add applied rules to single cart item
         *
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        function get_exlusion_rules(){
            if( ! empty($this->exlusion_rules) ){
                return $this->exlusion_rules;
            }

            $exclusion_rules = array();
            foreach( $this->validated_rules as $rule ){
                if( $rule['discount_mode'] == 'exclude_items' ){
                    $exclusion_rules[] = $rule;
                }
            }

            $this->exlusion_rules = $exclusion_rules;

            return $this->exlusion_rules;
        }
        /**
         * Add applied rules to single cart item
         *
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        function get_adjusts_to_product( $cart_item ) {

            if ( empty( $cart_item ) ) {
                return false;
            }

            $item_discounts = array();

            foreach ( $this->validated_rules as $key_rule => $rule ) {

                //check if the rule is exclusive

                //check if the rule can be applied to the same product

            }
        }

        function get_discount_price( $default_price, $product ){


            $current_difference = 0;

            foreach( $this->validated_rules as $rule ){

                //product onsale
                $even_onsale = ( isset( $rule['apply_on_sale'] ) ) ? 1 : 0;
//                if( ! $even_onsale && $product->is_on_sale() ){
//                    continue;
//                }

                if ( isset( $rule['show_in_loop'] ) && $rule['show_in_loop'] == 1 && $rule['apply_adjustment'] == 'same_product' && YITH_WC_Dynamic_Pricing_Helper()->valid_product_to_apply_bulk( $rule, $product->id ) ) {
                    $is_exclusive = ( isset( $rule['apply_with_other_rules'] ) && $rule['apply_with_other_rules'] == 1 ) ? 0 : 1;
                    foreach( $rule['rules'] as $qty_rule ){
                        if( $qty_rule['min_quantity'] == 1 ){
                            switch( $qty_rule['type_discount'] ){
                                case 'percentage':
                                    $current_difference = $default_price * $qty_rule['discount_amount'];
                                    break;
                                case 'price':
                                    $current_difference = $qty_rule['discount_amount'];
                                    break;
                                case 'fixed-price':
                                    $current_difference = $default_price - $qty_rule['discount_amount'];
                                    break;
                                default:
                            }
                        }
                    }
                    if( $is_exclusive ){
                        break;
                    }
                }
            }

            $discount_price = ( ( $default_price - $current_difference ) < 0 ) ? 0 : ( $default_price - $current_difference ) ;

            return $discount_price;
        }

        /**
         * Return all adjustments to single cart item
         *
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function apply_discount( $cart_item, $cart_item_key ){

            $discounts = $cart_item['ywdpd_discounts'];
            $product_id = ( isset( $cart_item['variation_id'] ) && $cart_item['variation_id']!='' ) ? $cart_item['variation_id'] : $cart_item['product_id'];
            $product    = wc_get_product( $product_id );
            $has_exclusive = $this->has_exclusive($discounts);

            $default_price =  $cart_item['data']->price;

            //$default_price = ( WC()->cart->tax_display_cart == 'excl' ) ? $product->get_price_excluding_tax() : $product->get_price_including_tax();
            $price = $current_price = $default_price;
            $difference = 0;

            foreach ( $discounts as $discount ) {

                if( ! isset( $discount['discount_amount'] ) || ! isset( $discount['discount_mode'] ) ){
                    continue;
                }

                if( $discount['discount_amount'] == 'exclude' ){
                    $price = $current_price = $default_price;
                    $difference = 0;
                }

                if ( ! $discount['onsale'] && ( $product->get_sale_price() !== '' && $product->get_sale_price() !== $product->get_regular_price() ) ) {
                    continue;
                }

                //check if the discount has an exclusive rule
                if( $has_exclusive && ! $discount['exclusive'] ){
                    continue;
                }

                $current_difference = 0;
                if( $discount['discount_mode'] == 'bulk' && isset( $discount['discount_amount']['type']) ){
                    switch( $discount['discount_amount']['type'] ){
                        case 'percentage':
                            $current_difference = $price * $discount['discount_amount']['amount'];
                            break;
                        case 'price':
                            $current_difference = $discount['discount_amount']['amount'];
                            break;
                        case 'fixed-price':
                            $current_difference = $price - $discount['discount_amount']['amount'];
                            break;
                        default:
                    }
                }elseif( $discount['discount_mode'] == 'special_offer' && isset( $discount['discount_amount']['type'])  ){

                    $repeat = ( isset($discount['discount_amount']['repeat']) && $discount['discount_amount']['repeat'] == 0 ) ? 1 : $discount['discount_amount']['repeat'] ;

                    switch( $discount['discount_amount']['type'] ){
                        case 'percentage':
                            if( $discount['discount_amount']['qty_receive'] != 0 ){
                                $current_difference = $repeat * $price * $discount['discount_amount']['amount'] / $discount['discount_amount']['qty_receive'];
                            }
                            break;
                        case 'price':
                            if( $discount['discount_amount']['qty_receive'] != 0 ) {
                                $current_difference = $repeat * $discount['discount_amount']['amount'] / $discount['discount_amount']['qty_receive'];
                            }
                            break;
                        case 'fixed-price':
                            if( ($price - $discount['discount_amount']['amount']) > 0){
                                if(  $discount['discount_amount']['same_product']  == 1 ){
                                    if( $discount['discount_amount']['repeat'] != 0 ){
                                        $y =  floor( $discount['discount_amount']['qty_purchase'] / ( $discount['discount_amount']['purchase'] + $discount['discount_amount']['receive'] )  );
                                        $current_difference =  ($price - $discount['discount_amount']['amount']) * $y / $discount['discount_amount']['qty_purchase'];
                                    }else{
                                        $current_difference =  ($price - $discount['discount_amount']['amount'])/ $discount['discount_amount']['qty_purchase'] ;
                                    }
                                }else{

                                    $current_difference =  ($price - $discount['discount_amount']['amount']) * $repeat/$discount['discount_amount']['qty_receive'] ;
                                }
                                break;
                            }

                        default:
                    }
                }

                $difference += $current_difference;
                $price = ( ( $default_price - $difference ) < 0 ) ? 0 : ( $default_price - $difference ) ;

                WC()->cart->cart_contents[$cart_item_key]['ywdpd_discounts'][$discount['key']]['status']           = 'applied';
                WC()->cart->cart_contents[$cart_item_key]['ywdpd_discounts'][$discount['key']]['discount_applied'] = $current_difference;
                WC()->cart->cart_contents[$cart_item_key]['ywdpd_discounts'][$discount['key']]['current_price']    = $price;

            }
			remove_filter( 'woocommerce_get_price', array( YITH_WC_Dynamic_Pricing_Frontend(), 'get_price' ), 10, 2 );
            WC()->cart->cart_contents[$cart_item_key]['ywdpd_discounts']['default_price'] =  ( WC()->cart->tax_display_cart == 'excl' ) ? $product->get_price_excluding_tax() : $product->get_price_including_tax();
			add_filter( 'woocommerce_get_price', array( YITH_WC_Dynamic_Pricing_Frontend(), 'get_price' ), 10, 2 );
			WC()->cart->cart_contents[$cart_item_key]['data']->price = floatval( $price );

        }

        function has_exclusive( $discounts ){
            foreach( $discounts as $discount ){
                if( isset($discount['exclusive']) && $discount['exclusive'] == 1 ){
                    return true;
                }
            }
            return false;
        }
        /**
         * Check if a product has specific categories
         *
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        function product_categories_validation( $product_id, $categories, $min_amount ) {
            $categories_cart = YITH_WC_Dynamic_Pricing_Helper()->cart_categories;
            $intersect_cart_category = array_intersect( $categories, $categories_cart );

            $return = false;

            if( is_array( $intersect_cart_category ) ){
                $categories_counter = YITH_WC_Dynamic_Pricing_Helper()->categories_counter;
                $categories_of_item = wc_get_product_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
                $intersect_product_category = array_intersect( $categories_of_item, $categories );

                if( is_array( $intersect_product_category ) ){
                    $tot = 0;
                    foreach( $categories as $cat ){
                        $tot += $categories_counter[$cat];
                    }

                    if( $tot >= $min_amount ){
                        $return = true;
                    }
                }

            }

            return $return;

        }

        /**
         * Load YIT Plugin Framework
         *
         * @since  1.0.0
         * @return void
         * @author Emanuela Castorina
         */
        public function plugin_fw_loader() {
            if ( ! defined( 'YIT_CORE_PLUGIN' ) ) {
                global $plugin_fw_data;
                if( ! empty( $plugin_fw_data ) ){
                    $plugin_fw_file = array_shift( $plugin_fw_data );
                    require_once( $plugin_fw_file );
                }
            }
        }

        /**
         * Get options from db
         *
         * @access public
         * @since 1.0.0
         * @author  Emanuela Castorina
         * @param $option string
         * @return mixed
         */
        public function get_option( $option ) {
            // get all options
            $options = get_option( $this->plugin_options );

            if( isset( $options[ $option ] ) ) {
                return $options[ $option ];
            }

            return false;
        }

    }
}

/**
 * Unique access to instance of YITH_WC_Dynamic_Pricing class
 *
 * @return \YITH_WC_Dynamic_Pricing
 */
function YITH_WC_Dynamic_Pricing() {
    return YITH_WC_Dynamic_Pricing::get_instance();
}

