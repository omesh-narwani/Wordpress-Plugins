<?php
if ( !defined( 'ABSPATH' ) || ! defined( 'YITH_YWDPD_VERSION' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Implements helper functions for YITH WooCommerce Dynamic Pricing and Discounts
 *
 * @package YITH WooCommerce Dynamic Pricing and Discounts
 * @since   1.0.0
 * @author  Yithemes
 */

if ( !function_exists( 'ywdpd_get_shop_categories' ) ) {
    function ywdpd_get_shop_categories( $show_all = true ) {
        global $wpdb;

        $terms = $wpdb->get_results( 'SELECT name, slug, wpt.term_id FROM ' . $wpdb->prefix . 'terms wpt, ' . $wpdb->prefix . 'term_taxonomy wptt WHERE wpt.term_id = wptt.term_id AND wptt.taxonomy = "product_cat" ORDER BY name ASC;' );

        $categories = array();
        if ( $show_all ) {
            $categories['0'] = __( 'All categories', 'ywcm' );
        }
        if ( $terms ) {
            foreach ( $terms as $cat ) {
                $categories[$cat->term_id] = ( $cat->name ) ? $cat->name : 'ID: ' . $cat->slug;
            }
        }
        return $categories;
    }
}

if( ! function_exists( 'ywdpd_have_dynamic_coupon' ) ){
    function ywdpd_have_dynamic_coupon() {

        $coupons = WC()->cart->get_coupons();

        if( empty( $coupons ) ){
            return false;
        }

        $dynamic_coupon = YITH_WC_Dynamic_Pricing()->get_option( 'coupon_label' );

        foreach( $coupons as $code => $value ){
            if( strtolower( $code ) == strtolower( $dynamic_coupon ) ){
                return true;
            }
        }

        return false;
    }
}

if( ! function_exists( 'ywdpd_get_discounted_price_table' ) ) {
    function ywdpd_get_discounted_price_table( $price, $rule ) {

        $discount = 0;

        if ( $rule['type_discount'] == 'percentage' ) {
            $discount = $price * $rule['discount_amount'];
        }
        elseif ( $rule['type_discount'] == 'price' ) {
            $discount = $rule['discount_amount'];
        }
        elseif ( $rule['type_discount'] == 'fixed-price' ) {
            $discount = $price - $rule['discount_amount'];
        }

        return ( ( $price - $discount ) < 0 ) ? 0 : ( $price - $discount );
    }
}