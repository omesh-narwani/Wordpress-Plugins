<?php

$settings = array(

    'cart' => array(

        'header'    => array(

            array(
                'name' => __( 'Cart Discounts', 'ywdpd' ),
                'type' => 'title'
            ),

            array( 'type' => 'close' )
        ),


        'settings' => array(

            array( 'type' => 'open' ),


            array(
                'id'      => 'cart-rules',
                'name'    => __( 'Add a new rule for cart', 'ywdpd' ),
                'desc'    => '',
                'type'    => 'options-cart-rules'
            ),

            array( 'type' => 'close' ),
        )
    )
);

return apply_filters( 'yith_ywdpd_panel_settings_options', $settings );