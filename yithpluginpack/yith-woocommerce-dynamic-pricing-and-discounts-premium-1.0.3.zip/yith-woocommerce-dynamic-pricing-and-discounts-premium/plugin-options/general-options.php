<?php

$settings = array(

    'general' => array(

        'header'    => array(

            array(
                'name' => __( 'General Settings', 'ywdpd' ),
                'type' => 'title'
            ),

            array( 'type' => 'close' )
        ),


        'settings' => array(

            array( 'type' => 'open' ),

            array(
                'id'      => 'enabled',
                'name'    => __( 'Enable Dynamic Pricing and Discounts', 'ywdpd' ),
                'desc'    => '',
                'type'    => 'on-off',
                'std'     => 'yes'
            ),

            array(
                'id'      => 'coupon_label',
                'name'    => __( 'Coupon Label', 'ywdpd' ),
                'desc'    => __( 'Name of the coupon showed in cart if there are discounts in cart (add a single word)', 'ywdpd' ),
                'type'    => 'text',
                'std' => 'DISCOUNT'
            ),

            array(
                'id'      => 'show_quantity_table',
                'name'    => __( 'Display Quantity Table', 'ywdpd' ),
                'desc'    => '',
                'type'    => 'on-off',
                'std'     => 'no'
            ),

            array(
                'id'      => 'show_quantity_table_schedule',
                'name'    => __( 'Display Expiring Date In Quantity Table', 'ywdpd' ),
                'desc'    => '',
                'type'    => 'on-off',
                'std'     => 'yes'
            ),

            array(
                'id'      => 'show_quantity_table_label',
                'name'    => __( 'Quantity Table Title', 'ywdpd' ),
                'desc'    => __( 'Title of the Quantity Table', 'ywdpd' ),
                'type'    => 'text',
                'std' => __( 'Discount per Quantity', 'ywdpd')
            ),

            array(
                'id'      => 'show_quantity_table_label_quantity',
                'name'    => __( 'Label for Quantity', 'ywdpd' ),
                'desc'    => '',
                'type'    => 'text',
                'std' => __( 'Quantity', 'ywdpd')
            ),
            array(
                'id'      => 'show_quantity_table_label_price',
                'name'    => __( 'Label for Price', 'ywdpd' ),
                'desc'    => '',
                'type'    => 'text',
                'std' => __( 'Price', 'ywdpd')
            ),

            array(
                'id'      => 'show_quantity_table_place',
                'name'    => __( 'Display Quantity Table', 'ywdpd' ),
                'desc'    => '',
                'type'    => 'select',
                'options' => array(
                    'before_add_to_cart' => __( 'Before "Add to cart" button', 'ywdpd' ),
                    'after_add_to_cart'  => __( 'After "Add to cart" button', 'ywdpd' ),
                    'before_excerpt'     => __( 'Before excerpt', 'ywdpd' ),
                    'after_excerpt'      => __( 'After excerpt', 'ywdpd' ),
                    'after_meta'         => __( 'After product meta', 'ywdpd' ),

                ),
                'std'     => 'before_add_to_cart',
            ),

            array( 'type' => 'close' ),
        )
    )
);

return apply_filters( 'yith_ywdpd_panel_settings_options', $settings );