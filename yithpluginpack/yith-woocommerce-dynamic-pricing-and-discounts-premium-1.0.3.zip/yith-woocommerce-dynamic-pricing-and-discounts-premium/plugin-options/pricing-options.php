<?php

$settings = array(

    'pricing' => array(

        'header'    => array(

            array(
                'name' => __( 'Pricing Rules', 'ywdpd' ),
                'type' => 'title'
            ),

            array( 'type' => 'close' )
        ),


        'settings' => array(

            array( 'type' => 'open' ),


            array(
                'id'      => 'pricing-rules',
                'name'    => __( 'Add a new rule for pricing', 'ywdpd' ),
                'desc'    => '',
                'type'    => 'options-pricing-rules'
            ),

            array( 'type' => 'close' ),
        )
    )
);

return apply_filters( 'yith_ywdpd_panel_settings_options', $settings );