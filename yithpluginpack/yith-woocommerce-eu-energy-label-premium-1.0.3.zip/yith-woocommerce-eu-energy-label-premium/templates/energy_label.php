<?php
/**
 * Template for EU Energy Label in Frontend
 *
 * @author  Yithemes
 * @package YITH WooCommerce EU Energy Label
 * @version 1.0.0
 */

if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
$energy_label_array = array(
    1  => 'A+++',
    2  => 'A++',
    3  => 'A+',
    4  => 'A',
    5  => 'B',
    6  => 'C',
    7  => 'D',
    8  => 'E',
    9  => 'F',
    10 => 'G',
);

if ( is_array( $meta ) )
    extract( $meta );
?>

<?php if ( $energy_label > 0 ) : ?>

    <div class="yith-wceue-eu-energy-label yith-wceue-eu-energy-label-<?php echo $energy_label ?> <?php echo $class?>">
        <?php echo $energy_label_array[ $energy_label ] ?>
    </div>

<?php endif; ?>