=== YITH WooCommerce EU VAT ===

Contributors: yithemes
Tags: digital VAT, digital goods, EU tax, EU VAT, euvat, IVA, moss, EU moss, european tax, VAT compliance, EU VAT compliance, woocommerce, e-commerce, e commerce, tax, order tax, order VAT, EU VAT compliance, european VAT, VAT moss, VAT rates, vatmoss, taxes, VAT, vatmoss, ue, commerce, ecommerce
Requires at least: 3.5.1
Tested up to: 4.4.1
Stable tag: 1.2.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= Version 1.2.8 - RELEASED: JAN 15, 2016 =

* Fixed: function call not supported by PHP version prior to 5.4

= Version 1.2.7 - RELEASED: JAN 08, 2016 =

* Updated: plugin ready for WooCommerce 2.5
* Fixed: unable to change tax classes monitored by the plugin

= Version 1.2.6 - RELEASED: DEC 26, 2015 =

* Fixed: JS script not checks the VAT number validation when the plugin settings do not ask for country validation
* Updated: CSS font-size for error messages

= Version 1.2.5 - RELEASED: NOV 23, 2015 =

* Updated: changed action used for YITH Plugin FW loading from after_setup_theme to plugins_loaded

= Version 1.2.4 - RELEASED: NOV 02, 2015 =

* Update: changed text-domain from ywev to yith-woocommerce-eu-vat
* Update: YITH plugin framework

= Version 1.2.3 - RELEASED: OCT 26, 2015 =

* Update: changed the webservice used for EU VAT validation

= Version 1.2.2 - RELEASED: OCT 01, 2015 =

* Fix: removed wp_die.

= Version 1.2.1 - RELEASED: AUG 12, 2015 =

* Tweak: update YITH Plugin framework.

= Version 1.2.0 - RELEASED: MAY 21, 2015 =

* Fix : support WooCommerce plugin version prior than 2.3.0

= Version 1.1.0 - RELEASED: APR 22, 2015 =

* Fix : security issue (https://make.wordpress.org/plugins/2015/04/20/fixing-add_query_arg-and-remove_query_arg-usage/)
* Tweak : support up to Wordpress 4.2

= 1.0.0 =

Initial release