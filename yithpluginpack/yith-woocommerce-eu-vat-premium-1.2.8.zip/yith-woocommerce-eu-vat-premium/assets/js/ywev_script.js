jQuery(document).ready(function ($) {

    /**
     * Check if the country selected by the customer is different from the country
     * detected from the IP address
     */
    function must_check_eu_vat_number() {
        var selected_country = $('select#billing_country').val();
        var check_countries_list = ywev.ask_confirm_countries;

        if (selected_country && ( ( check_countries_list.indexOf(selected_country) >= 0 ) )) {
            return true;
        }

        return false;
    }

    /**
     * Hide warning messages
     */
    function hide_conflicts() {
        $("div.country_conflicts, #eu_vat_confirm_country_field").empty();
        $("div.country_conflicts, #eu_vat_confirm_country_field").hide();
    }

    /**
     * If the country selected by the customer is an EU country,
     * verify if the VAT number inserted is a valid EU VAT number and if
     * there is a mismatch between the country selected by the customer and the country detected from IP address
     */
    function verify_eu_vat_number() {
        hide_conflicts();
        $('.eu-vat-message').empty();

        if (!must_check_eu_vat_number()) {
            return;
        }

        var vat_number = $("input#ywev_vat_number").val();
        if (vat_number.length > 0) {
            //  check VAT number and show a message
            var data = {
                'action': 'check_eu_vat_number',
                'vat_number': vat_number,
                'selected_country': $('select#billing_country').val(),
                'confirm': $("#eu_vat_confirm_country").attr('checked') ? true : false
            };

            $("#ywev_vat_number_field").block({
                message: null,
                overlayCSS: {
                    background: "#fff url(" + ywev.loader + ") no-repeat center",
                    opacity: .6
                }
            });

            // since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
            $.post(woocommerce_params.ajax_url, data, function (response) {

                if (1 == response.code) {
                    $('input#ywev_vat_number').after('<span style="color:green;font-size: 12px" class="eu-vat-message">' + response.value + '</span>');
                    /**
                     * Show a warning  message
                     */
                    show_confirm_section();
                } else if (-1 == response.code) {
                    $('input#ywev_vat_number').after('<span style="color:red;font-size: 12px" class="eu-vat-message">' + response.value + '</span>');
                }

                $("#ywev_vat_number_field").unblock();

            })
        }
    }

    /**
     * Show a confirm section when the VAT number is entered and is a valid EU VAT number but the country selected by the customer is different from the country
     * detected from the IP address
     */
    function show_confirm_section() {
        var current_country = $('select#billing_country option:selected').text();

        if (ywev.mandatory_match_country && (current_country != ywev.geo_country)) {

            //  add the containers of the items to be shown in case of country conflicts
            if ($("div#ywev_vat_number div.country_conflicts").length == 0) {
                $("div#ywev_vat_number").append('<div class="country_conflicts"></div>');
                $("div#ywev_vat_number").append('<p class="form-row form-row-wide validate-required update_totals_on_change" id="eu_vat_confirm_country_field"></p>');
            }

            $("div.country_conflicts").html('<span>' + ywev.message_country_conflicted + '</span>');

            $("#eu_vat_confirm_country_field").html('<div>' +
            '<input type="radio" class="input-radio " value="unknown" name="eu_vat_confirm_country" id="eu_vat_confirm_country_unknown" checked="checked" style="display: inline-block;        vertical-align: top; margin-top: 10px; margin-right: 5px;">' +
            '<label for="eu_vat_confirm_country_unknown" class="radio " style="display: inline-block; width: 90%;">' + ywev.message_confirm_option1 + '</label>' +
            '</div>' +
            '<div>' +
            '<input type="radio" class="input-radio " style="display: inline-block; vertical-align: top; margin-top: 10px; margin-right: 5px;" value="confirm" name="eu_vat_confirm_country" id="eu_vat_confirm_country_confirm">' +
            '<label for="eu_vat_confirm_country_confirm" class="radio " style="display: inline-block; width: 90%;">' + ywev.message_confirm_option2 + ' ' + '<b><span class="ywev_customer_country">' + current_country + '</span></b>' + ', ' + ywev.message_confirm_option2b + '</label>' +
            '</div>');

            $("div.country_conflicts, #eu_vat_confirm_country_field").show();
        }
    }

    $('input#ywev_vat_number').on('change', function () {
        verify_eu_vat_number();
    });


    $('select#billing_country').on('change', function () {
        verify_eu_vat_number();
    });
});