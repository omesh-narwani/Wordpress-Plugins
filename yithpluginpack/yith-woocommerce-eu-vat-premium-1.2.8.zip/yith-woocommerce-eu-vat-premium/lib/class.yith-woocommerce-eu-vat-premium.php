<?php
/**
 * Premium version class
 *
 * @author  Your Inspiration Themes
 * @package YITH WooCommerce EU VAT
 * @version 1.0.0
 */

if ( ! defined ( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

if ( ! class_exists ( 'YITH_WooCommerce_EU_VAT_Premium' ) ) {
    /**
     * Admin class.
     * The class manage all the admin behaviors.
     *
     * @since 1.0.0
     */
    class YITH_WooCommerce_EU_VAT_Premium extends YITH_WooCommerce_EU_VAT {
        /**
         * Set if vat number is a mandatory field
         *
         * @var bool
         */
        public $mandatory_vat_number = false;

        /**
         * Verify EU VAT number
         *
         * @var bool
         */
        public $check_eu_vat_number = false;

        /**
         * Allow invalid EU VAT number to go to checkout
         *
         * @var bool
         */
        public $stop_invalid_eu_vat_number = false;

        /**
         * Verify with geolocalization service the customer base location
         *
         * @var bool
         */
        public $check_country = false;

        /**
         * Customer base location must match with geolocalizated country value
         *
         * @var bool
         */
        public $mandatory_match_country = false;

        /**
         * Single instance of the class
         *
         * @since 1.0.0
         */
        protected static $instance;

        /**
         * Returns single instance of the class
         *
         * @since 1.0.0
         */
        public static function get_instance () {
            if ( is_null ( self::$instance ) ) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        /**
         * Constructor
         *
         * @access public
         * @since  1.0.0
         */
        public function __construct () {


            parent::__construct ();

            $this->set_metabox_actions ();


            /**
             * Init plugin options
             */
            $this->init_plugin_options ();

            /**
             * Add some plugin options
             */
            add_filter ( 'yith_ywev_general_settings', array ( $this, 'set_plugin_options' ) );

            /**
             * Do some check during data modification on checkout page
             */
            add_action ( 'woocommerce_checkout_update_order_review', array (
                $this,
                'update_data_on_checkout_change',
            ), 99 ); // Check during ajax update totals

            add_action ( 'woocommerce_after_order_notes', array ( $this, 'show_additional_data_on_checkout' ) );

            /**
             * add custom script
             */
            add_action ( 'wp_footer', array ( $this, 'add_plugin_scripts' ) );


            /**
             * Store additional data on checkout
             */
            add_filter ( 'yith_ywev_storing_data', array ( $this, 'store_geo_data' ) );

            /**
             * Process the checkout
             */
            add_action ( 'woocommerce_checkout_process', array ( $this, 'checks_before_confirm_order' ) );

            /**
             * Check for digital goods on current cart that should be VAT exempt
             */
            add_filter ( 'woocommerce_after_calculate_totals', array ( $this, 'check_digital_goods_for_eu_vat' ) );

            /**
             * Show the amount of VAT tax that is removed from checkout when a valid EU VAT number is entered by a european customer
             */
            add_action ( 'woocommerce_review_order_before_order_total', array (
                $this,
                'show_eu_vat_amount_on_checkout',
            ) );

            /**
             * Check EU VAT numbers validity during checkout
             */
            add_action ( 'wp_ajax_check_eu_vat_number', array ( $this, 'check_eu_vat_number_callback' ) );
            add_action ( 'wp_ajax_nopriv_check_eu_vat_number', array ( $this, 'check_eu_vat_number_callback' ) );

        }

        /**
         * Retrieve shop base location to be used for EU VAT chekcs
         */
        public function get_base_country () {
            if ( "yes" == get_option ( "ywev_use_custom_base_location" ) ) {
                return explode ( ",", get_option ( "ywev_custom_base_location" ) );
            } else {
                return array (
                    WC ()->countries->get_base_country (),
                );
            }
        }

        /**
         * Verify the if a VAT number is a valid EU VAT number
         *
         * @return mixed return an json array of type ("code" => $code, "value" => $value) where code is 1 for succes and value is a string to show
         *
         * @since  1.0
         * @author Lorenzo giuffrida
         */
        public function check_eu_vat_number_callback () {
            $vat_number       = $_POST[ 'vat_number' ];
            $selected_country = $_POST[ 'selected_country' ];

            $countries = wc ()->countries->get_countries ();
            $country   = $countries[ $selected_country ];

            if ( $this->check_eu_vat_number && isset( $vat_number ) && isset( $selected_country ) ) {
                //  check if current country is on EU country list
                if ( ! $this->is_eu_customer ( $selected_country ) ) {
                    wp_send_json ( array ( "code" => 0, "value" => "It's not a EU country." ) );
                }

                $response = $this->check_eu_vat_number_validity ( $selected_country, $vat_number );
                if ( "valid" == $response ) {
                    wp_send_json ( array ( "code" => 1, "value" => __ ( "Valid EU VAT number." ) ) );
                } else {
                    wp_send_json ( array (
                        "code"  => - 1,
                        "value" => __ ( "{$selected_country}{$vat_number} is not a valid {$country} EU VAT number , taxes will be charged normally." ),
                    ) );
                }
            }

            wp_send_json ( array ( "code" => 0, "value" => "Exit" ) );
        }

        /**
         * Register actions and filters to be used for creating an entry on YIT Plugin menu
         *
         * @since  1.0
         * @author Lorenzo giuffrida
         * @access public
         * @return void
         */
        public function set_metabox_actions () {
            /**
             * Add metabox on order, to let vendor add order tracking code and carrier
             */
            add_action ( 'add_meta_boxes', array ( $this, 'add_invoice_metabox' ) );
        }

        /**
         *  Add a metabox on backend order page, to be filled with order tracking information
         *
         * @since  1.0
         * @author Lorenzo giuffrida
         * @access public
         * @return void
         */
        function add_invoice_metabox () {
            add_meta_box ( 'ywev-order-data', __ ( 'EU VAT', 'ywpi' ), array (
                $this,
                'show_eu_vat_metabox',
            ), 'shop_order', 'side', 'high' );
        }

        /**
         * Show data stored during che checkout process
         *
         * @param $post the order object that is currently shown
         *
         * @since  1.0
         * @author Lorenzo giuffrida
         * @access public
         * @return void
         */
        function show_eu_vat_metabox ( $post ) {

            //  retrieve stored data for current order
            $eu_vat_data = get_post_meta ( $post->ID, '_ywev_order_vat_paid', true );

            $has_digital_goods = ! empty( $eu_vat_data[ "eu_cart_with_digital_goods" ] ) && ( 1 == $eu_vat_data[ "eu_cart_with_digital_goods" ] ) ? true : false;

            if ( $has_digital_goods ) {
                $reverse_charge_amount = ( ! empty( $eu_vat_data[ "eu_vat_amount" ] ) && ( $eu_vat_data[ "eu_vat_amount" ] > 0 ) ) ? $eu_vat_data[ "eu_vat_amount" ] : 0;
                $vat_number            = $eu_vat_data[ "vat_number" ];
                $localization          = $eu_vat_data[ "Localization" ];

                $customer_country = $localization[ "COUNTRY" ];
                $geo_country      = $localization[ "GEO_COUNTRY" ];
                $ip_address       = $localization[ "IP_ADDRESS" ];

                $country_conflicted = $eu_vat_data[ "country_conflicted" ];
                $country_confirmed  = $eu_vat_data[ "country_confirmed" ];

                ?>

                <div class="eu-vat-information">
                    <div style="overflow: hidden; padding: 5px 0">
                        <span style="float:left"><?php _e ( 'VAT number: ', 'ywpi' ); ?></span>
                        <span style="float:right"><?php echo $vat_number; ?></span>
                    </div>
                    <div style="overflow: hidden; padding: 5px 0">
                        <span style="float:left"><?php _e ( 'Reverse charge amount: ', 'ywpi' ); ?></span>
                        <span style="float:right"><?php echo wc_price ( $reverse_charge_amount ); ?></span>
                    </div>
                    <div style="overflow: hidden; padding: 5px 0">
                        <span style="float:left"><?php _e ( 'Customer country: ', 'ywpi' ); ?></span>
                        <span style="float:right"><?php echo WC ()->countries->countries[ $customer_country ]; ?></span>
                    </div>
                    <div style="overflow: hidden; padding: 5px 0">
                        <span style="float:left"><?php _e ( 'Geolocalized country: ', 'ywpi' ); ?></span>
                        <span style="float:right"><?php echo WC ()->countries->countries[ $geo_country ]; ?></span>
                    </div>
                    <div style="overflow: hidden; padding: 5px 0">
                        <span style="float:left"><?php _e ( 'Customer IP address: ', 'ywpi' ); ?></span>
                        <span style="float:right"><?php echo $ip_address; ?></span>
                    </div>
                    <?php if ( $country_confirmed ) : ?>
                        <div style="overflow: hidden; padding: 5px 0">
							<span
                                style="float:left"><?php _e ( 'The customer manually confirmed his/her country', 'ywpi' ); ?></span>
                        </div>
                    <?php else: ?>
                        <div style="overflow: hidden; padding: 5px 0">
							<span
                                style="float:left"><?php _e ( 'The customer did NOT confirm his/her country', 'ywpi' ); ?></span>
                        </div>
                    <?php endif; ?>
                </div>
                <?php
            } else {
                ?>
                <div class="eu-vat-information">
                    <div style="overflow: hidden; padding: 5px 0">
                        <span style="float:left"><?php _e ( 'Reverse charge not applied.', 'ywpi' ); ?></span>
                    </div>
                </div>
                <?php
            }
        }

        /**
         * Show the amount of VAT tax that is removed from checkout when a valid EU VAT number is entered by a european customer
         */
        public function show_eu_vat_amount_on_checkout () {

            $eu_vat_exempt_amount = WC ()->session->get ( "eu_vat_exempt_amount" );

            if ( $eu_vat_exempt_amount > 0 ) :
                ?>

                <tr class="eu-vat-amount">
                    <th><?php _e ( 'EU VAT exempted', 'yith-woocommerce-eu-vat' ); ?></th>
                    <td>
                        <del><span class="amount"><?php echo wc_price ( $eu_vat_exempt_amount ); ?></span></del>
                    </td>
                </tr>
                <?php
            endif;

        }

        /**
         * Verify if the country selected by the user is an EU country and is different from the one detected from IP address
         *
         * @return bool selected country and detected country is in conflict
         */
        public function eu_country_conflict () {
            $taxable_addresses     = WC ()->customer->get_taxable_address ();
            $customer_country_code = WC ()->session->get ( "checkout_country", $taxable_addresses [ 0 ] );

            if ( $this->is_eu_customer ( $customer_country_code ) ) {

                $geo_country_code = $this->get_geolocated_country_code ();

                //  check if country entered by the customer doesn't match the country found with geolocalization and one of these if an european country and ask for customer entered data
                if ( $geo_country_code != $customer_country_code ) {
                    return true;
                }
            }

            return false;
        }

        public function remove_eu_vat_taxes ( $cart ) {

            $eu_vat_exempt_amount = 0;

            foreach ( $cart->cart_contents as $cart_item_key => $values ) {
                $_product = $values[ 'data' ];

                if ( ! $_product->is_taxable () ) {
                    continue;
                }

                if ( ! $_product->is_virtual () ) {
                    continue;
                }

                //  if the customer in from an european country and he inserted a valid EU VAT number, remove tax if the tax class is on the list of tax class to be monitored from the plugin option page.
                $eu_vat_tax_used_list = get_option ( 'ywev_eu_vat_tax_list', array () );

                $line_tax_data       = $values[ "line_tax_data" ];
                $line_tax_data_total = $line_tax_data[ "total" ];
                //$line_tax_data_subtotal = $line_tax_data["subtotal"];

                foreach ( $line_tax_data_total as $key => $values ) {
                    //  Check if the tax rate is on the list of tax rate monitored by the plugin
                    if ( isset( $eu_vat_tax_used_list[ $key ] ) ) {
                        $eu_vat_exempt_amount += $values;
                        $cart->cart_contents[ $cart_item_key ][ "line_tax" ] -= $values;
                        $cart->taxes[ $key ] -= $values;
                        $cart->total -= $values;
                        $cart->cart_contents[ $cart_item_key ][ "line_tax_data" ][ "total" ][ $key ] = 0;

                        $cart->cart_contents[ $cart_item_key ][ "line_subtotal_tax" ] -= $cart->cart_contents[ $cart_item_key ][ "line_tax_data" ][ "subtotal" ][ $key ];
                        $cart->cart_contents[ $cart_item_key ][ "line_tax_data" ][ "subtotal" ][ $key ] = 0;
                    }
                }
            }

            $cart->set_session ();

            WC ()->session->set ( "eu_vat_exempt_amount", $eu_vat_exempt_amount );

            return $cart;
        }

        /**
         * Check for digital goods on current cart that should be VAT exempt.
         *
         * @return array Tax totals without digital goods VAT exempted
         */
        public function check_digital_goods_for_eu_vat ( $cart ) {
            //  if on EU VAT number check option, is set don't validate VAT number, skip this step
            if ( ! $this->check_eu_vat_number ) {
                return;
            }

            $valid_eu_vat_number = WC ()->session->get ( "valid_eu_vat_number" );


            if ( ! $valid_eu_vat_number ) {
                return $cart;
            }

            if ( $this->eu_country_conflict () ) {

                if ( ! $this->mandatory_match_country ) {

                    return $this->remove_eu_vat_taxes ( $cart );
                } else {

                    //   check for manual confirmation
                    if ( isset( $_POST[ "post_data" ] ) ) {

                        parse_str ( $_POST[ "post_data" ] );

                        //  Check if a country conflict is shown and if the customer have done a manual confirmation
                        if ( isset( $eu_vat_confirm_country ) && ( "confirm" === $eu_vat_confirm_country ) ) {

                            return $this->remove_eu_vat_taxes ( $cart );
                        }
                    }
                }
            }


            return $cart;
        }


        /**
         * Add scripts for dealing with checkout page elements
         */
        public function add_plugin_scripts () {
            if ( ! is_checkout () ) {
                return;
            }

            //  register and enqueue ajax calls related script file
            wp_register_script ( "ajax-script", YITH_YWEV_URL . 'assets/js/ywev_script.js', array ( 'jquery' ) );
            wp_localize_script ( 'ajax-script', 'ywev', array (
                'ask_confirm_countries'      => '["' . implode ( '","', $this->get_foreign_eu_countries () ) . '"]',
                /*'base_country'               => WC()->countries->get_base_country(),*/
                'base_countries'             => $this->get_base_country (),
                'geo_country'                => $this->get_geolocated_country_code (),
                'mandatory_match_country'    => $this->mandatory_match_country,
                'mandatory_vat_number'       => $this->mandatory_vat_number,
                'loader'                     => apply_filters ( 'yith_ywev_loader_gif', YITH_YWEV_ASSETS_URL . '/images/loading.gif' ),
                'message_country_conflicted' => __ ( "In order to make the digital goods in the cart VAT exempted, you must validate your base location.", 'yith-woocommerce-eu-vat' ),
                'message_confirm_option1'    => __ ( "Calculate normal tax rates.", 'yith-woocommerce-eu-vat' ),
                'message_confirm_option2'    => __ ( "I'm from", 'yith-woocommerce-eu-vat' ),
                'message_confirm_option2b'   => __ ( "apply the EU VAT reverse charge.", 'yith-woocommerce-eu-vat' ),
            ) );

            wp_enqueue_script ( 'ajax-script' );
        }

        /**
         * Get EU countries other than the shop base location
         *
         * @return array
         */
        public function get_foreign_eu_countries () {
            $ask_confirm_countries = array_values ( WC ()->countries->get_european_union_countries ( 'eu_vat' ) );

            /*
            $shop_base_location    = WC()->countries->get_base_country();
            if ( ( $key = array_search( $shop_base_location, $ask_confirm_countries ) ) !== false ) {
                unset( $ask_confirm_countries[ $key ] );
            }
*/
            $shop_base_location = $this->get_base_country ();
            foreach ( $shop_base_location as $location ) {
                if ( ( $key = array_search ( $location, $ask_confirm_countries ) ) !== false ) {
                    unset( $ask_confirm_countries[ $key ] );
                }
            }

            return $ask_confirm_countries;
        }

        /**
         * Initi plugin options
         */
        public function init_plugin_options () {
            $this->mandatory_vat_number = ( "yes" === get_option ( 'ywev_mandatory_vat_number' ) ) ? true : false;

            $vat_number_checks = get_option ( 'ywev_eu_vat_number_checks' );
            if ( $vat_number_checks ) {
                switch ( $vat_number_checks ) {
                    case 'never':
                        /* nothing to set, $check_country and $mandatory_match_country are false by default */
                        break;
                    case 'check':
                        $this->check_eu_vat_number = true;
                        break;
                    case 'stop':
                        $this->check_eu_vat_number        = true;
                        $this->stop_invalid_eu_vat_number = true;
                        break;
                }
            }

            $country_checks = get_option ( 'ywev_country_conflicts' );
            if ( $country_checks ) {
                switch ( $country_checks ) {
                    case 'never':
                        /* nothing to set, $check_country and $mandatory_match_country are false by default */
                        break;
                    case 'store':
                        $this->check_country = true;
                        break;
                    case 'ask':
                        $this->check_country           = true;
                        $this->mandatory_match_country = true;
                        break;
                }
            }
        }

        /**
         * Add some additional entry on plugin option list
         *
         * @param $args current option list
         *
         * @return array new option list
         */
        public function set_plugin_options ( $args ) {
            $mandatory_vat_number = array (
                'id'      => 'ywev_mandatory_vat_number',
                'type'    => 'checkbox',
                'name'    => __ ( 'Mandatory VAT number', 'yith-woocommerce-eu-vat' ),
                'desc'    => __ ( "The VAT number is a mandatory field.", 'yith-woocommerce-eu-vat' ),
                'default' => 'no',
                'std'     => 'no',
            );

            $eu_vat_number_conflicts = array (
                'id'      => 'ywev_eu_vat_number_checks',
                'type'    => 'radio',
                'options' => array (
                    'never' => __ ( "Never check EU VAT number validity, VAT will always be charged.", 'yith-woocommerce-eu-vat' ),
                    'check' => __ ( "Check EU VAT number validity and charge VAT if the number is not valid.", 'yith-woocommerce-eu-vat' ),
                    'stop'  => __ ( "Check EU VAT number validity and stop checkout if the number is not valid.", 'yith-woocommerce-eu-vat' ),
                ),
                'default' => 'check',
                'std'     => 'check',
                'name'    => __ ( 'EU VAT number check', 'yith-woocommerce-eu-vat' ),
                'desc'    => __ ( "When selling to EU customers, choose which check should be done about the EU VAT number validitation.", 'yith-woocommerce-eu-vat' ),
            );

            $manage_country_conflicts = array (
                'id'      => 'ywev_country_conflicts',
                'type'    => 'radio',
                'options' => array (
                    'never' => __ ( "Never check customer's origin.", 'yith-woocommerce-eu-vat' ),
                    'store' => __ ( "Allow the checkout but store the origin.", 'yith-woocommerce-eu-vat' ),
                    'ask'   => __ ( "Allow the checkout only after an origin confirmation by the customer.", 'yith-woocommerce-eu-vat' ),
                ),
                'default' => 'never',
                'std'     => 'never',
                'name'    => __ ( "Customer's country check", 'yith-woocommerce-eu-vat' ),
                'desc'    => __ ( "Choose how to proceed when the customer's location is different from the geolocalized country.", 'yith-woocommerce-eu-vat' ),
            );

            $use_custom_base_location = array (
                'id'      => 'ywev_use_custom_base_location',
                'type'    => 'checkbox',
                'name'    => __ ( 'Custom base location', 'yith-woocommerce-eu-vat' ),
                'desc'    => __ ( "Use custom base location instead of WooCommerce setting.", 'yith-woocommerce-eu-vat' ),
                'default' => 'no',
                'std'     => 'no',
            );

            $custom_base_location = array (
                'id'      => 'ywev_custom_base_location',
                'type'    => 'text',
                'name'    => __ ( 'Base locations', 'yith-woocommerce-eu-vat' ),
                'desc'    => __ ( "Add comma separated countries code to be used as base location.", 'yith-woocommerce-eu-vat' ),
                'default' => '',
                'std'     => '',
            );

            $args = array_slice ( $args, 0, count ( $args ) - 1, true ) +
                array (
                    'use_custom_base_location' => $use_custom_base_location,
                    'custom_base_location'     => $custom_base_location,
                    'mandatory_vat_number'     => $mandatory_vat_number,
                    'eu_vat_conflicts'         => $eu_vat_number_conflicts,
                    'country_conflict'         => $manage_country_conflicts,
                ) +
                array_slice ( $args, 3, count ( $args ) - 1, true );

            return $args;
        }

        /**
         * Do some checks and update based on data current displayed on checkout page
         *
         * @param $form_data
         */
        public function update_data_on_checkout_change ( $form_data ) {

            WC ()->session->__unset ( "eu_vat_exempt_amount" );

            parse_str ( $form_data );

            $valid_eu_vat    = false;
            $do_eu_vat_check = true;

            /**  if current stored country is an european country, please check
             *  EU VAT validity */
            if ( ! $this->is_eu_customer ( $billing_country ) ) {
                $do_eu_vat_check = false;
            }

            if ( empty( $billing_country ) && empty( $shipping_country ) ) {
                $do_eu_vat_check = false;
            }

            if ( empty( $ywev_vat_number ) ) {
                $do_eu_vat_check = false;
            }

            if ( $this->mandatory_match_country && isset( $eu_vat_confirm_country ) && ( "confirm" != $eu_vat_confirm_country ) ) {
                $do_eu_vat_check = false;
            }

            if ( $do_eu_vat_check ) {

                $ywev_vat_number = sanitize_text_field ( $ywev_vat_number );

                $response = $this->check_eu_vat_number_validity ( $billing_country, $ywev_vat_number );

                if ( "valid" == $response ) {
                    $valid_eu_vat = true;
                }
            }


            WC ()->session->set ( "eu_vat_number", $ywev_vat_number );
            WC ()->session->set ( "checkout_country", $billing_country );
            WC ()->session->set ( "valid_eu_vat_number", $valid_eu_vat ? 1 : 0 );

            return;
        }

        /**
         * Use an external free service to check if a VAT number is a recognized EU
         * VAT number for a specific country.
         *
         * @param string $vat_country the country of the customer
         * @param string $vat_number  the VAT number of the customer
         *
         * @return string return a response between :
         * "valid" for VAT number recognized as EU VAT number,
         * "busy" if the server who provide the response is currently busy
         * "invalid" for VAT number not recognized as EU VAT number for the specific country
         * "error" for general error during the verification request.
         */
        public function check_eu_vat_number_validity ( $vat_country, $vat_number ) {

            //  before doing a request to an external service, see if a positive response was
            //  received during a previous request
            if ( WC ()->session->get ( $vat_country . $vat_number ) != null ) {

                return "valid";
            }

            $client = new SoapClient( "http://ec.europa.eu/taxation_customs/vies/checkVatService.wsdl" );

            if ( $client ) {
                try {
                    $resp = $client->checkVat ( array (
                        'countryCode' => $vat_country,
                        'vatNumber'   => $vat_number,
                    ) );

                    if ( $resp->valid == true ) {
                        WC ()->session->set ( $vat_country . $vat_number, 1 );

                        return "valid";
                    }

                    //  VAT number not valid

                    return "invalid";
                } catch ( SoapFault $e ) {

                    return "error";
                }
            }

            // Connection to host not possible
            return "busy";

        }

        /**
         * Show additional fields base don plugin settings.
         *
         * @param $checkout
         */
        public function show_additional_data_on_checkout ( $checkout ) {
            echo '<div id="ywev_vat_number"><h3>' . __ ( "VAT information", 'yith-woocommerce-eu-vat' ) . '</h3>';

            // Add VAT number field on checkout form
            woocommerce_form_field ( 'ywev_vat_number', array (
                'type'        => 'text',
                'class'       => array ( 'form-row-wide update_totals_on_change' ),
                'label'       => __ ( 'VAT number', 'yith-woocommerce-eu-vat' ),
                'placeholder' => __ ( 'Enter your VAT number', 'yith-woocommerce-eu-vat' ),
                'required'    => $this->mandatory_vat_number,
            ), $checkout->get_value ( 'ywev_vat_number' ) );

            echo '</div>';
        }

        /**
         * Extract client ip address
         *
         * @return string   ip address
         */
        private function get_client_ip_address () {
            return getenv ( 'HTTP_CLIENT_IP' ) ? :
                getenv ( 'HTTP_X_FORWARDED_FOR' ) ? :
                    getenv ( 'HTTP_X_FORWARDED' ) ? :
                        getenv ( 'HTTP_FORWARDED_FOR' ) ? :
                            getenv ( 'HTTP_FORWARDED' ) ? :
                                getenv ( 'REMOTE_ADDR' );
        }

        /**
         * Store additional data related to EU VAT laws on checkout
         *
         * @param $order_storing_data
         */
        public function store_geo_data ( $order_storing_data ) {
            $order_storing_data[ "eu_vat_amount" ]              = WC ()->session->get ( "eu_vat_exempt_amount" );
            $order_storing_data[ "country_conflicted" ]         = WC ()->session->get ( "country_conflicted" );
            $order_storing_data[ "vat_number" ]                 = WC ()->session->get ( "vat_number" );
            $order_storing_data[ "country_confirmed" ]          = WC ()->session->get ( "country_confirmed" );
            $order_storing_data[ "eu_cart_with_digital_goods" ] = $this->current_cart_contains_digital_goods ();

            $taxable_location = &$order_storing_data[ 'Localization' ];

            if ( ! isset( $taxable_location ) ) {
                return;
            }

            $taxable_location[ "GEO_COUNTRY" ] = $this->get_geolocated_country_code ();
            $taxable_location[ "IP_ADDRESS" ]  = $this->get_client_ip_address ();

            return $order_storing_data;
        }

        /**
         * Check before confirm an order, if the customer is from an EU country and
         * check data entered in according of the plugin settings.
         */
        function checks_before_confirm_order () {
            WC ()->session->__unset ( "vat_number" );

            /**
             * Check if a VAT number is requested and stop processing the order if the VAT number is not present
             */
            if ( $this->mandatory_vat_number ) {
                if ( empty( $_POST[ "ywev_vat_number" ] ) ) {
                    wc_add_notice ( __ ( "Please insert you're VAT number, it is a mandatory field.", 'yith-woocommerce-eu-vat' ), 'error' );

                    return;
                }
            }

            if ( ! empty( $_POST[ "ywev_vat_number" ] ) ) {
                WC ()->session->set ( "vat_number", $_POST[ "ywev_vat_number" ] );
            }

            /**
             * If the current cart doesn't contain digital goods, nothing should be done in this section
             */
            $eu_cart_with_digital_goods = $this->current_cart_contains_digital_goods (); //WC()->session->get("eu_cart_with_digital_goods");

            if ( ! $eu_cart_with_digital_goods ) {
                return;
            }

            /*  if the customer is not from an EU country, there is nothing to do in this section. */
            $customer_country_code = WC ()->session->get ( "checkout_country" );

            if ( ! $this->is_eu_customer ( $customer_country_code ) ) {
                return;
            }

            /**
             * if the customer country is the same of the shop, there is nothing to do in this section.
             */
            /*
            if ( $customer_country_code == WC()->countries->get_base_country() ) {
                return;
            }
            */
            if ( in_array ( $customer_country_code, $this->get_base_country () ) ) {
                return;
            }

            $valid_eu_vat_number = WC ()->session->get ( "valid_eu_vat_number" );

            //  If a VAT number is entered, check if the plugin option said that the VAT number must be valid for complete the order
            if ( $this->stop_invalid_eu_vat_number && ! $valid_eu_vat_number ) {
                wc_add_notice ( __ ( "The VAT number was not validated by the EU VAT number checking service. Please check if the number is correct and try again.", 'yith-woocommerce-eu-vat' ), 'error' );

                return;
            }

            WC ()->session->__unset ( "country_conflicted" );
            WC ()->session->__unset ( "country_confirmed" );

            /*
             * if the VAT number is a valid EU VAT number, check the country and ask for confirm if the related plugin option is enabled.
             *
             */
            if ( $valid_eu_vat_number && $this->eu_country_conflict () ) {

                WC ()->session->set ( "country_conflicted", 1 );

                if ( $this->mandatory_match_country ) {

                    //  Check if a country conflict is shown and if the customer have done a manual confirmation
                    if ( ! isset( $_POST[ "eu_vat_confirm_country" ] ) || ( "confirm" != $_POST[ "eu_vat_confirm_country" ] ) ) {

                        wc_add_notice ( __ ( "You must manually confirm your base location to complete the current order.", 'yith-woocommerce-eu-vat' ), 'error' );

                        return;
                    }
                    WC ()->session->set ( "country_confirmed", 1 );
                } else {
                    WC ()->session->set ( "country_confirmed", 0 );
                }
            }
        }

        /**
         * Get the customer country code.
         *
         * @return bool|array the country code or false if something goes wrong
         */
        public function get_geolocated_country_code () {
            $data = WC_Geolocation::geolocate_ip ( $this->get_client_ip_address () );
            if ( is_array ( $data ) && isset( $data[ 'country' ] ) ) {
                return $data[ 'country' ];
            }

            return false;
        }
    }
}