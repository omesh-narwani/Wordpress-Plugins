=== YITH WooCommerce Featured Audio Video Content ===

Contributors: yithemes
Tags: woocommerce, featured video, featured image, featured, product, e-commerce, shop, vimeo, youtube, html5, player, video player, html5 video, responsive, videojs, yit, yith, yithemes
Requires at least: 3.5.1
Tested up to: 4.4.1
Stable tag: 1.1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

YITH WooCommerce Featured Video allows you to set a video in place of the featured image in the product detail page.

== Description ==

YITH WooCommerce Featured Video plugin is an extension of Woocommerce plugin that allow your users to see a Youtube or Vimeo video in place of featured image in the product detail page.
You can simply set a video in place of featured image in the product detail page, by setting the URL of youtube or vimeo video in the specific field of product configuration page.

= Installation =

Once you have installed the plugin, you just need to activate the plugin in order to enable it.

= Configuration =

1. Open the configuration page of product where you want to set the featured video;
2. Set the URL of video in the "Featured Video URL" field, in the "Product Data" box.

== Installation ==

1. Unzip the downloaded zip file.
2. Upload the plugin folder into the `wp-content/plugins/` directory of your WordPress site.
3. Activate `YITH WooCommerce Featured Video` from Plugins page

== Screenshots ==

1. The product detail page with featured video.
2. The admin field in product configuration.

== Changelog ==

= 1.1.3 =

* Tweak: improved integration with YITH WooCommerce Zoom Magnifier
* Fixed: Upload image in admin

= 1.1.2 =

* Added: filter "yith_featured_video_enabled"
* Updated: Plugin Framework

= 1.1.1 =

* Added: show or hide video related option for YouTube

= 1.1.0 =

* Tweak: improved uploading of video and audio files in admin side
* Tweak: improved uploading of video and audio files for variable products both for admin and in frontend
* Added: aspect ratio option for videos
* Added: additional options for YouTube and Vimeo
* Added: compatibility fixes with YITH WooCommerce Zoom Magnifier (free and premium versions)
* Added: slider for non-featured videos and audio files
* Removed: videojs for YouTube and Vimeo

= 1.0.3 =

* Fixed : Change Video in Variable Product
* Fixed : Black screen on video uploaded


= 1.0.2 =

* Updated: Plugin Framework 2.0

= 1.0.1 =

* Fixed : javascript error in admin
* Fixed : aspect-ratio for video and audio
* Fixed : function Hex2RGB already exists

= 1.0.0 =

* Initial release
