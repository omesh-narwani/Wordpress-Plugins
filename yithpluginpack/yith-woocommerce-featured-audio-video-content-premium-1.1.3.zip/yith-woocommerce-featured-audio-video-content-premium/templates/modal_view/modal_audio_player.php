<?php
if( !defined( 'ABSPATH' ) )
    exit;


$audio_meta_id =  $atts['audio']['id'];
$audio_meta_id = isset( $atts['index'] )? $audio_meta_id.'_'.$atts['index'] : $audio_meta_id;
$img_src = $atts['audio']['thumbn'];
$autoplay = empty( $atts['autoplay'] ) ? 0 : 1;

$url = urlencode( $atts['audio']['url'] );
$width = get_option( 'ywcfav_width_player' );
$height = get_option( 'ywcfav_height_player');
?>

<div class="ywcfav_audio_moodal_container">
    <iframe id="<?php echo $audio_meta_id;?>" width="<?php echo $width;?>" height="<?php echo $height;?>" src="https://w.soundcloud.com/player/?url=<?php echo $url;?>" frameborder="no" scrolling="no" ></iframe>
</div>
<script type="text/javascript">
    jQuery(document).ready(function($){

        var widget = SC.Widget('<?php echo $audio_meta_id;?>');




        widget.load('<?php echo $url.'&color='.$atts['color'];?>',
            {   'show_artwork' : <?php echo $atts['show_artwork'];?>,
                'auto_play' : <?php echo $atts['auto_play'];?>,
                'sharing'  : <?php echo $atts['show_share'];?>,
                'show_comments' : <?php echo $atts['show_comments'];?>
            }
        );


        widget.bind(SC.Widget.Events.READY, function () {

            // load new widget
            widget.getSounds( function(sounds){

                if( sounds.length>1)

                    $('#<?php echo $audio_meta_id;?>').height(450);

            });

            widget.setVolume(<?php echo $atts['volume'];?>);
        });

    });
</script>