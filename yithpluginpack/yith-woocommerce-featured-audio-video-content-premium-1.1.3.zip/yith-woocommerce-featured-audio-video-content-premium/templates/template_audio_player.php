<?php
if( !defined( 'ABSPATH' ) )
    exit;


$audio_meta_id =  $atts['audio']['id'];

$img_src = $atts['audio']['thumbn'];
$autoplay = empty( $atts['autoplay'] ) ? 0 : 1;

$url = urlencode( $atts['audio']['url'] );

?>

<div class="ywcfav_audio_container">
    <iframe id="<?php echo $audio_meta_id;?>" src="https://w.soundcloud.com/player/?url=<?php echo $url;?>" frameborder="no" scrolling="no" ></iframe>
</div>

<script type="text/javascript">
    jQuery(document).ready(function($){

        var div_img = $('.product .images'),
            width_div = div_img.width();

            var widget = SC.Widget('<?php echo $audio_meta_id;?>');

               widget.load('<?php echo $url.'&color='.$color;?>',
                                {   'show_artwork' : <?php echo $atts['show_artwork'];?>,
                                    'auto_play' : <?php echo $atts['auto_play'];?>,
                                    'sharing'  : <?php echo $atts['show_share'];?>,
                                    'show_comments' : <?php echo $atts['show_comments'];?>
                                }
                );

                widget.bind(SC.Widget.Events.READY, function () {

                    $('#<?php echo $audio_meta_id;?>').width( width_div );
                    // load new widget
                    widget.getSounds( function(sounds){

                        if( sounds.length>1)

                            $('#<?php echo $audio_meta_id;?>').height(450);

                    });

                    widget.setVolume(<?php echo $atts['volume'];?>);
                });

            widget.bind( SC.Widget.Events.PLAY_PROGRESS, function(){
                $('.woocommerce span.onsale:first, .woocommerce-page span.onsale:first').hide();
            });
            widget.bind( SC.Widget.Events.FINISH , function(){

                $('.woocommerce span.onsale:first, .woocommerce-page span.onsale:first').show();
            });
            widget.bind( SC.Widget.Events.PAUSE , function(){
                $('.woocommerce span.onsale:first, .woocommerce-page span.onsale:first').show();
            });
    });
</script>