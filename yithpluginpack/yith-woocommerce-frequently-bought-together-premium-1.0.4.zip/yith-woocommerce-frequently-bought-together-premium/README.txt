== Changelog ==

= 1.0.4 = 01/12/2016 =

* Added: Compatibility with WooCommerce 2.5
* Added: Option to set a background to "Frequently Bought" form
* Updated: Plugin Core

= 1.0.3 = 08/28/2015 =

* Fixed: Thumbnail image size option

= 1.0.2 = 08/21/2015 =

* Added: Compatibility with WooCommerce 2.4.x
* Added: ITA Translation
* Added: Compatibility with Wordpress 4.3
* Updated: Plugin Core

= 1.0.1 = 07/24/2015 =

* Fixed: Minor Bugs
* Updated: Plugin Core

= 1.0.0 = 05/22/2015 =

* Initial release