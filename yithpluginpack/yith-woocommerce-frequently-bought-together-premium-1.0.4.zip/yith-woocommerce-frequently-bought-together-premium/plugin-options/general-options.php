<?php
/**
 * GENERAL ARRAY OPTIONS
 */

$general = array(

	'general'  => array(

		array(
			'title' => __( 'General Options', 'ywbt' ),
			'type' => 'title',
			'desc' => '',
			'id' => 'yith-wcfbt-general-options'
		),

		array(
			'id'        => 'yith-wfbt-form-title',
			'name'      => __( 'Box title', 'ywbt' ),
			'desc'      => __( 'Title shown on "Frequently Bought Together" box.', 'ywbt' ),
			'type'      => 'text',
			'default'   => __( 'Frequently Bought Together', 'ywbt' )
		),

		array(
			'id'        => 'yith-wfbt-total-single-label',
			'name'      => __( 'Total label for single product', 'ywbt' ),
			'desc'      => __( 'This is the text shown for total price label when only one product has been checked.', 'ywbt' ),
			'type'      => 'text',
			'default'   => __( 'Price', 'ywbt' )
		),

		array(
			'id'        => 'yith-wfbt-total-double-label',
			'name'      => __( 'Total label for double products', 'ywbt' ),
			'desc'      => __( 'This is the text shown for total price label when two products have been checked.', 'ywbt' ),
			'type'      => 'text',
			'default'   =>  __( 'Price for both', 'ywbt' )
		),

		array(
			'id'        => 'yith-wfbt-total-three-label',
			'name'      => __( 'Total label for three products', 'ywbt' ),
			'desc'      => __( 'This is the text shown for total price label when three products have been checked.', 'ywbt' ),
			'type'      => 'text',
			'default'   =>  __( 'Price for all three', 'ywbt' )
		),

		array(
			'id'        => 'yith-wfbt-total-multi-label',
			'name'      => __( 'Total label for multiple products', 'ywbt' ),
			'desc'      => __( 'This is the label shown for total price label when more than three products have been checked.', 'ywbt' ),
			'type'      => 'text',
			'default'   => __( 'Price for all', 'ywbt' )
		),

		array(
			'id'        => 'yith-wfbt-button-single-label',
			'name'      => __( 'Button label for single product', 'ywbt' ),
			'desc'      => __( 'This is the label shown for "Add to cart" button when only one product has been checked.', 'ywbt' ),
			'type'      => 'text',
			'default'   => __( 'Add to Cart', 'ywbt' )
		),

		array(
			'id'        => 'yith-wfbt-button-double-label',
			'name'      => __( 'Button label for two products', 'ywbt' ),
			'desc'      => __( 'This is the label shown for "Add to cart" button when two products have been checked.', 'ywbt' ),
			'type'      => 'text',
			'default'   =>  __( 'Add both to Cart', 'ywbt' )
		),

		array(
			'id'        => 'yith-wfbt-button-three-label',
			'name'      => __( 'Button label for three products', 'ywbt' ),
			'desc'      => __( 'This is the label shown for "Add to cart" button when three products have been checked.', 'ywbt' ),
			'type'      => 'text',
			'default'   =>  __( 'Add all three to Cart', 'ywbt' )
		),

		array(
			'id'        => 'yith-wfbt-button-multi-label',
			'name'      => __( 'Button label for multiple products', 'ywbt' ),
			'desc'      => __( 'This is the label shown for "Add to cart" button when more than two products have been checked.', 'ywbt' ),
			'type'      => 'text',
			'default'   => __( 'Add all to Cart', 'ywbt' )
		),

		array(
			'id'        => 'yith-wfbt-form-background-color',
			'name'      => __( 'Form Background Color', 'ywbt' ),
			'desc'      => __( 'Select background color for Frequently Bought form', 'ywbt' ),
			'type'      => 'color',
			'default'   => '#ffffff'
		),

		array(
			'id'        => 'yith-wfbt-button-color',
			'name'      => __( 'Button Color', 'ywbt' ),
			'desc'      => __( 'Select button background color', 'ywbt' ),
			'type'      => 'color',
			'default'   => '#222222'
		),

		array(
			'id'        => 'yith-wfbt-button-color-hover',
			'name'      => __( 'Button Hover Color', 'ywbt' ),
			'desc'      => __( 'Select button background hover color', 'ywbt' ),
			'type'      => 'color',
			'default'   => '#222222'
		),

		array(
			'id'        => 'yith-wfbt-button-text-color',
			'name'      => __( 'Button Text Color', 'ywbt' ),
			'desc'      => __( 'Select button text color', 'ywbt' ),
			'type'      => 'color',
			'default'   => '#ffffff'
		),

		array(
			'id'        => 'yith-wfbt-button-text-color-hover',
			'name'      => __( 'Button Text Hover Color', 'ywbt' ),
			'desc'      => __( 'Select button text hover color', 'ywbt' ),
			'type'      => 'color',
			'default'   => '#ffffff'
		),

		array(
			'id'        => 'yith-wfbt-loader',
			'name'      => __( 'Loader Image', 'ywbt' ),
			'desc'      => __( 'Upload a custom loading image.', 'ywbt' ),
			'type'      => 'yith_wfbt_upload',
			'default'   => YITH_WFBT_ASSETS_URL . '/images/loader.gif'
		),

		array(
			'id'        => 'yith-wfbt-image-size',
			'name'      => __( 'Image Size', 'ywbt' ),
			'desc'      => sprintf( __( 'Set image size (px). After changing these settings you may need to %s.', 'ywbt' ), '<a href="http://wordpress.org/extend/plugins/regenerate-thumbnails/">' . __( 'regenerate your thumbnails', 'ywbt' ) . '</a>' ),
			'type'      => 'yith_image_size',
			'default'   => array(
				'width'     => '70',
				'height'    => '70',
				'crop'      => 1
			)
		),

		array(
			'id'        => 'yith-wfbt-form-position',
			'name'      => __( 'Select box position', 'ywbt' ),
			'type'      => 'select',
			'options'   => array(
				'1' =>  __( 'Below product summary', 'ywbt' ),
				'2' =>  __( 'Above product tabs', 'ywbt' ),
				'3' =>  __( 'Below product tabs', 'ywbt' )
			),
			'default'   => '2'
		),

		array(
			'type'      => 'sectionend',
			'id'        => 'yith-wcfbt-general-options'
		)
	)
);

return apply_filters( 'yith_wcfbt_panel_general_options', $general );