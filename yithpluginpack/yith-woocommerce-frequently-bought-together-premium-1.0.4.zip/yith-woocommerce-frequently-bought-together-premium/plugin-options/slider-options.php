<?php
/**
 * SLIDER ARRAY OPTIONS
 */

$slider = array(

	'slider'  => array(

		array(
			'title' => __( 'Slider Options', 'ywbt' ),
			'type' => 'title',
			'desc' => '',
			'id' => 'yith-wfbt-slider-options'
		),

		array(
			'id'        => 'yith-wfbt-slider-title',
			'title'     => __( 'Slider Title', 'ywbt' ),
			'desc'      => __( 'Give a title to the slider with products', 'ywbt' ),
			'type'      => 'text',
			'default'   => __( 'Customers who bought the items in your wishlist also purchased', 'ywbt' )
		),

		array(
			'id'        => 'yith-wfbt-slider-elems',
			'title'     => __( 'Number of products', 'ywbt' ),
			'desc'      => __( 'Choose the maximum number of products displayed at a time when the browser is used with its widest width.', 'ywbt' ),
			'type'      => 'number',
			'default'   => 4,
			'custom_attributes' => array( 'min' => '1' )
		),

		array(
			'id'        => 'yith-wfbt-slider-buy-button',
			'title'     => __( '"Add to cart" button label', 'ywbt' ),
			'desc'      => __( 'Choose the label for "Add to cart" button.', 'ywbt' ),
			'type'      => 'text',
			'default'   => __( 'Add to cart', 'ywbt' )
		),

		array(
			'id'        => 'yith-wfbt-slider-wishlist-button',
			'title'     => __( '"Wishlist" button', 'ywbt' ),
			'desc'      => __( 'Choose the label for "Wishlist" button.', 'ywbt' ),
			'type'      => 'text',
			'default'   => __( 'Add to Wishlist', 'ywbt' )
		),

		array(
			'id'            => 'yith-wfbt-slider-product-image',
			'title'         => __( 'Select product content', 'ywbt' ),
			'desc'          => __( 'Product Image', 'ywbt' ),
			'type'          => 'checkbox',
			'default'       => 'yes',
			'checkboxgroup' => 'start'
		),

		array(
			'id'            => 'yith-wfbt-slider-product-title',
			'desc'          => __( 'Product Name', 'ywbt' ),
			'type'          => 'checkbox',
			'default'       => 'yes',
			'checkboxgroup' => ''
		),

		array(
			'id'            => 'yith-wfbt-slider-product-price',
			'desc'          => __( 'Product Price', 'ywbt' ),
			'type'          => 'checkbox',
			'default'       => 'yes',
			'checkboxgroup' => ''
		),

		array(
			'id'            => 'yith-wfbt-slider-product-variation',
			'desc'          => __( 'Product Variation', 'ywbt' ),
			'type'          => 'checkbox',
			'default'       => 'yes',
			'checkboxgroup' => ''
		),

		array(
			'id'            => 'yith-wfbt-slider-product-rating',
			'desc'          => __( 'Product Rating', 'ywbt' ),
			'type'          => 'checkbox',
			'default'       => 'yes',
			'checkboxgroup' => 'end'
		),

		array(
			'type'      => 'sectionend',
			'id'        => 'yith-wfbt-slider-options'
		)
	)
);

return apply_filters( 'yith_wcfbt_panel_slider_options', $slider );