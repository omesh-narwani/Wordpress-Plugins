
jQuery(document).ready(function ($) {

    /** Show the edit gift card button */
    $("button.ywgc-do-edit").css("display", "inline");

    /** init datepicker */
    $("div.gift-card-generator .datepicker").datepicker({dateFormat: "yy-mm-dd", minDate: +1, maxDate: "+1Y"});

    function update_gift_card_amount(amount, addcurrency) {
        if (addcurrency) {
            $("div.gift-card-amount span.amount").text(ywgc.currency + amount);
        }
        else {
            $("div.gift-card-amount span.amount").text(amount);
        }
    }

    function show_gift_card_editor(val) {
        if (val) {

            $("div.gift_card_product_wrap").css('display', 'inherit');
            $("div.gift-card-generator").css('display', 'inherit');
            $("div.gift-card-generator").css('visibility', 'visible');

            //  Set the flag required on <input> elements
            $('input[name="recipient-email"]').add('input[name="sender-name"]').prop("required", true);
        }
        else {
            $("div.gift-card-generator").css('display', 'none');
            $("div.gift_card_product_wrap").css('display', 'none');

            //  Unset the flag required on <input> elements
            $('input[name="recipient-email"]').add('input[name="sender-name"]').prop("required", false);
        }
    }

    function show_hide_add_to_cart_button() {
        var select_element = $(".gift-cards-list select");
        $('.gift-cards-list input.manual-amount').addClass('hidden');

        if ("-1" == select_element.val()) {
            /* the user should enter a manual value as gift card amount */
            var manual_amount_element = $('.gift-cards-list input.manual-amount');
            manual_amount_element.removeClass('hidden');

            /* If the user entered a valid amount, show "add to cart" button and gift card
             editor.
             */
            if ((Math.floor(manual_amount_element.val()) == manual_amount_element.val()) && $.isNumeric(manual_amount_element.val())) {
                show_gift_card_editor(true);
                update_gift_card_amount(manual_amount_element.val(), true);
            }
            else {
                show_gift_card_editor(false);
            }
        }
        else if (!select_element.val()) {
            show_gift_card_editor(false);
        }
        else {
            show_gift_card_editor(true);
            var amount = select_element.children("option:selected").text();
            update_gift_card_amount(amount, false);
        }
    }

    $(document).on('input', '.gift-cards-list input.manual-amount', function (e) {
        show_hide_add_to_cart_button();
    });

    function add_recipient() {
        var last = $('div.ywgc-single-recipient').last();
        var new_div = '<div class="ywgc-single-recipient">\
            <input type="email" name="recipient-email[]" class="ywgc-recipient" required/> \
            <a href="#" class="remove-recipient hide-if-alone">x</a> \
            </div>';

        last.after(new_div);


        //  show the remove recipient links
        $("a.remove-recipient").css('visibility', 'visible');

        $("div.gift_card_template_button input[name='quantity']").css("display", "none");

        //  show a message for quantity disabled when multi recipients is entered
        if (!$("div.gift_card_template_button div.multi-recipients").length) {
            $("div.gift_card_template_button div.quantity").after("<div class='multi-recipients'><span>" + ywgc.multiple_recipient + "</span></div>");
        }
    }

    function remove_recipient(element) {
        //  remove the element
        $(element).parent("div.ywgc-single-recipient").remove();

        //  Avoid the deletion of all recipient
        var emails = $('input[name="recipient-email[]"');
        if (emails.length == 1) {
            //  only one recipient is entered...
            $("a.hide-if-alone").css('visibility', 'hidden');
            $("div.gift_card_template_button input[name='quantity']").css("display", "inherit");

            $("div.multi-recipients").remove();
        }
    }

    $(document).on('click', 'a.add-recipient', function (e) {
        e.preventDefault();
        add_recipient();
    });

    $(document).on('click', 'a.remove-recipient', function (e) {
        e.preventDefault();
        remove_recipient($(this));
    });

    $(document).on('input', '#gift-card-message', function (e) {
        //$(".card-message").html(stripHTML($('#gift-card-message').val()));
        $(".card-message").text($('#gift-card-message').val());
    });

    $(document).on('change', '.gift-cards-list select', function (e) {
        show_hide_add_to_cart_button();
    });

    $(document).on('click', 'a.customize-gift-card', function (e) {
        e.preventDefault();
        $('div.summary.entry-summary').after('<div class="gift-card-customizer"></div>');
    });

    /** Set to default the image used on the gift card editor on product page */
    $(document).on('click', '.gift-card-default-picture-link', function (e) {
        e.preventDefault();
        var control = $('#uploadFile');
        control.replaceWith(control = control.clone(true));
        $('div.gift-card-picture img.gift-card-main-image').attr('src', ywgc.default_gift_card_image);
        //  Reset style if previously a custom image was used
        $("div.gift-card-picture").css("background-color", "");
        $("div.gift-card-too-small").remove();

    });

    /** Show the custom file choosed by the user as the image used on the gift card editor on product page */
    $(document).on('click', '.gift-card-customize-picture-link', function (e) {
        $('#uploadFile').click();
    });

    $('#uploadFile').on('change', function () {
        var preview_image = function (file) {
            var oFReader = new FileReader();
            oFReader.readAsDataURL(file);

            oFReader.onload = function (oFREvent) {
                document.getElementById("gift-card-main-image").src = oFREvent.target.result;

                /** Check the size of the file choosed and notify it to the user if it is too small */
                if ($("#gift-card-main-image").width() < $("div.gift-card-picture").width()) {
                    $("div.gift-card-picture").css("background-color", "#ffe326");
                    $(".gift-card-preview").prepend('<div class="gift-card-too-small">' + ywgc.notify_custom_image_small + '</div>');
                }
                else {
                    $("div.gift-card-picture").css("background-color", "");
                }
            }
        }

        //  Remove previous errors shown
        $(".gift-card-customize-picture-error").remove();

        var ext = $(this).val().split('.').pop().toLowerCase();
        if ($.inArray(ext, ['gif', 'png', 'jpg', 'jpeg', 'bmp']) == -1) {
            $("div.gift-card-content-editor.step-appearance").append('<span class="gift-card-customize-picture-error">' +
                ywgc.invalid_image_extension + '</span>');
            return;
        }

        if ($(this)[0].files[0].size > ywgc.custom_image_max_size * 1024 * 1024) {
            $("div.gift-card-content-editor.step-appearance").append('<span class="gift-card-customize-picture-error">' +
                ywgc.invalid_image_size + '</span>');
            return;
        }

        preview_image($(this)[0].files[0]);
    });

    $(document).on('click', '#give-as-present', function (e) {
        e.preventDefault();

        $("div.gift-card-generator").append('<input type="hidden" name="gift_card_enabled" value="1">');
        $("#give-as-present").css("visibility", "hidden");
        $("#cancel-gift-card-creation").css("visibility", "visible");

        $("div.gift-card-generator").css('display', 'inherit');
        $("div.gift-card-generator").css('visibility', 'visible');

        $("input[name='recipient-email[]']").prop('required', true);
        $("input[name='sender-name']").prop('required', true);
    });

    $(document).on('click', '#cancel-gift-card-creation', function (e) {
        e.preventDefault();
        $("div.gift-card-generator input[name='gift_card_enabled']").remove();
        $("#give-as-present").css("visibility", "visible");
        $("#cancel-gift-card-creation").css("visibility", "hidden");

        $("div.gift-card-generator").css('display', 'none');
        $("input[name='recipient-email[]']").prop('required', false);
        $("input[name='sender-name']").prop('required', false);
    });

    $(document).on('change', '#postdate-sending', function (e) {
        if ($(this).is(':checked')) {
            $("#delivery-date").removeClass("hidden");
        }
        else {
            $("#delivery-date").addClass("hidden");
        }
    });

    $(document).on('change', "table.variations select", function () {
        var variation_price_element = $("div.single_variation span.price span.amount");
        if (variation_price_element.length) {
            var current = $("div.single_variation span.price span.amount").text();
            $("div.gift-card-amount span.amount").text(current);
        }
    });

    function show_edit_gift_cards(element, visible) {
        var container = $(element).closest("div.ywgc-gift-card-content");
        var edit_container = container.find("div.ywgc-gift-card-edit-details");
        var details_container = container.find("div.ywgc-gift-card-details");

        if (visible) {
            //go to edit
            edit_container.removeClass("ywgc-hide");
            edit_container.addClass("ywgc-show");

            details_container.removeClass("ywgc-show");
            details_container.addClass("ywgc-hide");
        }
        else {
            //go to details
            edit_container.removeClass("ywgc-show");
            edit_container.addClass("ywgc-hide");

            details_container.removeClass("ywgc-hide");
            details_container.addClass("ywgc-show");
        }
    }

    $(document).on('click', 'button.ywgc-apply-edit, button.ywgc-cancel-edit, button.ywgc-do-edit', function (e) {

        var clicked_element = $(this);

        var container = clicked_element.closest("div.ywgc-gift-card-content");
        var edit_container = container.find("div.ywgc-gift-card-edit-details");
        var details_container = container.find("div.ywgc-gift-card-details");

        if (clicked_element.hasClass("ywgc-do-edit")) {
            //go to edit
            show_edit_gift_cards(clicked_element, true);
        }
        else if (clicked_element.hasClass("ywgc-cancel-edit")) {
            //go to details
            show_edit_gift_cards(clicked_element, false);
        }
        else {

            var sender_element = container.find('input[name="gift-card-sender-name"]');
            var recipient_element = container.find('input[name="gift-card-recipient-email"]');
            var message_element = container.find('textarea[name="gift-card-message"]');

            //  Apply changes, if apply button was clicked
            if (clicked_element.hasClass("apply")) {
                var data = {
                    'action': 'edit_gift_card',
                    'item_id': container.find('input[name="gift-card-item-id"]').text(),
                    'sender': sender_element.text(),
                    'recipient': recipient_element.text(),
                    'message': message_element.val()
                };

                container.block({
                    message: null,
                    overlayCSS: {
                        background: "#fff url(" + ywgc.loader + ") no-repeat center",
                        opacity: .6
                    }
                });

                $.post(ywgc.ajax_url, data, function (response) {
                    if (response.code == 1) {
                        container.find("span.ywgc-sender").text(response.values.sender);
                        container.find("span.ywgc-recipient").text(response.values.recipient);
                        container.find("span.ywgc-message").text(response.values.message);
                    }
                    container.unblock();

                    //go to details
                    show_edit_gift_cards(clicked_element, false);
                });
            }
        }
    });

    $(document).on('click', 'form.gift-cards_form button.gift_card_add_to_cart_button', function (e) {
        $('div.gift-card-content-editor.step-content p.data-filling-error').remove();
        if ($('#postdate-sending').is(':checked') && !$.datepicker.parseDate('yy-mm-dd', $('#delivery-date').val())) {
            $('div.gift-card-content-editor.step-content').append('<p class="data-filling-error">' + ywgc.missing_scheduled_date + '</p>');
            e.preventDefault();
        }
    });
});