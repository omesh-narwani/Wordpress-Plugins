<?php

/**
 * Include files
 */
require_once ( YITH_YWGC_DIR . 'lib/class.yith-woocommerce-gift-cards.php' );
require_once ( YITH_YWGC_DIR . 'lib/class.yith-woocommerce-gift-cards-premium.php' );
require_once ( YITH_YWGC_DIR . 'lib/class.yith-woocommerce-gift-cards-backend.php' );
require_once ( YITH_YWGC_DIR . 'lib/class.yith-woocommerce-gift-cards-backend-premium.php' );
require_once ( YITH_YWGC_DIR . 'lib/class.yith-woocommerce-gift-cards-frontend.php' );
require_once ( YITH_YWGC_DIR . 'lib/class.yith-woocommerce-gift-cards-frontend-premium.php' );

require_once ( YITH_YWGC_DIR . 'lib/class.ywgc-gift-card.php' );
require_once ( YITH_YWGC_DIR . 'lib/class.ywgc-gift-card-premium.php' );
//require_once ( YITH_YWGC_DIR . 'lib/class.ywgc-product-gift-card.php' );
require_once ( YITH_YWGC_DIR . 'lib/class.ywgc-plugin-fw-loader.php' );

/** Define constant values */
defined ( 'YWGC_CUSTOM_POST_TYPE_NAME' ) || define ( 'YWGC_CUSTOM_POST_TYPE_NAME', 'gift_card' );
defined ( 'YWGC_GIFT_CARD_PRODUCT_TYPE' ) || define ( 'YWGC_GIFT_CARD_PRODUCT_TYPE', 'gift-card' );
defined ( 'YWGC_GIFT_CARD_LAST_VIEWED_ID' ) || define ( 'YWGC_GIFT_CARD_LAST_VIEWED_ID', 'ywgc_last_viewed' );
defined ( 'YWGC_AMOUNTS' ) || define ( 'YWGC_AMOUNTS', '_gift_card_amounts' );
defined ( 'YWGC_PRODUCT_PLACEHOLDER' ) || define ( 'YWGC_PRODUCT_PLACEHOLDER', '_ywgc_placeholder' );
defined ( 'YWGC_MANUAL_AMOUNT_MODE' ) || define ( 'YWGC_MANUAL_AMOUNT_MODE', '_ywgc_manual_amount_mode' );
defined ( 'YWGC_PHYSICAL_GIFT_CARD' ) || define ( 'YWGC_PHYSICAL_GIFT_CARD', '_ywgc_physical_gift_card' );
defined ( 'YWGC_ACTION_RETRY_SENDING' ) || define ( 'YWGC_ACTION_RETRY_SENDING', 'retry-sending' );

/*  gift card post_metas */
defined ( 'YWGC_META_GIFT_CARD_AMOUNT' ) || define ( 'YWGC_META_GIFT_CARD_AMOUNT', '_ywgc_amount' );
defined ( 'YWGC_META_GIFT_CARD_AMOUNT_TAX' ) || define ( 'YWGC_META_GIFT_CARD_AMOUNT_TAX', '_ywgc_amount_tax' );
defined ( 'YWGC_META_GIFT_CARD_AMOUNT_BALANCE' ) || define ( 'YWGC_META_GIFT_CARD_AMOUNT_BALANCE', '_ywgc_amount_balance' );
defined ( 'YWGC_META_GIFT_CARD_AMOUNT_BALANCE_TAX' ) || define ( 'YWGC_META_GIFT_CARD_AMOUNT_BALANCE_TAX', '_ywgc_amount_balance_tax' );
defined ( 'YWGC_META_GIFT_CARD_SENT' ) || define ( 'YWGC_META_GIFT_CARD_SENT', '_ywgc_email_sent' );
defined ( 'YWGC_META_GIFT_CARD_ORDER_ID' ) || define ( 'YWGC_META_GIFT_CARD_ORDER_ID', '_ywgc_order_id' );
defined ( 'YWGC_META_GIFT_CARD_ORDERS' ) || define ( 'YWGC_META_GIFT_CARD_ORDERS', '_ywgc_orders' );
defined ( 'YWGC_ORDER_ITEM_DATA' ) || define ( 'YWGC_ORDER_ITEM_DATA', '_ywgc_order_item_data' );

/*  order item metas    */
defined ( 'YWGC_META_GIFT_CARD_USER_DATA' ) || define ( 'YWGC_META_GIFT_CARD_USER_DATA', '_ywgc_gift_card_user_data' );
defined ( 'YWGC_META_GIFT_CARD_POST_ID' ) || define ( 'YWGC_META_GIFT_CARD_POST_ID', '_ywgc_gift_card_post_id' );
defined ( 'YWGC_META_GIFT_CARD_DELIVERY_DATE' ) || define ( 'YWGC_META_GIFT_CARD_DELIVERY_DATE', '_ywgc_gift_card_delivery_date' );

//region Gift card table columns
defined ( 'YWGC_TABLE_COLUMN_ORDER' ) || define ( 'YWGC_TABLE_COLUMN_ORDER', 'purchase_order' );
defined ( 'YWGC_TABLE_COLUMN_INFORMATION' ) || define ( 'YWGC_TABLE_COLUMN_INFORMATION', 'information' );
defined ( 'YWGC_TABLE_COLUMN_AMOUNT' ) || define ( 'YWGC_TABLE_COLUMN_AMOUNT', 'amount' );
defined ( 'YWGC_TABLE_COLUMN_BALANCE' ) || define ( 'YWGC_TABLE_COLUMN_BALANCE', 'balance' );
defined ( 'YWGC_TABLE_COLUMN_DEST_ORDERS' ) || define ( 'YWGC_TABLE_COLUMN_DEST_ORDERS', 'dest_orders' );
defined ( 'YWGC_TABLE_COLUMN_DEST_ORDERS_TOTAL' ) || define ( 'YWGC_TABLE_COLUMN_DEST_ORDERS_TOTAL', 'dest_order_total' );
//endregion

if ( ! function_exists ( 'ywgc_required' ) ) {
    /**
     * Give the "required" attribute, if in use
     *
     * @param           $value
     * @param bool|true $compare
     * @param bool|true $echo
     *
     * @return string
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywgc_required ( $value, $compare = true, $echo = true ) {
        $required = ( $value === $compare ) || ( $value instanceof $compare );
        $result   = $required ? "required" : '';
        if ( $echo ) {
            echo $result;
        } else {
            return $result;
        }
    }
}

if ( ! function_exists ( 'ywgc_can_create_gift_card' ) ) {
    /**
     * Verify if current user can create product of type gift card
     */
    function ywgc_can_create_gift_card () {
        return apply_filters ( 'ywgc_can_create_gift_card', true );
    }
}