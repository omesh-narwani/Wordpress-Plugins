<?php
if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}


if ( ! class_exists ( 'YITH_WooCommerce_Gift_Cards_Backend_Premium' ) ) {

    /**
     *
     * @class   YITH_WooCommerce_Gift_Cards_Backend_Premium
     * @package Yithemes
     * @since   1.0.0
     * @author  Your Inspiration Themes
     */
    class YITH_WooCommerce_Gift_Cards_Backend_Premium extends YITH_WooCommerce_Gift_Cards_Backend {
        /**
         * Single instance of the class
         *
         * @since 1.0.0
         */
        protected static $instance;

        /**
         * Returns single instance of the class
         *
         * @since 1.0.0
         */
        public static function get_instance () {
            if ( is_null ( self::$instance ) ) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0
         * @author Lorenzo Giuffrida
         */
        protected function __construct () {

            parent::__construct ();

            // Add to admin_init function
            add_filter ( 'manage_edit-gift_card_columns', array ( $this, 'add_custom_columns_title' ) );

            // Add to admin_init function
            add_action ( 'manage_gift_card_posts_custom_column', array (
                $this,
                'add_custom_columns_content',
            ), 10, 2 );

            add_action ( 'woocommerce_before_order_itemmeta', array ( $this, 'woocommerce_before_order_itemmeta' ), 10, 3 );


            //region Email
            /**
             * Add an email action for sending the digital gift card
             */
            add_filter ( 'woocommerce_email_actions', array ( $this, 'add_gift_cards_trigger_action' ) );

            /**
             * Locate the plugin email templates
             */
            add_filter ( 'woocommerce_locate_core_template', array ( $this, 'locate_core_template' ), 10, 3 );

            /**
             * Add the email used to send digital gift card to woocommerce email tab
             */
            add_filter ( 'woocommerce_email_classes', array ( $this, 'add_woocommerce_email_classes' ) );

            //endregion

            add_action ( 'ywgc_start_gift_cards_sending', array ( $this, 'send_delayed_gift_cards' ) );

            /**
             * Set the class rate and class tax as visible for product of  type "gift cards"
             */
            add_action ( 'woocommerce_product_options_general_product_data', array ( $this, 'show_tax_class_for_gift_cards' ) );

            add_action ( 'init', array ( $this, 'redirect_gift_cards_link' ) );
        }

        /**
         * send the gift card code email
         *
         * @param int $gift_card_id the gift card id
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function send_gift_card_email ( $gift_card_id ) {
            $gift_card = new YWGC_Gift_Card_Premium( $gift_card_id );

            if ( ! $gift_card->ID ) {
                //  it isn't a gift card
                return;
            }

            if ( ! $gift_card->is_virtual () || empty( $gift_card->recipient ) ) {
                // not a digital gift card or missing recipient
                return;
            }

            include ( 'emails/class.ywgc-email-send-gift-card.php' );
            do_action ( 'ywgc-email-send-gift-card_notification', $gift_card );
        }

        /**
         * Make some redirect based on the current action being performed
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function  redirect_gift_cards_link () {

            /*
             * Check if the user ask for retrying sending the gift card email that are not shipped yet
             */

            if ( isset( $_GET[ YWGC_ACTION_RETRY_SENDING ] ) ) {
                $post_id = $_GET[ 'id' ];
                $this->send_gift_card_email ( $post_id );

                wp_redirect ( esc_url ( remove_query_arg ( array ( YWGC_ACTION_RETRY_SENDING, 'id' ) ) ) );
                die();
            }

            if ( ! isset( $_GET[ "post_type" ] ) || ! isset( $_GET[ "s" ] ) ) {
                return;
            }

            if ( 'shop_coupon' != ( $_GET[ "post_type" ] ) ) {
                return;
            }

            if ( preg_match ( "/(\w{4}-\w{4}-\w{4}-\w{4})(.*)/i", $_GET[ "s" ], $matches ) ) {
                wp_redirect ( admin_url ( 'edit.php?s=' . $matches[ 1 ] . '&post_type=gift_card' ) );
                die();
            }
        }

        public function show_tax_class_for_gift_cards () {
            ?>
            <script>
                jQuery("select#_tax_status").closest("div.options_group").addClass("show_if_gift-card");


            </script>
            <?php
        }

        /**
         * Locate the plugin email templates
         *
         * @param $core_file
         * @param $template
         * @param $template_base
         *
         * @return string
         */
        public function locate_core_template ( $core_file, $template, $template_base ) {
            $custom_template = array (
                'emails/send-gift-card.php',
                'emails/plain/send-gift-card.php',
                'emails/notify-customer.php',
                'emails/plain/notify-customer.php',
            );

            if ( in_array ( $template, $custom_template ) ) {
                $core_file = YITH_YWGC_TEMPLATES_DIR . '/' . $template;
            }

            return $core_file;
        }

        /**
         * Add an email action for sending the digital gift card
         *
         * @param $actions array list of current actions
         *
         * @return array
         */
        function add_gift_cards_trigger_action ( $actions ) {
            //  Add trigger action for sending digital gift card
            $actions[] = 'ywgc-email-send-gift-card';
            $actions[] = 'ywgc-email-notify-customer';

            return $actions;
        }

        /**
         * Add the email used to send digital gift card to woocommerce email tab
         *
         * @param $email_classes current email classes
         *
         * @return mixed
         */
        public function add_woocommerce_email_classes ( $email_classes ) {
            // add the email class to the list of email classes that WooCommerce loads
            $email_classes[ 'ywgc-email-send-gift-card' ]  = include ( 'emails/class.ywgc-email-send-gift-card.php' );
            $email_classes[ 'ywgc-email-notify-customer' ] = include ( 'emails/class.ywgc-email-notify-customer.php' );

            return $email_classes;
        }

        /**
         * Show the gift card code under the order item, in the order admin page
         *
         * @param int        $item_id
         * @param array      $item
         * @param WC_product $_product
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function woocommerce_before_order_itemmeta ( $item_id, $item, $_product ) {
            $gift_ids = wc_get_order_item_meta ( $item_id, YWGC_META_GIFT_CARD_POST_ID );
            if ( is_numeric ( $gift_ids ) ) {
                $gift_ids = array ( $gift_ids );
            }

            if ( $gift_ids ) {
                foreach ( $gift_ids as $gift_id ) {
                    $code = get_the_title ( $gift_id );
                    ?>
                    <div>
                    <span
                        class="ywgc-gift-code-label"><?php _e ( "Gift card code: ", 'yith-woocommerce-gift-cards' ); ?></span>
                        <a href="<?php echo admin_url ( 'edit.php?s=' . $code . '&post_type=gift_card&mode=list' ); ?>"
                           class="ywgc-gift-card-code"><?php echo $code; ?></a>
                    </div>
                    <?php
                }
            }
        }

        /**
         * Add custom columns to custom post type table
         *
         * @param array $defaults current columns
         *
         * @return array new columns
         */
        function add_custom_columns_title ( $defaults ) {
            $columns = array_slice ( $defaults, 0, 2 );

            $columns[ YWGC_TABLE_COLUMN_ORDER ]             = __ ( "Order", 'yith-woocommerce-gift-cards' );
            $columns[ YWGC_TABLE_COLUMN_AMOUNT ]            = __ ( "Amount", 'yith-woocommerce-gift-cards' );
            $columns[ YWGC_TABLE_COLUMN_BALANCE ]           = __ ( "Balance", 'yith-woocommerce-gift-cards' );
            $columns[ YWGC_TABLE_COLUMN_DEST_ORDERS ]       = __ ( "Orders", 'yith-woocommerce-gift-cards' );
            $columns[ YWGC_TABLE_COLUMN_DEST_ORDERS_TOTAL ] = __ ( "Order total", 'yith-woocommerce-gift-cards' );
            $columns[ YWGC_TABLE_COLUMN_INFORMATION ]       = __ ( "Information", 'yith-woocommerce-gift-cards' );

            return array_merge ( $columns, array_slice ( $defaults, 1 ) );
        }

        /**
         * @param WC_Order|int $order
         *
         * @return int
         */
        private function get_order_number_and_details ( $order ) {

            if ( empty( $order ) ) {
                return "";
            }

            if ( is_numeric ( $order ) ) {
                $the_order = wc_get_order ( $order );
                $order_id  = $order;
            } else {
                $the_order = $order;
                $order_id  = $order->id;
            }

            if ( $the_order->user_id ) {
                $user_info = get_userdata ( $the_order->user_id );
            }

            if ( ! empty( $user_info ) ) {
                $username = '<a href="user-edit.php?user_id=' . absint ( $user_info->ID ) . '">';

                if ( $user_info->first_name || $user_info->last_name ) {
                    $username .= esc_html ( ucfirst ( $user_info->first_name ) . ' ' . ucfirst ( $user_info->last_name ) );
                } else {
                    $username .= esc_html ( ucfirst ( $user_info->display_name ) );
                }

                $username .= '</a>';

            } else {

                if ( $the_order->billing_first_name || $the_order->billing_last_name ) {
                    $username = trim ( $the_order->billing_first_name . ' ' . $the_order->billing_last_name );
                } else {
                    $username = __ ( 'Guest', 'yith-woocommerce-gift-cards' );
                }
            }

            return sprintf ( _x ( '%s by %s', 'Order number by X', 'yith-woocommerce-gift-cards' ),
                '<a href="' . admin_url ( 'post.php?post=' . absint ( $order_id ) . '&action=edit' ) . '" class="row-title"><strong>#' .
                esc_attr ( $the_order->get_order_number () ) . '</strong></a>',
                $username );
        }

        /**
         * show content for custom columns
         *
         * @param $column_name string column shown
         * @param $post_ID     int     post to use
         */
        function add_custom_columns_content ( $column_name, $post_ID ) {
            switch ( $column_name ) {
                case YWGC_TABLE_COLUMN_ORDER :
                    $order_id = get_post_meta ( $post_ID, YWGC_META_GIFT_CARD_ORDER_ID, true );
                    echo $this->get_order_number_and_details ( $order_id );

                    break;

                case YWGC_TABLE_COLUMN_AMOUNT :
                    $_amount = get_post_meta ( $post_ID, YWGC_META_GIFT_CARD_AMOUNT, true );
                    $_amount = empty( $_amount ) ? 0.00 : $_amount;

                    $_amount_tax = get_post_meta ( $post_ID, YWGC_META_GIFT_CARD_AMOUNT_TAX, true );
                    $_amount_tax = empty( $_amount_tax ) ? 0.00 : $_amount_tax;

                    echo wc_price ( $_amount + $_amount_tax );
                    break;

                case YWGC_TABLE_COLUMN_BALANCE:
                    $_amount = get_post_meta ( $post_ID, YWGC_META_GIFT_CARD_AMOUNT_BALANCE, true );
                    $_amount = empty( $_amount ) ? 0.00 : $_amount;

                    $_amount_tax = get_post_meta ( $post_ID, YWGC_META_GIFT_CARD_AMOUNT_BALANCE_TAX, true );
                    $_amount_tax = empty( $_amount_tax ) ? 0.00 : $_amount_tax;

                    echo wc_price ( $_amount + $_amount_tax );
                    break;

                case YWGC_TABLE_COLUMN_DEST_ORDERS:
                    $orders = get_post_meta ( $post_ID, YWGC_META_GIFT_CARD_ORDERS, true );
                    if ( $orders ) {
                        foreach ( $orders as $order_id ) {
                            echo $this->get_order_number_and_details ( $order_id );
                            echo "<br>";
                        }
                    } else {
                        _e ( "The code has not been used yet", 'yith-woocommerce-gift-cards' );
                    }

                    break;

                case YWGC_TABLE_COLUMN_INFORMATION:
                    $content   = get_post_meta ( $post_ID, YWGC_META_GIFT_CARD_USER_DATA, true );
                    $recipient = isset( $content[ "recipient" ] ) ? $content[ "recipient" ] : '';

                    if ( empty( $recipient ) ) {
                        ?>
                        <div>
                            <span><?php echo __ ( "Physical product", 'yith-woocommerce-gift-cards' ); ?></span>
                        </div>
                        <?php
                    } else {

                        $status_class   = "";
                        $status_message = "";

                        $delivery_date = get_post_meta ( $post_ID, YWGC_META_GIFT_CARD_DELIVERY_DATE, true );
                        $email_date    = get_post_meta ( $post_ID, YWGC_META_GIFT_CARD_SENT, true );
                        $retry_link    = '';

                        if ( $email_date ) {
                            $status_class   = "sent";
                            $status_message = sprintf ( __ ( "Sent on %s", 'yith-woocommerce-gift-cards' ), $email_date );
                        } else if ( $delivery_date >= current_time ( 'Y-m-d' ) ) {
                            $status_class   = "scheduled";
                            $status_message = __ ( "Scheduled", 'yith-woocommerce-gift-cards' );
                        } else {
                            $status_class   = "failed";
                            $status_message = __ ( "Failed", 'yith-woocommerce-gift-cards' );
                        }

                        $retry_link = sprintf ( '<br><a class="ywgc-delivery-status retry-sending" href="%s" title="%s">%s</a>',
                            esc_url ( add_query_arg ( array ( YWGC_ACTION_RETRY_SENDING => 1, 'id' => $post_ID ) ) ),
                            __ ( "Send now", 'yith-woocommerce-gift-cards' ),
                            __ ( "Send now", 'yith-woocommerce-gift-cards' ) );

                        ?>

                        <div>
                            <span><?php echo sprintf ( __ ( "Recipient: %s", 'yith-woocommerce-gift-cards' ), $recipient ); ?></span>
                        </div>
                        <div>
                            <span><?php echo sprintf ( __ ( "Delivery date: %s", 'yith-woocommerce-gift-cards' ), $delivery_date ); ?></span>
                            <br>
                            <span
                                class="ywgc-delivery-status <?php echo $status_class; ?>"><?php echo $status_message; ?></span>
                            <?php echo $retry_link; ?>

                        </div>
                        <?php
                    }

                    break;

                case YWGC_TABLE_COLUMN_DEST_ORDERS_TOTAL:
                    $orders = get_post_meta ( $post_ID, YWGC_META_GIFT_CARD_ORDERS, true );
                    $total  = 0.00;

                    if ( $orders ) {
                        foreach ( $orders as $order_id ) {

                            $the_order   = wc_get_order ( $order_id );
                            $order_total = floatval ( preg_replace ( '#[^\d.]#', '', $the_order->get_subtotal_to_display () ) );
                            $total += $order_total;
                        }
                    }
                    echo wc_price ( $total );

                    $_amount = get_post_meta ( $post_ID, YWGC_META_GIFT_CARD_AMOUNT, true );
                    $_amount = empty( $_amount ) ? 0.00 : $_amount;

                    if ( $_amount && ( $total > $_amount ) ) {
                        $percent = (float)( $total - $_amount ) / $_amount * 100;
                        echo '<br><span class="ywgc-percent">' . sprintf ( __ ( '(+ %.2f%%)', 'yith-woocommerce-gift-cards' ), $percent ) . '</span>';
                    }

                    break;
                /*
                default:
                do_action("ywgc_gift_card_table_column_content", $column_name, $post_ID);
                */
            }
        }

        /**
         * Send the digital gift cards that should be received on specific date.
         *
         * @param null $send_date
         */
        public function send_delayed_gift_cards ( $send_date = null ) {
            if ( ! class_exists ( "YWGC_Email_Send_Gift_Card" ) ) {
                include ( 'emails/class.ywgc-email-send-gift-card.php' );
            }

            if ( null == $send_date ) {
                $send_date = current_time ( 'Y-m-d', 0 );
            }

            // retrieve gift card to be sent for specific date
            $gift_cards_ids = $this->main->get_postdated_gift_cards ( $send_date );

            foreach ( $gift_cards_ids as $gift_card_id ) {
                // send digital single gift card to recipient
                $gift_card = new YWGC_Gift_Card_Premium( $gift_card_id );

                if ( ! $gift_card->is_virtual () || empty( $gift_card->recipient ) ) {
                    // not a digital gift card or missing recipient
                    continue;
                }

                if ( $gift_card->has_been_sent () ) {
                    //  avoid sending emails more than one time
                    continue;
                }

                do_action ( 'ywgc-email-send-gift-card_notification', $gift_card );
            }
        }

        /**
         * Start the scheduling that let gift cards to be sent on expected date
         */
        public static function start_gift_cards_scheduling () {
            wp_schedule_event ( time (), 'daily', 'ywgc_start_gift_cards_sending' );
        }

        /**
         * Stop the scheduling that let gift cards to be sent on expected date
         */
        public static function end_gift_cards_scheduling () {
            wp_clear_scheduled_hook ( 'ywgc_start_gift_cards_sending' );
        }
    }
}