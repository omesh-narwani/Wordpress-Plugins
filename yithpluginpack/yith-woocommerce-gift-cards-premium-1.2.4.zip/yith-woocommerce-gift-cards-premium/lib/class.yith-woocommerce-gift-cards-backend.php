<?php
if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}


if ( ! class_exists ( 'YITH_WooCommerce_Gift_Cards_Backend' ) ) {

    /**
     *
     * @class   YITH_WooCommerce_Gift_Cards_Backend
     * @package Yithemes
     * @since   1.0.0
     * @author  Your Inspiration Themes
     */
    class YITH_WooCommerce_Gift_Cards_Backend {
        /** @var YITH_WooCommerce_Gift_Cards|YITH_WooCommerce_Gift_Cards_Premium main */
        public $main;

        /**
         * Single instance of the class
         *
         * @since 1.0.0
         */
        protected static $instance;

        /**
         * Returns single instance of the class
         *
         * @since 1.0.0
         */
        public static function get_instance () {
            if ( is_null ( self::$instance ) ) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0
         * @author Lorenzo Giuffrida
         */
        protected function __construct () {

            /**
             * Remove unwanted WordPress submenu item
             */
            add_action ( 'admin_menu', array ( $this, 'remove_unwanted_custom_post_type_features' ), 5 );

            /**
             * show a bubble with the number of new gift cards from the last visit
             */
            add_action ( 'admin_menu', array ( $this, 'show_number_of_new_gift_cards' ), 99 );

            /**
             * Enqueue scripts and styles
             */
            add_action ( 'admin_enqueue_scripts', array ( $this, 'enqueue_backend_files' ) );

            /**
             * Add the "Gift card" type to product type list
             */
            add_filter ( 'product_type_selector', array ( $this, 'add_gift_card_product_type' ) );

            /**
             * * Save gift card data when a product of type "gift card" is saved
             */
            add_action ( 'save_post', array ( $this, 'save_gift_card' ), 1, 2 );

            /**
             * Ajax call for adding and removing gift card amounts on product edit page
             */
            add_action ( 'wp_ajax_add_gift_card_amount', array ( $this, 'add_gift_card_amount_callback' ) );
            add_action ( 'wp_ajax_remove_gift_card_amount', array ( $this, 'remove_gift_card_amount_callback' ) );

            /**
             * Hide some item meta from product edit page
             */
            add_filter ( 'woocommerce_hidden_order_itemmeta', array ( $this, 'hide_item_meta' ) );

            /**
             * Append gift card amount generation controls to general tab on product page
             */
            add_action ( 'woocommerce_product_options_sku', array ( $this, 'show_gift_card_product_content' ) );

            /**
             * Generate a valid card number for every gift card product in the order
             */
            add_action ( 'woocommerce_order_status_changed', array ( $this, 'order_status_changed' ), 10, 3 );

            /**
             * Check if a gift card discount code was used and deduct the amount from the gift card.
             */
            add_action ( 'woocommerce_order_add_coupon', array ( $this, 'deduct_amount_from_gift_card' ), 10, 5 );
        }

        /**
         * show a bubble with the number of new gift cards from the last visit
         */
        public function show_number_of_new_gift_cards () {
            global $menu;
            foreach ( $menu as $key => $value ) {
                if ( isset( $value[ 5 ] ) && ( $value[ 5 ] == 'menu-posts-' . YWGC_CUSTOM_POST_TYPE_NAME ) ) {
                    //  Add a bubble with the new gift card created since the last time
                    $last_viewed = get_option ( YWGC_GIFT_CARD_LAST_VIEWED_ID, 0 );
                    global $wpdb;
                    $new_ids = $wpdb->get_var ( $wpdb->prepare ( "SELECT count(id) FROM {$wpdb->prefix}posts WHERE post_type = %s and ID > %d", YWGC_CUSTOM_POST_TYPE_NAME, $last_viewed ) );
                    $bubble  = "<span class='awaiting-mod count-{$new_ids}'><span class='pending-count'>{$new_ids}</span></span>";
                    $menu[ $key ][ 0 ] .= $bubble;

                    return;
                }
            }
        }

        /*
         * Remove features for the review custom post type
         */
        public function remove_unwanted_custom_post_type_features () {
            global $submenu;

            if ( isset( $submenu[ "edit.php?post_type=" . YWGC_CUSTOM_POST_TYPE_NAME ] ) ) {
                $gift_card_menu = $submenu[ 'edit.php?post_type=' . YWGC_CUSTOM_POST_TYPE_NAME ];

                foreach ( $gift_card_menu as $key => $value ) {
                    if ( $value[ 2 ] == 'post-new.php?post_type=' . YWGC_CUSTOM_POST_TYPE_NAME ) {
                        //  it's the add-new submenu item, we want to remove it
                        unset( $submenu[ "edit.php?post_type=" . YWGC_CUSTOM_POST_TYPE_NAME ][ $key ] );
                        break;
                    }
                }
            }
        }

        /**
         * Check if a gift card discount code was used and deduct the amount from the gift card.
         */
        public function deduct_amount_from_gift_card ( $order_id, $item_id, $code, $discount_amount, $discount_amount_tax = 0.00 ) {

            $gift = $this->main->get_gift_card_by_code ( $code );

            if ( $gift != null ) {
                $gift->deduct_amount ( $discount_amount, $discount_amount_tax );

                //  register the order in the list of orders where the gift card was used
                $orders   = get_post_meta ( $gift->ID, YWGC_META_GIFT_CARD_ORDERS, true );
                $orders[] = $order_id;
                update_post_meta ( $gift->ID, YWGC_META_GIFT_CARD_ORDERS, $orders );
            }
        }

        /**
         * Enqueue scripts on administration comment page
         *
         * @param $hook
         */
        function enqueue_backend_files ( $hook ) {
            global $post_type, $wp_version;

            if ( ( $screen = get_current_screen () ) && ( "edit-gift_card" == $screen->id ) ) {
                //  update last viewed gift card  id
                global $wpdb;
                $last_id = $wpdb->get_var ( $wpdb->prepare ( "SELECT max(id) FROM {$wpdb->prefix}posts WHERE post_type = %s", YWGC_CUSTOM_POST_TYPE_NAME ) );
                update_option ( YWGC_GIFT_CARD_LAST_VIEWED_ID, $last_id );
            }


            $suffix = defined ( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

            /**
             * Add styles
             */
            wp_enqueue_style ( 'ywgc-backend-css', YITH_YWGC_ASSETS_URL . '/css/ywgc-backend.css' );

            //  Hide some unused elements on the screen that should not be shown
            if ( YWGC_CUSTOM_POST_TYPE_NAME == $post_type ) {

                if ( version_compare ( $wp_version, '4.3-RC1', '>=' ) ) {
                    $rule = ".post-type-{$post_type} .wrap .page-title-action{ display: none; }";
                } else {
                    $rule = ".post-type-{$post_type} .add-new-h2{ display: none; }";
                }
                wp_add_inline_style ( 'ywgc-backend-css', $rule );
            }
            /**
             * Add scripts
             */
            wp_register_script ( "ywgc-backend", YITH_YWGC_URL . 'assets/js/ywgc-backend' . $suffix . '.js', array (
                'jquery',
                'jquery-blockui',
            ) );

            wp_localize_script ( 'ywgc-backend', 'ywgc', array (
                'loader'   => apply_filters ( 'yith_gift_cards_loader', YITH_YWGC_ASSETS_URL . '/images/loading.gif' ),
                'ajax_url' => admin_url ( 'admin-ajax.php' ),
            ) );

            wp_enqueue_script ( "ywgc-backend" );
        }

        /**
         * Add the "Gift card" type to product type list
         *
         * @param array $types current type array
         *
         * @return mixed
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function add_gift_card_product_type ( $types ) {
            if ( ywgc_can_create_gift_card () ) {
                $types[ YWGC_GIFT_CARD_PRODUCT_TYPE ] = __ ( "Gift card", 'yith-woocommerce-gift-cards' );
            }

            return $types;
        }

        public function save_gift_card_amounts ( $product_id, $amounts = array () ) {
            update_post_meta ( $product_id, YWGC_AMOUNTS, $amounts );
        }

        /**
         * Save gift card amount when a product is saved
         *
         * @param $post_id int
         * @param $post    object
         *
         * @return mixed
         */
        function save_gift_card ( $post_id, $post ) {
            $product = wc_get_product ( $post_id );

            if ( null == $product ) {
                return;
            }

            if ( ! isset( $_POST[ "product-type" ] ) || ( YWGC_GIFT_CARD_PRODUCT_TYPE != $_POST[ "product-type" ] ) ) {

                return;
            }

            // verify this is not an auto save routine.
            if ( defined ( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
                return;
            }

            $amounts = isset( $_POST[ "gift-card-amounts" ] ) ? $_POST[ "gift-card-amounts" ] : array ();

            /**
             * Update gift card amounts
             */
            $this->save_gift_card_amounts ( $post_id, $amounts );

            do_action ( 'yith_gift_cards_after_product_save', $post_id, $post, $product );
        }

        private function get_gift_card_product_amounts ( $product_id ) {
            $metas = get_post_meta ( $product_id, YWGC_AMOUNTS, true );

            return is_array ( $metas ) ? $metas : array ();
        }

        /**
         * Add a new amount to the available gift card amounts
         *
         * @param $product_id int   the gift card product id
         * @param $amount     int       the amount to add
         *
         * @return bool amount added, false if the same value still exists
         */
        public function add_amount_to_gift_card ( $product_id, $amount ) {
            $amounts = $this->get_gift_card_product_amounts ( $product_id );

            if ( ! in_array ( $amount, $amounts ) ) {

                $amounts[] = $amount;
                sort ( $amounts, SORT_NUMERIC );
                $this->save_gift_card_amounts ( $product_id, $amounts );

                return true;
            }

            return false;
        }

        /**
         * Remove an amount to a gift card
         *
         * @param $product_id int   the gift card product id
         * @param $amount     int       the amount to remove
         *
         * @return bool amount added, false if the same value still exists
         */
        public function remove_amount_to_gift_card ( $product_id, $amount ) {
            $amounts = $this->get_gift_card_product_amounts ( $product_id );

            if ( in_array ( $amount, $amounts ) ) {
                if ( ( $key = array_search ( $amount, $amounts ) ) !== false ) {
                    unset( $amounts[ $key ] );
                }


                $this->save_gift_card_amounts ( $product_id, $amounts );

                return true;
            }

            return false;
        }

        /**
         * Add a new amount to a gift card prdduct
         *
         * @since  1.0
         * @author Lorenzo Giuffrida
         */
        public function add_gift_card_amount_callback () {
            $amount = number_format ( $_POST[ 'amount' ], 2, wc_get_price_decimal_separator (), '' );

            $product_id = intval ( $_POST[ 'product_id' ] );

            $res = $this->add_amount_to_gift_card ( $product_id, $amount );

            wp_send_json ( array ( "code" => $res, "value" => $this->gift_card_amount_list_html ( $product_id ) ) );
        }

        /**
         * Retrieve the html content that shows the gift card amounts list
         *
         * @param $product_id int gift card product id
         *
         * @return string
         */
        private function gift_card_amount_list_html ( $product_id ) {
            ob_start ();
            $this->show_gift_card_amount_list ( $product_id );
            $html = ob_get_contents ();
            ob_end_clean ();

            return $html;
        }

        /**
         * Remove amount to a gift card prdduct
         *
         * @since  1.0
         * @author Lorenzo Giuffrida
         */
        public function remove_gift_card_amount_callback () {
            $amount     = number_format ( $_POST[ 'amount' ], 2, wc_get_price_decimal_separator (), '' );
            $product_id = intval ( $_POST[ 'product_id' ] );

            $res = $this->remove_amount_to_gift_card ( $product_id, $amount );

            wp_send_json ( array ( "code" => $res ) );
        }

        /**
         * Hide some item meta from order edit page
         */
        public function hide_item_meta ( $args ) {
            $args[] = YWGC_META_GIFT_CARD_POST_ID;

            return $args;
        }

        /**
         * Show controls on backend product page to let create the gift card price
         */
        public function show_gift_card_product_content () {
            if ( ! ywgc_can_create_gift_card () ) {
                return;
            }

            global $post, $thepostid;
            ?>
            <div class="show_if_gift-card">
                <p class="form-field">
                    <label><?php _e ( "Gift card amount", 'yith-woocommerce-gift-cards' ); ?></label>
                <span class="wrap add-new-amount-section">
                    <input type="text" id="gift_card-amount" name="gift_card-amount" class="short" style=""
                           placeholder="">
                    <a href="#" class="add-new-amount"><?php _e ( "Add", 'yith-woocommerce-gift-cards' ); ?></a>
                </span>
                </p>
                <?php
                $this->show_gift_card_amount_list ( $thepostid );
                apply_filters ( 'yith_gift_cards_after_amount_list', $thepostid );
                ?>
            </div>
            <?php
        }

        /**
         * Show the gift card amounts list
         *
         * @param $product_id int gift card product id
         */
        private function show_gift_card_amount_list ( $product_id ) {
            $amounts = $this->get_gift_card_product_amounts ( $product_id );
            apply_filters ( 'yith_gift_cards_before_amount_list', $product_id, $amounts );
            ?>

            <p class="form-field _gift_card_amount_field">
                <?php if ( $amounts ): ?>
                    <?php foreach ( $amounts as $amount ) : ?>
                        <span class="variation-amount"><?php echo wc_price ( $amount ); ?>
                            <input type="hidden" name="gift-card-amounts[]" value="<?php _e ( $amount ); ?>">
                        <a href="#" class="remove-amount"></a></span>
                    <?php endforeach; ?>
                <?php else: ?>
                    <span
                        class="no-amounts"><?php _e ( "You don't have configured any gift card yet", 'yith-woocommerce-gift-cards' ); ?></span>
                <?php endif; ?>
            </p>
            <?php
        }

        /**
         * When the order is completed, generate a card number for every gift card product
         *
         * @param $order      int|WC_Order the order which status is changing
         * @param $old_status string Current order status
         * @param $new_status string New order status
         *
         */
        public function order_status_changed ( $order, $old_status, $new_status ) {

            if ( "completed" != $new_status ) {
                return;
            }

            if ( is_numeric ( $order ) ) {
                $the_order = new WC_Order( $order );
            } else {
                $the_order = $order;
            }

            if ( apply_filters ( 'yith_gift_cards_generate_on_order_completed', true, $order ) ) {

                foreach ( $the_order->get_items ( 'line_item' ) as $order_item_id => $order_item_data ) {

                    $product_id = $order_item_data[ "product_id" ];
                    $product    = wc_get_product ( $product_id );

                    //  skip all item that belong to product other than the gift card type
                    if ( ! $this->main->is_gift_card_product ( $product ) ) {
                        continue;
                    }

                    //  Check if current product, of type gift card, hasn't a discount code associated to it
                    if ( $gift_ids = wc_get_order_item_meta ( $order_item_id, YWGC_META_GIFT_CARD_POST_ID ) ) {
                        return;
                    }

                    $meta_order_item_data = wc_get_order_item_meta ( $order_item_id, YWGC_ORDER_ITEM_DATA );

                    $is_postdated  = false;
                    $delivery_date = current_time ( 'Y-m-d', 0 );

                    //  Set a delivery date (today or the gift card delivery date)
                    if ( ! empty( $meta_order_item_data[ "postdated_delivery" ] ) ) {
                        if ( ! empty ( $meta_order_item_data[ "delivery_date" ] ) ) {
                            $delivery_date = $meta_order_item_data[ "delivery_date" ];
                            $is_postdated  = true;
                        }
                    }

                    $line_subtotal     = isset( $meta_order_item_data[ "line_subtotal" ] ) ? $meta_order_item_data[ "line_subtotal" ] : 0.00;
                    $line_subtotal_tax = 0.00;

                    //update this on next release
                    if ( $product->is_taxable () ) {

                        $tax_rates   = WC_Tax::get_base_tax_rates ( $product->tax_class );
                        $taxes       = WC_Tax::calc_tax ( $line_subtotal, $tax_rates, true );
                        $tax_amounts = WC_Tax::round ( array_sum ( $taxes ) );
                    }

                    $line_subtotal_tax = isset( $meta_order_item_data[ "line_subtotal_tax" ] ) ? $meta_order_item_data[ "line_subtotal_tax" ] : 0.00;

                    //  Generate as many gift card code as the quantity bought
                    $quantity = $order_item_data[ "qty" ];
                    $new_ids  = array ();

                    for ( $i = 0; $i < $quantity; $i ++ ) {
                        $single_amount = (float)( $line_subtotal / $quantity );
                        $single_tax    = (float)( $line_subtotal_tax / $quantity );

                        //  Generate a gift card post type and save it
                        $gift_card = $this->main->get_new_gift_card ( $single_amount, $single_tax, $product_id, $the_order->id );
                        $gift_card->generate_gift_card_code ();
                        $gift_card->save ();

                        //  Save the gift card id
                        $new_ids[] = $gift_card->ID;

                        //  Attach gift card user contents from order item meta to post meta
                        update_post_meta ( $gift_card->ID, YWGC_META_GIFT_CARD_USER_DATA, $meta_order_item_data );

                        //  set the delivery date...
                        update_post_meta ( $gift_card->ID, YWGC_META_GIFT_CARD_DELIVERY_DATE, $delivery_date );

                        //  ...and send it now if it's not postdated
                        if ( ! $is_postdated && $gift_card->is_virtual () ) {
                            do_action ( 'ywgc-email-send-gift-card_notification', $gift_card->ID );
                        }
                    }

                    // save gift card Post ids on order item
                    wc_update_order_item_meta ( $order_item_id, YWGC_META_GIFT_CARD_POST_ID, $new_ids );
                }

                //  Check if the customer notification is set...
                if ( $this->main->notify_customer ) {

                    foreach ( $the_order->get_used_coupons () as $coupon_code ) {
                        // if the code belong to a gift card, notify the customer

                        $gift_card = $this->main->get_gift_card_by_code ( $coupon_code );

                        if ( ( null != $gift_card ) && $gift_card->is_virtual () ) {
                            do_action ( 'ywgc-email-notify-customer_notification', $gift_card->ID );
                        }
                    }
                }
            }
        }
    }
}