<?php
if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}


if ( ! class_exists ( 'YITH_WooCommerce_Gift_Cards_Frontend_Premium' ) ) {

    /**
     *
     * @class   YITH_WooCommerce_Gift_Cards_Frontend_Premium
     * @package Yithemes
     * @since   1.0.0
     * @author  Your Inspiration Themes
     */
    class YITH_WooCommerce_Gift_Cards_Frontend_Premium extends YITH_WooCommerce_Gift_Cards_Frontend {
        /* @var YITH_WooCommerce_Gift_Cards_Premium main */
        public $main;

        /**
         * Single instance of the class
         *
         * @since 1.0.0
         */
        protected static $instance;

        /**
         * Returns single instance of the class
         *
         * @since 1.0.0
         */
        public static function get_instance () {
            if ( is_null ( self::$instance ) ) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0
         * @author Lorenzo Giuffrida
         */
        protected function __construct () {
            parent::__construct ();

            /**
             * Permit to enter free gift card amount
             */
            add_action ( 'yith_gift_cards_template_after_amounts', array ( $this, 'show_free_amount_area' ) );

            /**
             * Let the user to enter a free amount instead of choosing from the select
             */
            add_action ( 'yith_gift_cards_template_append_amount', array ( $this, 'add_manual_amount_item' ) );

            /**
             * Show a live preview of how the gift card will look like
             */
            add_action ( 'yith_gift_cards_template_after_gift_card_form', array ( $this, 'show_gift_card_generator' ), 1 );

            /**
             * Let the customer to use a product of type WC_Product_Simple  as source for a gift card
             */
            add_action ( 'woocommerce_after_add_to_cart_button', array ( $this, 'show_give_as_present_link_simple' ) );

            /**
             * Let the customer to use a product of type WC_Product_Variable  as source for a gift card
             */
            add_action ( 'woocommerce_single_variation', array ( $this, 'show_give_as_present_link_variable' ), 99 );

            /*
             * let the customer edit their gift card contentthe upload section
             */
            add_action ( 'woocommerce_order_item_meta_start', array (
                $this,
                'edit_gift_card',
            ), 10, 3 );

            //  Let the user to edit che gift card content
            add_action ( 'wp_ajax_edit_gift_card', array ( $this, 'edit_gift_card_callback' ) );
        }

        /**
         * Let the user to edit che gift card content
         */
        public function edit_gift_card_callback () {
            if ( ! $this->main->allow_modification ) {
                return;
            }

            $order_item_id = intval ( sanitize_text_field ( $_POST[ 'item_id' ] ) );
            $sender        = sanitize_email ( $_POST[ 'sender' ] );
            $recipient     = sanitize_email ( $_POST[ 'recipient' ] );
            $message       = implode ( "\n", array_map ( 'sanitize_text_field', explode ( "\n", $_POST[ 'message' ] ) ) );

            //  Retrieve the gift card content. If a valid gift card was generated, the content to be edited is a postmeta of the
            //  Gift card post type, else the content is still on the order_item_meta.
            $gift_card_id = wc_get_order_item_meta ( $order_item_id, YWGC_META_GIFT_CARD_POST_ID );

            if ( $gift_card_id ) {
                //  edit values from the gift card
                $gift_card = new YWGC_Gift_Card_Premium( $gift_card_id );

                //  Update gift card content
                $gift_card->sender    = $sender;
                $gift_card->recipient = $recipient;
                $gift_card->message   = $message;
                $gift_card->save ();

            } else {
                //  a gift card custom post type object doesn't exists, edit order item meta values
                $meta = wc_get_order_item_meta ( $order_item_id, YWGC_ORDER_ITEM_DATA );

                //edit order item meta
                $meta[ "sender" ]    = $sender;
                $meta[ "recipient" ] = $recipient;
                $meta[ "message" ]   = $message;

                wc_update_order_item_meta ( $order_item_id, YWGC_ORDER_ITEM_DATA, $meta );

                wp_send_json ( array (
                    "code"   => 1,
                    "values" => array (
                        "sender"    => $sender,
                        "recipient" => $recipient,
                        "message"   => $message,
                    ),
                ) );
            }

            wp_send_json ( array (
                "code" => - 1,
            ) );
        }

        /**
         * Let the user to edit the gift card
         *
         * @param $order_item_id
         * @param $item
         * @param $order
         */
        public function edit_gift_card ( $order_item_id, $item, $order ) {

            if ( ! $this->main->allow_modification ) {
                return;
            }

            //  Allow editing only on checkout or my orders pages
            if ( ! is_checkout () && ! is_account_page () ) {
                return;
            }

            $item_meta_array = $item[ "item_meta" ];
            //  Check if current order item is a gift card
            if ( ! isset( $item_meta_array[ YWGC_ORDER_ITEM_DATA ] ) ) {
                return;
            }

            //  Retrieve the gift card content. If a valid gift card was generated, the content to be edited is a postmeta of the
            //  Gift card post type, else the content is still on the order_item_meta.
            $gift_card_id = wc_get_order_item_meta ( $order_item_id, YWGC_META_GIFT_CARD_POST_ID );

            if ( $gift_card_id ) {
                //  edit values from the gift card
                $gift_card = new YWGC_Gift_Card_Premium( $gift_card_id );
            } else {
                //  a gift card custom post type object doesn't exists, edit order item meta values
                $order_item_meta = $item_meta_array[ YWGC_ORDER_ITEM_DATA ];
                $order_item_meta = $order_item_meta[ 0 ];
                $order_item_meta = maybe_unserialize ( $order_item_meta );

                $gift_card = new YWGC_Gift_Card_Premium( $order_item_meta );
            }

            //  There is nothing to edit for physical gift card product, only virtual gift cards
            //  can be edited
            if ( ! $gift_card->is_virtual () ) {
                return;
            }

            ?>

            <div id="current-gift-card-<?php echo $order_item_id; ?>" class="ywgc-gift-card-content">
                <div class="ywgc-gift-card-details ywgc-show">
                    <fieldset style="border: none">
                        <label><?php _e ( "Sender: ", 'yith-woocommerce-gift-cards' ); ?></label>
                        <span class=" ywgc-sender"><?php echo $gift_card->sender; ?></span>
                    </fieldset>

                    <fieldset style="border: none">
                        <label><?php _e ( "Recipient: ", 'yith-woocommerce-gift-cards' ); ?></label>
                        <span class=" ywgc-recipient"><?php echo $gift_card->recipient; ?></span>
                    </fieldset>

                    <fieldset style="border: none">
                        <label><?php _e ( "Message: ", 'yith-woocommerce-gift-cards' ); ?></label>
                        <span class=" ywgc-message"><?php echo $gift_card->message; ?></span>
                    </fieldset>
                    <button
                        class="ywgc-do-edit btn btn-ghost"
                        style="display: none;"><?php _e ( "Edit", 'yith-woocommerce-gift-cards' ); ?></button>
                </div>

                <div class="ywgc-gift-card-edit-details ywgc-hide" style="display: none">
                    <form name="form-gift-card-<?php echo $order_item_id; ?>">
                        <input type="hidden" name="gift-card-item-id" value="<?php echo $order_item_id; ?>">
                        <fieldset>
                            <label><?php _e ( "Sender: ", 'yith-woocommerce-gift-cards' ); ?></label>
                            <input type="text" name="gift-card-sender-name"
                                   value="<?php echo $gift_card->sender; ?>">
                        </fieldset>
                        <fieldset>
                            <label><?php _e ( "Recipient: ", 'yith-woocommerce-gift-cards' ); ?></label>
                            <input type="email" name="gift-card-recipient-email"
                                   value="<?php echo $gift_card->recipient; ?>"">
                        </fieldset>
                        <fieldset>
                            <label><?php _e ( "Message: ", 'yith-woocommerce-gift-cards' ); ?></label>
                        <textarea name="gift-card-message"
                                  rows="5"><?php echo $gift_card->message; ?></textarea>
                        </fieldset>
                    </form>

                    <button
                        class="ywgc-apply-edit btn apply"><?php _e ( "Apply", 'yith-woocommerce-gift-cards' ); ?></button>
                    <button
                        class="ywgc-cancel-edit btn btn-ghost"><?php _e ( "Cancel", 'yith-woocommerce-gift-cards' ); ?></button>
                </div>
            </div>
            <?php
        }

        /**
         * Let the customer to use a product of type WC_Product_Simple  as source for a gift card
         */
        public function show_give_as_present_link_simple () {
            if ( ! $this->main->allow_product_as_present ) {
                return;
            }

            global $product;
            if ( $product instanceof WC_Product_Simple ) {
                // Load the template
                wc_get_template ( 'single-product/add-to-cart/give-product-as-present.php',
                    '',
                    '',
                    trailingslashit ( YITH_YWGC_TEMPLATES_DIR ) );
            }
        }

        /**
         * Let the customer to use a product of type WC_Product_Variable  as source for a gift card
         */
        public function show_give_as_present_link_variable () {
            if ( ! $this->main->allow_product_as_present ) {
                return;
            }

            global $product;
            if ( $product instanceof WC_Product_Variable ) {
                // Load the template
                wc_get_template ( 'single-product/add-to-cart/give-product-as-present.php',
                    '',
                    '',
                    trailingslashit ( YITH_YWGC_TEMPLATES_DIR ) );
            }
        }

        /**
         * Let the user to enter a free amount instead of choosing from the select
         * */
        public function add_manual_amount_item () {
            global $product;

            //  Physical gift card product do not permit manual amounts
            if ( ! $product->is_virtual () ) {
                return;
            }

            //  Check if the current product permit free entered amount...
            if ( ! $this->main->is_manual_amount_allowed ( $product->id ) ) {
                return;
            }

            ?>
            <option value="-1"><?php _e ( "Add amount", 'yith-woocommerce-gift-cards' ); ?></option>
            <?php
        }


        /**
         * Show a live preview of how the gift card will look like
         */
        public function show_gift_card_generator () {
            global $product;

            if ( ( $product instanceof WC_Product_Gift_Card ) && ! $product->is_virtual () ) {
                return;
            }

            ?>
            <div class="gift-card-generator">
                <h3><?php _e ( "Your gift card", 'yith-woocommerce-gift-cards' ); ?></h3>

                <?php $this->main->preview_digital_gift_cards ( $product ); ?>
                <input type="hidden" name="recipient-required"
                       value="<?php ywgc_required ( $product, 'WC_Product_Gift_Card' ); ?>"/>

                <div class="gift-card-content-editor variations_button">
                    <div class="gift-card-content-editor step-appearance">
                        <h3><?php _e ( "1. Select the style of the gift card", 'yith-woocommerce-gift-cards' ); ?></h3>
                        <input type="button"
                               class="gift-card-default-picture-link"
                               value="<?php _e ( "Default image", 'yith-woocommerce-gift-cards' ); ?>"/>
                        <input type="button"
                               class="gift-card-customize-picture-link"
                               value="<?php _e ( "Customize", 'yith-woocommerce-gift-cards' ); ?>"/>
                        <input type="file" name="uploadFile" id="uploadFile" accept="image/*"/>
                    </div>

                    <div class="gift-card-content-editor step-content">
                        <h3><?php _e ( "2. Add the information for the gift card", 'yith-woocommerce-gift-cards' ); ?></h3>
                        <label
                            for="recipient-email"><?php _e ( "Recipient's email", 'yith-woocommerce-gift-cards' ); ?></label>

                        <div class="ywgc-single-recipient">
                            <input type="email"
                                   name="recipient-email[]" <?php ywgc_required ( $product, 'WC_Product_Gift_Card' ); ?>
                                   class="ywgc-recipient"/>
                            <a href="#" class="remove-recipient hide-if-alone">x</a>
                        </div>

                        <?php if ( $product instanceof WC_Product_Gift_Card ): ?>
                            <a href="#" class="add-recipient"
                               id="add_recipient"><?php _e ( "Add recipient", 'yith-woocommerce-gift-cards' ); ?></a>
                        <?php endif; ?>
                        <div class="ywgc-sender-name">
                            <label for="sender-name"><?php _e ( "Your name", 'yith-woocommerce-gift-cards' ); ?></label>
                            <input type="text" name="sender-name" id="sender-name">
                        </div>
                        <div class="ywgc-message">
                            <label
                                for="gift-card-message"><?php _e ( "Message", 'yith-woocommerce-gift-cards' ); ?></label>
                            <textarea id="gift-card-message" name="gift-card-message" rows="5"
                                      placeholder="<?php _e ( "Your message...", 'yith-woocommerce-gift-cards' ); ?>"></textarea>
                        </div>

                        <div class="ywgc-postdate">
                            <label
                                for="postdate-sending"><?php _e ( "Postpone delivery", 'yith-woocommerce-gift-cards' ); ?></label>
                            <input type="checkbox" id="postdate-sending" name="postdate-sending">
                            <input type="text" id="delivery-date" name="delivery-date" class="datepicker hidden">
                        </div>
                        <?php if ( ! ( $product instanceof WC_Product_Gift_Card ) ): ?>
                            <input type="hidden" name="product_as_present" value="1">
                        <?php endif; ?>
                    </div>

                    <button type="submit"
                            class="single_add_to_cart_button gift_card_add_to_cart_button button alt"><?php echo esc_html ( $product->single_add_to_cart_text () ); ?></button>
                    <?php if ( ! ( $product instanceof WC_Product_Gift_Card ) ): ?>
                        <button id="cancel-gift-card-creation"
                                class="button"><?php _e ( "Cancel", 'yith-woocommerce-gift-cards' ); ?></button>
                    <?php endif; ?>

                </div>
            </div>
            <?php
        }

        /**
         * Permit to enter free gift card amount
         */
        public function show_free_amount_area () {
            ?>
            <input id="manual-amount" name="manual-amount" class="manual-amount hidden" type="text"
                   placeholder="<?php _e ( "Add amount", 'yith-woocommerce-gift-cards' ); ?>">
            <?php
        }

        /**
         * Custom add_to_cart handler for gift card product type
         */
        public function add_to_cart_handler () {
            //  If it's a digital gift card, check the data submitted, else create a gift card without content
            if ( isset( $_POST[ "sender-name" ] ) ) {

                //  Digital gift card
                if ( empty( $_POST[ "sender-name" ] ) ) {
                    wc_add_notice ( __ ( 'You have to add the sender\'s name', 'yith-woocommerce-gift-cards' ), 'error' );

                    return false;
                }

                $recipient_list  = $_POST[ "recipient-email" ];
                $recipient_count = count ( $recipient_list );

                if ( ! $recipient_count ) {
                    wc_add_notice ( __ ( 'Add a valid email for the recipient', 'yith-woocommerce-gift-cards' ), 'error' );

                    return false;
                }

                if ( $recipient_count > 1 ) {
                    $quantity = $recipient_count;
                } else {
                    $quantity = isset( $_REQUEST[ 'quantity' ] ) ? intval ( $_REQUEST[ 'quantity' ] ) : 1;
                }

                $product_id = 0;
                $no_errors  = true;
                for ( $i = 0; $i < $quantity; $i ++ ) {

                    $gift_card = $this->main->create_gift_card_for_cart ();

                    //  Set the real recipient for the gift card
                    if ( $recipient_count > 1 ) {
                        $gift_card->recipient = sanitize_email ( $recipient_list[ $i ] );
                    } else {
                        $gift_card->recipient = sanitize_email ( $recipient_list[ 0 ] );
                    }

                    $product_id = $gift_card->product_id;
                    $product    = wc_get_product ( $product_id );

                    if ( $gift_card != null ) {
                        if ( false === WC ()->cart->add_to_cart ( $product_id, 1, 0, array (), (array)$gift_card ) ) {
                            $no_errors = false;
                            break;
                        }
                    }
                }

                if ( ! $product_id ) {
                    wc_add_notice ( __ ( 'An error occurred while adding the product to the cart.', 'yith-woocommerce-gift-cards' ), 'error' );

                    return false;
                }

                if ( $no_errors ) {
                    wc_add_to_cart_message ( $product_id );
                }
            } else {
                //  Physical gift card
                $product_id = absint ( $_POST[ 'add-to-cart' ] );
                $product    = wc_get_product ( $product_id );
                if ( $product ) {

                    $quantity = isset( $_REQUEST[ 'quantity' ] ) ? intval ( $_REQUEST[ 'quantity' ] ) : 1;
                    if ( ! isset( $_POST[ 'gift_amounts' ] ) ) {
                        return false;
                    }

                    $amount    = $_POST[ 'gift_amounts' ];
                    $no_errors = true;

                    $gift_card = $this->main->get_new_gift_card ( $amount, 0, $product_id );

                    if ( $gift_card != null ) {
                        if ( false === WC ()->cart->add_to_cart ( $product_id, $quantity, 0, array (), (array)$gift_card ) ) {
                            $no_errors = false;
                        }
                    }

                    if ( ! $product_id ) {

                        wc_add_notice ( __ ( 'An error occurred while adding the product to the cart.', 'yith-woocommerce-gift-cards' ), 'error' );

                        return false;
                    }

                    if ( $no_errors ) {
                        wc_add_to_cart_message ( $product_id );
                    }
                }
            }

            // If we added the product to the cart we can now optionally do a redirect.
            if ( wc_notice_count ( 'error' ) === 0 ) {

                $url = '';
                // If has custom URL redirect there
                if ( $url = apply_filters ( 'woocommerce_add_to_cart_redirect', $url ) ) {
                    wp_safe_redirect ( $url );
                    exit;
                } elseif ( get_option ( 'woocommerce_cart_redirect_after_add' ) === 'yes' ) {
                    if ( function_exists ( 'wc_get_cart_url' ) ) {
                        wp_safe_redirect ( wc_get_cart_url () );
                    } else {
                        wp_safe_redirect ( WC ()->cart->get_cart_url () );
                    }
                    exit;
                }
            }
        }

        public function show_gift_cards_amount_dropdown ( $product ) {
            $selected = isset( $_REQUEST[ 'gift_amounts' ] ) ? wc_clean ( $_REQUEST[ 'gift_amounts' ] ) : '';
            ?>
            <select id="gift_amounts" name="gift_amounts">
                <option value=""><?php _e ( "Choose an amount", 'yith-woocommerce-gift-cards' ); ?></option>

                <?php foreach ( $product->get_amounts_to_be_shown () as $value => $price ) : ?>

                    <option
                        value="<?php echo $value; ?>" <?php echo selected ( $price, $value, false ); ?>><?php echo wc_price ( $price ); ?></option>
                <?php endforeach; ?>

                <?php do_action ( 'yith_gift_cards_template_append_amount' ); ?>

            </select>
            <?php
            do_action ( 'yith_gift_cards_template_after_amounts' );
        }
    }
}