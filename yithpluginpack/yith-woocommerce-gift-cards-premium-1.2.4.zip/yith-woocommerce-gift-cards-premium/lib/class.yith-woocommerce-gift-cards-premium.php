<?php
if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}


if ( ! class_exists ( 'YITH_WooCommerce_Gift_Cards_Premium' ) ) {

    /**
     *
     * @class   YITH_WooCommerce_Gift_Cards_Premium
     * @package Yithemes
     * @since   1.0.0
     * @author  Your Inspiration Themes
     */
    class YITH_WooCommerce_Gift_Cards_Premium extends YITH_WooCommerce_Gift_Cards {
        /**
         * @var int The default product of type gift card
         */
        public $default_gift_card = - 1;

        /**
         * @var bool Let the user to enter manually the amount of the gift card
         */
        public $allow_manual_amount = false;

        /**
         * @var bool allow the customer to choose a product from the shop to be used as a present for the gift card
         */
        public $allow_product_as_present = false;

        /**
         * @var bool allow the customer to edit the content of a gift card
         */
        public $allow_modification = false;

        /**
         * @var bool notify the customer when a gift card he bought is used
         */
        public $notify_customer = false;

        /**
         * @var string the shop name
         */
        public $shop_name;

        /**
         * @var int limit the maximum size of custom image uploaded by the customer
         */
        public $custom_image_max_size;

        /**
         * @var string  the logo to be used on the gift card
         */
        public $shop_logo_url;

        /**
         * @var string the image url used as gift card header
         */
        public $gift_card_header_url;

        /**
         * @var bool set if the admin should receive the email containing the gift card code in BCC
         */
        public $blind_carbon_copy;
        /**
         * Single instance of the class
         *
         * @since 1.0.0
         */
        protected static $instance;

        /**
         * Returns single instance of the class
         *
         * @since 1.0.0
         */
        public static function get_instance () {
            if ( is_null ( self::$instance ) ) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0
         * @author Lorenzo Giuffrida
         */
        protected function __construct () {
            parent::__construct ();

            if ( ! class_exists ( 'Emogrifier' ) ) {

                $path = WC ()->plugin_path () . '/includes/libraries/class-emogrifier.php';
                require_once ( WC ()->plugin_path () . '/includes/libraries/class-emogrifier.php' );
            }

            /**
             * Show checkbox enabling the product to avoid use of free amount
             */
            add_filter ( 'yith_gift_cards_after_amount_list', array ( $this, 'show_manual_amount_section' ) );

            /*
             * Save additional product attribute when a gift card product is saved
             */
            add_action ( 'yith_gift_cards_after_product_save', array ( $this, 'save_gift_card_product' ), 10, 3 );

            /*
             * Customize a gift card with data entered by the customer on product page
             */
            add_filter ( 'yith_gift_cards_before_add_to_cart', array ( $this, 'customize_card_before_add_to_cart' ) );

            /**
             * Permit gift card to be purchasable even without price
             */
            add_filter ( 'woocommerce_is_purchasable', array ( $this, 'gift_card_is_purchasable' ), 10, 2 );

            /**
             * Add an option to let the admin set the gift card as a physical good or digital goods
             */
            add_filter ( 'product_type_options', array ( $this, 'add_type_option' ) );

            /**
             * Add CSS style to gift card emails header
             */
            add_action ( 'woocommerce_email_header', array ( $this, 'include_css_for_emails' ), 10, 2 );

            /**
             * Add the customer product suggestion is there is one
             */
            add_action ( 'ywgc_gift_card_email_after_preview', array ( $this, 'add_product_recommended' ) );

            /**
             * When the default gift card image is changed from the plugin setting, update the product image
             * of the default gift card
             */
            add_action ( 'yit_panel_wc_after_update', array ( $this, 'update_default_gift_card' ) );

            /**
             * Add plugin compatibility with YITH WooCommerce Multi Vendor
             */
            add_filter ( 'ywgc_can_create_gift_card', array ( $this, 'user_can_create_gift_cards' ) );

            /**
             * Show an introductory text before the gift cards editor
             */
            add_action ( 'ywgc_gift_cards_email_before_preview', array ( $this, 'show_introductory_text' ), 10, 2 );

            /**
             * Append CSS for the email being sent to the customer
             */
            add_action ( 'yith_gift_cards_template_before_add_to_cart_form', array ( $this, 'append_css_files' ) );

            /**
             * Add information to the email footer
             */
            add_action ( 'woocommerce_email_footer', array ( $this, 'add_footer_information' ) );

            /**
             * Add the admin email as recipient in BCC for every gift card code sent
             */
            add_filter ( 'ywgc_gift_card_code_email_bcc', array ( $this, 'add_admin_to_email_bcc' ) );

            add_filter ( 'woocommerce_resend_order_emails_available', array ( $this, 'resend_gift_card_code' ) );

            /**
             * YITH WooCommerce Dynamic Pricing and Discount Premium compatibility.
             * Single product template. Manage the price exclusion when used with the YITH WooCommerce Dynamic Pricing
             */
            add_filter ( 'ywdpd_get_price_exclusion', array ( $this, 'exclude_price_for_yith_dynamic_discount_product_page' ), 10, 3 );

            /**
             * YITH WooCommerce Dynamic Pricing and Discount Premium compatibility.
             * Cart template. Manage the price exclusion
             */
            add_filter ( 'ywdpd_replace_cart_item_price', array ( $this, 'set_price_for_yith_dynamic_discount_cart_page' ), 10, 4 );

            /**
             * YITH WooCommerce Dynamic Pricing and Discount Premium compatibility.
             * Show the table with pricing discount
             */
            add_filter ( 'ywdpd_show_price_on_table_pricing', array ( $this, 'show_price_on_table_pricing' ), 10, 3 );

            /**
             * YITH WooCommerce Points and Rewards Premium compatibility.
             * Set the points earned for a gift card product
             */
            add_filter ( 'ywpar_get_product_point_earned', array ( $this, 'set_points_rewards_earning' ), 10, 2 );
        }

        /**
         * Set the points earned while used within YITH Points and Rewards plugin.
         *
         * @param float      $points
         * @param WC_Product $product
         *
         * @return float
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function set_points_rewards_earning ( $points, $product ) {

            //  Gift card products are not eligible for earning points!

            if ( YWGC_GIFT_CARD_PRODUCT_TYPE == $product->product_type ) {
                return 0.00;
            }

            return $points;
        }

        /**
         * Show discounted price in the YITH WooCommerce Dynamic Pricing table
         *
         * @param string     $html    current value being shown
         * @param array      $rule    rule to be applied
         * @param WC_Product $product current product
         *
         * @return string
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function show_price_on_table_pricing ( $html, $rule, $product ) {
            if ( YWGC_GIFT_CARD_PRODUCT_TYPE != $product->product_type ) {
                return $html;
            }
            /** @var WC_Product_Gift_Card $product */
            $prices = $product->get_gift_card_amounts ();
            if ( $prices ) {
                $min_price          = current ( $prices );
                $discount_min_price = ywdpd_get_discounted_price_table ( $min_price, $rule );
                $max_price          = end ( $prices );
                $discount_max_price = ywdpd_get_discounted_price_table ( $max_price, $rule );

                $html = $discount_min_price !== $discount_max_price ? sprintf ( _x ( '%1$s&ndash;%2$s', 'Price range: from-to', 'woocommerce' ), wc_price ( $discount_min_price ), wc_price ( $discount_max_price ) ) : wc_price ( $discount_min_price );

            }

            return $html;
        }

        /**
         * Single product template. Manage the price exclusion when used with the YITH WooCommerce Dynamic Pricing
         *
         * @param bool       $status  current visibility status
         * @param float      $price   the price to be shown
         * @param WC_Product $product the product in use
         *
         * @return bool
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function exclude_price_for_yith_dynamic_discount_product_page ( $status, $price, $product ) {

            if ( YWGC_GIFT_CARD_PRODUCT_TYPE == $product->product_type ) {
                return true;
            }

            return $status;
        }

        /**
         * Cart template. Manage the price exclusion when used with the YITH WooCommerce Dynamic Pricing
         *
         * @param float $price     the formatted price that will be shown in place of the real price
         * @param float $old_price the real price
         * @param array $cart_item
         * @param array $cart_item_key
         *
         * @return mixed
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function set_price_for_yith_dynamic_discount_cart_page ( $price, $old_price, $cart_item, $cart_item_key ) {

            $original_price = $cart_item[ 'amount' ];
            $_product       = $cart_item[ 'data' ];

            if ( ! $original_price || ! $_product ) {
                return $price;
            }

            if ( $_product instanceof WC_Product_Gift_Card ) {
                $price = '<del>' . wc_price ( $original_price ) . '</del> ' . WC ()->cart->get_product_price ( $_product );
            }

            return $price;
        }

        /**
         * Add gift card email to the available email on resend order email feature
         *
         * @param array $emails current emails
         *
         * @return array
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function resend_gift_card_code ( $emails ) {
            $emails[] = 'ywgc-email-send-gift-card';

            return $emails;
        }

        /**
         * Add the BCC header to the email that send gift card code to the users
         *
         * @param string $headers current email headers
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         *
         * @return string
         */
        public function add_admin_to_email_bcc ( $headers ) {
            //  Check if the option is set
            if ( ! $this->blind_carbon_copy ) {
                return $headers;
            }

            $admin_email = get_option ( 'admin_email' );

            return $headers . "\nbcc: " . $admin_email;
        }

        /**
         * Append CSS for the email being sent to the customer
         *
         * @param WC_Email $email the email content
         */
        public function add_footer_information ( $email = null ) {
            if ( ( $email == null ) || ( ! $this->instanceof_giftcard ( $email->object ) ) ) {
                return;
            }

            //  Print the name and shop url
            $text = $this->shop_name;
            if ( empty( $text ) ) {
                $text = __ ( "Go to shop", 'yith-woocommerce-gift-cards' );
            }
            ?>

            <div class="ywgc-footer">
                <a target="_blank" class="center-email"
                   href="<?php echo get_permalink ( wc_get_page_id ( 'shop' ) ); ?>"><?php echo $text; ?></a>
            </div>
            <?php
        }

        /**
         * Add CSS style to gift card emails header
         */
        public function include_css_for_emails ( $email_heading, $email = null ) {
            if ( ( $email == null ) || ( ! $this->instanceof_giftcard ( $email->object ) ) ) {
                return;
            }
            ?>
            <style type="text/css">
                /* Put your CSS here */
                <?php include(YITH_YWGC_ASSETS_DIR . "/css/ywgc-frontend.css"); ?>

                #gift-card-main-image {
                    max-height: 250px;
                    width: auto;
                    height: 100%;
                }

                h2,
                .center-email,
                .ywgc-footer {
                    margin: 0 auto;
                    margin-bottom: 15px;
                    text-align: center;
                }

                a.product-image-url {
                    float: left;
                    display: inline-block;
                    width: 30%;
                }

                div.product-description {
                    float: left;
                    width: 60%;
                    padding: 10px;
                }

                div.ywgc-gift-card-content input,
                div.ywgc-gift-card-content textarea,
                div.ywgc-gift-card-content button {
                    display: none;
                }

                div.ywgc-gift-card-content fieldset {
                    border: none;
                }

                div.gift-card-amount {
                    display: inline-block;
                    width: 50%;
                }

                div.shop-logo {
                    width: 40%;
                    display: inline-block;
                }

                img.shop-logo-image {
                    width: 100px;
                }

            </style>
            <?php
        }

        /**
         * Append CSS for the email being sent to the customer
         */
        public function append_css_files () {
            $this->frontend->enqueue_frontend_style ();
        }

        /**
         * Show the indotroductory message on the email being sent
         *
         * @param string         $text
         * @param YWGC_Gift_Card $gift_card
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function show_introductory_text ( $text, $gift_card ) {
            ?>
            <p class="center-email"><?php echo apply_filters ( 'ywgc_gift_cards_email_before_preview_text', $text, $gift_card ); ?></p>
            <?php
        }

        /**
         * Deny all vendors from creating gift cards
         *
         * @param $enable_user bool current enable status
         *
         * @return bool
         */
        public function user_can_create_gift_cards ( $enable_user ) {
            //  if YITH Multivendor is active, check if the user can
            if ( defined ( 'YITH_WPV_PREMIUM' ) ) {
                $vendor = yith_get_vendor ( 'current', 'user' );

                return $vendor->is_super_user ();
            }

            return $enable_user;
        }

        /**
         * When the default gift card image is changed from the plugin setting, update the product image
         * of the default gift card
         */
        public function update_default_gift_card () {
            if ( isset( $_POST[ "ywgc_gift_card_header_url-yith-attachment-id" ] ) ) {
                update_post_meta ( $this->default_gift_card, "_thumbnail_id", $_POST[ "ywgc_gift_card_header_url-yith-attachment-id" ] );
            }
        }


        /**
         * Add the customer product suggestion is there is one
         *
         * @param $gift_card YWGC_Gift_Card_Premium
         */
        public function add_product_recommended ( $gift_card ) {
            if ( ! $gift_card->product_as_present ) {
                return;
            }

            //  The customer has suggested a product when he bought the gift card
            if ( $gift_card->present_variation_id ) {
                $product = wc_get_product ( $gift_card->present_variation_id );
            } else {
                $product = wc_get_product ( $gift_card->present_product_id );
            }

            $product_url = get_permalink ( $product->id );
            ?>
            <div class="center-email">
            <span><?php echo sprintf ( __ ( "%s would like to suggest you to use this gift card to purchase the following product:", 'yith-woocommerce-gift-cards' ), $gift_card->sender ); ?>
            </span>

                <div style="overflow: hidden">
                    <a class="product-image-url" href="<?php echo $product_url; ?>">
                        <img
                            src="<?php echo $product->get_image_id () ? current ( wp_get_attachment_image_src ( $product->get_image_id (), 'thumbnail' ) ) : wc_placeholder_img_src (); ?>"
                            style="vertical-align:middle; margin-right: 10px;"/>
                    </a>

                    <div class="product-description" style="float: left">
                        <span><?php echo $product->post->post_excerpt; ?></span>
                        <br>

                        <a href="<?php echo $product_url; ?>">
                            <?php _e ( "Go to the product", 'yith-woocommerce-gift-cards' ); ?></a>
                    </div>
                </div>
            </div>

            <?php
        }

        /**
         * Add an option to let the admin set the gift card as a physical good or digital goods.
         */
        public function add_type_option ( $array ) {
            if ( isset( $array[ "virtual" ] ) ) {
                $array[ "virtual" ][ "wrapper_class" ] = add_cssclass ( 'show_if_gift-card', $array[ "virtual" ][ "wrapper_class" ] );
            }

            return $array;
        }

        /**
         * Permit gift card to be purchasable even without price
         */
        public function gift_card_is_purchasable ( $purchasable, $product ) {
            if ( ! ( $product instanceof WC_Product_Gift_Card ) ) {
                return $purchasable;
            }

            return true;
        }

        /**
         * Create a product of type gift card to be used as placeholder. Should not be visible on shop page.
         */
        public function initialize_products () {
            //  Search for a product with meta YWGC_PRODUCT_PLACEHOLDER
            $this->default_gift_card = get_option ( YWGC_PRODUCT_PLACEHOLDER, - 1 );

            if ( - 1 == $this->default_gift_card ) {

                //  Create a default gift card product
                $args = array (
                    'post_title'   => __ ( 'Gift card', 'yith-woocommerce-gift-cards' ),
                    'post_name'    => __ ( 'gift_card', 'yith-woocommerce-gift-cards' ),
                    'post_content' => __ ( 'This product has been automatically created by the plugin YITH Gift Cards.You must not edit it, or the plugin could not work properly', 'yith-woocommerce-gift-cards' ),
                    'post_status'  => 'publish',
                    'post_date'    => date ( 'Y-m-d H:i:s' ),
                    'post_author'  => 0,
                    'post_type'    => 'product',
                );

                $this->default_gift_card = wp_insert_post ( $args );
                update_option ( YWGC_PRODUCT_PLACEHOLDER, $this->default_gift_card );

                //  Create a taxonomy for products of type YWGC_GIFT_CARD_PRODUCT_TYPE and
                //  set the product created to the new taxonomy
                //  Create product type
                $term = wp_insert_term ( YWGC_GIFT_CARD_PRODUCT_TYPE, 'product_type' );

                $term_id = - 1;
                if ( $term instanceof WP_Error ) {
                    $error_code = $term->get_error_code ();
                    if ( "term_exists" == $error_code ) {
                        $term_id = $term->get_error_data ( $error_code );
                    }
                } else {
                    $term_id = $term[ "term_id" ];
                }

                if ( $term_id != - 1 ) {
                    wp_set_object_terms ( $this->default_gift_card, $term_id, 'product_type' );
                } else {
                    wp_die ( __ ( "An error occurred, you cannot use the plugin", 'yith-woocommerce-gift-cards' ) );
                }
            }
            //  set this default gift card product as virtual
            update_post_meta ( $this->default_gift_card, "_virtual", 'yes' );
        }

        public function init_plugin () {
            $this->allow_manual_amount      = "yes" == get_option ( 'ywgc_permit_free_amount' );
            $this->allow_product_as_present = "yes" == get_option ( 'ywgc_permit_its_a_present' );
            $this->allow_modification       = "yes" == get_option ( 'ywgc_permit_modification' );
            $this->notify_customer          = "yes" == get_option ( 'ywgc_notify_customer' );

            $this->shop_name             = get_option ( 'ywgc_shop_name', '' );
            $this->custom_image_max_size = get_option ( 'ywgc_custom_image_max_size', 1 );
            $this->shop_logo_url         = get_option ( "ywgc_shop_logo_url", YITH_YWGC_ASSETS_IMAGES_URL . 'default-giftcard-main-image.png' );
            $this->gift_card_header_url  = get_option ( "ywgc_gift_card_header_url", YITH_YWGC_ASSETS_IMAGES_URL . 'default-giftcard-main-image.png' );

            $this->blind_carbon_copy = "yes" == get_option ( "ywgc_blind_carbon_copy" );

            $this->initialize_products ();
        }

        /**
         * Register the custom post type
         */
        public function init_post_type () {
            $args = array (
                'label'               => __ ( 'Gift Cards', 'yith-woocommerce-gift-cards' ),
                'description'         => __ ( 'Gift Cards', 'yith-woocommerce-gift-cards' ),
                // Features this CPT supports in Post Editor
                'supports'            => array (
                    'title',
                ),
                'hierarchical'        => false,
                'public'              => false,
                'show_ui'             => true,
                'show_in_menu'        => true,
                'show_in_nav_menus'   => false,
                'show_in_admin_bar'   => false,
                'menu_position'       => 9,
                'can_export'          => false,
                'has_archive'         => false,
                'exclude_from_search' => true,
                'menu_icon'           => 'dashicons-clipboard',
                'query_var'           => false,
            );

            // Registering your Custom Post Type
            register_post_type ( YWGC_CUSTOM_POST_TYPE_NAME, $args );
        }

        /**
         * Checks for YWGC_Gift_Card_Premium instance
         *
         * @param object $obj the object to check
         *
         * @return bool obj is an instance of YWGC_Gift_Card_Premium
         */
        public function instanceof_giftcard ( $obj ) {
            return $obj instanceof YWGC_Gift_Card_Premium;
        }

        /**
         * Retrieve a gift card product instance from the gift card code
         *
         * @param $code string the card code to search for
         *
         * @return YWGC_Gift_Card_Premium
         */
        public function get_gift_card_by_code ( $code ) {
            $object = get_page_by_title ( $code, OBJECT, YWGC_CUSTOM_POST_TYPE_NAME );
            if ( null == $object ) {
                return null;
            }

            return new YWGC_Gift_Card_Premium( $object );
        }

        /**
         * Create a gift card object with specific amount, product and order
         *
         * @param float $amount
         * @param float $tax_amount
         * @param int   $product_id
         * @param int   $order_id
         *
         * @return YWGC_Gift_Card_Premium
         */
        public function get_new_gift_card ( $amount = 0, $tax_amount = 0, $product_id = 0, $order_id = 0 ) {
            $gift = new YWGC_Gift_Card_Premium();

            return $this->initialize_new_gift_card ( $gift, $amount, $tax_amount, $product_id, $order_id );
        }

        /**
         * Show checkbox enabling the product to avoid use of free amount
         */
        public function show_manual_amount_section ( $product_id ) {
            $manual_mode    = get_post_meta ( $product_id, YWGC_MANUAL_AMOUNT_MODE, true );
            $global_checked = ( $manual_mode == "global" ) || ( ( $manual_mode != "accept" ) && ( $manual_mode != "reject" ) );

            ?>
            <p class="form-field permit_free_amount show_if_virtual">
                <label><?php _e ( "Variable amount mode", 'yith-woocommerce-gift-cards' ); ?></label>
                <span class="wrap">
                    <input type="radio" class="manual-amount-mode global-manual-mode" name="manual_amount_mode"
                           value="global" <?php checked ( $global_checked, true ); ?>>
                    <span><?php _e ( "Default", 'yith-woocommerce-gift-cards' ); ?></span>
                    <input type="radio" class="manual-amount-mode accept-manual-mode" name="manual_amount_mode"
                           value="accept" <?php checked ( $manual_mode, "accept" ); ?>>
                    <span><?php _e ( "Enabled", 'yith-woocommerce-gift-cards' ); ?></span>
                    <input type="radio" class="manual-amount-mode deny-manual-mode" name="manual_amount_mode"
                           value="reject" <?php checked ( $manual_mode, "reject" ); ?>>
                    <span><?php _e ( "Not enabled", 'yith-woocommerce-gift-cards' ); ?></span>
                </span>
            </p>
            <?php
        }

        /**
         * Check if a gift card product avoid entering manual amount value
         *
         * @param $product_id int the product id to check
         *
         * @return bool
         */
        public function is_manual_amount_allowed ( $product_id ) {
            $manual_amount = get_post_meta ( $product_id, YWGC_MANUAL_AMOUNT_MODE, true );

            //  if the gift card have specific manual entered amount behavour, return that
            if ( "global" != $manual_amount ) {
                return "accept" == $manual_amount;
            }

            return $this->allow_manual_amount;
        }

        /**
         * Save additional product attribute when a gift card product is saved
         *
         * @param $post_id int current product id
         */
        public function save_gift_card_product ( $post_id, $post, $product ) {
            $is_virtual = isset( $_POST[ "_virtual" ] );
            //  If the gift card is digital
            if ( $is_virtual ) {
                update_post_meta ( $post_id, YWGC_MANUAL_AMOUNT_MODE, $_POST[ "manual_amount_mode" ] );
            }
        }

        /**
         * Create a new gift card object from POST data so it can be added to the cart with all the
         * settings needed.
         */
        public function create_gift_card_for_cart () {
            $product_as_present   = isset( $_POST[ "product_as_present" ] );
            $present_variation_id = 0;
            $present_product_id   = 0;

            if ( $product_as_present ) {
                $product_id = $this->default_gift_card;

                $present_product_id   = $_POST[ "add-to-cart" ];
                $present_variation_id = 0;

                if ( isset( $_POST[ "variation_id" ] ) ) {
                    $present_variation_id = $_POST[ "variation_id" ];
                }

                if ( $present_variation_id ) {
                    $product = new WC_Product( $present_variation_id );
                } else {
                    $product = new WC_Product( $present_product_id );
                }

                $amount = $product->get_price ();
            } else {
                $product_id = absint ( $_POST[ 'add-to-cart' ] );
                $product    = new WC_Product( $product_id );

                if ( isset( $_POST[ 'gift_amounts' ] ) ) {
                    if ( $_POST[ 'gift_amounts' ] > - 1 ) {
                        $amount = $_POST[ 'gift_amounts' ];
                    } else {
                        $amount = $_POST[ 'manual-amount' ];

                        //  Pay attention calculating the base price without tax
                        if ( $product->is_taxable () ) {
                            if ( ( 'yes' === get_option ( 'woocommerce_calc_taxes' ) ) && ( "no" == get_option ( 'woocommerce_prices_include_tax' ) ) ) {
                                $tax_rates = WC_Tax::get_base_tax_rates ( $product->tax_class );
                                $taxes     = WC_Tax::calc_tax ( $amount, $tax_rates, true );
                                $amount    = WC_Tax::round ( $amount - array_sum ( $taxes ) );
                            }
                        }
                    }
                } else {
                    $amount = wc_get_product ( $product_id )->get_price ();
                }
            }

            $gift_card = $this->get_new_gift_card ( $amount, 0, $product_id );

            /** @var YWGC_Gift_Card_Premium $gift_card */
            $gift_card->product_as_present   = $product_as_present;
            $gift_card->present_variation_id = $present_variation_id;
            $gift_card->present_product_id   = $present_product_id;

            /**
             * Sanitize the gift card message, leaving the newline
             */
            $gift_card->message            = implode ( "\n", array_map ( 'sanitize_text_field', explode ( "\n", $_POST[ 'gift-card-message' ] ) ) );
            $gift_card->sender             = sanitize_text_field ( $_POST[ "sender-name" ] );
            $gift_card->postdated_delivery = isset( $_POST[ "postdate-sending" ] );

            if ( $gift_card->postdated_delivery ) {
                $gift_card->delivery_date = sanitize_text_field ( $_POST[ "delivery-date" ] );
            }

            $custom_image = $_FILES[ "uploadFile" ];
            if ( isset( $custom_image[ "tmp_name" ] ) && ( 0 == $custom_image[ "error" ] ) ) {
                $gift_card->custom_image      = $this->save_uploaded_file ( $custom_image );
                $gift_card->use_default_image = false;
            }

            return $gift_card;
        }

        /**
         * move an uploaded file into a persistent folder
         *
         * @param $image uploaded image
         *
         * @return string   real path of the uploaded image
         */
        public function save_uploaded_file ( $image ) {
            // Create folders for storing documents
            $date     = getdate ();
            $folder   = sprintf ( "%s/%s", $date[ "year" ], $date[ "mon" ] );
            $filename = $image[ "name" ];

            while ( true ) {

                $relative_path = sprintf ( "%s/%s", $folder, $filename );
                $dir_path      = sprintf ( "%s/%s", YITH_YWGC_SAVE_DIR, $folder );
                $full_path     = sprintf ( "%s/%s", YITH_YWGC_SAVE_DIR, $relative_path );

                if ( ! file_exists ( $full_path ) ) {
                    if ( ! file_exists ( $dir_path ) ) {
                        wp_mkdir_p ( $dir_path );
                    }

                    move_uploaded_file ( $image[ "tmp_name" ], $full_path );

                    return $relative_path;
                } else {

                    $unique_id = rand ();

                    $name_without_ext = pathinfo ( $filename, PATHINFO_FILENAME );
                    $ext              = pathinfo ( $filename, PATHINFO_EXTENSION );

                    $filename = $name_without_ext . $unique_id . '.' . $ext;
                }
            }
        }

        public function get_postdated_gift_cards ( $send_date ) {
            $args = array (
                'meta_query' => array (
                    array (
                        'key'     => YWGC_META_GIFT_CARD_DELIVERY_DATE,
                        'value'   => $send_date,
                        'compare' => '<=',
                    ),
                    array (
                        'key'     => YWGC_META_GIFT_CARD_SENT,
                        'value'   => '1',
                        'compare' => 'NOT EXISTS',
                    ),
                ),

                'post_type'      => YWGC_CUSTOM_POST_TYPE_NAME,
                'fields'         => 'ids',
                'post_status'    => 'publish',
                'posts_per_page' => - 1,
            );

            $ids = get_posts ( $args );

            return $ids;
        }

        /**
         * Output a gift cards template filled with real data or with sample data to start editing it
         * on product page
         *
         * @param $object WC_Product|YWGC_Gift_Card_Premium
         */
        public function preview_digital_gift_cards ( $object ) {

            if ( $object instanceof WC_Product ) {

                // check if the admin set a default image for gift card
                $header_image_url = $this->get_default_gift_card_header_image ();
                $price            = ( $object instanceof WC_Product_Simple ) ? wc_price ( $object->get_display_price () ) : wc_price ( 0 );
                $gift_card_code   = "xxxx-xxxx-xxxx-xxxx";
                $message          = __ ( "Your message...", 'yith-woocommerce-gift-cards' );
            } else if ( $object instanceof YWGC_Gift_Card_Premium ) {
                //  Choose a valid gift card image header...
                if ( ! $object->use_default_image ) {
                    //  There is a custom header image submitted by the user?
                    $header_image_url = YITH_YWGC_SAVE_URL . $object->custom_image;
                } else {
                    if ( ! empty( $this->gift_card_header_url ) ) {
                        $header_image_url = $this->gift_card_header_url;
                    } else {
                        $header_image_url = YITH_YWGC_ASSETS_IMAGES_URL . 'default-giftcard-main-image.png';
                    }
                }

                $price          = wc_price ( $object->get_balance ( true ) );
                $gift_card_code = $object->gift_card_number;
                $message        = $object->message;
            }

            ?>
            <div class="gift-card-preview">
                <div class="gift-card-picture">
                    <img src="<?php echo $header_image_url; ?>"
                         id="gift-card-main-image" class="gift-card-main-image" alt="gift card image"
                         title="gift card image">
                </div>
                <div class="card-values">
                    <div class="shop-logo">
                        <img src="<?php echo $this->shop_logo_url; ?>"
                             class="shop-logo-image" alt="gift card image" title="gift card image">
                    </div>

                    <div class="gift-card-amount">
                        <?php echo $price; ?>
                    </div>

                </div>
                <div class="gift-card-code"><?php _e ( "Your Gift Card code", 'yith-woocommerce-gift-cards' ); ?>
                    <br>
                    <?php echo $gift_card_code; ?>
                </div>
                <div class="card-message"><?php echo $message; ?></div>
            </div>
            <?php
        }

        /**
         * @return mixed|string|void
         */
        public function get_default_gift_card_header_image () {
            $header_image_url = $this->gift_card_header_url;

            if ( ! $header_image_url ) {
                $header_image_url = YITH_YWGC_ASSETS_IMAGES_URL . 'default-giftcard-main-image.png';

                return $header_image_url;
            }

            return $header_image_url;
        }
    }
}