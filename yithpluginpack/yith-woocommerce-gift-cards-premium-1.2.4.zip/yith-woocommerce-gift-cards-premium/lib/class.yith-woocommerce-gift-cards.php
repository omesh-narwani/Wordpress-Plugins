<?php
if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}


if ( ! class_exists ( 'YITH_WooCommerce_Gift_Cards' ) ) {

    /**
     *
     * @class   YITH_WooCommerce_Gift_Cards
     * @package Yithemes
     * @since   1.0.0
     * @author  Your Inspiration Themes
     */
    class YITH_WooCommerce_Gift_Cards {
        /**
         * @var YITH_WooCommerce_Gift_Cards_Backend|YITH_WooCommerce_Gift_Cards_Backend_Premium The instance for backend features and methods
         */
        public $admin;

        /**
         * @var YITH_WooCommerce_Gift_Cards_Frontend|YITH_WooCommerce_Gift_Cards_Frontend_Premium instance for frontend features and methods
         */
        public $frontend;

        /**
         * Single instance of the class
         *
         * @since 1.0.0
         */
        protected static $instance;

        /**
         * Returns single instance of the class
         *
         * @since 1.0.0
         */
        public static function get_instance () {
            if ( is_null ( self::$instance ) ) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0
         * @author Lorenzo Giuffrida
         */
        protected function __construct () {

            require_once ( YITH_YWGC_DIR . 'lib/class.ywgc-product-gift-card.php' );

            /**
             * Do some stuff on plugin init
             */
            add_action ( 'init', array ( $this, 'on_plugin_init' ) );

            /**
             * Hide the temporary gift card product from being shown on backend product list
             */
            add_filter ( 'request', array ( $this, 'hide_from_backend_product_list' ) );

            /**
             * Hide the temporary gift card product from being shown on shop page
             */
            add_action ( 'woocommerce_product_query', array ( $this, 'hide_from_shop_page' ), 10, 1 );

            add_filter ( 'yith_plugin_status_sections', array ( $this, 'set_plugin_status' ) );
        }

        /**
         * Set information about the plugin status
         *
         * @param array $status current YITH plugins status
         *
         * @return mixed
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function set_plugin_status ( $status ) {
            $status[] = array (
                'header' => __ ( "YITH Gift Cards", 'yith-woocommerce-gift-cards' ),
                array (
                    'type'        => 'text',
                    "label"       => __ ( "Placeholder id", 'yith-woocommerce-gift-cards' ),
                    "description" => $this->default_gift_card,
                ),
            );

            return $status;
        }

        /**
         * Hide the temporary gift card product from being shown on shop page
         *
         * @param WP_Query $query The current query
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function hide_from_shop_page ( $query ) {
            $default_gift_card = get_option ( YWGC_PRODUCT_PLACEHOLDER, - 1 );
            if ( $default_gift_card > 0 ) {
                $query->set ( 'post__not_in', array ( $default_gift_card ) );
            }
        }

        /**
         * Hide the temporary gift card product from being shown on backend product list
         *
         * @param array $request the current request
         *
         * @return mixed
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function hide_from_backend_product_list ( $request ) {
            global $typenow;

            //  Don't hide gift card placeholder element on backend anymore
            return $request;

            $default_gift_card = get_option ( YWGC_PRODUCT_PLACEHOLDER, - 1 );

            if ( is_admin () && ( 'product' == $typenow ) ) {
                $request[ "post__not_in" ] = array ( $default_gift_card );
            }

            return $request;
        }

        /**
         * Add some data to the options table
         *
         */
        public static function init_db () {

            /**
             * Initialize plugin DB version
             */
            if ( ! get_option ( 'yith_gift_cards_db_version' ) ) {

                //  Initialize database tables...
                global $wpdb;

                //  Update metakey from YITH Gift Cards 1.0.0
                $query = "Update {$wpdb->prefix}woocommerce_order_itemmeta
                        set meta_key = '" . YWGC_META_GIFT_CARD_POST_ID . "'
                        where meta_key = 'gift_card_post_id'";
                $wpdb->query ( $query );

                add_option ( 'yith_gift_cards_db_version', YITH_YWGC_DB_VERSION );
            }
        }

        /**
         * Execute update on data used by the plugin that has been changed passing
         * from a DB version to another
         */
        public static function update () {

            /**
             * Init DB version if not exists
             */
            $db_version = get_option ( 'yith_gift_cards_db_version' );
            if ( ! $db_version ) {
                update_option ( 'yith_gift_cards_db_version', YITH_YWGC_DB_VERSION );

                return;
            }

            if ( version_compare ( $db_version, YITH_YWGC_DB_VERSION, '>=' ) ) {
                return; //last DB version in use
            }

            // Start update
            switch ( $db_version ) {
                case '1.0.0' :  //  Update from DB version 1.0.0

                    //  Set gift card placeholder with catalog visibility equal to "hidden"
                    $placeholder_id = get_option ( YWGC_PRODUCT_PLACEHOLDER );

                    update_post_meta ( $placeholder_id, '_visibility', 'hidden' );
            }

            //  Update the current DB version
            update_option ( 'yith_gift_cards_db_version', YITH_YWGC_DB_VERSION );
        }

        /**
         *  Execute all the operation need when the plugin init
         */
        public function on_plugin_init () {
            $this->init_post_type ();

            $this->init_plugin ();

            self::update ();
        }

        /**
         * Initialize plugin data and shard instances
         */
        public function init_plugin () {
            //nothing to do
        }

        /**
         * Register the custom post type
         */
        public function init_post_type () {
            $args = array (
                'label'               => __ ( 'Gift Cards', 'yith-woocommerce-gift-cards' ),
                'description'         => __ ( 'Gift Cards', 'yith-woocommerce-gift-cards' ),
                //'labels' => $labels,
                // Features this CPT supports in Post Editor
                'supports'            => array (
                    //'title',
                    'editor',
                    //'author',
                ),
                'hierarchical'        => false,
                'public'              => false,
                'show_ui'             => false,
                'show_in_menu'        => true,
                'show_in_nav_menus'   => false,
                'show_in_admin_bar'   => false,
                'menu_position'       => 9,
                'can_export'          => false,
                'has_archive'         => false,
                'exclude_from_search' => true,
                'menu_icon'           => 'dashicons-clipboard',
                'query_var'           => false,
            );

            // Registering your Custom Post Type
            register_post_type ( YWGC_CUSTOM_POST_TYPE_NAME, $args );
        }

        /**
         * Checks for YWGC_Gift_Card instance
         *
         * @param object $obj the object to check
         *
         * @return bool obj is an instance of YWGC_Gift_Card
         */
        public function instanceof_giftcard ( $obj ) {
            return $obj instanceof YWGC_Gift_Card;
        }

        /**
         * Checks for WC_Product_Gift_Card instance
         *
         * @param object $obj the object to check
         *
         * @return bool obj is an instance of WC_Product_Gift_Card_Premium
         */
        public function is_gift_card_product ( $obj ) {
            return $obj instanceof WC_Product_Gift_Card;
        }

        /**
         * Check if an order item if a gift card product type and if
         * a gift card was generated.
         *
         * @param $order_item_id int the order item to check
         *
         * @return bool the order item has an attached gift card.
         */
        public function order_item_has_gift_card ( $order_item_id ) {
            $gift_id = wc_get_order_item_meta ( $order_item_id, YWGC_META_GIFT_CARD_POST_ID );

            return isset( $gift_id ) && ( $gift_id > 0 );
        }

        /**
         * Retrieve a gift card product instance from the gift card code
         *
         * @param $code string the card code to search for
         *
         * @return YWGC_Gift_Card
         */
        public function get_gift_card_by_code ( $code ) {
            $object = get_page_by_title ( $code, OBJECT, YWGC_CUSTOM_POST_TYPE_NAME );
            if ( null == $object ) {
                return null;
            }

            return new YWGC_Gift_Card( $object );
        }

        /**
         * Initialize a newly created gift card
         *
         * @param YWGC_Gift_Card|YWGC_Gift_Card_Premium $gift instance of the object
         * @param float                                 $amount
         * @param float                                 $tax_amount
         * @param int                                   $product_id
         * @param int                                   $order_id
         *
         * @return mixed
         */
        public function initialize_new_gift_card ( $gift, $amount = 0.00, $tax_amount = 0.00, $product_id = 0, $order_id = 0 ) {
            $gift->set_amount ( $amount, $tax_amount );
            $gift->product_id = $product_id;
            $gift->order_id   = $order_id;

            return $gift;
        }

        /**
         * Istantiate a new gift card object
         *
         * @param float $amount
         * @param float $tax_amount
         * @param int   $product_id
         * @param int   $order_id
         *
         * @return mixed
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function get_new_gift_card ( $amount = 0.00, $tax_amount = 0.00, $product_id = 0, $order_id = 0 ) {
            $gift = new YWGC_Gift_Card();

            return $this->initialize_new_gift_card ( $gift, $amount, $tax_amount, $product_id, $order_id );
        }

        /**
         * Create a new gift card object from POST data so it can be added to the cart with all the
         * settings needed.
         */
        public function create_gift_card_for_cart () {
            $product_id = absint ( $_POST[ 'add-to-cart' ] );
            $amount     = isset( $_POST[ 'gift_amounts' ] ) && ( $_POST[ 'gift_amounts' ] > - 1 ) ? $_POST[ 'gift_amounts' ] : $_POST[ 'manual-amount' ];

            return $this->get_new_gift_card ( $amount, 0, $product_id );
        }
    }
}