<?php
if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! class_exists ( 'YWGC_Gift_Card_Premium' ) ) {
    /**
     *
     * @class   YWGC_Gift_Card_Premium
     * @package Yithemes
     * @since   1.0.0
     * @author  Your Inspiration Themes
     */
    class YWGC_Gift_Card_Premium extends YWGC_Gift_Card {

        public $postdated_delivery = false;

        public $delivery_date;

        public $recipient = '';

        public $sender = '';

        public $message = '';

        public $use_default_image = true;

        public $custom_image;

        public $product_as_present = false;

        public $present_variation_id = 0;

        /**
         * @var int the product id used as a present
         */
        public $present_product_id = 0;

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @param $args int|array|WP_Post
         *
         * @since  1.0
         * @author Lorenzo Giuffrida
         */
        public function __construct ( $args = null ) {
            parent::__construct ( $args );
        }

        /**
         * Limit the keys that are used to initialize an object of this type
         *
         * @return array
         */
        protected function get_allowed_keys () {
            return array (
                'ID',
                'product_id',
                'order_id',
                'gift_card_number',
                'amount',
                'balance',
                'postdated_delivery',
                'delivery_date',
                'recipient',
                'sender',
                'message',
                'use_default_image',
                'custom_image',
                'product_as_present',
                'present_variation_id',
                'present_product_id',
                'virtual' );
        }

        /**
         * Retrive data from the a gift card post type
         *
         * @param $post WP_Post the gift card post
         *
         * @return array
         */
        protected function get_post_value_array ( $post ) {
            //  $args is a custom post type, so retrieve value from the post object
            $array = array (
                "ID"               => $post->ID,
                "gift_card_number" => $post->post_title,
                "product_id"       => $post->post_parent,
                "order_id"         => get_post_meta ( $post->ID, YWGC_META_GIFT_CARD_ORDER_ID, true ),
            );

            $data = get_post_meta ( $post->ID, YWGC_META_GIFT_CARD_USER_DATA, true );

            if ( $data ) {
                $array[ "postdated_delivery" ]   = isset( $data[ "postdated_delivery" ] ) ? (bool)$data[ "postdated_delivery" ] : false;
                $array[ "delivery_date" ]        = isset( $data[ "delivery_date" ] ) ? $data[ "delivery_date" ] : "";
                $array[ "recipient" ]            = isset( $data[ "recipient" ] ) ? $data[ "recipient" ] : "";
                $array[ "sender" ]               = isset( $data[ "sender" ] ) ? $data[ "sender" ] : "";
                $array[ "message" ]              = isset( $data[ "message" ] ) ? $data[ "message" ] : "";
                $array[ "use_default_image" ]    = isset( $data[ "use_default_image" ] ) ? $data[ "use_default_image" ] : true;
                $array[ "custom_image" ]         = isset( $data[ "custom_image" ] ) ? $data[ "custom_image" ] : "";
                $array[ "product_as_present" ]   = isset( $data[ "product_as_present" ] ) ? $data[ "product_as_present" ] : false;
                $array[ "present_variation_id" ] = isset( $data[ "present_variation_id" ] ) ? $data[ "present_variation_id" ] : 0;
                $array[ "present_product_id" ]   = isset( $data[ "present_product_id" ] ) ? $data[ "present_product_id" ] : 0;
            }

            return $array;
        }

        /**
         * The gift card product is virtual
         */
        public function is_virtual () {

            $is_virtual = false;
            $product    = wc_get_product ( $this->product_id );
            if ( $product ) {
                $is_virtual = $product->is_virtual ();
            }

            return $is_virtual;
        }

        /**
         * Check if the gift card has been sent
         */
        public function has_been_sent () {
            return get_post_meta ( $this->ID, YWGC_META_GIFT_CARD_SENT, true );
        }

        /**
         * Set the gift card as sent
         */
        public function set_as_sent () {
            update_post_meta ( $this->ID, YWGC_META_GIFT_CARD_SENT, current_time ( 'Y-m-d', 0 ) );
        }

        /**
         * Save the current object
         */
        public function save () {
            parent::save ();

            /**
             * Save user content as a serialized array if a gift card object is created and
             * valid.
             */
            if ( $this->ID ) {
                update_post_meta ( $this->ID, YWGC_META_GIFT_CARD_USER_DATA, (array)$this );
            }
        }
    }
}