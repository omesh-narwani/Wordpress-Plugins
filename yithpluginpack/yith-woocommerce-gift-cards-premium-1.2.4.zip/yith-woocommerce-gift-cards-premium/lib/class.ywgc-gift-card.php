<?php
if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! class_exists ( 'YWGC_Gift_Card' ) ) {

    /**
     *
     * @class   YWGC_Gift_Card
     * @package Yithemes
     * @since   1.0.0
     * @author  Your Inspiration Themes
     */
    class YWGC_Gift_Card {
        /**
         * @var int the id of the gift card post type
         */
        public $ID = 0;

        /**
         * @var int the product id for the prodyuct of type WC_Product_Gift_Card
         */
        public $product_id = 0;

        /**
         * @var int the order id  for the gift card
         */
        public $order_id = 0;

        /**
         * @var string the code that let the customer apply the discuount
         */
        public $gift_card_number = '';

        /**
         * @var float the gift card amount
         */
        public $amount = 0.00;

        /**
         * @var float
         */
        public $amount_tax = 0.00;

        /**
         * @var float the gift card current balance
         */
        public $balance = 0.00;

        /**
         * @var float
         */
        public $balance_tax = 0.00;

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @param $args int|array|WP_Post
         *
         * @since  1.0
         * @author Lorenzo Giuffrida
         */
        public function __construct ( $args = null ) {
            //  retrieve args from the post object
            $args = $this->get_array ( $args );

            if ( $args ) {
                $allowed_keys = $this->get_allowed_keys ();
                foreach ( $args as $key => $value ) {
                    if ( in_array ( $key, $allowed_keys ) ) {
                        $this->{$key} = $value;
                    }
                }
                //  Initialize amount value
                $this->amount  = $this->get_amount ();
                $this->balance = $this->get_balance ();
            }
        }

        /**
         * Limit the keys that are used to initialize an object of this type
         *
         * @return array
         */
        protected function get_allowed_keys () {
            return array (
                'ID',
                'product_id',
                'order_id',
                'gift_card_number',
                'amount',
                'balance',
            );
        }

        /**
         * retrieve item attribute
         *
         * @param int|array|WP_Post $post_id the object to be used
         *
         * @return array|null
         */
        public function get_array ( $args ) {
            if ( is_array ( $args ) ) {
                return $args;
            }

            if ( is_numeric ( $args ) ) {
                $args = get_post ( $args );
            }

            if ( ! ( $args instanceof WP_Post ) ) {
                return null;
            }

            if ( YWGC_CUSTOM_POST_TYPE_NAME != $args->post_type ) {
                return null;
            }

            //  $args is a custom post type, so retrieve value from the post object
            return $this->get_post_value_array ( $args );
        }

        /**
         * Retrieve data from the a gift card post type
         *
         * @param WP_Post $post the gift card post
         *
         * @return array
         */
        protected function get_post_value_array ( $post ) {
            //  $args is a custom post type, so retrieve value from the post object
            return array (
                "ID"               => $post->ID,
                "gift_card_number" => $post->post_title,
                "product_id"       => $post->post_parent,
                "order_id"         => get_post_meta ( $post->ID, YWGC_META_GIFT_CARD_ORDER_ID, true ),
            );
        }

        /**
         * Set the initial amount for the current gift card. Can't be updated if previously set.
         *
         * @param float $amount     The gift card amount
         * @param float $tax_amount The gift card amount
         */
        public function set_amount ( $amount, $tax_amount = 0.00 ) {
            //  can't set a gift card original amount if the gift card still have a value
            if ( $this->amount > 0 ) {
                return;
            }

            $this->amount     = $this->balance = $amount;
            $this->amount_tax = $this->balance_tax = $tax_amount;
        }

        /**
         * Persist the current balance on the database
         *
         * @param float|null $new_balance The new balance for the gift card or false to use the current amount
         */
        private function update_balance ( $new_balance = null, $new_balance_tax = 0.00 ) {
            if ( $new_balance !== null ) {
                $this->balance     = $new_balance;
                $this->balance_tax = $new_balance_tax;
            }

            if ( $this->ID ) {
                update_post_meta ( $this->ID, YWGC_META_GIFT_CARD_AMOUNT_BALANCE, $this->balance );
                update_post_meta ( $this->ID, YWGC_META_GIFT_CARD_AMOUNT_BALANCE_TAX, $this->balance_tax );
            }
        }

        /**
         * Persist the current amount on the database
         *
         * @param $new_amount float|bool the new amount for the gift card or false to use the current amount
         */
        private function update_amount ( $new_amount = null, $new_amount_tax = 0.00 ) {
            if ( $new_amount != null ) {
                $this->amount     = $new_amount;
                $this->amount_tax = $new_amount_tax;
            }

            if ( $this->ID ) {
                update_post_meta ( $this->ID, YWGC_META_GIFT_CARD_AMOUNT, $this->amount );
                update_post_meta ( $this->ID, YWGC_META_GIFT_CARD_AMOUNT_TAX, $this->amount_tax );
            }
        }

        /**
         * Retrieve the gift card original amount
         *
         * @return float the current gift card amount
         */
        private function get_amount ( $incl_tax = false ) {
            if ( $this->ID ) {
                $_amount = get_post_meta ( $this->ID, YWGC_META_GIFT_CARD_AMOUNT, true );
                $_amount = empty( $_amount ) ? 0.00 : $_amount;

                if ( $incl_tax ) {
                    $_tax = get_post_meta ( $this->ID, YWGC_META_GIFT_CARD_AMOUNT_TAX, true );
                    $_amount .= $_tax;
                }

                return $_amount;
            }

            return 0.00;
        }

        /**
         * Retrieve the gift card current balance
         *
         * @return float the current gift card balance
         */
        public function get_balance ( $incl_tax = false ) {

            if ( $this->ID ) {
                $_balance = get_post_meta ( $this->ID, YWGC_META_GIFT_CARD_AMOUNT_BALANCE, true );
                $_balance = empty( $_balance ) ? 0.00 : $_balance;

                if ( $incl_tax ) {
                    $_tax = get_post_meta ( $this->ID, YWGC_META_GIFT_CARD_AMOUNT_BALANCE_TAX, true );
                    $_tax = empty( $_tax ) ? 0.00 : $_tax;
                    $_balance += $_tax;
                }

                return $_balance;
            }

            return 0.00;
        }

        /**
         * Generate a new gift card code
         * @param bool|false $overwrite overwrite a previous value
         *
         * @return bool
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function generate_gift_card_code ( $overwrite = false ) {
            if ( ! $overwrite && ! empty( $this->gift_card_number ) ) {
                return false;   // gift card code not updated
            }

            //  Create a new gift card number

            //http://stackoverflow.com/questions/3521621/php-code-for-generating-decent-looking-coupon-codes-mix-of-alphabets-and-number
            $code = strtoupper ( substr ( base_convert ( sha1 ( uniqid ( mt_rand () ) ), 16, 36 ), 0, 16 ) );

            $code = sprintf ( "%s-%s-%s-%s",
                substr ( $code, 0, 4 ),
                substr ( $code, 4, 4 ),
                substr ( $code, 8, 4 ),
                substr ( $code, 12, 4 )
            );

            $this->gift_card_number = $code;

            return true;
        }

        /**
         * Deduct an amount from the gift card
         *
         * @param float $deduct_amount     the amount to be deducted from current gift card balance
         * @param float $deduct_amount_tax the tax amount to be deducted from current gift card balance
         */
        public function deduct_amount ( $deduct_amount, $deduct_amount_tax = 0.00 ) {

            $new_amount     = $this->get_balance () - $deduct_amount;
            $new_amount_tax = $this->get_balance ( true ) - $this->get_balance () - $deduct_amount_tax;

            if ( $new_amount < 0 ) {
                $new_amount     = 0.00;
                $new_amount_tax = 0.00;
            }

            $this->update_balance ( $new_amount, $new_amount_tax );
        }

        /**
         * Check if the gift card has enough balance to cover the amount requested
         *
         * @param $amount int the amount to be deducted from current gift card balance
         *
         * @return bool the gift card has enough credit
         */
        public function has_sufficient_credit ( $amount ) {
            return $this->get_balance ( true ) >= $amount;
        }

        /**
         * Save the current object
         */
        public function save () {
            // Create post object
            $args = array (
                'post_title'  => $this->gift_card_number,
                'post_status' => 'publish',
                'post_type'   => YWGC_CUSTOM_POST_TYPE_NAME,
                'post_parent' => $this->product_id,
            );

            if ( $this->ID == 0 ) {
                // Insert the post into the database
                $this->ID = wp_insert_post ( $args );

            } else {
                $args[ "ID" ] = $this->ID;
                $this->ID     = wp_update_post ( $args );
            }

            //  Save Gift Card metas
            $this->update_amount ();
            $this->update_balance ();

            update_post_meta ( $this->ID, YWGC_META_GIFT_CARD_ORDER_ID, $this->order_id );

            return $this->ID;
        }
    }
}