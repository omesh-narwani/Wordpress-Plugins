<?php
if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! class_exists ( 'WC_Product_Gift_Card' ) ) {

    /**
     *
     * @class   YWGC_Gift_Card
     * @package Yithemes
     * @since   1.0.0
     * @author  Your Inspiration Themes
     */
    class WC_Product_Gift_Card extends WC_Product {

        /**
         * Initialize a gift card product.
         *
         * @param mixed $product
         */
        public function __construct ( $product ) {
            $this->product_type = YWGC_GIFT_CARD_PRODUCT_TYPE;

            parent::__construct ( $product );
        }

        /**
         * Retrieve the number of amounts setted for this product
         *
         * @return int
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        private function get_amounts_count () {
            return count ( $this->get_amounts () );
        }

        /**
         * Retrieve a list of amounts for the current product
         *
         * @return array
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        private function get_amounts () {
            if ( $this->id ) {
                $metas = get_post_meta ( $this->id, YWGC_AMOUNTS, true );

                return is_array ( $metas ) ? $metas : array ();
            }

            return array ();
        }

        /**
         * Returns false if the product cannot be bought.
         *
         * @return bool
         */
        public function is_purchasable () {

            if ( ! $this->get_amounts_count () ) {

                $purchasable = false;
            } else {
                $purchasable = true;

            }

            return apply_filters ( 'woocommerce_is_purchasable', $purchasable, $this );
        }

        /**
         * Retrieve an array of gift cards amounts to be shown
         *
         * @return array
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function get_amounts_to_be_shown () {
            $amounts          = $this->get_gift_card_amounts ();
            $amounts_to_show  = array ();
            $tax_display_mode = get_option ( 'woocommerce_tax_display_shop' );

            foreach ( $amounts as $amount ) {
                if ( 'incl' === $tax_display_mode ) {
                    $price = $this->get_price_including_tax ( 1, $amount );
                } else {
                    $price = $this->get_price_excluding_tax ( 1, $amount );
                }

                $amounts_to_show[ $amount ] = $price;
            }

            return $amounts_to_show;
        }

        /**
         * Returns the price in html format.
         *
         * @access public
         *
         * @param string $price (default: '')
         *
         * @return string
         */
        public function get_price_html ( $price = '' ) {
            $amounts = $this->get_gift_card_amounts ();

            // No price for current gift card
            if ( ! count ( $amounts ) ) {
                $price = apply_filters ( 'yith_woocommerce_gift_cards_empty_price_html', '', $this );
            } else {
                $prices    = $this->get_amounts_to_be_shown ();
                $min_price = current ( $prices );
                $max_price = end ( $prices );

                $price = $min_price !== $max_price ? sprintf ( _x ( '%1$s&ndash;%2$s', 'Price range: from-to', 'yith-woocommerce-gift-cards' ), wc_price ( $min_price ), wc_price ( $max_price ) ) : wc_price ( $min_price );
                $price = apply_filters ( 'yith_woocommerce_gift_cards_amount_range', $price, $this );
            }

            return apply_filters ( 'woocommerce_get_price_html', $price, $this );
        }

        /**
         * Get the add to cart button text
         *
         * @return string
         */
        public function add_to_cart_text () {

            return apply_filters ( 'yith_woocommerce_gift_cards_add_to_cart_text', __ ( 'Select amount', 'yith-woocommerce-gift-cards' ), $this );
        }

        /**
         * Get the gift card amount list
         *
         * @return mixed|void
         */
        public function get_gift_card_amounts () {
            return apply_filters ( 'yith_ywgc_gift_card_amounts', $this->get_amounts (), $this );
        }
    }
}