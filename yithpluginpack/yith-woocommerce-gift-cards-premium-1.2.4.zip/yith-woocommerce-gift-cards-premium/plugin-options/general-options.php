<?php
/**
 * This file belongs to the YIT Plugin Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined ( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly
$general_options = array (

    'general' => array (

        array (
            'name' => __ ( 'General settings', 'yith-woocommerce-gift-cards' ),
            'type' => 'title',
        ),
        'ywgc_shop_name'             => array (
            'name' => __ ( 'Shop name', 'yith-woocommerce-gift-cards' ),
            'type' => 'text',
            'id'   => 'ywgc_shop_name',
            'desc' => __ ( 'Set the name of the shop for the email sent to the customer.', 'yith-woocommerce-gift-cards' ),
        ),
        'ywgc_permit_free_amount'    => array (
            'name'    => __ ( 'Allow variable amount', 'yith-woocommerce-gift-cards' ),
            'type'    => 'checkbox',
            'id'      => 'ywgc_permit_free_amount',
            'desc'    => __ ( 'Allow your customers to add any amount in addition to those already set.', 'yith-woocommerce-gift-cards' ),
            'default' => 'no',
        ),
        'ywgc_permit_its_a_present'  => array (
            'name'    => __ ( 'Enable the "Gift this product" option', 'yith-woocommerce-gift-cards' ),
            'type'    => 'checkbox',
            'id'      => 'ywgc_permit_its_a_present',
            'desc'    => __ ( 'Allow users to create a gift card from a product they would like to gift', 'yith-woocommerce-gift-cards' ),
            'default' => 'no',
        ),
        'ywgc_permit_modification'   => array (
            'name'    => __ ( 'Allow editing', 'yith-woocommerce-gift-cards' ),
            'type'    => 'checkbox',
            'id'      => 'ywgc_permit_modification',
            'desc'    => __ ( 'Allow you users to edit the message and the receiver of the gift card', 'yith-woocommerce-gift-cards' ),
            'default' => 'no',
        ),
        'ywgc_notify_customer'       => array (
            'name'    => __ ( 'Purchase notification', 'yith-woocommerce-gift-cards' ),
            'type'    => 'checkbox',
            'id'      => 'ywgc_notify_customer',
            'desc'    => __ ( 'Notify customers when a gift card they have purchased is used', 'yith-woocommerce-gift-cards' ),
            'default' => 'no',
        ),
        'ywgc_blind_carbon_copy'     => array (
            'name'    => __ ( 'BCC email', 'yith-woocommerce-gift-cards' ),
            'type'    => 'checkbox',
            'id'      => 'ywgc_blind_carbon_copy',
            'desc'    => __ ( 'Send the email containing the gift card code to the admin with Blind Carbon Copy', 'yith-woocommerce-gift-cards' ),
            'default' => 'no',
        ),
        'ywgc_custom_image_max_size' => array (
            'name'              => __ ( 'Max image size', 'yith-woocommerce-gift-cards' ),
            'type'              => 'number',
            'id'                => 'ywgc_custom_image_max_size',
            'desc'              => __ ( 'Put a limit (in MB) to the size of the customized images that customers can use. Set to 0 if you don\'t want any limit.', 'yith-woocommerce-gift-cards' ),
            'custom_attributes' => array (
                'min'      => 0,
                'step'     => 1,
                'required' => 'required',
            ),
            'default'           => 1,
        ),
        'ywgc_shop_logo_url'         => array (
            'name' => __ ( 'Shop logo', 'yith-woocommerce-gift-cards' ),
            'type' => 'ywgc_upload_image',
            'id'   => 'ywgc_shop_logo_url',
            'desc' => __ ( 'Set the logo of the shop you want to show in the gift card sent to customers. The logo will be showed with a maximum size of 100x60 pixels.', 'yith-woocommerce-gift-cards' ),
        ),
        'yith_gift_card_header_url'  => array (
            'name' => __ ( 'Logo of the gift card product', 'yith-woocommerce-gift-cards' ),
            'type' => 'ywgc_upload_image',
            'id'   => 'ywgc_gift_card_header_url',
            'desc' => __ ( 'Select the logo of a default gift card product', 'yith-woocommerce-gift-cards' ),
        ),
        array (
            'type' => 'sectionend',
        ),
    ),
);

return $general_options;


