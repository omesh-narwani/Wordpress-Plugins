﻿=== YITH WooCommerce Gift Cards Premium ===

Contributors: yithemes
Tags: gift card, gift cards, coupon, gift, discount
Requires at least: 4.0
Tested up to: 4.4.2
Stable tag: 1.2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= Version 1.2.4 - Released: Feb 11, 2016 =

* Fixed: in cart page the "Coupon" text was not localizable.
* Fixed: the class selector for datepicker conflict with other datepicker in the page
* Fixed: adding to cart of product with "sold individually" flag setted fails
* Fixed: require_once of class.ywgc-product-gift-card.php lead sometimes to "the Class 'WC_Product' not found" fatal error
* Added: compatibility with the YITH WooCommerce Points and Rewards plugin

= Version 1.2.3 - Released: Jan 18, 2016 =

* Fixed: notification email on gift card code used not delivered to the customer

= Version 1.2.2 - Released: Jan 15, 2016 =

* Added: compatibility with YITH WooCommerce Dynamic Pricing

= Version 1.2.1 - Released: Jan 14, 2016 =

* Fixed: missing parameter 2 on emails

= Version 1.2.0 - Released: Jan 13, 2016 =

* Updated: gift card code is generated only one time, even if the order status changes to 'completed' several time
* Updated: plugin ready for WooCommerce 2.5
* Updated: removed action ywgc_gift_cards_email_footer for woocommerce_email_footer on email template
* Fixed: prevent gift card message containing HTML or scripts to be rendered
* Added: resend gift card email on the resend order emails dropdown on order page

= Version 1.1.6 - Released: Dec 28, 2015 =

* Added: digital gift cards content shown on gift cards table in admin dashboard
* Added: option to force gift card code sending when automatic sending fails

= Version 1.1.5 - Released: Dec 14, 2015 =

* Fixed: YITH Plugin Framework breaks updates on WordPress multisite

= Version 1.1.4 - Released: Dec 11, 2015 =

* Fixed: manual entered text not used in emails

= Version 1.1.3 - Released: Dec 08, 2015 =

* Fixed: YIT panel script not enqueued in admin

= Version 1.1.2 - Released: Dec 07, 2015 =

* Fixed: temporary gift card tax calculation
* Updated: temporary gift card is visible on dashboard so it can be set the title and the image

= Version 1.1.1 - Released: Nov 30 2015 =

* Fixed: Emogrifier warning caused by typo in CSS
* Fixed: problem that prevent the gift card email from being sent
* Fixed: ask for a valid date when postdated delivery is checked

= Version 1.1.0 - Released: Nov 26 2015 =

* Added: optionally redirect to cart after a gift cards is added to cart
* Fixed: postdated gift cards was sent on wrong date

= Version 1.0.9 - Released: Nov 25 2015 =

* Fixed: missing function on YIT Plugin Framework
* Updated: gift cards sender and recipient details added on emails

= Version 1.0.8 - Released: Nov 24 2015 =

* Fixed: wrong gift card values generated when in WooCommerce Tax Options, prices are set as entered without tax and displayd inclusiding taxes

= Version 1.0.7 - Released: Nov 20 2015 =

* Updated: gift card price support price including or excluding taxes

= Version 1.0.6 - Released: Nov 19 2015 =

* Updated: Gift Cards object cast to array for third party compatibility

= Version 1.0.5 - Released: Nov 17 2015 =

* Fixed: tax not deducted when gift card code was used

= Version 1.0.4 - Released: Nov 13 2015 =

* Fixed: multiple gift cards code not generated

= Version 1.0.3 - Released: Nov 12 2015 =

* Added: tax class on gift card product type
* Updated: changed action used for YITH Plugin FW loading
* Updated: gift card full amount(product price plus taxes) used for cart discount

= Version 1.0.2 - Released: Nov 06, 2015 =

* Fixed: coupon conflicts at checkout

= Version 1.0.1 - Released: Oct 29, 2015 =

* Update: YITH plugin framework

= Version 1.0.0 - Released: Oct 22, 2015 =

* Initial release