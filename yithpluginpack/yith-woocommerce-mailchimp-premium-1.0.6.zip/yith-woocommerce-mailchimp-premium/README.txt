=== YITH WooCommerce Mailchimp ===

Contributors: yithemes
Tags: mailchimp, woocommerce, checkout, themes, yit, e-commerce, shop, newsletter, subscribe, subscription, marketing, signup, order, email, mailchimp for wordpress, mailchimp for wp, mailchimp signup, mailchimp subscribe, newsletter, newsletter subscribe, newsletter checkbox, double optin
Requires at least: 4.0
Tested up to: 4.4
Stable tag: 1.0.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Documentation: http://yithemes.com/docs-plugins/yith-woocommerce-mailchimp

== Changelog ==

= 1.0.6 =

* Added: option to hide form after successful registration, in shortcodes and widgets
* Added: options to customize success message, in shortcodes and widgets
* Added: check over MailChimp class existence, to avoid Fatal Error with other plugins including that class
* Added: MailChimp error translation via .po archives
* Tweak: improved plugin import procedure
* Tweak: Updated internal plugin-fw

= 1.0.5 =

* Tweak: Performance improved with new plugin core 2.0
* Fixed: eCommerce 360 campaign data workflow

= 1.0.4 =

* Fixed: WC general notices print in MailChimp widget / shortcode
* Fixed: Missing file on activation

= 1.0.3 =

* Added: Compatibility with WC 2.4.2
* Tweak: Updated internal plugin-fw
* Tweak: Improved wpml compatibility
* Tweak: Removed class row from subscription form
* Tweak: Removed un-needed nl from types templates
* Fixed: Removed call to deprecated $this->WP_Widget method
* Fixed: added nopriv ajax handling for form subscription
* Removed: control on "show" flag for fields

= 1.0.2 =

* Added: WP 4.2.1 support
* Fixed: "Plugin Documentation" appearing on all plugins
* Fixed: various minor bug

= 1.0.1 =

* Initial release