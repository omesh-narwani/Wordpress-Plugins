jQuery( document ).ready( function( $ ){
    var forms = $( '.yith-wcmc-subscription-form' );

    forms.on( 'submit', 'form', function(ev){
        var form = $(this),
            hide_after = form.data( 'hide'),
            data = form.serialize();

        ev.preventDefault();

        data += '&action=' + yith_wcmc.actions.yith_wcmc_subscribe_action;

        $.ajax({
            beforeSend: function(){
                form.block({
                    message: null,
                    overlayCSS: {
                        background: '#fff',
                        opacity: 0.6
                    }
                });
            },
            complete: function(){
                form.unblock();
            },
            data: data,
            dataType: 'json',
            error: function(){

            },
            method: 'POST',
            success: function(data, status, xhr){
                if( data.length == 0 ){
                    return;
                }

                var status = data.status,
                    message = data.message,
                    subscription_notice_container = form.prev( '.subscription-notice' );

                subscription_notice_container.fadeOut( 300, function (){
                    var message_html = '';

                    if( status ){
                        message_html = '<div class="woocommerce-message">' + message + '</div>';
                    }
                    else{
                        message_html = '<div class="woocommerce-error">' + message + '</div>';
                    }

                    $('html, body').animate({
                        scrollTop: form.parent().offset().top
                    }, 1000);

                    if( status && hide_after == 'yes' ){
                        form.fadeOut( 300, function(){
                            subscription_notice_container
                                .html( message_html)
                                .fadeIn( 300 );
                        } );
                    }
                    else{
                        subscription_notice_container
                            .html( message_html)
                            .fadeIn( 300 );
                    }
                } );
            },
            url: yith_wcmc.ajax_url
        });
    } );
} );