<?php
/**
 * Widget settings page
 *
 * @author  Your Inspiration Themes
 * @package YITH WooCommerce Mailchimp
 * @version 1.0.0
 */

if ( ! defined( 'YITH_WCMC' ) ) {
	exit;
} // Exit if accessed directly

// retrieve lists
$list_options = YITH_WCMC()->retrieve_lists();
$selected_list = get_option( 'yith_wcmc_widget_mailchimp_list' );

// retrieve groups
$groups_options = ( ! empty( $selected_list ) ) ? YITH_WCMC()->retrieve_groups( $selected_list ) : array();

return apply_filters( 'yith_wcmc_widget_options', array(
	'widget' => array(
		'widget-general-options' => array(
			'title' => __( 'Widget Options', 'yith-wcmc' ),
			'type' => 'title',
			'desc' => sprintf( __( 'Set here the options for <b>YITH MailChimp Subscription Form</b> widget; use the widget in you sidebars, by selecting it from <a href="%s">Appearance > Widgets</a>', 'yith-wcmc' ), admin_url( 'widgets.php' ) ),
			'id' => 'yith_wcmc_widget_options'
		),

		'widget-general-title' => array(
			'title' => __( 'Form title', 'yith-wcmc' ),
			'type' => 'text',
			'id' => 'yith_wcmc_widget_title',
			'desc' => __( 'Select a title for the newsletter subscription form', 'yith-wcmc' ),
			'default' => __( 'Newsletter', 'yith-wcmc' ),
			'css' => 'min-width:300px;'
		),

		'widget-general-submit-label' => array(
			'title' => __( '"Submit" button label', 'yith-wcmc' ),
			'type' => 'text',
			'id' => 'yith_wcmc_widget_submit_button_label',
			'desc' => __( 'Select a label for the "Submit" button found in the form', 'yith-wcmc' ),
			'default' => __( 'SUBMIT', 'yith-wcmc' ),
			'css' => 'min-width:300px;'
		),

		'widget-general-success-message' => array(
			'title' => __( '"Successfully Registered" message', 'yith-wcmc' ),
			'type' => 'textarea',
			'id' => 'yith_wcmc_widget_success_message',
			'desc' => __( 'Select a message to display to users when registration has been completed successfully', 'yith-wcmc' ),
			'default' => __( 'Great! You\'re now subscribed to our newsletter', 'yith-wcmc' ),
			'css' => 'min-width:500px; min-height:100px;'
		),

		'widget-general-hide-after-registration' => array(
			'title' => __( 'Hide form after registration', 'yith-wcmc' ),
			'type' => 'checkbox',
			'id' => 'yith_wcmc_widget_hide_after_registration',
			'desc' => __( 'When you select this option, the registration form will be hidden after a successful registration', 'yith-wcmc' ),
			'default' => 'no'
		),

		'widget-general-email-type' => array(
			'title' => __( 'Email type', 'yith-wcmc' ),
			'type' => 'select',
			'id' => 'yith_wcmc_widget_email_type',
			'desc' => __( 'User preferential email type (HTML or plain text)', 'yith-wcmc' ),
			'options' => array(
				'html' => __( 'HTML', 'yith-wcmc' ),
				'text' => __( 'Text', 'yith-wcmc' )
			),
			'default' => 'html'
		),

		'widget-general-double-optin' => array(
			'title' => __( 'Double Opt-in', 'yith-wcmc' ),
			'type' => 'checkbox',
			'id' => 'yith_wcmc_widget_double_optin',
			'desc' => __( 'When you check this option, MailChimp will send a confirmation email before adding the user to the list', 'yith-wcmc' ),
			'default' => ''
		),

		'widget-general-update-existing' => array(
			'title' => __( 'Update existing', 'yith-wcmc' ),
			'type' => 'checkbox',
			'id' => 'yith_wcmc_widget_update_existing',
			'desc' => __( 'When you check this option, existing users will be updated and MailChimp servers will not show errors', 'yith-wcmc' ),
			'default' => ''
		),

		'widget-general-replace-interests' => array(
			'title' => __( 'Replace interests', 'yith-wcmc' ),
			'type' => 'checkbox',
			'id' => 'yith_wcmc_widget_replace_interests',
			'desc' => __( 'When you check this option, interest group of an already registered user will be replaced with the one selected in the new subscription', 'yith-wcmc' ),
			'default' => ''
		),

		'widget-general-send-welcome' => array(
			'title' => __( 'Send welcome email', 'yith-wcmc' ),
			'type' => 'checkbox',
			'id' => 'yith_wcmc_widget_send_welcome',
			'desc' => __( 'Send a welcome email to the user (only available when double opt-in is disabled)', 'yith-wcmc' ),
			'default' => ''
		),

		'widget-general-options-end' => array(
			'type'  => 'sectionend',
			'id'    => 'yith_wcmc_widget_options'
		),

		'widget-list-options' => array(
			'title' => __( 'List Options', 'yith-wcmc' ),
			'type' => 'title',
			'desc' => '',
			'id' => 'yith_wcmc_widget_list_options'
		),

		'widget-list' => array(
			'title' => __( 'MailChimp list', 'yith-wcmc' ),
			'type' => 'select',
			'desc' => __( 'Select a list for the new user', 'yith-wcmc' ),
			'id' => 'yith_wcmc_widget_mailchimp_list',
			'options' => $list_options,
			'custom_attributes' => empty( $list_options ) ? array(
				'disabled' => 'disabled'
			) : array(),
			'css' => 'min-width:300px;',
			'class' => 'list-select'
		),

		'widget-group' => array(
			'title' => __( 'Interest groups', 'yith-wcmc' ),
			'type' => 'multiselect',
			'desc' => __( 'Select an interest group for the new user', 'yith-wcmc' ),
			'id' => 'yith_wcmc_widget_mailchimp_groups',
			'options' => $groups_options,
			'custom_attributes' => empty( $groups_options ) ? array(
				'disabled' => 'disabled'
			) : array(),
			'class' => 'chosen_select',
			'css' => 'width:300px;'
		),

		'widget-list-options-end' => array(
			'type'  => 'sectionend',
			'id'    => 'yith_wcmc_widget_list_options'
		),

		'widget-fields-options' => array(
			'title' => __( 'Field Options', 'yith-wcmc' ),
			'type' => 'title',
			'desc' => '',
			'id' => 'yith_wcmc_widget_fields_options'
		),

		'widget-fields' => array(
			'title' => __( 'Fields', 'yith-wctc' ),
			'type' => 'yith_wcmc_custom_fields',
			'id' => 'yith_wcmc_widget_custom_fields'
		),

		'widget-fields-options-end' => array(
			'type'  => 'sectionend',
			'id'    => 'yith_wcmc_widget_fields_options'
		),

		'widget-style-options' => array(
			'title' => __( 'Style Options', 'yith-wcmc' ),
			'type' => 'title',
			'desc' => '',
			'id' => 'yith_wcmc_widget_style_fields_options'
		),

		'widget-style-enable' => array(
			'title' => __( 'Enable custom CSS', 'yith-wcmc' ),
			'type' => 'checkbox',
			'desc' => __( 'Check this option to enable custom CSS handling', 'yith-wcmc' ),
			'id' => 'yith_wcmc_widget_style_enable'
		),

		'widget-style-button-corners' => array(
			'id'        => 'yith_wcmc_widget_subscribe_button_round_corners',
			'name'      => __( 'Round Corners for "Subscribe" Button', 'yith-wcmc' ),
			'type'      => 'checkbox',
			'desc'      => __( 'Check this option  to make button corners round', 'yith-wcmc' ),
			'default'   => 'yes'
		),

		'widget-style-button-background-color' => array(
			'id'      => 'yith_wcmc_widget_subscribe_button_background_color',
			'name'    => __( '"Subscribe" Button Background Color', 'yith-wcmc' ),
			'type'    => 'color',
			'desc'    => '',
			'default' => '#ebe9eb'
		),

		'widget-style-button-color' => array(
			'id'      => 'yith_wcmc_widget_subscribe_button_color',
			'name'    => __( '"Subscribe" Button Text Color', 'yith-wcmc' ),
			'type'    => 'color',
			'desc'    => '',
			'default' => '#515151'
		),

		'widget-style-button-border-color' => array(
			'id'      => 'yith_wcmc_widget_subscribe_button_border_color',
			'name'    => __( '"Subscribe" Button Border Color', 'yith-wcmc' ),
			'type'    => 'color',
			'desc'    => '',
			'default' => '#ebe9eb'
		),

		'widget-style-button-background-color-hover' => array(
			'id'      => 'yith_wcmc_widget_subscribe_button_background_hover_color',
			'name'    => __( '"Subscribe" Button Hover Background Color', 'yith-wcmc' ),
			'type'    => 'color',
			'desc'    => '',
			'default' => '#dad8da'
		),

		'widget-style-button-color-hover' => array(
			'id'      => 'yith_wcmc_widget_subscribe_button_hover_color',
			'name'    => __( '"Subscribe" Button Hover Text Color', 'yith-wcmc' ),
			'type'    => 'color',
			'desc'    => '',
			'default' => '#515151'
		),

		'widget-style-button-border-color-hover' => array(
			'id'      => 'yith_wcmc_widget_subscribe_button_border_hover_color',
			'name'    => __( '"Subscribe" Button Hover Border Color', 'yith-wcmc' ),
			'type'    => 'color',
			'desc'    => '',
			'default' => '#dad8da'
		),

		'widget-style-custom' => array(
			'id'      => 'yith_wcmc_widget_custom_css',
			'name'    => __( 'Custom css', 'yith-wcmc' ),
			'type'    => 'textarea',
			'desc'    => __( 'Insert here your custom CSS for the widget', 'yith-wcmc' ),
			'default' => '',
			'css' => 'width:100%;min-height:100px;'
		),

		'widget-style-options-end' => array(
			'type'  => 'sectionend',
			'id'    => 'yith_wcmc_widget_style_fields_options'
		),
	)
) );