<div class="condition-item" id="condition_<?php echo esc_attr( $item_id ) ?>_<?php echo esc_attr( $condition_id ) ?>">
	<div class="condition-row">
		<div class="condition-column">
			<label for="yith_wcmc_advanced_integration_<?php echo esc_attr( $item_id ) ?>_conditions_<?php echo esc_attr( $condition_id ) ?>_condition"><?php _e( 'Condition', 'yith-wcmc' )?></label>
			<select class="condition_type" name="yith_wcmc_advanced_integration[<?php echo esc_attr( $item_id ) ?>][conditions][<?php echo esc_attr( $condition_id ) ?>][condition]" id="yith_wcmc_advanced_integration_<?php echo esc_attr( $item_id ) ?>_conditions_<?php echo esc_attr( $condition_id ) ?>_condition" style="width: 300px;">
				<option value="product_in_cart" <?php selected( $condition, 'product_in_cart' ) ?> ><?php _e( 'Product in cart', 'yith-wcmc' )?></option>
				<option value="product_cat_in_cart" <?php selected( $condition, 'product_cat_in_cart' ) ?> ><?php _e( 'Product category in cart', 'yith-wcmc' )?></option>
				<option value="order_total" <?php selected( $condition, 'order_total' ) ?> ><?php _e( 'Order total', 'yith-wcmc' )?></option>
				<option value="custom" <?php selected( $condition, 'custom' ) ?> ><?php _e( 'Custom', 'yith-wcmc' )?></option>
			</select>
		</div>
		<div class="condition-column">
			<label><?php _e( 'Details', 'yith-wcmc' )?></label>

			<!-- Operator set -->
			<select class="condition_op_set" name="yith_wcmc_advanced_integration[<?php echo esc_attr( $item_id ) ?>][conditions][<?php echo esc_attr( $condition_id ) ?>][op_set]" id="yith_wcmc_advanced_integration_<?php echo esc_attr( $item_id ) ?>_conditions_<?php echo esc_attr( $condition_id ) ?>_op_set" style="min-width: 300px;">
				<option value="contains_one" <?php selected( $op_set, 'contains_one' ) ?> ><?php _e( 'Contains at least one of', 'yith-wcmc' )?></option>
				<option value="contains_all" <?php selected( $op_set, 'contains_all' ) ?> ><?php _e( 'Contains all of', 'yith-wcmc' )?></option>
				<option value="not_contain" <?php selected( $op_set, 'not_contain' ) ?> ><?php _e( 'Does not contain', 'yith-wcmc' )?></option>
			</select>

			<!-- Operator number -->
			<select class="condition_op_number" name="yith_wcmc_advanced_integration[<?php echo esc_attr( $item_id ) ?>][conditions][<?php echo esc_attr( $condition_id ) ?>][op_number]" id="yith_wcmc_advanced_integration_<?php echo esc_attr( $item_id ) ?>_conditions_<?php echo esc_attr( $condition_id ) ?>_op_number" style="min-width: 300px;">
				<option value="less_than" <?php selected( $op_number, 'less_than' ) ?> ><?php _e( 'Less than', 'yith-wcmc' )?></option>
				<option value="less_or_equal" <?php selected( $op_number, 'less_or_equal' ) ?> ><?php _e( 'Less than or equal to', 'yith-wcmc' )?></option>
				<option value="equal" <?php selected( $op_number, 'equal' ) ?> ><?php _e( 'Equals to', 'yith-wcmc' )?></option>
				<option value="greater_or_equal" <?php selected( $op_number, 'greater_or_equal' ) ?> ><?php _e( 'Greater than or equal to', 'yith-wcmc' )?></option>
				<option value="greater_than" <?php selected( $op_number, 'greater_than' ) ?> ><?php _e( 'Greater than', 'yith-wcmc' )?></option>
			</select>

			<!-- Products -->
			<input type="hidden" class="condition_products wc-product-search" data-multiple="true" name="yith_wcmc_advanced_integration[<?php echo esc_attr( $item_id ) ?>][conditions][<?php echo esc_attr( $condition_id ) ?>][products]" id="yith_wcmc_advanced_integration_<?php echo esc_attr( $item_id ) ?>_conditions_<?php echo esc_attr( $condition_id ) ?>_products" data-action="woocommerce_json_search_products_and_variations" data-selected="<?php echo esc_attr( json_encode( $json_ids ) )?>" style="min-width: 300px;" data-placeholder="<?php _e( 'Search for a product&hellip;', 'yith-wcmc' ); ?>" value="<?php echo implode( ',', array_keys( $json_ids ) ); ?>" />

			<!-- Products cat -->
			<select class="wc-enhanced-select condition_cats" multiple="multiple" name="yith_wcmc_advanced_integration[<?php echo esc_attr( $item_id ) ?>][conditions][<?php echo esc_attr( $condition_id ) ?>][prod_cats][]" id="yith_wcmc_advanced_integration_<?php echo esc_attr( $item_id ) ?>_conditions_<?php echo esc_attr( $condition_id ) ?>_prod_cats" style="min-width: 300px;" data-placeholder="<?php _e( 'Select a category', 'yith-wcmc' ); ?>">
				<?php
				$categories   = get_terms( 'product_cat', 'orderby=name&hide_empty=0' );

				if ( $categories ) :
					foreach ( $categories as $cat ) :
					?>
					<option value="<?php echo esc_attr( $cat->term_id )?>" <?php selected( in_array( $cat->term_id, $prod_cats ) ) ?> ><?php echo esc_html( $cat->name )?></option>
				<?php
					endforeach;
				endif;
				?>
			</select>

			<!-- Order total -->
			<input class="condition_total" type="number" step="any" name="yith_wcmc_advanced_integration[<?php echo esc_attr( $item_id ) ?>][conditions][<?php echo esc_attr( $condition_id ) ?>][order_total]" id="yith_wcmc_advanced_integration_<?php echo esc_attr( $item_id ) ?>_conditions_<?php echo esc_attr( $condition_id ) ?>_order_total" placeholder="<?php _e( 'Threshold', 'yith-wcmc' )?>" style="min-width: 300px;" value="<?php echo esc_attr( $order_total ) ?>" />

			<!-- Custom key -->
			<input class="condition_key" type="text" name="yith_wcmc_advanced_integration[<?php echo esc_attr( $item_id ) ?>][conditions][<?php echo esc_attr( $condition_id ) ?>][custom_key]" id="yith_wcmc_advanced_integration_<?php echo esc_attr( $item_id ) ?>_conditions_<?php echo esc_attr( $condition_id ) ?>_custom_key" placeholder="<?php _e( 'Field name in checkout page', 'yith-wcmc' )?>" style="min-width: 300px;" value="<?php echo esc_attr( $custom_key ) ?>" />

			<!-- Operator mixed -->
			<select class="condition_op_mixed" name="yith_wcmc_advanced_integration[<?php echo esc_attr( $item_id ) ?>][conditions][<?php echo esc_attr( $condition_id ) ?>][op_mixed]" id="yith_wcmc_advanced_integration_<?php echo esc_attr( $item_id ) ?>_conditions_<?php echo esc_attr( $condition_id ) ?>_op_mixed" style="min-width: 300px;">
				<optgroup label="<?php _e( 'String operator', 'yith-wcmc' )?>">
					<option value="is" <?php selected( $op_mixed, 'is' ) ?> ><?php _e( 'Is', 'yith-wcmc' )?></option>
					<option value="not_is" <?php selected( $op_mixed, 'not_is' ) ?> ><?php _e( 'Is not', 'yith-wcmc' )?></option>
					<option value="contains" <?php selected( $op_mixed, 'contains' ) ?> ><?php _e( 'Contains', 'yith-wcmc' )?></option>
					<option value="not_contains" <?php selected( $op_mixed, 'not_contains' ) ?> ><?php _e( 'Does not contain', 'yith-wcmc' )?></option>
				</optgroup>
				<optgroup label="<?php _e( 'Number', 'yith-wcmc' )?>">
					<option value="less_than" <?php selected( $op_mixed, 'less_than' ) ?> ><?php _e( 'Less than', 'yith-wcmc' )?></option>
					<option value="less_or_equal" <?php selected( $op_mixed, 'less_or_equal' ) ?> ><?php _e( 'Less than or equal to', 'yith-wcmc' )?></option>
					<option value="equal" <?php selected( $op_mixed, 'equal' ) ?> ><?php _e( 'Equal to', 'yith-wcmc' )?></option>
					<option value="greater_or_equal" <?php selected( $op_mixed, 'greater_or_equal' ) ?> ><?php _e( 'Greater than or equal to', 'yith-wcmc' )?></option>
					<option value="greater_than" <?php selected( $op_mixed, 'greater_than' ) ?> ><?php _e( 'Greater than', 'yith-wcmc' )?></option>
				</optgroup>
			</select>

			<!-- Custom value -->
			<input class="condition_value" type="text" name="yith_wcmc_advanced_integration[<?php echo esc_attr( $item_id ) ?>][conditions][<?php echo esc_attr( $condition_id ) ?>][custom_value]" id="yith_wcmc_advanced_integration_<?php echo esc_attr( $item_id ) ?>_conditions_<?php echo esc_attr( $condition_id ) ?>_custom_value" placeholder="<?php _e( 'Field value in checkout page', 'yith-wcmc' )?>" style="min-width: 300px;" value="<?php echo esc_attr( $custom_value ) ?>" />
		</div>
		<a href="#" class="remove-button"><?php _e( 'Remove', 'yith-wcmc' )?></a>
	</div>
</div>