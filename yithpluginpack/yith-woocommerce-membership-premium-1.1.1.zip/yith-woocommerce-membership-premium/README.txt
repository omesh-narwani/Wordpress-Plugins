=== YITH WooCommerce Membership ===

Contributors: yithemes
Tags: membership, member, membership plan, member plan, plan, woocommerce, product, products, themes, yit, e-commerce, shop, yith, premium, yithemes
Requires at least: 3.5.1
Tested up to: 4.4.1
Stable tag: 1.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

YITH WooCommerce Membership allows you to create custom membership for the contents of your shop.


== Description ==

Do you have particular contents that you want to reveal only to specific users? The best solution is taking advantage of a powerful membership system that will let you control the access to certain products, posts or pages. An easy-to-use management offers you the freedom to set the level of access of your contents with a simple click.

In this way, all users of your shop will be able to purchase their membership with few steps, following a flexible process that will convert them in members, granting them the visualization of all your extra contents.


= Features: =

* Create a Membership
* Allow only members or non-members to access to products, pages and posts.

== Installation ==

1. Unzip the downloaded zip file.
2. Upload the plugin folder into the `wp-content/plugins/` directory of your WordPress site.
3. Activate `YITH WooCommerce Membership` from Plugins page

YITH WooCommerce Membership will add a new submenu called "Membership" under the "YIT Plugins" menu, from which you can manage your custom Membership.
To sell your Membership Plan, you have to create a virtual product, and then assign it to the Membership Plan.
The people that will buy this product will become members.
To restrict the access to products, posts or pages you can choose the "Allow access to" option in the Edit Page of each product, post or page.

== Screenshots ==

1. Admin view: Membership Settings
2. Admin view: Display membership in Product List
3. Admin view: "Allow access to" option for a product

== Changelog ==

= 1.1.1 =

* Tweak: fixed bug for current memberships without credits management

= 1.1.0 =

* Added: download credits management for membership
* Added: possibility to choose limit for membership downloads
* Added: membership and download reports
* Added: user download reports table and graphics in orders
* Added: status filters in Memberships WP List
* Added: compatibility with WooCommerce 2.5 RC2
* Tweak: fixed minor bug with bbPress
* Tweak: fixed membership bulk actions for users
* Tweak: fixed pot language file
* Tweak: changed menu name Memberships in All Memberships
* Tweak: fixed minor bugs

= 1.0.4 =

* Added: possibility to hide items directly in membership plan settings page
* Tweak: better styling management for membership item list (shortcode)
* Tweak: improved compatibility with YITH WooCommerce Multi Vendor
* Tweak: improved cron performance
* Tweak: fixed end date calculation after pause
* Tweak: fixed minor bugs

= 1.0.3 =

* Added: support for membership bought by guest users
* Added: shortcode for showing membership history
* Tweak: improved compatibility with YITH WooCommerce Multi Vendor
* Tweak: added possibility to hide membership history in My Account page
* Tweak: improved download list

= 1.0.2 =

* Initial release

== Suggestions ==

If you have suggestions about how to improve YITH WooCommerce Membership, you can [write us](mailto:plugins@yithemes.com "Your Inspiration Themes") so we can enhance our YITH WooCommerce Membership plugin.

== Translators ==

= Available Languages =
* English (Default)

If you have created your own language pack, or have an update for an existing one, you can send [gettext PO and MO file](http://codex.wordpress.org/Translating_WordPress "Translating WordPress")
[use](http://yithemes.com/contact "Your Inspiration Themes") so we can bundle it into YITH WooCommerce Membership

== Upgrade notice ==

= 1.0.0 =

Initial release