jQuery( function ( $ ) {
    $( '.tips' ).tipTip( {
        'attribute': 'data-tip',
        'fadeIn': 50,
        'fadeOut': 50,
        'delay': 0
    } );
} );