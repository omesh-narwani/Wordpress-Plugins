jQuery( function ( $ ) {
    $( 'div.create-account' ).show();
    $( 'p.create-account' ).hide();
} );