<?php
if ( !defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

/**
 * Shortcodes Class
 *
 * @class   YITH_WCMBS_Shortcodes
 * @package Yithemes
 * @since   1.0.0
 * @author  Yithemes
 *
 */
class YITH_WCMBS_Shortcodes {

    /**
     * Single instance of the class
     *
     * @var \YITH_WCMBS_Shortcodes
     * @since 1.0.0
     */
    protected static $instance;

    /**
     * Returns single instance of the class
     *
     * @return \YITH_WCMBS_Manager
     * @since 1.0.0
     */
    public static function get_instance() {
        $self = __CLASS__;

        if ( is_null( $self::$instance ) ) {
            $self::$instance = new $self;
        }

        return $self::$instance;
    }

    /**
     * Constructor
     *
     * @access public
     * @since  1.0.0
     */
    public function __construct() {
        /* Print WooCommerce Login form*/
        add_shortcode( 'loginform', array( $this, 'render_login_form' ) );

        /* Print link for protected media by ID of the media*/
        add_shortcode( 'protected_media', array( $this, 'render_protected_media_link' ) );

        /* Print the list of items in a membership plan */
        add_shortcode( 'membership_items', array( $this, 'render_list_items_in_plan' ) );

        /* Print link for product download files */
        add_shortcode( 'membership_download_product_links', array( $this, 'render_membership_download_product_links' ) );

        /* Print membership history */
        add_shortcode( 'membership_history', array( $this, 'print_membership_history' ) );

    }

    /**
     * Render Login Form
     *
     * EXAMPLE:
     * <code>
     *  [loginform]
     * </code>
     * this code displays the WooCommerce Login Form
     *
     * @access   public
     * @since    1.0.0
     *
     * @author   Leanza Francesco <leanzafrancesco@gmail.com>
     *
     * @param      $atts array the attributes of shortcode
     * @param null $content
     *
     * @return string
     */
    public function render_login_form( $atts, $content = null ) {
        ob_start();
        if ( !is_user_logged_in() ) {
            echo '<div class="woocommerce">';
            wc_get_template( 'myaccount/form-login.php' );
            echo '</div>';
        }

        return ob_get_clean();
    }


    /**
     * Render Protected Media Link for downloading
     *
     * EXAMPLE:
     * <code>
     *  [protected_media id=237]Link Text[/protected_media]
     * </code>
     * this code displays a link for protected media download
     *
     * @access   public
     * @since    1.0.0
     *
     * @author   Leanza Francesco <leanzafrancesco@gmail.com>
     *
     * @param      $atts array the attributes of shortcode
     * @param null $content
     *
     * @return string
     */
    public function render_protected_media_link( $atts, $content = null ) {
        if ( !empty( $atts[ 'id' ] ) && !empty( $content ) ) {
            $user_id = get_current_user_id();
            $post_id = $atts[ 'id' ];

            $manager = YITH_WCMBS_Manager();
            if ( $manager->user_has_access_to_post( $user_id, $post_id ) ) {

                $link = add_query_arg( array( 'protected_media' => $post_id ), home_url( '/' ) );

                $html = "<a href='{$link}'>";
                $html .= $content;
                $html .= "</a>";

                return $html;
            }
        }

        return '';
    }

    /**
     * Render Product Link for downloading
     *
     * EXAMPLE:
     * <code>
     *  [membership_download_product_links link_class="btn btn-class"] Download [/membership_download_product_links]
     * </code>
     * this code displays a link for protected product download files
     *
     * @access   public
     * @since    1.0.0
     *
     * @author   Leanza Francesco <leanzafrancesco@gmail.com>
     *
     * @param array  $atts the attributes of shortcode
     * @param string $content
     *
     * @return string
     */
    public function render_membership_download_product_links( $atts, $content = null ) {
        $r            = '';
        $default_atts = array(
            'link_class' => '',
        );

        $atts       = wp_parse_args( $atts, $default_atts );
        $link_class = $atts[ 'link_class' ];
        $return     = !empty( $content ) ? 'links' : 'links_names';
        $id         = !empty( $atts[ 'id' ] ) ? $atts[ 'id' ] : false;

        $links = YITH_WCMBS_Products_Manager()->get_download_links( array( 'return' => 'links_names', 'id' => $id ) );

        if ( !empty( $links ) ) {
            foreach ( $links as $link ) {
                switch ( $return ) {
                    case 'links':
                        $my_link         = $link[ 'link' ];
                        $my_name         = $link[ 'name' ];
                        $just_downloaded = $link[ 'unlocked' ];
                        $locked          = $just_downloaded ? 'unlocked' : 'locked';
                        $link_class .= ' ' . $locked;
                        $link_class .= ' yith-tooltips';
                        $data = '';
                        if ( $locked == 'locked' ) {
                            $data .= 'data-locked="' . __( 'Locked Download: unlock it using one credit!', 'yith-woocommerce-membership' ) . '"';
                        }

                        $r .= "<a class='{$link_class}' {$data} href='{$my_link}' title='{$my_name}'>{$content}</a>";
                        break;
                    case 'links_names':
                        $my_link         = $link[ 'link' ];
                        $my_name         = $link[ 'name' ];
                        $just_downloaded = $link[ 'unlocked' ];
                        $locked          = $just_downloaded ? 'unlocked' : 'locked';
                        $link_class .= ' ' . $locked;

                        $data = '';
                        if ( $locked == 'locked' ) {
                            $link_class .= ' yith-tooltips';
                            $data = 'title="' . __( 'Locked Download: unlock it using one credit!', 'yith-woocommerce-membership' ) . '"';
                        }

                        $r .= "<a class='{$link_class}' {$data} href='{$my_link}'>{$my_name}</a>";
                        break;
                }
            }
        }

        return $r;
    }


    /**
     * Print the list of items in a membership plan
     *
     * EXAMPLE:
     * <code>
     *  [membership_items plan=237]
     * </code>
     * this code displays the list of items in the membership plan with ID = 237
     *
     * @access   public
     * @since    1.0.0
     *
     * @author   Leanza Francesco <leanzafrancesco@gmail.com>
     *
     * @param      $atts array the attributes of shortcode
     * @param null $content
     *
     * @return string
     */
    public function render_list_items_in_plan( $atts, $content = null ) {
        if ( !empty( $atts[ 'plan' ] ) ) {
            $user_id = get_current_user_id();
            $plan_id = $atts[ 'plan' ];

            $member = YITH_WCMBS_Members()->get_member( $user_id );
            if ( current_user_can( 'create_users' ) || ( !empty( $member ) && $member->has_active_plan( $plan_id ) ) ) {
                $allowed_in_plan = YITH_WCMBS_Manager()->get_allowed_posts_in_plan( $plan_id, true );
                $ordered_items   = get_post_meta( $plan_id, '_yith_wcmbs_plan_items', true );
                $ordered_items   = !empty( $ordered_items ) ? $ordered_items : array();

                foreach ( $ordered_items as $key => $item ) {
                    if ( is_numeric( $item ) ) {
                        if ( !in_array( $item, $allowed_in_plan ) ) {
                            unset( $ordered_items[ $key ] );
                        }
                    }
                }

                $plan_list_styles = get_post_meta( $plan_id, '_yith_wcmbs_plan_list_styles', true );
                $show_icons       = isset( $plan_list_styles[ 'show_icons' ] ) ? ( $plan_list_styles[ 'show_icons' ] == 'yes' ) : true;

                if ( !empty( $allowed_in_plan ) ) {
                    foreach ( $allowed_in_plan as $item_id ) {
                        if ( !in_array( $item_id, $ordered_items ) )
                            $ordered_items[ ] = $item_id;
                    }
                }

                $active_plan = $member->get_oldest_active_plan( $plan_id );

                $t_args = array(
                    'posts'       => $ordered_items,
                    'plan_id'     => $plan_id,
                    'show_icons'  => $show_icons,
                    'active_plan' => $active_plan

                );

                ob_start();
                wc_get_template( '/frontend/plan_list_items.php', $t_args, YITH_WCMBS_TEMPLATE_PATH, YITH_WCMBS_TEMPLATE_PATH );
                $html = ob_get_clean();

                return $html;
            }
        }

        return '';
    }

    /**
     * Print the list of items in a membership plan
     *
     * EXAMPLE:
     * <code>
     *  [membership_history]
     * </code>
     * this code displays the history for all user memberships
     *
     * EXAMPLE 2:
     * <code>
     *  [membership_history id="123" title="Title"]
     * </code>
     * this code displays the history user membership with id 123
     *
     * @access   public
     * @since    1.0.0
     *
     * @author   Leanza Francesco <leanzafrancesco@gmail.com>
     *
     * @param      $atts array the attributes of shortcode
     * @param null $content
     *
     * @return string
     */
    public function print_membership_history( $atts, $content = null ) {
        $user_plans = array();
        $title      = isset( $atts[ 'title' ] ) ? $atts[ 'title' ] : '';

        $no_membership_message = '';

        if ( empty( $atts[ 'id' ] ) ) {
            // ALL MEMBERSHIPS
            $user_id = get_current_user_id();

            $member     = new YITH_WCMBS_Member_Premium( $user_id );
            $user_plans = $member->get_membership_plans( array(
                'return' => 'complete',
                'status' => 'any',
            ) );

            // filter all user membership in base of type (only memberships, only subscriptions)
            $type = isset( $atts[ 'type' ] ) ? $atts[ 'type' ] : '';
            switch ( $type ) {
                case 'membership':
                    foreach ( $user_plans as $key => $membership ) {
                        if ( $membership->has_subscription() )
                            unset( $user_plans[ $key ] );
                    }
                    $no_membership_message = '<p>' . __( 'You don\'t have any membership without a subscription plan yet.', 'yith-woocommerce-membership' ) . '</p>';
                    break;
                case 'subscription':
                    foreach ( $user_plans as $key => $membership ) {
                        if ( !$membership->has_subscription() )
                            unset( $user_plans[ $key ] );
                    }
                    $no_membership_message = '<p>' . __( 'You don\'t have any membership with a subscription plan yet.', 'yith-woocommerce-membership' ) . '</p>';
                    break;
                default:
                    $no_membership_message = '<p>' . __( 'You don\'t have any membership yet.', 'yith-woocommerce-membership' ) . '</p>';
                    break;
            }

        } else {
            $membership_id = $atts[ 'id' ];
            $membership    = new YITH_WCMBS_Membership( $membership_id );
            $user_plans    = ( $membership->is_valid() && $membership->user_id == get_current_user_id() ) ? array( $membership ) : array();

            if ( empty( $user_plans ) )
                return;
        }

        $args = array(
            'user_plans'            => $user_plans,
            'title'                 => $title,
            'no_membership_message' => $no_membership_message
        );

        wc_get_template( '/frontend/my_account_membership_plans.php', $args, YITH_WCMBS_TEMPLATE_PATH, YITH_WCMBS_TEMPLATE_PATH );
    }


}

/**
 * Unique access to instance of YITH_WCMBS_Shortcodes class
 *
 * @return YITH_WCMBS_Shortcodes
 * @since 1.0.0
 */
function YITH_WCMBS_Shortcodes() {
    return YITH_WCMBS_Shortcodes::get_instance();
}