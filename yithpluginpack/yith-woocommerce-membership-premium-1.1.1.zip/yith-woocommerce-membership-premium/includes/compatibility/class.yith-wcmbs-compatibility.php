<?php
if ( !defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

/**
 * Compatibility Class
 *
 * @class   YITH_WCMBS_Compatibility
 * @package Yithemes
 * @since   1.0.0
 * @author  Yithemes
 *
 */
class YITH_WCMBS_Compatibility {

    /**
     * Single instance of the class
     *
     * @var \YITH_WCMBS_Compatibility
     * @since 1.0.0
     */
    protected static $instance;

    /**
     * Returns single instance of the class
     *
     * @return \YITH_WCMBS_Compatibility
     * @since 1.0.0
     */
    public static function get_instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * Constructor
     *
     * @access public
     * @since  1.0.0
     */
    public function __construct() {
        YITH_WCMBS_Multivendor_Compatibility();
        YITH_WCMBS_Subscription_Compatibility();
    }

    /**
     * Check if user has YITH Subscription Premium plugin
     *
     * @author Leanza Francesco <leanzafrancesco@gmail.com>
     * @since  1.0
     * @return bool
     */
    static function has_subscription_plugin() {
        return defined( 'YITH_YWSBS_PREMIUM' ) && YITH_YWSBS_PREMIUM;
    }

    /**
     * Check if user has YITH Multivendor Premium plugin
     *
     * @author Leanza Francesco <leanzafrancesco@gmail.com>
     * @since  1.0
     * @return bool
     */
    static function has_multivendor_plugin() {
        return defined( 'YITH_WPV_PREMIUM' ) && YITH_WPV_PREMIUM && defined( 'YITH_WPV_VERSION' ) && version_compare( YITH_WPV_VERSION, apply_filters( 'yith_wcmbs_multivendor_min_version', '1.5.0' ), '>' );
    }
}

/**
 * Unique access to instance of YITH_WCMBS_Compatibility class
 *
 * @return YITH_WCMBS_Compatibility
 * @since 1.0.0
 */
function YITH_WCMBS_Compatibility() {
    return YITH_WCMBS_Compatibility::get_instance();
}