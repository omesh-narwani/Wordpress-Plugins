<?php

if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( !class_exists( 'YITH_WCMBS_Expiring_Mail' ) ) :

    /**
     * Membership Welcome Email
     *
     * @class       YITH_WCMBS_Welcome_Mail
     * @version     1.0.0
     * @package     YITH WooCommerce Membership Premium
     * @author      Yithemes
     * @extends     WC_Email
     */
    class YITH_WCMBS_Expiring_Mail extends WC_Email {

        public $custom_message;

        /**
         * Constructor
         */
        function __construct() {

            $this->id          = 'membership_expiring';
            $this->title       = __( 'Membership Expiring', 'yith-woocommerce-membership' );
            $this->description = __( 'Membership Expiring email is sent when a membership is expiring.', 'yith-woocommerce-membership' );

            $this->template_html  = '/emails/membership-expiring.php';
            $this->template_plain = '/emails/plain/membership-expiring.php';

            $this->subject = __( 'Membership {membership_name} is expiring', 'yith-woocommerce-membership' );
            $this->heading = __( 'Membership {membership_name} is expiring', 'yith-woocommerce-membership' );

            // Triggers
            add_action( 'yith_wcmbs_membership_expiring_notification', array( $this, 'trigger' ) );

            // Other settings
            $this->custom_message = $this->get_option( 'custom_message', __( 'Dear Customer {firstname} {lastname}, your membership {membership_name} will expire on {membership_expire_date}.', 'yith_wcmbs' ) );

            // Call parent constructor
            parent::__construct();
        }


        /**
         * Trigger.
         *
         * @param array $args
         */
        function trigger( $args ) {

            if ( !$this->is_enabled() ) {
                return;
            }

            if ( $args ) {
                $default = array(
                    'user_id'    => 0,
                    'membership' => false
                );

                $args = wp_parse_args( $args, $default );
                extract( $args );

                if ( $membership instanceof YITH_WCMBS_Membership ) {
                    $user = get_user_by( 'id', $user_id );

                    $plan_post = get_post( $membership->id );
                    if ( !$plan_post )
                        return;

                    $this->find[ 'firstname' ]              = '{firstname}';
                    $this->find[ 'lastname' ]               = '{lastname}';
                    $this->find[ 'membership-name' ]        = '{membership_name}';
                    $this->find[ 'membership-expire-date' ] = '{membership_expire_date}';

                    $this->replace[ 'firstname' ]              = $user->user_firstname;
                    $this->replace[ 'lastname' ]               = $user->user_lastname;
                    $this->replace[ 'membership-name' ]        = $membership->get_plan_title();
                    $this->replace[ 'membership-expire-date' ] = $membership->get_formatted_date( 'end_date' );

                    $user = get_user_by( 'id', $user_id );

                    $this->recipient = $user->user_email;

                    if ( $this->get_recipient() ) {
                        $this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
                    }
                }

            }
        }

        /**
         * get_content_html function.
         *
         * @access public
         * @return string
         */
        function get_content_html() {
            ob_start();
            wc_get_template( $this->template_html, array(
                'email_heading'  => $this->get_heading(),
                'custom_message' => $this->format_string( $this->custom_message ),
            ), YITH_WCMBS_TEMPLATE_PATH, YITH_WCMBS_TEMPLATE_PATH );

            return ob_get_clean();
        }

        /**
         * Get content plain.
         *
         * @return string
         */
        function get_content_plain() {
            ob_start();
            wc_get_template( $this->template_plain, array(
                'email_heading'  => $this->get_heading(),
                'custom_message' => $this->format_string( $this->custom_message ),
            ), YITH_WCMBS_TEMPLATE_PATH, YITH_WCMBS_TEMPLATE_PATH );

            return ob_get_clean();
        }


        /**
         * Initialise Settings Form Fields - these are generic email options most will use.
         */
        public function init_form_fields() {
            $this->form_fields = array(
                'enabled'        => array(
                    'title'   => __( 'Enable/Disable', 'woocommerce' ),
                    'type'    => 'checkbox',
                    'label'   => __( 'Enable this email notification', 'woocommerce' ),
                    'default' => 'yes'
                ),
                'subject'        => array(
                    'title'       => __( 'Email Subject', 'woocommerce' ),
                    'type'        => 'text',
                    'description' => sprintf( __( 'Defaults to <code>%s</code>', 'woocommerce' ), $this->subject ),
                    'placeholder' => '',
                    'default'     => ''
                ),
                'heading'        => array(
                    'title'       => __( 'Email Heading', 'woocommerce' ),
                    'type'        => 'text',
                    'description' => sprintf( __( 'Defaults to <code>%s</code>', 'woocommerce' ), $this->heading ),
                    'placeholder' => '',
                    'default'     => ''
                ),
                'custom_message' => array(
                    'title'       => __( 'Custom Message', 'yith-woocommerce-membership' ),
                    'type'        => 'textarea',
                    'description' => sprintf( __( 'Defaults to <code>%s</code>', 'woocommerce' ), $this->custom_message ),
                    'placeholder' => '',
                    'default'     => ''
                ),
                'email_type'     => array(
                    'title'       => __( 'Email type', 'woocommerce' ),
                    'type'        => 'select',
                    'description' => __( 'Choose which format of email to send.', 'woocommerce' ),
                    'default'     => 'html',
                    'class'       => 'email_type wc-enhanced-select',
                    'options'     => $this->get_email_type_options()
                )
            );
        }

    }

endif;

return new YITH_WCMBS_Expiring_Mail();