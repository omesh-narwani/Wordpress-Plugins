<?php
/*
 * Template for Plan List Items in frontend
 */

$manager = YITH_WCMBS_Manager();
?>
<?php
if ( !empty( $posts ) ) {

    $plan_id = $plan->plan_id;

    echo "<ul class='yith-wcmbs-plan-list-items'>";

    $content_start     = '<ul class="child">';
    $content_end       = '</ul></li>';
    $print_content_end = false;

    $loop             = 0;

    $products_manager = YITH_WCMBS_Products_Manager();

    foreach ( $posts as $value ) {
        if ( is_numeric( $value ) ) {
            $post_title = get_the_title( $value );
            $post_type  = get_post_type( $value );
            $post_link  = $manager->get_post_link( $value, get_current_user_id() );

            $post_type_icon = "<span class='yith-wcmbs-post-type-icon yith-wcmbs-post-type-icon-{$post_type}'></span>";

            $text_html = !empty( $post_link ) ? "<a href='{$post_link}'>{$post_type_icon} {$post_title}</a>" : "{$post_type_icon} {$post_title}";

            $delay_time = get_post_meta( $value, '_yith_wcmbs_plan_delay', true );

            $access = false;
            if ( $post_type == 'product' ) {
                if ( $products_manager->is_allowed_download() ) {
                    $access = YITH_WCMBS_Products_Manager()->user_has_access_to_product( get_current_user_id(), $value );
                }
            } else {
                $access = $manager->user_has_access_to_post( get_current_user_id(), $value );
            }

            if ( !empty( $delay_time[ $plan_id ] ) && !$access ) {
                // The item has delay time for this plan
                $delay = $delay_time[ $plan_id ];

                if ( $plan->is_active() ) {
                    $availability_date = date( wc_date_format(), strtotime( '+ ' . $delay . ' days', $plan->start_date + ( $plan->paused_days * 60 * 60 * 24 ) ) );

                    $text_html .= '<span class="yith-wcmbs-plan-items-availability-info">' . sprintf( __( 'Availability date: %s ', 'yith-woocommerce-membership' ), $availability_date ) . '</span>';
                } else {
                    $text_html .= '<span class="yith-wcmbs-plan-items-availability-info">' . sprintf( _n( 'available after %s day since the beginning of the membership', 'available after %s days since the beginning of the membership', $delay, 'yith-woocommerce-membership' ), $delay ) . '</span>';
                }
            }
            if ( $post_type == 'product' ) {
                $text_html .= do_shortcode( '[membership_download_product_links link_class="yith-wcmbs-download-links" id="' . $value . '"]<span class="dashicons dashicons-download"></span>[/membership_download_product_links]' );
            }

            echo "<li class='yith-wcmbs-plan-item' rel='{$loop}'>{$text_html}</li>";

        } elseif ( is_string( $value ) ) {
            if ( $print_content_end ) {
                echo $content_end;
                $print_content_end = false;
            }

            echo "<li class='yith-wcmbs-plan-item-text' rel='{$loop}'><h5>{$value}</h5>";

            echo $content_start;
            $print_content_end = true;

        } else {
            continue;
        }
        $loop++;
    }

    if ( $print_content_end ) {
        echo $content_end;
    }
    echo '</ul>';
}
?>
