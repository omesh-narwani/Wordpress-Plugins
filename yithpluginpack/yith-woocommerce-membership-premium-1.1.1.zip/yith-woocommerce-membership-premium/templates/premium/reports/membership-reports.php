<?php
/*
 * Template for Membership Reports
 */
?>
<div class="postbox yith-wcmbs-reports-metabox">
    <h2><span><?php _e( 'Active memberships', 'yith-woocommerce-membership' ) ?></span></h2>

    <div class="yith-wcmbs-reports-content">
        <div class="yith-wcmbs-reports-big-number"><?php echo YITH_WCMBS_Membership_Helper()->get_count_active_membership() ?></div>
    </div>
</div>
<div class="postbox yith-wcmbs-reports-metabox">
    <h2><span><?php _e( 'Last actived memberships', 'yith-woocommerce-membership' ) ?></span></h2>

    <div class="yith-wcmbs-reports-content">
        <table class="yith-wcmbs-reports-table-membership">
            <tr>
                <th><?php _e( 'Today', 'yith-woocommerce-membership' ) ?></th>
                <td><?php echo YITH_WCMBS_Membership_Helper()->get_count_actived_membership( 'today' ) ?></td>
            </tr>
            <tr>
                <th><?php _e( '7days', 'yith-woocommerce-membership' ) ?></th>
                <td><?php echo YITH_WCMBS_Membership_Helper()->get_count_actived_membership( '7day' ) ?></td>
            </tr>
            <tr>
                <th><?php _e( 'This month', 'yith-woocommerce-membership' ) ?></th>
                <td><?php echo YITH_WCMBS_Membership_Helper()->get_count_actived_membership( 'month' ) ?></td>
            </tr>
            <tr>
                <th><?php _e( 'Last month', 'yith-woocommerce-membership' ) ?></th>
                <td><?php echo YITH_WCMBS_Membership_Helper()->get_count_actived_membership( 'last_month' ) ?></td>
            </tr>
            <tr>
                <th><?php _e( 'This year', 'yith-woocommerce-membership' ) ?></th>
                <td><?php echo YITH_WCMBS_Membership_Helper()->get_count_actived_membership( 'year' ) ?></td>
            </tr>
        </table>
    </div>
</div>
<div class="postbox yith-wcmbs-reports-metabox">
    <h2><span><?php _e( 'Total membership (ever)', 'yith-woocommerce-membership' ) ?></span></h2>

    <div class="yith-wcmbs-reports-content">
        <div class="yith-wcmbs-reports-big-number"><?php echo YITH_WCMBS_Membership_Helper()->get_count_actived_membership( 'ever' ) ?></div>
    </div>
</div>
