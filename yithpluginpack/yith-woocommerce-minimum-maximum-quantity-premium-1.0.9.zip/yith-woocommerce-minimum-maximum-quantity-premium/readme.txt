﻿=== YITH WooCommerce Minimum Maximum Quantity ===

Contributors: yithemes
Tags: woocommerce, products, themes, yit, yith, yithemes, e-commerce, shop, minimum quantity, maximum quantity
Requires at least: 4.0
Tested up to: 4.4.2
Stable tag: 1.0.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

YITH WooCommerce Minimum Maximum Quantity allows you to set a minimum and/or maximum quantity for purchases in your shop

== Changelog ==

= 1.0.9 =

* Added: product quantity starts from minimum value
* Fixed: variation saving issues

= 1.0.8 =

* Fixed: category value calculation

= 1.0.7 =

* Fixed: error with product variations

= 1.0.6 =

* Updated: language file

= 1.0.5 =

* Fixed: The notices in the cart still remains even if the conditions have been fulfilled

= 1.0.4 =

* Updated: plugin core framework
* Updated: file class-yith-wc-custom-textarea.php

= 1.0.3 =

* Updated: changed text domain from ywmmq to yith-woocommerce-minimum-maximum-quantity
* Updated: changed all language file for the new text domain

= 1.0.1 =

* Updated: plugin core framework
* Fixed: notification on bulk operations page

= 1.0.0 =

* Initial release