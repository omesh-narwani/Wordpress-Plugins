<?php

return array(
	'premium' => array(
		'home' => array(
			'type'   => 'custom_tab',
			'action' => 'yith_wcms_premium_tab',
		)
	)
);