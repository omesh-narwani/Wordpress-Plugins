=== YITH WooCommerce Multi-step Checkout Premium ===

Contributors: yithemes
Tags: woocommerce, multi-step checkout, yit, yith, yithemes
Requires at least: 4.0
Tested up to: 4.4.1
Stable tag: 1.1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= 1.1.3 =

* Added: yith_wcms_load_checkout_template_from_plugin hook to enable main template overriding by theme
* Added: Support to WooCommerce Gateway Stripe plugin
* Fixed: Place order button text doesn't work

= 1.1.2 =

* Fixed: Checkout as guest doesn't work

= 1.1.1 =

* Updated: Plugin core framework

= 1.1.0 =

* Added: Support to WooCommerce 2.5-RC1
* Added: Support to WordPress 4.4.1
* Added: wpml-config.xml file for WPML Support
* Added: Disable previous button in last step
* Tweak: Plugin core framework
* Updated: All language files

= 1.0.8 =

* Tweak: Required checkout fields get correct class from localize script
* Updated: Text domain from yith_wcms to yith-woocommerce-multi-step-checkout

= 1.0.7 =

* Fixed: issue in paying old unpaid orders

= 1.0.6 =

* Added: Partial Spanish translation (by Daniel Aparisi)
* Tweak: Performance improved with new plugin core 2.0

= 1.0.5 =

* Fixed: Fatal error on form-checkout.php template if overwrite by theme

= 1.0.4 =

* Added: Italian translation (By Lidia Cirrone)
* Fixed: jQuery Issue With Payment Methods

= 1.0.3 =

* Added: Support to WooCommerce 2.4

= 1.0.2 =

* Fixed: Warning on checkout login page

= 1.0.1 =

* Initial release