<div class="vacation woocommerce-info">
    <?php echo $vacation_message; ?>
</div>
