=== YITH WooCommerce Name Your Price ===

Contributors: yithemes
Tags: WooCommerce, ecommerce, name your price, WooCommerce name your price, pay a coffe, shop, yith, yit, yithemes
Requires at least: 3.5.1
Tested up to: 4.4
Stable tag: 1.0.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


Give your users the freedom to choose how much they want to pay with YITH WooCommerce Name Your Price.


== Description ==

What's better than let your customers decide how much they would like to spend? Think about it: whether they are purchasing a song or a book, the emotional attachment to that particular product could encourage them to spend more than the regular price you would expect.
But think about the exact opposite: maybe offering something completely free to catch you users' attention could be also a powerful marketing action, so that they will decide freely to pay you up for something you would also give for free. YITH WooCommerce Name Your Price will unchain you and your customers from fixed prices for your products: feel free to set it on the product you want and see how much your customers would like to spend for it!


== Changelog ==

= 1.0.6 =

* Fixed: Disabled ajax add to cart for "name your price" product
* Updated: Language File
* Updated: Plugin Framework

= 1.0.5 =

* Added: Compatibility with YITH WooCommerce Added to Cart Popup Premium

= 1.0.4 =

* Added: Compatibility with WooCommerce Multilingual (multi-currency support)
* Updated: Plugin Framework
* Fixed: Minor bug

= 1.0.3 =

* Fixed: icon sale visible when product is "name your price"
* Fixed : strikethrough line missing when product is on sale

= 1.0.2 =

* Fixed: Invalid price when the Decimal Separator is a comma
* Updated : Plugin Framework

= 1.0.1 =

* Initial release

== Upgrade Notice ==

Last Stable Tag 1.0.6