<?php
if( !defined( 'ABSPATH' ) )
    exit;

if( !class_exists( 'YITH_WC_Name_Your_Price_Premium_Frontend' ) ) {
    /**
     * implement free frontend features
     * Class YITH_WC_Name_Your_Price_Frontend
     */
    class YITH_WC_Name_Your_Price_Premium_Frontend extends YITH_WC_Name_Your_Price_Frontend
    {

        /**
         * @var YITH_WC_Name_Your_Price_Frontend , single instance
         */
        protected static $instance;

        /**
         * __construct function
         * @author YIThemes
         * @since 1.0.0
         */
        public function __construct(){


            parent::__construct();
            // print the template for grouped product
            add_action( 'woocommerce_grouped_product_list_before_price', array( $this, 'print_template_grouped_product' ) );
            //
            add_filter( 'woocommerce_available_variation', array( $this, 'set_nameyourprice_in_variation'), 20, 3 );

            add_filter( 'woocommerce_product_single_add_to_cart_text', array( $this, 'set_add_to_cart_text'), 5, 2 );

            add_filter( 'woocommerce_cart_item_subtotal', array( $this, 'change_price_in_cart_html' ), 100, 3 );
            add_filter( 'woocommerce_cart_item_price', array( $this, 'change_price_in_cart_html' ), 100, 3 );

            //include frontend style
            add_action( 'wp_enqueue_scripts', array( $this, 'include_frontend_style') );
            //include premium script
            add_action( 'wp_enqueue_scripts', array( $this, 'include_frontend_script') );

        }


        /**@author YIThemes
         * @since 1.0.0
         * @param $product
         */
        public function  print_template_grouped_product( $product ){

            ob_start();

            wc_get_template('single-product/nameyourprice-grouped.php', array(), '', YWCNP_TEMPLATE_PATH );
            $template = ob_get_contents();

            ob_end_clean();
            echo $template;

        }

        /**
         * @author YIThemes
         * @since 1.0.0
         * @param $cart_item_data
         * @param $product_id
         * @param $variation_id
         */
        public function yith_wc_name_your_price_add_cart_item_data( $cart_item_data, $product_id, $variation_id ) {

            if( isset( $_REQUEST['ywcnp_amount'] ) ){

                if( $variation_id )
                    $product_id = $variation_id;

                //add compatibility for grouped
                $amount = isset ( $_REQUEST['ywcnp_amount'][$product_id] ) ? $_REQUEST['ywcnp_amount'][$product_id] : $_REQUEST['ywcnp_amount'];
                $cart_item_data['ywcnp_amount'] =   floatval( ywcnp_format_number( $amount ) );

                $cart_item_data = apply_filters( 'ywcnp_add_cart_item_data', $cart_item_data, $product_id );

            }


            return $cart_item_data;
        }

        /**
         * @param $price_html
         * @param $cart_item
         * @param $cart_item_key
         * @return string
         */
        public function change_price_in_cart_html( $price_html, $cart_item, $cart_item_key ){

            $product_id = !empty($cart_item['variation_id']) ? $cart_item['variation_id'] : $cart_item['product_id'];
            $product = wc_get_product($product_id);


            if( ywcnp_product_is_name_your_price( $product_id ) ){

                $is_subtotal = current_filter() == 'woocommerce_cart_item_subtotal' ? true : false;
                $sub_price_html="";

                // Set quantity for 1 item if it's "price" column
                if ( !$is_subtotal ) {

                    $quantity = 1;
                }
                else {
                    $quantity = $cart_item['quantity'];

                    if ( $product->is_taxable() ) {

                        if ( WC()->cart->tax_display_cart == 'excl' )
                            $sub_price_html = ' <small class="tax_label">' . WC()->countries->ex_tax_or_vat() . '</small>';
                        else
                            $sub_price_html = ' <small class="tax_label">' . WC()->countries->inc_tax_or_vat() . '</small>';

                    }
                }

                // Get current item price in cart depending on tax display mode
                if ( WC()->cart->tax_display_cart == 'excl' ) {
                    $price = $cart_item['line_subtotal'];
                }
                else {
                    $price = $cart_item['line_subtotal'] + $cart_item['line_subtotal_tax'];
                }

                if ( ywcnp_product_has_subscription( $product_id ) )

                    $price_html = ywcnp_get_price_subscription( $product_id, wc_price( $product->get_display_price( $cart_item['ywcnp_amount'], $quantity ) ) );

                 else
                $price_html = wc_price( $product->get_display_price( $cart_item['ywcnp_amount'], $quantity ) ).$sub_price_html;


            }
            return $price_html;

        }

        /**
         * validation  product
         * @author YIThemes
         * @since 1.0.0
         * @param $passed
         * @param $amount
         * @param $product
         * @return bool
         */
        public function ywcnp_add_cart_validation( $passed, $amount, $product_id ){

            $error_message = '';

            //if add a grouped product
            if( is_array( $amount ) ){

                $amount = $amount[$product_id];
            }
            $amount = floatval( ywcnp_format_number( $amount ) );

            if( !is_numeric( $amount ) ) {
                $error_message = ywcnp_get_error_message( 'invalid_price' );
                $passed= false;
            }
           else {
               if ($amount < 0) {
                   $error_message = ywcnp_get_error_message('negative_price');
                   $passed = false;
               }

               $min_price = ywcnp_get_min_price($product_id);
               $max_price = ywcnp_get_max_price($product_id);

               $min_price = empty( $min_price ) ? 0 : floatval( ywcnp_format_number( $min_price ) );
               $max_price = empty( $max_price ) ? 0 : floatval( ywcnp_format_number( $max_price ) );

               if( is_numeric( $min_price ) && $min_price>0 && $amount < $min_price ) {
                   $error_message = ywcnp_get_error_message('min_error');
                   $passed = false;
               }

               if( is_numeric( $max_price ) && $max_price>0 && $amount > $max_price) {
                   $error_message = ywcnp_get_error_message('max_error');
                   $passed = false;
               }
           }
            if( $error_message )
                wc_add_notice( $error_message, 'error');

            return $passed;

        }

        /**
         * include style in frontend
         * @author YIThemes
         * @since 1.0.0
         */
        public function include_frontend_style(){

            wp_enqueue_style( 'ywcnp_premium_style', YWCNP_ASSETS_URL.'css/ywcnp_frontend_style.css' , array(), YWCNP_VERSION ,'all' );
        }

        /**
         * include frontend script
         * @author YIThemes
         * @since 1.0.0
         */
        public function include_frontend_script(){

            $suffix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';
            $wc_ver = version_compare( WC()->version,'2.5.0', '>=' ) ? '_2_5' : '';
            wp_enqueue_script( 'yit_name_your_price_premium_frontend', YWCNP_ASSETS_URL.'js/ywcnp_premium_frontend'.$wc_ver.$suffix.'.js', array('jquery'),  YWCNP_VERSION, true );
        }

        /** Set add to cart text for simple product
         * @author YIThemes
         * @since 1.0.0
         * @param $add_to_cart_text
         * @param $product
         * @return mixed|void
         */
        public function set_add_to_cart_text( $add_to_cart_text, $product ){

            if( ywcnp_product_is_name_your_price( $product->id ) && $product->is_type('simple') ){

                if( ywcnp_product_has_subscription( $product->id ) )
                    return get_option( 'ywsbs_add_to_cart_label' );
                else
                    return get_option( 'ywcnp_button_single_label' );

            }
            return $add_to_cart_text;
        }
        /**
         * Returns an array of date for a variation. Used in the add to cart form.
         * @author YIThemes
         * @since 1.0.0
         * @param $variation_data
         * @param $product
         * @param $variation
         */
        public function set_nameyourprice_in_variation(  $variation_data, $product, $variation ){

            $is_name_your_price = get_post_meta( $variation->variation_id, '_ywcnp_enabled_variation', true );


            if( 'yes' == $is_name_your_price ){
                $variation_data['ywcnp_variation'] = 'yes';
                $variation_data['ywcnp_variation_sugg_price']   =   ywcnp_get_suggest_price( $variation->variation_id );
                $variation_data['ywcnp_variation_min_price']    =   ywcnp_get_min_price( $variation->variation_id );
                $variation_data['ywcnp_variation_max_price']    =   ywcnp_get_max_price( $variation->variation_id );
                $variation_data['ywcnp_variation_sugg_price_html']    =   ywcnp_get_suggest_price_html( $variation->variation_id ) ;
                $variation_data['ywcnp_variation_min_price_html']    =    ywcnp_get_min_price_html( $variation->variation_id  );
                $variation_data['ywcnp_variation_max_price_html']    =   ywcnp_get_max_price_html( $variation->variation_id  );
                $variation_data['add_to_cart_text'] = ywcnp_product_has_subscription( $variation->variation_id ) ?  get_option( 'ywsbs_add_to_cart_label' ) : get_option( 'ywcnp_button_single_label' );

            }

            return $variation_data;
        }


        /**
         * return single instance
         * @author YIThemes
         * @since 1.0.0
         * @return YITH_WC_Name_Your_Price_Frontend
         */
        public static function get_instance()
        {
            if (is_null(self::$instance)) {
                self::$instance = new self();
            }

            return self::$instance;
        }


    }
}