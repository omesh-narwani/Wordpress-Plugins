= 1.0.2 =

* Added: Compatibility with YITH WooCommerce Customize My Account Page.
* Added: Shortcode [yith_wocc_myaccount] to print the my-account plugin section
* Updated: Language file .pot
* Updated: Plugin Core

= 1.0.1 =

* Added: Compatibility with WooCommerce 2.5 RC2.
* Updated: Plugin Core

= 1.0.0 =

* Initial release
