<?php

if( ! function_exists( 'yith_wocc_product_is_excluded' ) ) {
	/**
	 * Check if product or one of categories is in exclusions
	 *
	 * @since 1.0.0
	 * @param object $product
	 * @return bool
	 * @author Francesco Licandro
	 */
	function yith_wocc_product_is_excluded( $product ){

		$id = $product->id;
		$inverted = get_option( 'yith-wocc-exclusion-inverted' ) == 'yes' ? true : false;

		// first check for categories
		$excluded_categories = explode( ',', get_option( 'yith-wocc-excluded-cat' ) );
		$product_categories  = get_the_terms( $product->id, 'product_cat' );
		$in_list = false;

		if( ! empty( $excluded_categories ) ) {
			foreach( $product_categories as $key => $category ) {
				if( in_array( $category->term_id, $excluded_categories ) ) {
					$in_list = true;
					break;
				}
			}
		}

		if( $in_list ) {
			return $inverted ? false : true;
		}
		// else check for single product
		else {
			$meta_exist = (bool) get_post_meta( $id, '_yith_wocc_exclude_list', true );
			return $inverted ? ! $meta_exist : $meta_exist;
		}
	}
}

if( ! function_exists( 'yith_wocc_get_custom_address' ) ) {
	/**
	 * Get custom address for passed user.
	 *
	 * @since 1.0.0
	 * @param int|string $id
	 * @return array
	 * @author Francesco Licandro
	 */
	function yith_wocc_get_custom_address( $id ){
		return maybe_unserialize( get_user_meta( $id, 'yith-wocc-user-custom-address', true ) );
	}
}

if( ! function_exists( 'yith_wocc_save_custom_address' ) ) {
	/**
	 * Save custom address for passed user.
	 *
	 * @since 1.0.0
	 * @param int|string $id
	 * @param array $value
	 * @return bool|int
	 * @author Francesco Licandro
	 */
	function yith_wocc_save_custom_address( $id, $value ){
		return update_user_meta( $id, 'yith-wocc-user-custom-address', $value );
	}
}

if( ! function_exists( 'yith_wocc_enabled_shipping' ) ) {
	/**
	 * Check if shipping is enabled on shop
	 *
	 * @since 1.0.0
	 * @return bool
	 * @author Francesco Licandro
	 */
	function yith_wocc_enabled_shipping() {
		return ( get_option( 'woocommerce_calc_shipping' ) === 'yes' && ! wc_ship_to_billing_address_only() );
	}
}

if( ! function_exists( 'yith_wocc_is_stripe_enabled' ) ) {
	/**
	 * Check if plugin YITH Stripe is active and available
	 *
	 * @access public
	 * @since 1.0.0
	 * @param int $user_id The user ID
	 * @param string $user_meta The user meta name
	 * @return bool
	 * @author Francesco Licandro
	 */
	function yith_wocc_is_stripe_enabled( $user_id = 0, $user_meta = '' ) {

		// first check if stripe premium is active
		if( ! ( defined( 'YITH_WCSTRIPE_PREMIUM' ) && YITH_WCSTRIPE_PREMIUM ) ) {
			return false;
		}
		// then check in plugin option
		if( get_option('yith-wocc-stripe-integration') != 'yes' ) {
			return false;
		}

		// check also in user options if params are set
		$check_user = true;
		if( $user_id && $user_meta ) {
			$is_active = get_user_meta( $user_id, $user_meta, true );

			$check_user = isset( $is_active['use-stripe'] ) && $is_active['use-stripe'];
		}

		$class_stripe = YITH_WCStripe()->get_gateway();

		return $class_stripe->is_available() && $check_user;
	}
}