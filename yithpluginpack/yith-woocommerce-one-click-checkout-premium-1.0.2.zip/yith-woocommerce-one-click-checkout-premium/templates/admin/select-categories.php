<?php
/**
 * Admin View: Select categories type
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>

<tr valign="top">
	<th scope="row" class="select_categories">
		<label for="<?php echo $id ?>"><?php echo $title ?></label>
	</th>
	<td class="forminp forminp-color plugin-option">

		<div id="<?php echo $id ?>-container" class="yit_options rm_option rm_input rm_text">
			<div class="option">
				<input type="hidden" class="wc-product-search" style="width: 50%;" id="<?php echo $id ?>" name="<?php echo $id ?>" data-placeholder="<?php _e( 'Search for a category...', 'ywbt' ); ?>" data-multiple="true" data-action="yith_wocc_search_product_cat" data-selected="<?php
				$categories = explode( ',', $value );
				$json_ids    = array();

				foreach ( $categories as $category ) {
					$term_obj = get_term_by( 'id', $category, 'product_cat' );
					if ( $term_obj ) {
						$json_ids[ $category ] = wp_kses_post( $term_obj->name );
					}
				}

				echo esc_attr( json_encode( $json_ids ) );
				?>" value="<?php echo implode( ',', array_keys( $json_ids ) ); ?>" />
				<span class="description"><?php echo $desc ?></span>
			</div>
		</div>

	</td>
</tr>