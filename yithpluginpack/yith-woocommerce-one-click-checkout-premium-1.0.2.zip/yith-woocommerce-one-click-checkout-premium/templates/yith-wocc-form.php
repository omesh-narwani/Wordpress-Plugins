<?php
/**
 * One-Click Checkout Template
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

?>

<div class="clear"></div>
<div class="yith-wocc-wrapper">

	<?php do_action( 'yith_wocc_before_one_click_button' ); ?>

		<?php if( isset( $is_loop ) && $is_loop ) : ?>

			<a href="<?php echo esc_url_raw( add_query_arg( array( '_yith_wocc_one_click' => 'is_one_click', 'add-to-cart' => $product->id ), get_permalink( $product->id ) ) ) ?>"
			   class="yith-wocc-button button"><span class="button-label"><?php echo $label ?></span></a>

		<?php else: ?>

			<input type="hidden" name="_yith_wocc_one_click" value />
			<button type="submit" class="yith-wocc-button button"><span class="button-label"><?php echo $label ?></span></button>

		<?php endif; ?>

	<?php do_action( 'yith_wocc_after_one_click_button' ); ?>

</div>