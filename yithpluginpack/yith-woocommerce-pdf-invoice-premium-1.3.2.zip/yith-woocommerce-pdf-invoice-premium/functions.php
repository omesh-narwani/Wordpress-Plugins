<?php

//region some constant values used for url argument vars
defined ( 'YITH_YWPI_CREATE_INVOICE_ACTION' ) || define ( 'YITH_YWPI_CREATE_INVOICE_ACTION', 'create-invoice' );
defined ( 'YITH_YWPI_PREVIEW_INVOICE_ACTION' ) || define ( 'YITH_YWPI_PREVIEW_INVOICE_ACTION', 'preview-invoice' );
defined ( 'YITH_YWPI_VIEW_INVOICE_ACTION' ) || define ( 'YITH_YWPI_VIEW_INVOICE_ACTION', 'view-invoice' );
defined ( 'YITH_YWPI_RESET_INVOICE_ACTION' ) || define ( 'YITH_YWPI_RESET_INVOICE_ACTION', 'reset-invoice' );

defined ( 'YITH_YWPI_NONCE_ARG_NAME' ) || define ( 'YITH_YWPI_NONCE_ARG_NAME', 'check' );

defined ( 'YITH_YWPI_CREATE_SHIPPING_LIST_ACTION' ) || define ( 'YITH_YWPI_CREATE_SHIPPING_LIST_ACTION', 'create-shipping-list' );
defined ( 'YITH_YWPI_VIEW_SHIPPING_LIST_ACTION' ) || define ( 'YITH_YWPI_VIEW_SHIPPING_LIST_ACTION', 'view-shipping-list' );
defined ( 'YITH_YWPI_RESET_SHIPPING_LIST_ACTION' ) || define ( 'YITH_YWPI_RESET_SHIPPING_LIST_ACTION', 'reset-shipping-list' );

defined ( 'YITH_YWPI_RESET_DROPBOX' ) || define ( 'YITH_YWPI_RESET_DROPBOX', 'reset-dropbox' );

defined ( 'YITH_YWPI_CREATE_PRO_FORMA_INVOICE_ACTION' ) || define ( 'YITH_YWPI_CREATE_PRO_FORMA_INVOICE_ACTION', 'create-pro-forma-invoice' );

defined ( 'YITH_YWPI_DOCUMENT_TYPE_INVOICE' ) || define ( 'YITH_YWPI_DOCUMENT_TYPE_INVOICE', 'invoice' );
defined ( 'YITH_YWPI_DOCUMENT_TYPE_PROFORMA' ) || define ( 'YITH_YWPI_DOCUMENT_TYPE_PROFORMA', 'pro_forma' );
defined ( 'YITH_YWPI_DOCUMENT_TYPE_SHIPPING' ) || define ( 'YITH_YWPI_DOCUMENT_TYPE_SHIPPING', 'shipping_list' );

//endregion

function ywpi_get_query_args_list () {
    return array (
        YITH_YWPI_CREATE_INVOICE_ACTION,
        YITH_YWPI_VIEW_INVOICE_ACTION,
        YITH_YWPI_RESET_INVOICE_ACTION,
        YITH_YWPI_NONCE_ARG_NAME,
        YITH_YWPI_CREATE_SHIPPING_LIST_ACTION,
        YITH_YWPI_VIEW_SHIPPING_LIST_ACTION,
        YITH_YWPI_RESET_SHIPPING_LIST_ACTION,
        YITH_YWPI_CREATE_PRO_FORMA_INVOICE_ACTION,
    );
}

if ( ! function_exists ( 'ywpi_get_action_name_for_nonce' ) ) {
    /**
     * return the standard action name
     *
     * @param WC_order $order
     *
     * @return string
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_get_action_name_for_nonce ( $order ) {

        return 'ywpi_action_' . $order->order_key;
    }
}

if ( ! function_exists ( 'ywpi_document_nonce_url' ) ) {
    /**
     * Build an action link for a specific YITH-WooCommerce-PDF-Invoice action, resetting others query args presented for current url and
     * specified by $ywpi_query_arg_array array.
     */
    function ywpi_document_nonce_url ( $arg_name, $order ) {
        $action_url   = add_query_arg ( $arg_name, $order->id, remove_query_arg ( ywpi_get_query_args_list () ) );
        $complete_url = wp_nonce_url ( $action_url, ywpi_get_action_name_for_nonce ( $order ), YITH_YWPI_NONCE_ARG_NAME );

        return esc_url ( $complete_url );
    }
}

if ( ! function_exists ( 'ywpi_document_nonce_check' ) ) {

    /**
     * Verify nonce on an url asking to do an action over an invoice
     *
     * @param WC_Order $order the order for which the document should be created
     *
     * @return bool Nonce validated
     */
    function ywpi_document_nonce_check ( $order ) {
        //  check for nounce value
        if ( ! check_admin_referer ( ywpi_get_action_name_for_nonce ( $order ), YITH_YWPI_NONCE_ARG_NAME ) ) {
            return false;
        }

        return true;
    }
}

if ( ! function_exists ( 'ywpi_get_filesize_text' ) ) {
    /**
     * Verify nonce on an url asking to do an action over an invoice
     *
     * @param int $size the size in bytes
     *
     * @return string file size in text mode
     */
    function ywpi_get_filesize_text ( $size ) {
        $unit = array ( "bytes", "KB", "MB", "GB", "TB" );
        $step = 0;
        while ( $size >= 1024 ) {
            $size = $size / 1024;
            $step ++;
        }

        return sprintf ( "%s %s", round ( $size ), $unit[ $step ] );
    }
}

if ( ! function_exists ( 'ywpi_get_option_with_placeholder' ) ) {
    /**
     * Retrieve option value with a mandatory placeholder queued if not exists
     *
     * @param string $option_name name of the option to retrieve
     * @param string $placeholder name of the mandatory placeholder to be included
     * @param mixed  $obj         the object
     *
     * @return mixed|string|void    new option value
     */
    function ywpi_get_option_with_placeholder ( $option_name, $placeholder, $obj = null ) {
        $value = ywpi_get_option ( $option_name, $obj );

        if ( ! isset( $value ) ) {
            return $placeholder;
        }

        if ( false === strpos ( $value, $placeholder ) ) {

            return $value . $placeholder;
        }


        return $value;
    }
}

if ( ! function_exists ( 'ywpi_is_active_woo_eu_vat_number' ) ) {
    /***
     * Check if WooThemes EU VAT number is active
     */
    function ywpi_is_active_woo_eu_vat_number () {
        return defined ( 'WC_EU_VAT_VERSION' ) && ( version_compare ( WC_EU_VAT_VERSION, '2.1.0' ) >= 0 );
    }
}

if ( ! function_exists ( 'ywpi_use_woo_eu_vat_number' ) ) {
    /***
     * Check if WooThemes EU VAT number should be used
     */
    function ywpi_use_woo_eu_vat_number () {
        return ywpi_is_active_woo_eu_vat_number () && ( "eu-vat-number" == ywpi_get_option ( 'ywpi_ask_vat_number_source' ) );
    }
}

if ( ! function_exists ( 'ywpi_start_plugin_compatibility' ) ) {
    /**
     * Init all third part plugin compatibilities
     *
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_start_plugin_compatibility () {
        if ( defined ( 'YITH_WPV_PREMIUM' ) ) {

            require_once ( YITH_YWPI_LIB_DIR . 'class.yith-ywpi-multivendor-loader.php' );
        }
    }
}

if ( ! function_exists ( 'ywpi_get_option' ) ) {
    /**
     * Make a get_option call with filterable option name
     *
     * @param string $option  Name of option to retrieve. Expected to not be SQL-escaped.
     * @param mixed  $obj     the object id associated to the option.
     * @param mixed  $default Optional. Default value to return if the option does not exist.
     *
     * @return mixed Value set for the option.
     *
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_get_option ( $option, $obj = null, $default = false ) {
        $option = apply_filters ( 'ywpi_option_name', $option, $obj );

        return get_option ( $option, $default );
    }
}

if ( ! function_exists ( 'ywpi_update_option' ) ) {
    /**
     * Make a update_option call with filterable option name
     *
     * @param string $option Name of option to retrieve. Expected to not be SQL-escaped.
     * @param mixed  $obj    the object id associated to the option.
     * @param mixed  $value  the value
     *
     * @return mixed Value set for the option.
     *
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_update_option ( $option, $value, $obj = null ) {
        $option = apply_filters ( 'ywpi_option_name', $option, $obj );

        return update_option ( $option, $value );
    }
}


if ( ! function_exists ( 'ywpi_is_enabled_column_picture' ) ) {
    /**
     * Check if the picture column should be shown for a specific document
     *
     * @return bool
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_is_enabled_column_picture ( $document ) {
        $is_visible = false;

        if ( ( $document instanceof YITH_Invoice ) || ( $document instanceof YITH_Pro_Forma ) ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_invoice_column_picture', $document );
        }

        if ( $document instanceof YITH_Shipping ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_shipping_list_column_picture', $document );
        }

        return apply_filters ( 'ywpi_is_enabled_column_picture', $is_visible, $document );
    }
}

if ( ! function_exists ( 'ywpi_is_enabled_column_quantity' ) ) {
    /**
     * Check if the picture column should be shown for a specific document
     *
     * @return bool
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_is_enabled_column_quantity ( $document ) {
        $is_visible = false;

        if ( ( $document instanceof YITH_Invoice ) || ( $document instanceof YITH_Pro_Forma ) ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_invoice_column_quantity', $document );
        }

        if ( $document instanceof YITH_Shipping ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_shipping_list_column_quantity', $document );
        }

        return apply_filters ( 'ywpi_is_enabled_column_quantity', $is_visible, $document );
    }
}

if ( ! function_exists ( 'ywpi_is_enabled_column_product_price' ) ) {
    /**
     * Check if the picture column should be shown for a specific document
     *
     * @return bool
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_is_enabled_column_product_price ( $document ) {
        $is_visible = false;

        if ( ( $document instanceof YITH_Invoice ) || ( $document instanceof YITH_Pro_Forma ) ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_invoice_column_product_price', $document );
        }

        if ( $document instanceof YITH_Shipping ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_shipping_list_column_product_price', $document );
        }

        return apply_filters ( 'ywpi_is_enabled_column_product_price', $is_visible, $document );
    }
}

if ( ! function_exists ( 'ywpi_is_enabled_column_regular_price' ) ) {
    /**
     * Check if the picture column should be shown for a specific document
     *
     * @return bool
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_is_enabled_column_regular_price ( $document ) {
        $is_visible = false;

        if ( ( $document instanceof YITH_Invoice ) || ( $document instanceof YITH_Pro_Forma ) ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_invoice_column_regular_price', $document );
        }

        if ( $document instanceof YITH_Shipping ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_shipping_list_column_regular_price', $document );
        }

        return apply_filters ( 'ywpi_is_enabled_column_regular_price', $is_visible, $document );
    }
}

if ( ! function_exists ( 'ywpi_is_enabled_column_sale_price' ) ) {
    /**
     * Check if the picture column should be shown for a specific document
     *
     * @return bool
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_is_enabled_column_sale_price ( $document ) {
        $is_visible = false;

        if ( ( $document instanceof YITH_Invoice ) || ( $document instanceof YITH_Pro_Forma ) ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_invoice_column_sale_price', $document );
        }

        if ( $document instanceof YITH_Shipping ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_shipping_list_column_sale_price', $document );
        }

        return apply_filters ( 'ywpi_is_enabled_column_sale_price', $is_visible, $document );
    }
}

if ( ! function_exists ( 'ywpi_is_enabled_column_line_total' ) ) {
    /**
     * Check if the picture column should be shown for a specific document
     *
     * @return bool
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_is_enabled_column_line_total ( $document ) {
        $is_visible = false;

        if ( ( $document instanceof YITH_Invoice ) || ( $document instanceof YITH_Pro_Forma ) ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_invoice_column_line_total', $document );
        }

        if ( $document instanceof YITH_Shipping ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_shipping_list_column_line_total', $document );
        }

        return apply_filters ( 'ywpi_is_enabled_column_line_total', $is_visible, $document );
    }
}

if ( ! function_exists ( 'ywpi_is_enabled_column_tax' ) ) {
    /**
     * Check if the picture column should be shown for a specific document
     *
     * @return bool
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_is_enabled_column_tax ( $document ) {
        $is_visible = false;

        if ( ( $document instanceof YITH_Invoice ) || ( $document instanceof YITH_Pro_Forma ) ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_invoice_column_tax', $document );
        }

        if ( $document instanceof YITH_Shipping ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_shipping_list_column_tax', $document );
        }

        return apply_filters ( 'ywpi_is_enabled_column_tax', $is_visible, $document );
    }
}

if ( ! function_exists ( 'ywpi_is_enabled_column_variation' ) ) {
    /**
     * Check if the picture column should be shown for a specific document
     *
     * @return bool
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_is_enabled_column_variation ( $document ) {
        $is_visible = false;

        if ( ( $document instanceof YITH_Invoice ) || ( $document instanceof YITH_Pro_Forma ) ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_invoice_column_variation', $document );
        }

        if ( $document instanceof YITH_Shipping ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_invoice_column_variation', $document );
        }

        return apply_filters ( 'ywpi_is_enabled_column_variation', $is_visible, $document );
    }
}

if ( ! function_exists ( 'ywpi_is_enabled_column_sku' ) ) {
    /**
     * Check if the picture column should be shown for a specific document
     *
     * @return bool
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_is_enabled_column_sku ( $document ) {
        $is_visible = false;

        if ( ( $document instanceof YITH_Invoice ) || ( $document instanceof YITH_Pro_Forma ) ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_invoice_column_SKU', $document );
        }

        if ( $document instanceof YITH_Shipping ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_shipping_list_column_SKU', $document );
        }

        return apply_filters ( 'ywpi_is_enabled_column_sku', $is_visible, $document );
    }
}

if ( ! function_exists ( 'ywpi_is_enabled_column_short_description' ) ) {
    /**
     * Check if the picture column should be shown for a specific document
     *
     * @return bool
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_is_enabled_column_short_description ( $document ) {
        $is_visible = false;

        if ( ( $document instanceof YITH_Invoice ) || ( $document instanceof YITH_Pro_Forma ) ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_invoice_column_short_description', $document );
        }

        if ( $document instanceof YITH_Shipping ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_shipping_list_column_short_description', $document );
        }

        return apply_filters ( 'ywpi_is_enabled_column_short_description', $is_visible, $document );
    }
}

if ( ! function_exists ( 'ywpi_is_visible_shipping_details_section' ) ) {
    /**
     * Retrieve if the shipping details should be shown for a document
     *
     * @param $document
     *
     * @return mixed|void
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_is_visible_shipping_details_section ( $document ) {
        $is_visible = false;

        if ( ( $document instanceof YITH_Invoice ) || ( $document instanceof YITH_Pro_Forma ) ) {
            $is_visible = true;
        }

        if ( $document instanceof YITH_Shipping ) {
            $is_visible = false;
        }

        return apply_filters ( 'ywpi_is_visible_shipping_details_section', $is_visible, $document );
    }
}

if ( ! function_exists ( 'ywpi_is_visible_fee_details_section' ) ) {
    /**
     * Retrieve if the fee details should be shown for a document
     *
     * @param $document
     *
     * @return mixed|void
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_is_visible_fee_details_section ( $document ) {
        $is_visible = false;

        if ( ( $document instanceof YITH_Invoice ) || ( $document instanceof YITH_Pro_Forma ) ) {
            $is_visible = true;
        }

        if ( $document instanceof YITH_Shipping ) {
            $is_visible = false;
        }

        return apply_filters ( 'ywpi_is_visible_fee_details_section', $is_visible, $document );
    }
}

if ( ! function_exists ( 'ywpi_is_visible_order_totals' ) ) {
    /**
     * Retrieve if the order totals section should be shown for a document
     *
     * @param $document
     *
     * @return mixed|void
     * @author Lorenzo Giuffrida
     * @since  1.0.0
     */
    function ywpi_is_visible_order_totals ( $document ) {
        $is_visible = false;

        if ( ( $document instanceof YITH_Invoice ) || ( $document instanceof YITH_Pro_Forma ) ) {
            $is_visible = true;
        }

        if ( $document instanceof YITH_Shipping ) {
            $is_visible = 'yes' == ywpi_get_option ( 'ywpi_shipping_list_show_order_totals', $document );
        }

        return apply_filters ( 'ywpi_is_visible_order_totals', $is_visible, $document );
    }
}