<?php
if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! class_exists ( 'YITH_Document' ) ) {

    /**
     * Implements features related to a PDF document
     *
     * @class   YITH_Document
     * @package Yithemes
     * @since   1.0.0
     * @author  Your Inspiration Themes
     */
    abstract class YITH_Document {
        /**
         * @var string Current document type
         */
        public $document_type = '';

        /**
         * @var bool If a document of type $document_type exists
         */
        public $exists = false;

        /**
         * @var WC_Order the order associated to this document
         */
        public $order;

        /**
         * @var bool If this document is a valid WooCommerce order
         */
        public $is_valid = false;

        /**
         * @var string path to store the document
         */
        public $save_path;

        /**
         * @var string folder path for the current PDF document
         */
        public $save_folder;

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0
         * @author Lorenzo giuffrida
         * @access public
         */
        public function __construct ( $order_id = 0 ) {

            if ( ! $order_id ) {
                return;
            }

            /**
             * Get the WooCommerce order for this order id
             */
            $this->order = wc_get_order ( $order_id );

            /**
             * Check if an order exists for this order id
             */
            $this->is_valid = isset( $this->order ) && $this->order->id;
        }

        /**
         * Retrieve if a file for this document exists
         *
         * @return bool
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function file_exists () {
            return file_exists ( $this->get_full_path () );
        }

        /**
         * Get full path to the current document
         *
         * @return string
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function get_full_path () {
            return YITH_YWPI_DOCUMENT_SAVE_DIR . $this->save_folder . '/' . $this->save_path;
        }

        public function save () {
            //Do nothing
        }
    }
}