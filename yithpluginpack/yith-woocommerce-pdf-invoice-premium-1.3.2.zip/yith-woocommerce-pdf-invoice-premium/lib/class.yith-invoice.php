<?php
if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! class_exists ( 'YITH_Invoice' ) ) {

    /**
     * Implements features related to a PDF document
     *
     * @class   YITH_Invoice
     * @package Yithemes
     * @since   1.0.0
     * @author  Your Inspiration Themes
     */
    class YITH_Invoice extends YITH_Document {

        /**
         * @var string the specific type of the document
         */
        public $document_type;

        /**
         * @var string date of creation for the current invoice
         */
        public $date;

        /**
         * @var string the document number
         */
        public $number;

        /**
         * @var string the document prefix
         */
        public $prefix;

        /**
         * @var string the document suffix
         */
        public $suffix;

        /**
         * @var string the document formatted number
         */
        public $formatted_number;

        /**
         * Initialize plugin and registers actions and filters to be used
         *
         * @param int $order_id int the order for which an invoice is creating
         *
         * @since  1.0
         * @author Lorenzo giuffrida
         * @access public
         */
        public function __construct ( $order_id = 0 ) {

            $this->document_type = YITH_YWPI_DOCUMENT_TYPE_INVOICE;

            /**
             * Call base class constructor
             */
            parent::__construct ( $order_id );

            /**
             * if this document is not related to a valid WooCommerce order, exit
             */
            if ( ! $this->is_valid ) {
                return;
            }

            /**
             *  Fill invoice information from a previous invoice is exists or from general plugin options plus order related data
             * */
            $this->init_document ();
        }

        /*
         * Check if an invoice exist for current order and load related data
         */
        private function init_document () {

            $this->exists = get_post_meta ( $this->order->id, '_ywpi_invoiced', true );

            if ( $this->exists ) {
                $this->number           = get_post_meta ( $this->order->id, '_ywpi_invoice_number', true );
                $this->prefix           = get_post_meta ( $this->order->id, '_ywpi_invoice_prefix', true );
                $this->suffix           = get_post_meta ( $this->order->id, '_ywpi_invoice_suffix', true );
                $this->formatted_number = get_post_meta ( $this->order->id, '_ywpi_invoice_formatted_number', true );

                $this->date        = get_post_meta ( $this->order->id, '_ywpi_invoice_date', true );
                $this->save_path   = get_post_meta ( $this->order->id, '_ywpi_invoice_path', true );
                $this->save_folder = get_post_meta ( $this->order->id, '_ywpi_invoice_folder', true );
            }
        }

        /**
         * Cancel current document
         */
        public function reset () {

            delete_post_meta ( $this->order->id, '_ywpi_invoiced' );
            delete_post_meta ( $this->order->id, '_ywpi_invoice_number' );
            delete_post_meta ( $this->order->id, '_ywpi_invoice_prefix' );
            delete_post_meta ( $this->order->id, '_ywpi_invoice_suffix' );
            delete_post_meta ( $this->order->id, '_ywpi_invoice_formatted_number' );

            delete_post_meta ( $this->order->id, '_ywpi_invoice_path' );
            delete_post_meta ( $this->order->id, '_ywpi_invoice_folder' );
            delete_post_meta ( $this->order->id, '_ywpi_invoice_date' );
        }

        /**
         * Save invoice data
         */
        public function save () {

            $this->exists = true;
            update_post_meta ( $this->order->id, '_ywpi_invoiced', $this->exists );

            update_post_meta ( $this->order->id, '_ywpi_invoice_prefix', $this->prefix );
            update_post_meta ( $this->order->id, '_ywpi_invoice_suffix', $this->suffix );
            update_post_meta ( $this->order->id, '_ywpi_invoice_number', $this->number );
            update_post_meta ( $this->order->id, '_ywpi_invoice_formatted_number', $this->formatted_number );

            update_post_meta ( $this->order->id, '_ywpi_invoice_date', $this->date );
            update_post_meta ( $this->order->id, '_ywpi_invoice_path', $this->save_path );
            update_post_meta ( $this->order->id, '_ywpi_invoice_folder', $this->save_folder );
        }
    }
}