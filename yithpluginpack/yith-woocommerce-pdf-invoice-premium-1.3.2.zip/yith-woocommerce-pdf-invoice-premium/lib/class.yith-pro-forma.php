<?php
if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! class_exists ( 'YITH_Pro_Forma' ) ) {

    /**
     * Implements features related to a PDF document
     *
     * @class   YITH_Invoice
     * @package Yithemes
     * @since   1.0.0
     * @author  Your Inspiration Themes
     */
    class YITH_Pro_Forma extends YITH_Document {

        /**
         * @var string the specific type of the document
         */
        public $document_type;

        /**
         * Initialize plugin and registers actions and filters to be used
         *
         * @param int $order_id the order for which the document is generated
         *
         * @since  1.0
         * @author Lorenzo giuffrida
         * @access public
         */
        public function __construct ( $order_id = 0 ) {

            $this->document_type = YITH_YWPI_DOCUMENT_TYPE_PROFORMA;

            /**
             * Call base class constructor
             */
            parent::__construct ( $order_id );

            /**
             * if this document is not related to a valid WooCommerce order, exit
             */
            if ( ! $this->is_valid ) {
                return;
            }

            /**
             *  Fill invoice information from a previous invoice is exists or from general plugin options plus order related data
             * */
            $this->init_document ();
        }

        /*
         * Check if an invoice exist for current order and load related data
         */
        private function init_document () {
            $this->exists = get_post_meta ( $this->order->id, '_ywpi_has_pro_forma', true );

            if ( $this->exists ) {

                $this->save_path   = get_post_meta ( $this->order->id, '_ywpi_pro_forma_path', true );
                $this->save_folder = get_post_meta ( $this->order->id, '_ywpi_pro_forma_folder', true );
            }
        }


        /**
         *  Cancel reference to pro-forma options for the current order
         */
        public function reset () {
            delete_post_meta ( $this->order->id, '_ywpi_has_pro_forma' );
            delete_post_meta ( $this->order->id, '_ywpi_pro_forma_path' );
        }

        /**
         * Set invoice data for current order, picking the invoice number from the related general option
         */
        public function save () {

            update_post_meta ( $this->order->id, '_ywpi_has_pro_forma', true );
            update_post_meta ( $this->order->id, '_ywpi_pro_forma_path', $this->save_path );
            update_post_meta ( $this->order->id, '_ywpi_pro_forma_folder', $this->save_folder );
        }

    }
}