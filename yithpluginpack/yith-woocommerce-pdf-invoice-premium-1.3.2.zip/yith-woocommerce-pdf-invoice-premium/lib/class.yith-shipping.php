<?php
if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! class_exists ( 'YITH_Shipping' ) ) {

    /**
     * Implements features related to a PDF document
     *
     * @class   YITH_Shipping
     * @package Yithemes
     * @since   1.0.0
     * @author  Your Inspiration Themes
     */
    class YITH_Shipping extends YITH_Document {
        /**
         * @var string the specific type of the document
         */
        public $document_type;

        /**
         * Initialize plugin and registers actions and filters to be used
         *
         * @param int $order_id the order for which the document is generated
         *
         * @since  1.0
         * @author Lorenzo giuffrida
         * @access public
         */
        public function __construct ( $order_id = 0 ) {

            $this->document_type = YITH_YWPI_DOCUMENT_TYPE_SHIPPING;

            /**
             * Call base class constructor
             */
            parent::__construct ( $order_id );

            /**
             * if this document is not related to a valid WooCommerce order, exit
             */
            if ( ! $this->is_valid ) {
                return;
            }

            /**
             *  Fill invoice information from a previous invoice is exists or from general plugin options plus order related data
             * */
            $this->init_document ();
        }

        /*
         * Check if a document exist for current order and load related data
         */
        private function init_document () {
            $this->exists = get_post_meta ( $this->order->id, '_ywpi_has_shipping_list', true );

            if ( $this->exists ) {
                $this->save_path   = get_post_meta ( $this->order->id, '_ywpi_shipping_list_path', true );
                $this->save_folder = get_post_meta ( $this->order->id, '_ywpi_shipping_list_folder', true );
            }
        }

        /**
         *  Cancel shipping list document for the current order
         */
        public function reset () {
            delete_post_meta ( $this->order->id, '_ywpi_has_shipping_list' );
            delete_post_meta ( $this->order->id, '_ywpi_shipping_list_path' );
        }

        /**
         * Set invoice data for current order, picking the invoice number from the related general option
         */
        public function save () {

            $this->exists = true;

            update_post_meta ( $this->order->id, '_ywpi_has_shipping_list', $this->exists );
            update_post_meta ( $this->order->id, '_ywpi_shipping_list_path', $this->save_path );
            update_post_meta ( $this->order->id, '_ywpi_shipping_list_folder', $this->save_folder );


        }
    }
}