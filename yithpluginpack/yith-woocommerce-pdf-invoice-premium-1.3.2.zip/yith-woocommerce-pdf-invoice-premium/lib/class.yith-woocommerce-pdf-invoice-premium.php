<?php
if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! defined ( 'YITH_YWPI_GO_TO_DROPBOX' ) ) {
    define ( 'YITH_YWPI_GO_TO_DROPBOX', 'authenticate-dropbox' );
}

if ( ! class_exists ( 'YITH_WooCommerce_Pdf_Invoice_Premium' ) ) {

    /**
     * Implements features of YITH WooCommerce Pdf Invoice
     *
     * @class   YITH_WooCommerce_Pdf_Invoice_Premium
     * @package Yithemes
     * @since   1.0.0
     * @author  Your Inspiration Themes
     */
    class YITH_WooCommerce_Pdf_Invoice_Premium extends YITH_WooCommerce_Pdf_Invoice {

        /**
         * @var array the DropBox app infomation
         */
        private $dropbox_app_info = array (
            'key'    => '58dmyrhs688d3zs',
            'secret' => 'er8q2p42m2tu7mz',
        );

        private $dropbox_accesstoken = '';

        /**
         * @var bool set if pro-forma invoice are available
         */
        public $enable_pro_forma = false;

        /**
         * Single instance of the class
         *
         * @since 1.0.0
         */
        protected static $instance;

        /**
         * Returns single instance of the class
         *
         * @since 1.0.0
         */
        public static function get_instance () {
            if ( is_null ( self::$instance ) ) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0
         * @author Lorenzo giuffrida
         * @access public
         */
        public function __construct () {
            parent::__construct ();

            $this->dropbox_accesstoken = ywpi_get_option ( 'ywpi_dropbox_access_token' );

            add_filter ( 'woocommerce_admin_settings_sanitize_option_ywpi_dropbox_key', array ( $this, 'custom_save_ywpi_dropbox' ) );

            add_action ( 'woocommerce_admin_field_ywpi_dropbox', array ( $this, 'show_dropbox_option' ), 10, 1 );

            add_action ( 'woocommerce_update_option', array ( $this, 'copy_invoice_logo_to_local_path' ) );

            /**
             * Check for third party plugin compatibility
             */
            $this->check_third_part_compatibility ();

            /**
             * Add some fields on checkout process, that can be added on invoices.
             */
            YITH_Checkout_addon::get_instance ()->initialize ();
        }


        /**
         * Show the document title on the template
         *
         * @param string        $text     current text being shown
         * @param YITH_Document $document the document
         *
         * @author Lorenzo Giuffrida
         * @return string
         * @since  1.0.0
         */
        public function show_document_title ( $text, $document ) {

            if ( $document instanceof YITH_Pro_Forma ) {
                $title = __ ( 'Pro-forma Invoice', 'yith-woocommerce-pdf-invoice' );

                return '<span class="document-type">' . $title . '</span>';
            }

            return parent::show_document_title ( $text, $document );
        }

        /**
         * Initialize the plugin options
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function init_plugin_options () {
            $this->enable_pro_forma = ( 'yes' == ywpi_get_option ( 'ywpi_enable_pro_forma' ) );
            parent::init_plugin_options ();
        }

        /**
         * Show the data section for shipping documents
         *
         * @param YITH_Pro_Forma $document
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        private function yith_ywpi_show_template_proforma_data ( $document ) {
            if ( $document instanceof YITH_Pro_Forma ) {
                ?>
                <table class="invoice-data-table">
                    <tr class="invoice-order-number">
                        <td><?php _e ( "Order", 'yith-woocommerce-pdf-invoice' ); ?></td>
                        <td class="right"><?php echo $document->order->get_order_number (); ?></td>
                    </tr>

                    <tr class="invoice-date">
                        <td><?php _e ( "Order date", 'yith-woocommerce-pdf-invoice' ); ?></td>
                        <td class="right"><?php echo $this->get_document_formatted_date ( $document ); ?></td>
                    </tr>
                    <tr class="invoice-amount">
                        <td><?php _e ( "Order Amount", 'yith-woocommerce-pdf-invoice' ); ?></td>
                        <td class="right"><?php echo wc_price ( $document->order->get_total () ); ?></td>
                    </tr>
                </table>
                <?php
            }
        }

        /**
         * Show the document section with the document data like number, data, ...
         *
         * @param YITH_Document $document
         */
        public function show_template_document_data ( $document ) {

            if ( $document instanceof YITH_Pro_Forma ) {
                $this->yith_ywpi_show_template_proforma_data ( $document );

                return;
            }

            parent::show_template_document_data ( $document );
        }

        /**
         * Make a local copy of the image to be used as company logo for a fix to the DOMPDF library
         *
         * @param array $option
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function copy_invoice_logo_to_local_path ( $option ) {
            if ( 'ywpi_company_logo' === $option[ "id" ] ) {
                if ( ! empty( $_POST[ "ywpi_company_logo" ] ) ) {

                    $upload_dir = wp_upload_dir ();
                    $local_path = str_replace ( $upload_dir[ "baseurl" ], $upload_dir[ "basedir" ], $_POST[ "ywpi_company_logo" ] );
                    copy ( $local_path, YITH_YWPI_INVOICE_LOGO_PATH );
                }
            }
        }

        /**
         * Save DropBox access token
         */
        public function custom_save_ywpi_dropbox () {
            if ( isset( $_POST[ 'ywpi_dropbox_key' ] ) ) {
                //  Extract access token  if autorization token is valid
                $access_token = $this->get_dropbox_access_token ( $_POST[ 'ywpi_dropbox_key' ] );
                if ( $access_token ) {
                    update_option ( 'ywpi_dropbox_access_token', $access_token );
                }
            }

            return null;
        }

        /**
         * Check for third party plugin compatibility needs
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function check_third_part_compatibility () {
            if ( ywpi_is_active_woo_eu_vat_number () ) {
                add_filter ( 'ywpi_general_options', array ( $this, 'add_vat_number_source_option' ) );
            }
        }

        /**
         * Add an option to choose the VAT number source
         *
         * @param array $settings current option list
         *
         * @return mixed
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function add_vat_number_source_option ( $settings ) {
            $vat_number_source = array (
                'name'    => __ ( 'VAT number source', 'yith-woocommerce-pdf-invoice' ),
                'id'      => 'ywpi_ask_vat_number_source',
                'type'    => 'radio',
                'options' => array (
                    'yith'          => "Show the standard VAT number field from YITH WooCommerce PDF Invoice",
                    'eu-vat-number' => "Use the VAT number field from WooThemes EU VAT number plugin",
                ),
                'default' => 'yith',
            );

            $settings[ 'general' ] = array_slice ( $settings[ 'general' ], 0, count ( $settings[ 'general' ] ) - 2, true ) +
                array ( 'vat_number_source' => $vat_number_source ) +
                array_slice ( $settings[ 'general' ], 3, count ( $settings[ 'general' ] ) - 1, true );

            return $settings;
        }

        /**
         * add the right action based on GET var current used
         *
         */
        public function init_plugin_actions () {
            parent::init_plugin_actions ();

            if ( isset( $_GET[ YITH_YWPI_CREATE_PRO_FORMA_INVOICE_ACTION ] ) ) {
                $this->get_pro_forma_invoice ( $_GET[ YITH_YWPI_CREATE_PRO_FORMA_INVOICE_ACTION ] );
            } else if ( isset( $_GET[ YITH_YWPI_RESET_DROPBOX ] ) ) {
                $this->disable_dropbox_backup ();
                delete_option ( 'ywpi_dropbox_access_token' );
                wp_redirect ( esc_url_raw ( remove_query_arg ( YITH_YWPI_RESET_DROPBOX ) ) );
            }
        }

        /**
         * Retrieve the pro forma document from an order
         *
         * @param int $order_id the order id
         *
         * @return null|YITH_Pro_Forma
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        private function get_pro_forma_document ( $order_id ) {
            return $this->get_order_document_by_type ( $order_id, YITH_YWPI_DOCUMENT_TYPE_PROFORMA );
        }


        /**
         * Create a new pro-forma invoice document if not exists, else return the previous one
         *
         * @param int $order_id the order id for which the document is created
         */
        public function get_pro_forma_invoice ( $order_id ) {

            if ( ! $this->enable_pro_forma ) {
                return;
            }

            $document = $this->create_document ( $order_id, YITH_YWPI_DOCUMENT_TYPE_PROFORMA );

            /*
             * Check for url validation
             */
            if ( ! $document || ( ! $this->check_invoice_url_for_action ( $document ) ) ) {
                return;
            }

            //  Create the file and show it
            $this->show_file ( $document );
        }

        /**
         * Save the specific document
         *
         * @param YITH_Document $document the specific document
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         * @return void
         */
        public function save_document ( $document ) {
            parent::save_document ( $document );
            $this->send_document_to_dropbox ( $document );
        }

        /**
         * Retrieve an order document from a document type
         *
         * @param        $order_id
         * @param string $document_type
         *
         * @return null|Yith_Invoice|Yith_Shipping
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function get_order_document_by_type ( $order_id, $document_type = '' ) {

            if ( $document_type == YITH_YWPI_DOCUMENT_TYPE_PROFORMA ) {
                return new YITH_Pro_Forma( $order_id );
            }

            return parent::get_order_document_by_type ( $order_id, $document_type );
        }

        /**
         * Show DropBox option section
         *
         * @param array $args
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function show_dropbox_option ( $args = array () ) {
            if ( empty( $args ) ) {
                return;
            }
            $args[ 'value' ]           = ( get_option ( $args[ 'id' ] ) ) ? get_option ( $args[ 'id' ] ) : '';
            $name                      = isset( $args[ 'name' ] ) ? $args[ 'name' ] : '';
            $this->dropbox_accesstoken = ywpi_get_option ( 'ywpi_dropbox_access_token' );

            $show_dropbox_login = false;
            ?>
            <tr valign="top">
                <th scope="row">
                    <label for="ywpi_enable_dropbox"><?php echo $name; ?></label>
                </th>
                <td class="forminp forminp-color plugin-option">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo $name; ?></span>
                        </legend>
                        <label for="ywpi_enable_dropbox">
                            <?php if ( $this->dropbox_accesstoken ) {
                                $account_info = $this->get_dropbox_account_info ();
                                if ( $account_info ) {
                                    $quota = $account_info[ 'quota_info' ];
                                    echo sprintf ( __ ( 'Dropbox backup is currently active for <b>%s</b>. Used  <b>%s</b> over total <b>%s</b>.', 'yith-woocommerce-pdf-invoice' ), $account_info[ 'email' ], ywpi_get_filesize_text ( $quota[ 'normal' ] ), ywpi_get_filesize_text ( $quota[ 'quota' ] ) );
                                    echo '<br><a href="' . esc_url ( add_query_arg ( YITH_YWPI_RESET_DROPBOX, 1 ) ) . '" id="ywpi_disable_dropbox_button" class="button button-secondary">' . __ ( "Disable DropBox", 'yith-woocommerce-pdf-invoice' ) . '</a>';
                                } else {
                                    $show_dropbox_login = true;
                                    echo '<p><span style="color:red">' . __ ( "The authentication token provided is no longer valid, please repeat the Dropbox authentication steps.", 'yith-woocommerce-pdf-invoice' ) . '</span></p>';
                                }
                            }

                            if ( ! $this->dropbox_accesstoken || $show_dropbox_login ) {
                                $example_url = '<a class="thickbox" href="' . YITH_YWPI_ASSETS_IMAGES_URL . 'dropbox-howto.jpg">';
                                ?>
                                <a target="_blank" href="<?php echo $this->get_dropbox_authentication_url (); ?>"
                                   id="ywpi_enable_dropbox_button"
                                   class="button button-primary"><?php _e ( 'Login to Dropbox', 'yith-woocommerce-pdf-invoice' ); ?></a>
                                <?php echo __ ( sprintf ( 'Authorize this plugin to access to your Dropbox space.<br> All <b>new documents</b> will be sent to your dropbox space as soon as they are created. Copy and paste authorization code here, as in %s this example %s.', $example_url, '</a>' ), 'yith-woocommerce-pdf-invoice' ); ?>
                                <input name="ywpi_dropbox_key" id="ywpi_dropbox_key" type="text" style="width: 75%;">
                                <br>
                            <?php } ?>
                        </label>
                    </fieldset>
                </td>
            </tr>
            <?php
        }


        /**
         * Get the url to the dropbox authentication url
         *
         * @return string
         */
        public function get_dropbox_authentication_url () {
            # Include the Dropbox SDK libraries
            require_once YITH_YWPI_LIB_DIR . 'Dropbox/autoload.php';

            $appInfo = Dropbox\AppInfo::loadFromJson ( $this->dropbox_app_info );
            $webAuth = new Dropbox\WebAuthNoRedirect( $appInfo, "PHP-Example/1.0" );

            $authorizeUrl = $webAuth->start ();

            return $authorizeUrl;
        }

        /**
         * Disable the DropBox backup
         *
         * @return string
         */
        public function disable_dropbox_backup () {
            if ( $this->dropbox_accesstoken ) {
                try {
                    # Include the Dropbox SDK libraries
                    require_once YITH_YWPI_LIB_DIR . 'Dropbox/autoload.php';

                    $dbxClient = new Dropbox\Client( $this->dropbox_accesstoken, "PHP-Example/1.0" );

                    //  try to retrieve information to verify if access token is valid
                    return $dbxClient->disableAccessToken ();

                } catch ( \Dropbox\Exception $e ) {
                    error_log ( __ ( 'Dropbox backup: unable to disable authorization  -> ', 'yith-woocommerce-pdf-invoice' ) . $e->getMessage () );
                }
            }
        }

        /**
         * Check if current access token is valid and retrieve account information
         *
         * @return array|bool
         */
        private function get_dropbox_account_info () {
            if ( $this->dropbox_accesstoken ) {
                try {
                    # Include the Dropbox SDK libraries
                    require_once YITH_YWPI_LIB_DIR . 'Dropbox/autoload.php';

                    $dbxClient = new Dropbox\Client( $this->dropbox_accesstoken, "PHP-Example/1.0" );

                    //  try to retrieve information to verify if access token is valid
                    return $dbxClient->getAccountInfo ();
                } catch ( \Dropbox\Exception $e ) {
                    error_log ( __ ( 'Dropbox backup: unable to retrieve account information  -> ', 'yith-woocommerce-pdf-invoice' ) . $e->getMessage () );

                }
            }

            return false;
        }

        /**
         * Retrieve access token starting from an authorization code
         *
         * @param string $auth_code authorization code
         *
         * @return string
         */
        private function get_dropbox_access_token ( $auth_code ) {
            try {
                # Include the Dropbox SDK libraries
                require_once YITH_YWPI_LIB_DIR . 'Dropbox/autoload.php';

                $appInfo = Dropbox\AppInfo::loadFromJson ( $this->dropbox_app_info );
                $webAuth = new Dropbox\WebAuthNoRedirect( $appInfo, "PHP-Example/1.0" );

                list( $accessToken, $dropboxUserId ) = $webAuth->finish ( $auth_code );

                return $accessToken;
            } catch ( Exception $e ) {
                error_log ( __ ( 'Dropbox backup: unable to get access token  -> ', 'yith-woocommerce-pdf-invoice' ) . $e->getMessage () );
            }

            return false;
        }

        /**
         * Upload document to dropbox, if access token is valid
         *
         * @param YITH_Document $document the document to upload
         */
        public function send_document_to_dropbox ( $document ) {
            if ( ! $this->dropbox_accesstoken ) {
                return;
            }

            # Include the Dropbox SDK libraries
            require_once YITH_YWPI_LIB_DIR . 'Dropbox/autoload.php';
            try {
                $dbxClient = new Dropbox\Client( $this->dropbox_accesstoken, "PHP-Example/1.0" );

                if ( file_exists ( $document->get_full_path () ) ) {
                    $f = fopen ( $document->get_full_path (), "rb" );
                    $dbxClient->createFolder ( '/' . $document->save_folder );
                    $result = $dbxClient->uploadFile ( '/' . $document->save_folder . '/' . $document->save_path, Dropbox\WriteMode::force (), $f );
                    fclose ( $f );
                }
            } catch ( Exception $e ) {
                error_log ( __ ( 'Dropbox backup: unable to send file  -> ', 'yith-woocommerce-pdf-invoice' ) . $e->getMessage () );
            }
        }

        /**
         * Add a button to print invoice, if exists, from order page on frontend.
         * If not exists add a button for a pro-forma document.
         *
         * @param array    $actions current actions
         * @param WC_Order $order   the order being shown
         *
         * @return mixed
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function print_invoice_button ( $actions, $order ) {


            $invoice = new YITH_Invoice( $order->id );

            if ( $invoice->exists ) {
                // Add the print button
                $actions[ 'print-invoice' ] = array (
                    'url'  => ywpi_document_nonce_url ( YITH_YWPI_VIEW_INVOICE_ACTION, $order ),
                    'name' => __ ( 'Invoice', 'yith-woocommerce-pdf-invoice' ),
                );
            } else if ( $this->enable_pro_forma ) {

                $actions[ 'print-pro-forma-invoice' ] = array (
                    'url'  => ywpi_document_nonce_url ( YITH_YWPI_CREATE_PRO_FORMA_INVOICE_ACTION, $order ),
                    'name' => __ ( 'Pro-Forma', 'yith-woocommerce-pdf-invoice' ),
                );
            }

            return apply_filters ( 'yith_ywpi_my_order_actions', $actions, $order );
        }

    }
}