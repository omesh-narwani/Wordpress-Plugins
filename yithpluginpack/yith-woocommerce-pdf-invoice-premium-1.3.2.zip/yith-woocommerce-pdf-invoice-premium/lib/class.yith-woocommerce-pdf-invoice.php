<?php
if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! class_exists ( 'YITH_WooCommerce_Pdf_Invoice' ) ) {

    /**
     * Implements features of Yith WooCommerce Pdf Invoice
     *
     * @class   YITH_WooCommerce_Pdf_Invoice
     * @package Yithemes
     * @since   1.0.0
     * @author  Your Inspiration Themes
     */
    class YITH_WooCommerce_Pdf_Invoice {

        /**
         * @var bool the preview mode prevent the use of the counter
         */
        public $preview_mode = false;

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0
         * @author Lorenzo giuffrida
         * @access public
         */
        public function __construct () {
            $this->init_plugin_options ();

            add_action ( 'init', array ( $this, 'init_plugin_actions' ), 20 );
            $this->set_metabox_actions ();

            $this->add_buttons_on_customer_orders_page ();
            $this->add_features_on_admin_orders_page ();

            $this->add_order_status_related_actions ();

            /*
            * Check if invoice should be attached to emails
            */
            add_filter ( 'woocommerce_email_attachments', array ( $this, 'attach_invoice_to_email' ), 99, 3 );

            /*
             * Add a create/view invoice button on admin orders page
             */
            add_action ( 'woocommerce_admin_order_actions_end', array ( $this, 'add_back_end_invoice_buttons' ) );
            /*
             * Add a create/view shipping list button on admin orders page
             */
            add_action ( 'woocommerce_admin_order_actions_end', array (
                $this,
                'add_back_end_shipping_list_buttons',
            ) );

            //  Add stylesheets and scripts files to back-end
            add_action ( 'admin_enqueue_scripts', array ( $this, 'enqueue_styles' ) );
            add_action ( 'wp_enqueue_scripts', array ( $this, 'enqueue_styles' ) );

            //  *************************************************
            //  Hook action in the ywpi-invoice-template.php file
            add_action ( 'yith_ywpi_invoice_template_head', array ( $this, 'add_document_stylesheet' ) );
            add_filter ( 'yith_ywpi_document_template_title', array ( $this, 'show_document_title' ), 10, 2 );

            add_action ( 'yith_ywpi_invoice_template_sender', array ( $this, 'show_invoice_template_sender' ) );
            add_action ( 'yith_ywpi_invoice_template_company_logo', array (
                $this,
                'show_invoice_template_company_logo',
            ) );
            /**
             * Add the document content to the template
             */
            add_action ( 'yith_ywpi_invoice_template_customer_data', array (
                $this,
                'show_invoice_template_customer_data',
            ) );
            /**
             * Show the document section with the document data like number, data, ...
             */
            add_action ( 'show_template_document_data', array (
                $this,
                'show_template_document_data',
            ) );
            add_action ( 'yith_ywpi_invoice_template_products_list', array (
                $this,
                'show_invoice_products_list_template',
            ) );
            add_action ( 'yith_ywpi_invoice_template_footer', array ( $this, 'show_document_footer_template' ) );

            if ( $this->preview_mode ) {

                add_filter ( 'yith_ywpi_document_template_title', array ( $this, 'print_notice_preview_mode' ), 20, 2 );
            }

        }

        public function print_notice_preview_mode ( $text, $document ) {
            if ( ! $this->preview_mode ) {
                return $text;
            }

            return sprintf ( "<span class=\"document-type\">%s</span><br>%s", __ ( 'THIS IS ONLY A PREVIEW DOCUMENT - DISABLE THE PLUGIN SETTINGS FOR GENERATING VALID DOCUMENTS', 'yith-woocommerce-pdf-invoice' ), $text );
        }

        /**
         * Show product list for current order on invoice template
         *
         * @param YITH_Document $document the document to be build
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function show_invoice_products_list_template ( $document ) {

            wc_get_template ( 'invoice/ywpi-invoice-details.php',
                array (
                    'document' => $document,
                ),
                '',
                YITH_YWPI_TEMPLATE_DIR );
        }

        /**
         * Append the stylesheet to the document being created
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function add_document_stylesheet () {

            ob_start ();
            wc_get_template ( 'invoice/ywpi-invoice-style.css',
                null,
                '',
                YITH_YWPI_TEMPLATE_DIR );

            $content = ob_get_contents ();
            ob_end_clean ();

            if ( $content ) {
                ?>
                <style type="text/css">
                    <?php echo $content; ?>
                </style>
                <?php
            }
        }

        /**
         * Retrieve the plugin option value for the document notes visibility
         *
         * @param YITH_Document $document
         *
         * @return mixed|void
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        private function is_visible_document_notes ( $document ) {
            $is_visible = '';

            if ( ( $document instanceof YITH_Invoice ) || ( $document instanceof YITH_Pro_Forma ) ) {

                $is_visible = ywpi_get_option ( 'ywpi_show_invoice_notes', $document );
            } elseif ( $document instanceof YITH_Shipping ) {
                $is_visible = ywpi_get_option ( 'ywpi_shipping_list_show_notes', $document );
            }

            return apply_filters ( 'is_visible_document_notes', $is_visible, $document );
        }

        /**
         * Print the note section for the current document
         *
         * @param YITH_Document $document the document to be shown
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function print_document_notes ( $document ) {
            $html = '';

            if ( $this->is_visible_document_notes ( $document ) ) {
                $notes = $this->get_document_notes ( $document );
                if ( $notes ) {
                    $html = '<div class="notes">
                    <span class="notes-title">' . _e ( "Notes", "yith-woocommerce-pdf-invoice" ) . '</span>
                    <span>' . nl2br ( $this->get_document_notes ( $document ) ) . '</span>
                </div>';
                }
            }

            echo apply_filters ( 'print_document_notes', $html, $document );
        }

        /**
         * Retrieve the notes to be shown when printing a generic document
         *
         * @param YITH_Document $document
         *
         * @return mixed
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        function get_document_notes ( $document ) {
            $notes = '';
            if ( $document instanceof YITH_Invoice ) {
                $notes = ywpi_get_option ( 'ywpi_invoice_notes', $document );
            }

            if ( $document instanceof YITH_Pro_Forma ) {
                $notes = ywpi_get_option ( 'ywpi_pro_forma_notes', $document );
            }

            if ( $document instanceof YITH_Shipping ) {
                $notes = ywpi_get_option ( 'ywpi_shipping_list_notes', $document );
            }

            return apply_filters ( 'get_document_notes', $notes, $document );
        }

        /**
         * Check if a footer should be shown for a document
         *
         * @param YITH_Document $document
         *
         * @return mixed|void
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        function is_visible_document_footer ( $document ) {
            $is_visible = '';

            if ( ( $document instanceof YITH_Invoice ) || ( $document instanceof YITH_Pro_Forma ) ) {
                $is_visible = 'yes' == ywpi_get_option ( 'ywpi_show_invoice_footer', $document );
            }

            if ( $document instanceof YITH_Shipping ) {
                $is_visible = 'yes' == ywpi_get_option ( 'ywpi_shipping_list_show_footer', $document );
            }

            return apply_filters ( 'is_visible_document_footer', $is_visible, $document );
        }

        /**
         * Retrieve the footer to be shown when printing a generic document
         *
         * @param YITH_Document $document
         *
         * @return mixed
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        function get_document_footer ( $document ) {
            if ( $document instanceof YITH_Invoice ) {
                return ywpi_get_option ( 'ywpi_invoice_footer', $document );
            }

            if ( $document instanceof YITH_Pro_Forma ) {
                return ywpi_get_option ( 'ywpi_pro_forma_footer', $document );
            }

            if ( $document instanceof YITH_Shipping ) {
                return ywpi_get_option ( 'ywpi_shipping_list_footer', $document );
            }

            return '';
        }

        /**
         * Print the document footer
         *
         * @param YITH_Document $document
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        function print_document_footer ( $document ) {
            $html = '';
            if ( $this->is_visible_document_footer ( $document ) ) {
                $html = '<footer>
                    <span>' . $this->get_document_footer ( $document ) . '</span>
                </footer>';
            }

            echo apply_filters ( 'print_document_footer', $html, $document );
        }

        /**
         * Show the document footer for a document
         *
         * @param YITH_Document $document
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function show_document_footer_template ( $document ) {

            $this->print_document_notes ( $document );
            $this->print_document_footer ( $document );
        }

        /**
         * Show the document title on the template
         *
         * @param YITH_Document $document
         *
         * @author Lorenzo Giuffrida
         *
         * @return string
         *
         * @since  1.0.0
         */
        public function show_document_title ( $text, $document ) {
            //
            $title = '';

            if ( $document instanceof YITH_Invoice ) {
                $title = __ ( 'Invoice', 'yith-woocommerce-pdf-invoice' );
            } else if ( $document instanceof YITH_Shipping ) {
                $title = __ ( 'Shipping list', 'yith-woocommerce-pdf-invoice' );
            }

            return '<span class="document-type">' . $title . '</span>';
        }

        /**
         * Initialize the plugin options
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function init_plugin_options () {
            $this->preview_mode = "yes" === get_option ( 'ywpi_preview_mode', false );
        }

        /**
         * Enqueue css file
         *
         * @since  1.0
         * @author Lorenzo giuffrida
         */
        public function enqueue_styles () {
            wp_enqueue_style ( 'ywpi_css', YITH_YWPI_ASSETS_URL . '/css/ywpi.css' );
        }

        /**
         * Add some actions triggered by order status
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function add_order_status_related_actions () {
            //  If invoice generation is only manual, no automatic actions will be added
            if ( 'auto' != ywpi_get_option ( 'ywpi_invoice_generation' ) ) {
                return;
            }

            if ( 'new' === ywpi_get_option ( 'ywpi_create_invoice_on' ) ) {
                add_action ( 'woocommerce_order_status_on-hold', array ( $this, 'create_automatic_invoice' ) );
            } else if ( 'processing' === ywpi_get_option ( 'ywpi_create_invoice_on' ) ) {
                add_action ( 'woocommerce_order_status_processing', array ( $this, 'create_automatic_invoice' ) );
            } else if ( 'completed' === ywpi_get_option ( 'ywpi_create_invoice_on' ) ) {
                add_action ( 'woocommerce_order_status_completed', array ( $this, 'create_automatic_invoice' ) );
            }
        }

        /**
         * Create an invoice for a specific order
         *
         * @param int $order_id the order id
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function create_automatic_invoice ( $order_id ) {
            //  In "Preview mode" it's not possible to generate valid documents
            if ( $this->preview_mode ) {
                return;
            }

            if ( ! apply_filters ( 'yith_ywpi_create_automatic_invoices', true, $order_id ) ) {
                return;
            }

            $document = $this->get_order_document_by_type ( $order_id, YITH_YWPI_DOCUMENT_TYPE_INVOICE );

            if ( null != $document ) {
                $this->save_document ( $document );
            }

        }

        /**
         * Add invoice actions to the orders listing
         *
         * @param WC_Order $order
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function add_back_end_invoice_buttons ( $order ) {
            //  In "Preview mode" it's not possible to generate valid documents
            if ( $this->preview_mode ) {
                return;
            }

            $invoice = $this->get_order_document_by_type ( $order->id, YITH_YWPI_DOCUMENT_TYPE_INVOICE );

            if ( $invoice->exists ) {
                $url   = ywpi_document_nonce_url ( YITH_YWPI_VIEW_INVOICE_ACTION, $order );
                $text  = __ ( "Show invoice", 'yith-woocommerce-pdf-invoice' );
                $class = "ywpi_view_invoice";
            } else {
                $url   = ywpi_document_nonce_url ( YITH_YWPI_CREATE_INVOICE_ACTION, $order );
                $text  = __ ( "Create invoice", 'yith-woocommerce-pdf-invoice' );
                $class = "ywpi_create_invoice";
            }

            $html = '<a href="' . $url . '" class="button tips ywpi_buttons ' . $class . '" data-tip="' . $text . '" title="' . $text . '">' . $text . '</a>';
            echo apply_filters ( 'yith_ywpi_show_invoice_button_order_list', $html, $order );

        }

        /**
         * Add shipping list actions to the orders listing
         *
         * @param WC_Order $order
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function add_back_end_shipping_list_buttons ( $order ) {
            //  In "Preview mode" it's not possible to generate valid documents
            if ( $this->preview_mode ) {
                return;
            }

            if ( 'yes' == ywpi_get_option ( 'ywpi_enable_shipping_list' ) ) {

                $shipping_document = new YITH_Shipping( $order->id );

                if ( $shipping_document->exists ) {
                    $url   = ywpi_document_nonce_url ( YITH_YWPI_VIEW_SHIPPING_LIST_ACTION, $order );
                    $text  = __ ( "Show shipping list document", 'yith-woocommerce-pdf-invoice' );
                    $class = "ywpi_view_shipping_list";

                } else {
                    $url   = ywpi_document_nonce_url ( YITH_YWPI_CREATE_SHIPPING_LIST_ACTION, $order );
                    $text  = __ ( "Create shipping list document", 'yith-woocommerce-pdf-invoice' );
                    $class = "ywpi_create_shipping_list";
                }

                echo '<a href="' . $url . '" class="button tips ywpi_buttons ' . $class . '" data-tip="' . $text . '" title="' . $text . '">' . $text . '</a>';
            }
        }

        /**
         * Attach the documents to the email
         *
         * @param array  $attachments
         * @param string $status
         * @param mixed  $object
         *
         * @return array
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function attach_invoice_to_email ( $attachments, $status, $object ) {
            if ( ! $object instanceof WC_Order ) {
                return $attachments;
            }

            $invoice = new YITH_Invoice( $object->id );
            if ( ! $invoice->exists ) {
                return $attachments;
            }

            $allowed_statuses = array (
                'new_order',
                'customer_invoice',
                'customer_processing_order',
                'customer_completed_order',
            );

            if ( isset( $status ) && in_array ( $status, $allowed_statuses ) ) {
                $attachments[] = $invoice->get_full_path ();
            }

            return $attachments;
        }

        /**
         * Add front-end button for actions available for customers
         */
        public function add_buttons_on_customer_orders_page () {
            /**
             * Show print invoice button on frontend orders page
             */
            add_action ( 'woocommerce_my_account_my_orders_actions', array (
                $this,
                'print_invoice_button',
            ), 10, 2 );
        }

        /**
         * Add back-end buttons for actions available for admins
         */
        public function add_features_on_admin_orders_page () {
            add_action ( 'manage_shop_order_posts_custom_column', array (
                $this,
                'show_invoice_custom_column_data',
            ), 99 );
        }

        /**
         * Append invoice information on order_title column, if current order has an invoice associated
         *
         * @param string $column the column name being shown
         */
        public function show_invoice_custom_column_data ( $column ) {
            global $post;

            if ( 'order_title' != $column ) {
                return;
            }

            $this->show_invoice_information_link ( $post );
        }

        /**
         * show a link with the order invoiced status
         *
         * @param WP_Post $post
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function show_invoice_information_link ( $post ) {
            $order = wc_get_order ( $post );

            $invoice = new YITH_Invoice( $order->id );

            if ( ! $invoice->exists ) {
                return;
            }

            $url = ywpi_document_nonce_url ( YITH_YWPI_VIEW_INVOICE_ACTION, $order );

            ?>
            <div class="ywpi-invoiced-order">
                <a target="_blank" href="<?php echo $url; ?>"
                   title="<?php _e ( "View Invoice", 'yith-woocommerce-pdf-invoice' ); ?>"></a>
                <small
                    class="meta ywpi-invoice-information"><?php echo sprintf ( __ ( "Invoice No. %s (%s)", 'yith-woocommerce-pdf-invoice' ), $invoice->formatted_number, $this->get_document_formatted_date ( $invoice ) ); ?></small>
            </div>
            <?php
        }

        /**
         * add the right action based on GET var current used
         *
         */
        public function init_plugin_actions () {

            if ( isset( $_GET[ YITH_YWPI_CREATE_INVOICE_ACTION ] ) ) {
                $this->create_document ( $_GET[ YITH_YWPI_CREATE_INVOICE_ACTION ], YITH_YWPI_DOCUMENT_TYPE_INVOICE );
            } else if ( isset( $_GET[ YITH_YWPI_VIEW_INVOICE_ACTION ] ) ) {
                $this->view_document ( $_GET[ YITH_YWPI_VIEW_INVOICE_ACTION ], YITH_YWPI_DOCUMENT_TYPE_INVOICE );
            } else if ( isset( $_GET[ YITH_YWPI_RESET_INVOICE_ACTION ] ) ) {
                $this->reset_document ( $_GET[ YITH_YWPI_RESET_INVOICE_ACTION ], YITH_YWPI_DOCUMENT_TYPE_INVOICE );
            } else if ( isset( $_GET[ YITH_YWPI_CREATE_SHIPPING_LIST_ACTION ] ) ) {
                $this->create_document ( $_GET[ YITH_YWPI_CREATE_SHIPPING_LIST_ACTION ], YITH_YWPI_DOCUMENT_TYPE_SHIPPING );
            } else if ( isset( $_GET[ YITH_YWPI_VIEW_SHIPPING_LIST_ACTION ] ) ) {
                $this->view_document ( $_GET[ YITH_YWPI_VIEW_SHIPPING_LIST_ACTION ], YITH_YWPI_DOCUMENT_TYPE_SHIPPING );
            } else if ( isset( $_GET[ YITH_YWPI_RESET_SHIPPING_LIST_ACTION ] ) ) {
                $this->reset_document ( $_GET[ YITH_YWPI_RESET_SHIPPING_LIST_ACTION ], YITH_YWPI_DOCUMENT_TYPE_SHIPPING );
            } else if ( isset( $_GET[ YITH_YWPI_PREVIEW_INVOICE_ACTION ] ) ) {
                $this->view_preview ( $_GET[ YITH_YWPI_PREVIEW_INVOICE_ACTION ], YITH_YWPI_DOCUMENT_TYPE_INVOICE );
            } else {
                return;
            }

            wp_redirect ( esc_url_raw ( remove_query_arg ( ywpi_get_query_args_list () ) ) );
        }

        /**
         * Check nounce when an action for generating documents is called
         *
         * @param YITH_Document $document the document that is going to be created
         *
         * @return bool
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function check_invoice_url_for_action ( $document ) {

            if ( ! $document ) {
                return false;
            }

            //  Check if the document is for a valid order
            if ( ! $document->is_valid ) {
                return false;
            }

            //  check for nounce value
            if ( ! ywpi_document_nonce_check ( $document->order ) ) {

                return false;
            }

            return true;
        }

        /**
         * Retrieve an order document from a document type
         *
         * @param        $order_id
         * @param string $document_type
         *
         * @return null|Yith_Invoice|Yith_Shipping
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function get_order_document_by_type ( $order_id, $document_type = '' ) {

            if ( $document_type == YITH_YWPI_DOCUMENT_TYPE_INVOICE ) {
                return new Yith_Invoice( $order_id );
            } else if ( $document_type == YITH_YWPI_DOCUMENT_TYPE_SHIPPING ) {
                return new Yith_Shipping( $order_id );
            }

            return null;
        }

        /**
         * Retrieve the invoice document from an order
         *
         * @param int $order_id the order id
         *
         * @return null|YITH_Invoice
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        private function get_invoice_document ( $order_id ) {
            return $this->get_order_document_by_type ( $order_id, YITH_YWPI_DOCUMENT_TYPE_INVOICE );
        }

        /**
         * Retrieve the shipping list document from an order
         *
         * @param int $order_id the order id
         *
         * @return null|YITH_Shipping
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        private function get_shipping_list_document ( $order_id ) {
            return $this->get_order_document_by_type ( $order_id, YITH_YWPI_DOCUMENT_TYPE_SHIPPING );
        }

        /**
         * Create a new document of the type requested, for a specific order
         *
         * @param  int   $order_id      the order id for which the document is created
         * @param string $document_type the document type to be generated
         *
         * @return YITH_Document|null
         */
        public function create_document ( $order_id, $document_type = '' ) {
            //  In "Preview mode" it's not possible to generate valid documents
            if ( $this->preview_mode ) {
                return null;
            }

            $document = $this->get_order_document_by_type ( $order_id, $document_type );

            if ( ( null == $document ) || ! $this->check_invoice_url_for_action ( $document ) ) {
                return null;
            }

            $this->save_document ( $document );

            if ( YITH_YWPI_DOCUMENT_TYPE_INVOICE == $document_type ) {
                $this->increment_invoice_number ( $document );
            }

            return $document;
        }

        /**
         * Show a preview of the document requested, without affecting the counter and settings that should be used only for real invoices
         *
         * @param int    $order_id      the order id
         * @param string $document_type the document type requested
         *
         * @return null
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function view_preview ( $order_id, $document_type = '' ) {
            $document = $this->get_order_document_by_type ( $order_id, $document_type );

            if ( ( null == $document ) || ! $this->check_invoice_url_for_action ( $document ) ) {
                return null;
            }


            $this->create_pdf_file ( $document );
            $this->show_file ( $document->get_full_path () );
        }

        /**
         * Return the next available invoice number
         *
         * @param YITH_Document $document the document that need a new invoice number
         *
         * @return int|mixed
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        private function get_new_invoice_number ( $document ) {

            //  Check if this is the first invoice of the year, in this case, if reset on new year is enabled, restart from 1
            if ( 'yes' === get_option ( 'ywpi_invoice_reset' ) ) {
                $last_year = get_option ( 'ywpi_invoice_year_billing' );

                if ( isset( $last_year ) && is_numeric ( $last_year ) ) {
                    $current_year = getdate ();
                    $current_year = $current_year[ 'year' ];

                    if ( $last_year < $current_year ) {
                        //  set new year as last invoiced year and reset invoice number
                        update_option ( 'ywpi_invoice_year_billing', $current_year );
                        ywpi_update_option ( 'ywpi_invoice_number', 1, $document );
                    }
                }
            }

            $current_invoice_number = ywpi_get_option ( 'ywpi_invoice_number', $document );

            if ( ! isset( $current_invoice_number ) || ! is_numeric ( $current_invoice_number ) ) {
                $current_invoice_number = 1;
            }

            return $current_invoice_number;
        }

        /**
         * Save the next available invoice number
         *
         * @param YITH_Invoice $document
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        private function increment_invoice_number ( $document ) {

            ywpi_update_option ( 'ywpi_invoice_number', intval ( $document->number ) + 1, $document );
        }

        /**
         * Save the document in PDF
         *
         * @param YITH_Document $document the document to print in PDF
         *
         * @return bool
         * */
        public function save_document ( $document ) {

            if ( ! $document instanceof YITH_Document ) {
                return false;
            }

            $order = $document->order;

            if ( $document instanceof YITH_Invoice ) {

                /** @var YITH_Invoice $document */
                $document->date   = current_time ( 'mysql', 0 );
                $document->number = $this->get_new_invoice_number ( $document );
                $document->prefix = $this->replace_placeholders ( ywpi_get_option ( 'ywpi_invoice_prefix', $order ), $document->date );
                $document->suffix = $this->replace_placeholders ( ywpi_get_option ( 'ywpi_invoice_suffix', $order ), $document->date );

                $formatted_invoice_number = ywpi_get_option_with_placeholder ( 'ywpi_invoice_number_format', '[number]' );
                $formatted_invoice_number = str_replace (
                    array ( '[prefix]', '[suffix]', '[number]' ),
                    array ( $document->prefix, $document->suffix, $document->number ),
                    $formatted_invoice_number );

                $document->formatted_number = $formatted_invoice_number;
            }

            $this->create_pdf_file ( $document );

            $document->save ();
        }

        /**
         * Replace fixed placeholders from a specific string
         *
         * @param string $text the string to be parsed
         * @param string $date
         *
         * @return mixed
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        private function replace_placeholders ( $text, $date ) {

            $date = getdate ( strtotime ( $date ) );

            $replaced_text = str_replace (
                array (
                    '[year]',
                    '[month]',
                    '[day]',
                ),
                array (
                    $date[ 'year' ],
                    sprintf ( "%02d", $date[ 'mon' ] ),
                    sprintf ( "%02d", $date[ 'mday' ] ),
                ),
                $text );

            return $replaced_text;
        }

        /**
         * Show a document
         *
         * @param int    $order_id      the order id
         * @param string $document_type the type of document to show
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function view_document ( $order_id, $document_type ) {

            $document = $this->get_order_document_by_type ( $order_id, $document_type );

            if ( ( null == $document ) || ! $this->check_invoice_url_for_action ( $document ) ) {
                return;
            }

            $this->show_file ( $document->get_full_path () );
        }

        /**
         * Show a file on browser or ask for download, according with related option
         *
         * @param YITH_Document|string $resource the document to show or the path of the file to be shown
         */
        public function show_file ( $resource ) {

            $path = $resource;
            if ( $resource instanceof YITH_Document ) {
                $path = $resource->get_full_path ();
            }

            if ( 'open' == ywpi_get_option ( 'ywpi_pdf_invoice_behaviour' ) ) {
                header ( 'Content-type: application/pdf' );
                header ( 'Content-Disposition: inline; filename = "' . basename ( $path ) . '"' );
                header ( 'Content-Transfer-Encoding: binary' );
                header ( 'Content-Length: ' . filesize ( $path ) );
                header ( 'Accept-Ranges: bytes' );
                @readfile ( $path );
                exit();
            } else {
                header ( "Content-type: application/pdf" );
                header ( 'Content-Disposition: attachment; filename = "' . basename ( $path ) . '"' );
                @readfile ( $path );
            }
        }

        /**
         * Cancel an order document
         *
         * @param int    $order_id      the order id
         * @param string $document_type the type of document to reset
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function reset_document ( $order_id, $document_type ) {
            $document = $this->get_order_document_by_type ( $order_id, $document_type );

            if ( $this->check_invoice_url_for_action ( $document ) ) {
                $document->reset ();
            }
        }

        /**
         * Register actions and filters to be used for creating an entry on YIT Plugin menu
         *
         * @since  1.0
         * @author Lorenzo giuffrida
         * @access public
         * @return void
         */
        public function set_metabox_actions () {
            /**
             * Add metabox on order, to let vendor add order tracking code and carrier
             */
            add_action ( 'add_meta_boxes', array ( $this, 'add_invoice_metabox' ) );
        }

        /**
         *  Add a metabox on backend order page, to be filled with order tracking information
         *
         * @since  1.0
         * @author Lorenzo giuffrida
         * @access public
         * @return void
         */
        function add_invoice_metabox () {

            add_meta_box ( 'yith-pdf-invoice-box', __ ( 'YITH PDF Invoice', 'yith-woocommerce-pdf-invoice' ), array (
                $this,
                'show_pdf_invoice_metabox',
            ), 'shop_order', 'side', 'high' );
        }

        /**
         * Show the preview metabox for testing the current PDF template
         *
         * @param WP_Post $post
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        function show_preview_mode_metabox ( $post ) {
            if ( ! $this->preview_mode ) {
                return;
            }

            $_order = wc_get_order ( $post );

            ?>
            <div class="invoice-information">
                <p>
                    <a class="button tips ywpi_create_invoice"
                       data-tip="<?php _e ( "Preview invoice", 'yith-woocommerce-pdf-invoice' ); ?>"
                       href="<?php echo ywpi_document_nonce_url ( YITH_YWPI_PREVIEW_INVOICE_ACTION, $_order ); ?>"><?php _e ( "Preview invoice", 'yith-woocommerce-pdf-invoice' ); ?></a>
                </p>
            </div>
            <?php
        }

        /**
         * Show metabox content for tracking information on backend order page
         *
         * @param WP_Post $post the order object that is currently shown
         *
         * @since  1.0
         * @author Lorenzo giuffrida
         * @access public
         * @return void
         */
        function show_pdf_invoice_metabox ( $post ) {
            if ( $this->preview_mode ) {

                $this->show_preview_mode_metabox ( $post );

                return;
            }

            $invoice = $this->get_order_document_by_type ( $post->ID, YITH_YWPI_DOCUMENT_TYPE_INVOICE );
            $_order  = $invoice->order;

            ?>
            <div class="invoice-information">
                <?php if ( ( null != $invoice ) && $invoice->exists ) : ?>
                    <table class="form-table">
                        <tbody>
                        <tr valign="top">
                            <th scope="row" class="titledesc">
                                <label><?php _e ( 'Invoiced on: ', 'yith-woocommerce-pdf-invoice' ); ?></label>
                            </th>
                            <td class="forminp forminp-text">
                                <?php echo $this->get_document_formatted_date ( $invoice ); ?></td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" class="image_upload">
                                <label><?php _e ( 'Invoice number: ', 'yith-woocommerce-pdf-invoice' ); ?></label>
                            </th>
                            <td class="forminp forminp-text">
                                <?php echo $this->get_formatted_invoice_number ( $invoice ); ?>
                            </td>
                        </tr>
                        </tbody>
                    </table>

                    <div style="clear: both; margin-top: 15px">
                        <a target="blank" class="button tips ywpi_view_invoice"
                           data-tip="<?php _e ( "View invoice", 'yith-woocommerce-pdf-invoice' ); ?>"
                           href="<?php echo ywpi_document_nonce_url ( YITH_YWPI_VIEW_INVOICE_ACTION, $_order ); ?>"><?php _e ( "Invoice", 'yith-woocommerce-pdf-invoice' ); ?></a>
                        <a class="button tips ywpi_cancel_invoice"
                           data-tip="<?php _e ( "Cancel invoice", 'yith-woocommerce-pdf-invoice' ); ?>"
                           href="<?php echo ywpi_document_nonce_url ( YITH_YWPI_RESET_INVOICE_ACTION, $_order ); ?>"><?php _e ( "Invoice", 'yith-woocommerce-pdf-invoice' ); ?></a>
                    </div>
                <?php elseif ( apply_filters ( 'yith_ywpi_show_invoice_button_order_page', true, $_order ) ) : ?>
                    <p>
                        <a class="button tips ywpi_create_invoice"
                           data-tip="<?php _e ( "Create invoice", 'yith-woocommerce-pdf-invoice' ); ?>"
                           href="<?php echo ywpi_document_nonce_url ( YITH_YWPI_CREATE_INVOICE_ACTION, $_order ); ?>"><?php _e ( "Invoice", 'yith-woocommerce-pdf-invoice' ); ?></a>
                    </p>
                <?php endif; ?>

                <?php
                if ( 'yes' == ywpi_get_option ( 'ywpi_enable_shipping_list' ) ) {
                    $shipping = $this->get_order_document_by_type ( $post->ID, YITH_YWPI_DOCUMENT_TYPE_SHIPPING );
                    ?>
                    <?php if ( ( null != $shipping ) && $shipping->exists ) : ?>
                        <div style="clear: both; margin-top: 15px">
                            <a target="blank" class="button tips ywpi_view_shipping_list"
                               data-tip="<?php _e ( "View shipping list", 'yith-woocommerce-pdf-invoice' ); ?>"
                               href=" <?php echo ywpi_document_nonce_url ( YITH_YWPI_VIEW_SHIPPING_LIST_ACTION, $_order ); ?>"><?php _e ( "Shipping", 'yith-woocommerce-pdf-invoice' ); ?></a>
                            <a class="button tips ywpi_cancel_shipping_list"
                               data-tip="<?php _e ( "Cancel shipping list", 'yith-woocommerce-pdf-invoice' ); ?>"
                               href="<?php echo ywpi_document_nonce_url ( YITH_YWPI_RESET_SHIPPING_LIST_ACTION, $_order ); ?>"><?php _e ( "Shipping", 'yith-woocommerce-pdf-invoice' ); ?></a>
                        </div>
                    <?php else : ?>
                        <p>
                            <a class="button tips ywpi_create_shipping_list"
                               data-tip="<?php _e ( "Create shipping list", 'yith-woocommerce-pdf-invoice' ); ?>"
                               href="<?php echo ywpi_document_nonce_url ( YITH_YWPI_CREATE_SHIPPING_LIST_ACTION, $_order ); ?>"><?php _e ( "Shipping", 'yith-woocommerce-pdf-invoice' ); ?></a>
                        </p>
                        <?php
                    endif;
                } ?>
            </div>
            <?php
        }

        /**
         * Add a button to print invoice, if exists, from order page on frontend.
         *
         * @param array    $actions current actions
         * @param WC_Order $order   the order
         *
         * @return array
         */
        public function print_invoice_button ( $actions, $order ) {
            $invoice = new YITH_Invoice( $order->id );

            if ( $invoice->exists ) {
                // Add the print button
                $actions[ 'print-invoice' ] = array (
                    'url'  => ywpi_document_nonce_url ( YITH_YWPI_VIEW_INVOICE_ACTION, $order ),
                    'name' => __ ( 'Invoice', 'yith-woocommerce-pdf-invoice' ),
                );
            }

            return $actions;
        }

        /**
         * replace the customer details using the plugin option pattern
         *
         * @param string $pattern
         * @param int    $order_id
         *
         * @return string
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function replace_customer_details_pattern ( $pattern, $order_id ) {
            preg_match_all ( "/{{([^}}]*)}}/", $pattern, $matches );

            $customer_details = $pattern;
            if ( isset( $matches[ 1 ] ) ) {
                foreach ( $matches[ 1 ] as $match ) {
                    $replace_value = get_post_meta ( $order_id, $match, true );
                    //  Convert country code and convert it to the country name
                    if ( ( '_billing_country' == $match ) || ( '_shipping_country' == $match ) ) {
                        $countries = WC ()->countries->get_countries ();
                        if ( isset( $countries[ $replace_value ] ) ) {
                            $replace_value = $countries[ $replace_value ];
                        }
                    }
                    $customer_details = str_replace ( "{{" . $match . "}}", $replace_value, $customer_details );
                }
            }

            // Clean up white space
            $replace_details = preg_replace ( '/  +/', ' ', trim ( $customer_details ) );
            $replace_details = preg_replace ( '/\n\n+/', "\n", $replace_details );

            // Break newlines apart and remove empty lines/trim commas and white space
            $replace_details = explode ( "\n", $replace_details );

            // Add html breaks
            $replace_details = implode ( '<br/>', $replace_details );

            return $replace_details;
        }

        /**
         * Get the customer billing details
         *
         * @param YITH_Document $document
         *
         * @return string
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         *
         */
        public function get_customer_billing_details ( $document ) {
            $customer_details = ywpi_get_option ( 'ywpi_customer_billing_details', '' );

            return $this->replace_customer_details_pattern ( $customer_details, $document->order->id );
        }

        /**
         * Get the customer shipping details
         *
         * @param YITH_Document $document
         *
         * @return string
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         *
         */
        public function get_customer_shipping_details ( $document ) {
            $customer_details = ywpi_get_option ( 'ywpi_customer_shipping_details', '' );

            return $this->replace_customer_details_pattern ( $customer_details, $document->order->id );
        }

        /**
         * Show data of customer on invoice template
         *
         * @param YITH_Document $document
         */
        public function show_invoice_template_customer_data ( $document ) {

            /** @var WC_Order $order */
            $order   = $document->order;
            $label   = '';
            $content = '';

            if ( $document instanceof YITH_Invoice ) {
                $content = wp_kses ( $this->get_customer_billing_details ( $document ), array ( "br" => array () ) );
                $label   = __ ( "Invoice To:", 'yith-woocommerce-pdf-invoice' );
            } elseif ( $document instanceof YITH_Shipping ) {
                $content = wp_kses ( $this->get_customer_shipping_details ( $document ), array ( "br" => array () ) );
                $label   = __ ( "Shipping To:", 'yith-woocommerce-pdf-invoice' );
            } elseif ( $document instanceof YITH_Pro_Forma ) {
                $content = wp_kses ( $this->get_customer_billing_details ( $document ), array ( "br" => array () ) );
                $label   = __ ( "To:", 'yith-woocommerce-pdf-invoice' );
            }

            // Display values
            $result = "<div class='invoice-to-section'><span class='invoice-from-to'>$label</span>$content</div >";

            echo apply_filters ( 'yith_ywpi_show_invoice_template_customer_data', $result, $document );
        }

        /**
         * Show the data section for invoice documents
         *
         * @param YITH_Invoice $document
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        private function show_template_invoice_data ( $document ) {
            if ( $document instanceof YITH_Invoice ) {
                ?>
                <table class="invoice-data-table">
                    <tr class="invoice-number">
                        <td colspan="2"><?php _e ( "Invoice number", 'yith-woocommerce-pdf-invoice' ); ?></td>
                    </tr>

                    <tr class="invoice-number invoice-number-end">
                        <td colspan="2"><?php echo $this->get_formatted_invoice_number ( $document ); ?></td>
                    </tr>

                    <tr class="spacer">
                        <td></td>
                    </tr>

                    <tr class="invoice-order-number">
                        <td><?php _e ( "Order", 'yith-woocommerce-pdf-invoice' ); ?></td>
                        <td class="right"><?php echo $document->order->get_order_number (); ?></td>
                    </tr>

                    <tr class="invoice-date">
                        <td><?php _e ( "Invoice date", 'yith-woocommerce-pdf-invoice' ); ?></td>
                        <td class="right"><?php echo $this->get_document_formatted_date ( $document ); ?></td>
                    </tr>

                    <tr class="invoice-amount">
                        <td><?php _e ( "Order Amount", 'yith-woocommerce-pdf-invoice' ); ?></td>
                        <td class="right"><?php echo wc_price ( $document->order->get_total () ); ?></td>
                    </tr>
                </table>
                <?php
            }
        }

        /**
         * Show the data section for shipping documents
         *
         * @param YITH_Shipping $document
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        private function show_template_shipping_list_data ( $document ) {
            if ( $document instanceof YITH_Shipping ) {
                ?>
                <table class="invoice-data-table">
                    <tr class="invoice-order-number">
                        <td><?php _e ( "Order", 'yith-woocommerce-pdf-invoice' ); ?></td>
                        <td class="right"><?php echo $document->order->get_order_number (); ?></td>
                    </tr>

                    <tr class="invoice-date">
                        <td><?php _e ( "Order date", 'yith-woocommerce-pdf-invoice' ); ?></td>
                        <td class="right"><?php echo $this->get_document_formatted_date ( $document ); ?></td>
                    </tr>
                    <?php if ( 'yes' == ywpi_get_option ( 'ywpi_shipping_list_show_order_totals' ) ) : ?>
                        <tr class="invoice-amount">
                            <td><?php _e ( "Order Amount", 'yith-woocommerce-pdf-invoice' ); ?></td>
                            <td class="right"><?php echo wc_price ( $document->order->get_total () ); ?></td>
                        </tr>
                    <?php endif; ?>
                </table>
                <?php
            }
        }

        /**
         * Show the document section with the document data like number, data, ...
         *
         * @param YITH_Document $document
         */
        public function show_template_document_data ( $document ) {

            if ( $document instanceof YITH_Invoice ) {
                $this->show_template_invoice_data ( $document );
            } else if ( $document instanceof YITH_Shipping ) {
                $this->show_template_shipping_list_data ( $document );
            }
            ?>


            <?php
            /* pro-forma
            if (!isset($ywpi_document)) {
                return;
            }
            ?>
            <table>
                <tr class="invoice-order-number">
                    <td><?php _e("Order", 'yith-woocommerce-pdf-invoice'); ?></td>
                    <td class="right"><?php echo $ywpi_document->order->get_order_number(); ?></td>
                </tr>

                <tr class="invoice-date">
                    <td><?php _e("Order date", 'yith-woocommerce-pdf-invoice'); ?></td>
                    <td class="right"><?php echo $ywpi_document->get_document_formatted_date(); ?></td>
                </tr>
                <tr class="invoice-amount">
                    <td><?php _e("Order Amount", 'yith-woocommerce-pdf-invoice'); ?></td>
                    <td class="right"><?php echo wc_price($ywpi_document->order->get_total()); ?></td>
                </tr>
            </table>
        <?php*/

            /*invoice
            if ( ! isset( $ywpi_document ) || ! $ywpi_document->exists ) {
                return;
            }
            ?>
            <table>
                <tr class="invoice-number">
                    <td><?php _e ( "Invoice", 'yith-woocommerce-pdf-invoice' ); ?></td>
                    <td class="right"><?php echo $ywpi_document->get_formatted_invoice_number (); ?></td>
                </tr>

                <tr class="invoice-order-number">
                    <td><?php _e ( "Order", 'yith-woocommerce-pdf-invoice' ); ?></td>
                    <td class="right"><?php echo $ywpi_document->order->get_order_number (); ?></td>
                </tr>

                <tr class="invoice-date">
                    <td><?php _e ( "Invoice date", 'yith-woocommerce-pdf-invoice' ); ?></td>
                    <td class="right"><?php echo $ywpi_document->get_document_formatted_date (); ?></td>
                </tr>
                <tr class="invoice-amount">
                    <td><?php _e ( "Order Amount", 'yith-woocommerce-pdf-invoice' ); ?></td>
                    <td class="right"><?php echo wc_price ( $ywpi_document->order->get_total () ); ?></td>
                </tr>
            </table>
            <?php
            */

            /* shipping

            if ( ! isset( $ywpi_document ) ) {
                return;
            }
            ?>
            <table>
                <tr class="invoice-order-number">
                    <td><?php _e ( "Order", 'yith-woocommerce-pdf-invoice' ); ?></td>
                    <td class="right"><?php echo $ywpi_document->order->get_order_number (); ?></td>
                </tr>

                <tr class="invoice-date">
                    <td><?php _e ( "Order date", 'yith-woocommerce-pdf-invoice' ); ?></td>
                    <td class="right"><?php echo $ywpi_document->get_document_formatted_date (); ?></td>
                </tr>
                <?php if ( 'yes' == ywpi_get_option ( 'ywpi_shipping_list_show_order_totals' ) ) : ?>
                    <tr class="invoice-amount">
                        <td><?php _e ( "Order Amount", 'yith-woocommerce-pdf-invoice' ); ?></td>
                        <td class="right"><?php echo wc_price ( $ywpi_document->order->get_total () ); ?></td>
                    </tr>
                <?php endif; ?>
            </table>
            <?php
            */
        }

        /**
         * Show company logo on invoice template
         *
         * @param YITH_Document $document
         */
        public function show_invoice_template_company_logo ( $document ) {

            $company_logo = null;

            if ( ( $document instanceof YITH_Pro_Forma ) || ( $document instanceof YITH_Invoice ) ) {
                $company_logo = 'yes' === ywpi_get_option ( 'ywpi_show_company_logo', $document ) ? ywpi_get_option ( 'ywpi_company_logo', $document ) : null;
            } elseif ( $document instanceof YITH_Shipping ) {
                $company_logo = 'yes' === ywpi_get_option ( 'ywpi_shipping_list_show_company_logo', $document ) ? ywpi_get_option ( 'ywpi_company_logo', $document ) : null;
            }

            if ( $company_logo ) {

                echo '<div class="company-logo">
					<img src="' . $company_logo . '">
				</div>';
            }
        }

        /**
         * Render and show data to "sender section" on invoice template
         *
         * @param YITH_Document $document the document to be shown
         */
        public function show_invoice_template_sender ( $document ) {
            $company_details = '';
            $company_name    = '';
            $section_title   = '';

            if ( $document instanceof YITH_Shipping ) {
                $company_name    = 'yes' === ywpi_get_option ( 'ywpi_shipping_list_show_company_name', $document ) ? ywpi_get_option ( 'ywpi_company_name', $document ) : null;
                $company_details = 'yes' === ywpi_get_option ( 'ywpi_shipping_list_show_company_details', $document ) ? nl2br ( ywpi_get_option ( 'ywpi_company_details', $document ) ) : null;
                $section_title   = __ ( "Shipping From:", 'yith-woocommerce-pdf-invoice' );
            } else if ( ( $document instanceof YITH_Invoice ) || ( $document instanceof YITH_Pro_Forma ) ) {

                $company_name    = 'yes' === ywpi_get_option ( 'ywpi_show_company_name', $document ) ? ywpi_get_option ( 'ywpi_company_name', $document ) : null;
                $company_details = 'yes' === ywpi_get_option ( 'ywpi_show_company_details', $document ) ? nl2br ( ywpi_get_option ( 'ywpi_company_details', $document ) ) : null;
                $section_title   = __ ( "Invoice From:", 'yith-woocommerce-pdf-invoice' );
            }

            if ( ! isset( $company_name ) && ! isset( $show_logo ) ) {
                return;
            }

            echo '<span class="invoice-from-to">' . $section_title . '</span>';

            if ( isset( $company_name ) ) {
                echo '<span class="company-name">' . $company_name . '</span>';
            }

            if ( isset ( $company_details ) ) {
                echo '<span class="company-details" > ' . $company_details . '</span > ';
            }
        }

        /**
         * Return the folder where documents have to be stored. Create the folder path if not exists.
         *
         * @param YITH_Document $document
         *
         * @return string
         */
        private function create_storing_folder ( $document ) {

            /* Create folders for storing documents */
            $folder_path = get_option ( 'ywpi_invoice_folder_format' );

            $date_val = strtotime ( $document->order->order_date );
            $date     = getdate ( $date_val );

            $folder_path = str_replace (
                array (
                    '[year]',
                    '[month]',
                    '[day]',
                ),
                array (
                    $date[ 'year' ],
                    sprintf ( "%02d", $date[ 'mon' ] ),
                    sprintf ( "%02d", $date[ 'mday' ] ),
                ),
                $folder_path );

            $folder_path = apply_filters ( 'ywpi_storing_folder', $folder_path, $document );

            if ( ! file_exists ( YITH_YWPI_DOCUMENT_SAVE_DIR . $folder_path ) ) {
                wp_mkdir_p ( YITH_YWPI_DOCUMENT_SAVE_DIR . $folder_path );
            }

            return $folder_path;
        }

        /**
         * Get current document date using the current date format
         *
         * @param YITH_Document $document
         *
         * @return bool|string
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function get_document_formatted_date ( $document ) {
            $format = ywpi_get_option ( 'ywpi_invoice_date_format' );

            return date ( $format, strtotime ( $document->order->order_date ) );
        }

        /**
         * Retrieve a PDF file for a specific document
         *
         * @param YITH_Document $document the document for which a PDF file should be created
         *
         * @return int
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function create_pdf_file ( $document ) {

            $pdf_content = $this->generate_template ( $document );

            $document->save_folder = $this->create_storing_folder ( $document );
            $document->save_path   = sprintf ( "%s.pdf", $this->get_document_filename ( $document ) );

            return file_put_contents ( $document->get_full_path (), $pdf_content );
        }

        /**
         * Return the filename associated to the document, based on plugin settings.
         *
         * @param YITH_Document $document
         *
         * @return mixed|string|void
         */
        private function get_document_filename ( $document ) {

            $pattern = '';
            if ( $document instanceof YITH_Invoice ) {
                $pattern = ywpi_get_option_with_placeholder ( 'ywpi_invoice_filename_format', '[number]' );

                $pattern = str_replace (
                    array (
                        '[number]',
                        '[prefix]',
                        '[suffix]',
                    ),
                    array (
                        $document->number,
                        $document->prefix,
                        $document->suffix,
                    ),
                    $pattern );
            } else if ( $document instanceof YITH_Pro_Forma ) {
                $pattern = ywpi_get_option_with_placeholder ( 'ywpi_pro_forma_invoice_filename_format', '[order_number]' );

                $pattern = str_replace ( '[order_number]', $document->order->get_order_number (), $pattern );
            } else if ( $document instanceof YITH_Shipping ) {
                $pattern = ywpi_get_option_with_placeholder ( 'ywpi_shipping_list_filename_format', '[order_number]' );
                $pattern = str_replace ( '[order_number]', $document->order->get_order_number (), $pattern );
            }

            //  Substitute date placeholders
            $order_date = strtotime ( $document->order->order_date );
            $date       = getdate ( $order_date );

            $pattern = str_replace (
                array (
                    '[year]',
                    '[month]',
                    '[day]',
                ),
                array (
                    $date[ 'year' ],
                    sprintf ( "%02d", $date[ 'mon' ] ),
                    sprintf ( "%02d", $date[ 'mday' ] ),
                ),
                $pattern );

            return $pattern;
        }

        /**
         * Retrieve the formatted document number
         *
         * @param YITH_Document $document
         *
         * @return mixed|string|void
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public function get_formatted_invoice_number ( $document ) {
            // if a document number is set, retrieve it
            $formatted_invoice_number = get_post_meta ( $document->order->id, '_ywpi_invoice_formatted_number', true );

            if ( $formatted_invoice_number ) {
                return $formatted_invoice_number;
            }

            $formatted_invoice_number = ywpi_get_option_with_placeholder ( 'ywpi_invoice_number_format', '[number]' );

            $formatted_invoice_number = str_replace (
                array ( '[prefix]', '[suffix]', '[number]' ),
                array ( $document->prefix, $document->suffix, $document->number ),
                $formatted_invoice_number );

            return $formatted_invoice_number;
        }

        //  ------------------------------------------------------------------------------------------------------------------

        /**
         * Set a maximum execution time
         *
         * @param int $seconds time in seconds
         */
        private function set_time_limit ( $seconds ) {
            $check_safe_mode = ini_get ( 'safe_mode' );
            if ( ( ! $check_safe_mode ) || ( 'OFF' == strtoupper ( $check_safe_mode ) ) ) {

                @set_time_limit ( $seconds );
            }
        }

        /**
         * Generate the template for a document
         *
         * @param YITH_Document $document the document to create
         *
         * @return string
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        private function generate_template ( $document ) {
            $this->set_time_limit ( 120 );

            ob_start ();

            wc_get_template ( 'invoice/ywpi-invoice-template.php',
                array (
                    'document' => $document,
                ),
                '',
                YITH_YWPI_TEMPLATE_DIR );

            $html = ob_get_contents ();
            ob_end_clean ();

            require_once ( YITH_YWPI_DOMPDF_DIR . "dompdf_config.inc.php" );

            $pdf_file = new DOMPDF();

            $pdf_file->load_html ( $html );
            $pdf_file->render ();

            // The next call will store the entire PDF as a string in $pdf
            $pdf = $pdf_file->output ();

            return $pdf;
        }
    }
}