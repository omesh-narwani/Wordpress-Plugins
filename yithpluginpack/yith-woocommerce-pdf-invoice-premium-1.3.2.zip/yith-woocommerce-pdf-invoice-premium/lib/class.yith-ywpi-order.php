<?php
if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! class_exists ( 'YITH_YWPI_Order' ) ) {

    /**
     * Implements features related to an order to be used for invoice generation
     *
     * @class   YITH_YWPI_Order
     * @package Yithemes
     * @since   1.0.0
     * @author  Your Inspiration Themes
     */
    class YITH_YWPI_Order {

        /**
         * @var WC_Order the order associated to this document
         */
        public $order;

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @param WC_Order $order
         *
         * @since  1.0
         * @author Lorenzo giuffrida
         * @access public
         */
        private function __construct ( $order ) {

            $this->order = $order;

        }

        /**
         * @param WC_Order $order
         *
         * @return YITH_YWPI_Order
         *
         * @author Lorenzo Giuffrida
         * @since  1.0.0
         */
        public static function get_order ( $order ) {
            return new YITH_YWPI_Order( $order );
        }

        public function get_all_items ( $args = '' ) {
            if ( $args = '' ) {
                $args = 'line_item';
            }

            $order_items = $this->order->get_items ( $args );

            $results = array ();

            foreach ( $order_items as $item_id => $item ) {

            }

        }
    }
}