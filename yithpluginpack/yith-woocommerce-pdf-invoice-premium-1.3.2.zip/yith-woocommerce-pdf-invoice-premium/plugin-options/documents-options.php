<?php
/**
 * This file belongs to the YIT Plugin Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined ( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

$current_date = getdate ();

$general_options = array (

    'documents' => array (
        'section_invoice_settings'          => array (
            'name' => __ ( 'Document settings', 'yith-woocommerce-pdf-invoice' ),
            'type' => 'title',
        ),
        'next_invoice_number'               => array (
            'name'              => __ ( 'Next invoice number', 'yith-woocommerce-pdf-invoice' ),
            'type'              => 'number',
            'id'                => 'ywpi_invoice_number',
            'desc'              => __ ( 'Invoice number for next invoice document.', 'yith-woocommerce-pdf-invoice' ),
            'default'           => 1,
            'std'               => 1,
            'custom_attributes' => array (
                'min'      => 1,
                'step'     => 1,
                'required' => 'required',
            ),
        ),
        'next_invoice_year'                 => array (
            'name'    => __ ( 'billing year', 'yith-woocommerce-pdf-invoice' ),
            'type'    => 'hidden',
            'id'      => 'ywpi_invoice_year_billing',
            'default' => $current_date[ 'year' ],
        ),
        'invoice_prefix'                    => array (
            'name' => __ ( 'Invoice prefix', 'yith-woocommerce-pdf-invoice' ),
            'type' => 'text',
            'id'   => 'ywpi_invoice_prefix',
            'desc' => __ ( 'Set a text to be used as prefix in invoice number. Leave it blank if no prefix has to be used', 'yith-woocommerce-pdf-invoice' ),
        ),
        'invoice_suffix'                    => array (
            'name' => __ ( 'Invoice suffix', 'yith-woocommerce-pdf-invoice' ),
            'type' => 'text',
            'id'   => 'ywpi_invoice_suffix',
            'desc' => __ ( 'Set a text to be used as suffix in invoice number. Leave it blank if no suffix has to be used', 'yith-woocommerce-pdf-invoice' ),
        ),
        'invoice_number_format'             => array (
            'name'              => __ ( 'Invoice number format', 'yith-woocommerce-pdf-invoice' ),
            'type'              => 'text',
            'id'                => 'ywpi_invoice_number_format',
            'desc'              => __ ( 'Set format for invoice number. Use [number], [prefix] and [suffix] as placeholders.<br><b>Attention, the [number] placeholder is necessary. If not specified, it will be queued to the corresponding text.</b>', 'yith-woocommerce-pdf-invoice' ),
            'default'           => '[prefix]/[number]/[suffix]',
            'custom_attributes' => array (
                'required' => 'required',
            ),
        ),
        'invoice_filename_format'           => array (
            'name'              => __ ( 'Invoice filename format', 'yith-woocommerce-pdf-invoice' ),
            'type'              => 'text',
            'id'                => 'ywpi_invoice_filename_format',
            'desc'              => __ ( 'Set filename format for invoice documents. Use [number], [prefix], [suffix], [year], [month], [day] as placeholders. <br><b>Attention, the [number] placeholder is necessary. If not specified, it will be queued to the corresponding text.</b>', 'yith-woocommerce-pdf-invoice' ),
            'css'               => 'width:60%;',
            'default'           => 'Invoice_[number]',
            'custom_attributes' => array (
                'required' => 'required',
            ),
        ),
        'pro_forma_invoice_filename_format' => array (
            'name'              => __ ( 'Pro-Forma Invoice filename format', 'yith-woocommerce-pdf-invoice' ),
            'type'              => 'text',
            'id'                => 'ywpi_pro_forma_invoice_filename_format',
            'desc'              => __ ( 'Set filename format for Pro-Forma invoice documents. Use [order_number], [year], [month], [day] as placeholders. <br><b>Attention, the [order_number] placeholder is necessary. If not specified, it will be queued to the corresponding text.</b>', 'yith-woocommerce-pdf-invoice' ),
            'css'               => 'width:60%;',
            'default'           => 'Pro_Forma_[order_number]',
            'custom_attributes' => array (
                'required' => 'required',
            ),
        ),
        'shipping_list_filename_format'     => array (
            'name'              => __ ( 'Shipping list filename format', 'yith-woocommerce-pdf-invoice' ),
            'type'              => 'text',
            'id'                => 'ywpi_shipping_list_filename_format',
            'desc'              => __ ( 'Set filename format for shipping list documents. Use [order_number], [year], [month], [day] as placeholders.<br><b>Attention, the [order_number] placeholder is necessary. If not specified, it will be queued to the corresponding text.</b>', 'yith-woocommerce-pdf-invoice' ),
            'css'               => 'width:60%;',
            'default'           => 'Shipping_list_[order_number]',
            'custom_attributes' => array (
                'required' => 'required',
            ),
        ),
        'invoice_reset'                     => array (
            'name'    => __ ( 'Reset on 1st January', 'yith-woocommerce-pdf-invoice' ),
            'type'    => 'checkbox',
            'id'      => 'ywpi_invoice_reset',
            'desc'    => __ ( 'Set restart from 1 on 1st January.', 'yith-woocommerce-pdf-invoice' ),
            'default' => false,
        ),
        'invoice_settings_end'              => array (
            'type' => 'sectionend',
        ),
    ),
);


return $general_options;
