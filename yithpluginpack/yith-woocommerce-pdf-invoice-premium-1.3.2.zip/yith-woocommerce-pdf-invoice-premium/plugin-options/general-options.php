<?php
/**
 * This file belongs to the YIT Plugin Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined ( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

$current_date = getdate ();

$general_options = array (

    'general' => array (
        'section_general_settings' => array (
            'name' => __ ( 'General settings', 'yith-woocommerce-pdf-invoice' ),
            'type' => 'title',
        ),
        'preview_mode'                      => array (
            'name'    => __ ( 'Preview mode', 'yith-woocommerce-pdf-invoice' ),
            'type'    => 'checkbox',
            'id'      => 'ywpi_preview_mode',
            'desc'    => __ ( 'Set this flag if you want to test the PDF generation, for example when customizing the invoice template. When this option is enabled, no counter will be incremented', 'yith-woocommerce-pdf-invoice' ),
            'default' => false,
            'std'     => false,
        ),
        'invoice_folder_format'    => array (
            'name'    => __ ( 'Invoice folder format', 'yith-woocommerce-pdf-invoice' ),
            'type'    => 'text',
            'id'      => 'ywpi_invoice_folder_format',
            'desc'    => __ ( 'Set the folder where storing documents. Use [year], [month], [day] as placeholders. Example: "Invoices/[year]/[month]" for invoices stored per year and month or leave blank for storing on root folder.', 'yith-woocommerce-pdf-invoice' ),
            'default' => 'Invoices',
        ),
        'invoice_date_format'      => array (
            'name'    => __ ( 'Document date format', 'yith-woocommerce-pdf-invoice' ),
            'id'      => 'ywpi_invoice_date_format',
            'desc'    => __ ( 'Set date format as it should appear on documents. (Default is d/m/Y)', 'yith-woocommerce-pdf-invoice' ),
            'default' => 'd/m/Y',
            'std'     => 'd/m/Y',
            'type'    => 'select',
            'options' => array (
                'd/m/Y' => __ ( 'd/m/Y', 'ywot' ),
                'd-m-Y' => __ ( 'd-m-Y', 'ywot' ),
                'm/d/Y' => __ ( 'm/d/Y', 'ywot' ),
                'm-d-Y' => __ ( 'm-d-Y', 'ywot' ),
            ),
        ),
        array (
            'title'   => __ ( 'Invoice generation', 'yith-woocommerce-pdf-invoice' ),
            'id'      => 'ywpi_invoice_generation',
            'type'    => 'radio',
            'options' => array (
                'auto'   => "Automatic generation",
                'manual' => "Manual generation",
            ),
            'default' => 'manual',
            'std'     => 'manual',
        ),
        array (
            'title'   => __ ( 'Generate invoice automatically', 'yith-woocommerce-pdf-invoice' ),
            'id'      => 'ywpi_create_invoice_on',
            'type'    => 'radio',
            'options' => array (
                'new'        => __ ( "For new order.", 'yith-woocommerce-pdf-invoice' ),
                'processing' => __ ( "For processing order.", 'yith-woocommerce-pdf-invoice' ),
                'completed'  => __ ( "For completed order.", 'yith-woocommerce-pdf-invoice' ),
            ),
            'default' => 'completed',
            'std'     => 'completed',
        ),
        array (
            'title'   => __ ( 'Document generation mode', 'yith-woocommerce-pdf-invoice' ),
            'id'      => 'ywpi_pdf_invoice_behaviour',
            'type'    => 'radio',
            'options' => array (
                'download' => "Download PDF",
                'open'     => "Open PDF on browser",
            ),
            'default' => 'download',
            'std'     => 'download',
        ),
        'shipping_list'            => array (
            'name'    => __ ( 'Enable shipping list', 'yith-woocommerce-pdf-invoice' ),
            'type'    => 'checkbox',
            'id'      => 'ywpi_enable_shipping_list',
            'desc'    => __ ( 'Enable the shipping list document generation.', 'yith-woocommerce-pdf-invoice' ),
            'default' => 'yes',
        ),
        'pro-forma'                => array (
            'name'    => __ ( 'Enable pro-forma', 'yith-woocommerce-pdf-invoice' ),
            'type'    => 'checkbox',
            'id'      => 'ywpi_enable_pro_forma',
            'desc'    => __ ( 'Enable the pro-forma document generation.', 'yith-woocommerce-pdf-invoice' ),
            'default' => 'yes',
        ),
        'ask_ssn_number'           => array (
            'name'    => __ ( 'SSN number', 'yith-woocommerce-pdf-invoice' ),
            'type'    => 'checkbox',
            'id'      => 'ywpi_ask_ssn_number',
            'desc'    => __ ( 'Add a SSN number field on checkout page', 'yith-woocommerce-pdf-invoice' ),
            'default' => 'yes',
        ),
        'ask_vat_number'           => array (
            'name'    => __ ( 'VAT number', 'yith-woocommerce-pdf-invoice' ),
            'type'    => 'checkbox',
            'id'      => 'ywpi_ask_vat_number',
            'desc'    => __ ( 'Add a VAT number field on checkout page', 'yith-woocommerce-pdf-invoice' ),
            'default' => 'yes',
        ),

        'dropbox'                  => array (
            'name'    => __ ( 'Send documents to Dropbox', 'yith-woocommerce-pdf-invoice' ),
            'type'    => 'ywpi_dropbox',
            'id'      => 'ywpi_dropbox_key',
            'desc'    => __ ( 'Set automatic document backup to dropbox.', 'yith-woocommerce-pdf-invoice' ),
            'default' => 'yes',
        ),
        'general_settings_end'     => array (
            'type' => 'sectionend',
        ),
    ),
);


return apply_filters ( 'ywpi_general_options', $general_options );
