<?php
/**
 * This file belongs to the YIT Plugin Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined ( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

$current_date = getdate ();

$general_options = array (

    'template' => array (

        'section_template' => array (
            'name' => __ ( 'Template settings', 'yith-woocommerce-pdf-invoice' ),
            'type' => 'title',
        ),
        'company_name'     => array (
            'name'    => __ ( 'Company name', 'yith-woocommerce-pdf-invoice' ),
            'type'    => 'text',
            'id'      => 'ywpi_company_name',
            'desc'    => __ ( 'Set company name to be shown on invoices', 'yith-woocommerce-pdf-invoice' ),
            'default' => __ ( 'Your company name', 'yith-woocommerce-pdf-invoice' ),
        ),
        'company_logo'     => array (
            'name' => __ ( 'Your company logo', 'yith-woocommerce-pdf-invoice' ),
            'type' => 'ywpi_logo',
            'id'   => 'ywpi_company_logo',
            'desc' => __ ( 'Set a default logo to be shown', 'yith-woocommerce-pdf-invoice' ),
        ),
        'company_details'  => array (
            'name'    => __ ( 'Company details', 'yith-woocommerce-pdf-invoice' ),
            'type'    => 'textarea',
            'id'      => 'ywpi_company_details',
            'css'     => 'width:80%; height: 90px;',
            'desc'    => __ ( 'Set company details to be used on invoice document', 'yith-woocommerce-pdf-invoice' ),
            'default' => __ ( 'Your company details
Address
City, State' ),
        ),

        'section_template_end'                  => array (
            'type' => 'sectionend',
            'id'   => 'ywpi_template_end',
        ),
        'section_template_invoice'              => array (
            'name' => __ ( 'Invoice/Pro-Forma Invoice template settings', 'yith-woocommerce-pdf-invoice' ),
            'type' => 'title',
            'id'   => 'ywpi_section_template_invoice',
        ),
        'customer_billing_details'              => array (
            'name'    => __ ( 'Customer billing details', 'yith-woocommerce-pdf-invoice' ),
            'type'    => 'textarea',
            'id'      => 'ywpi_customer_billing_details',
            'css'     => 'width:80%; height: 90px;',
            'desc'    => __ ( 'Set the customer details to be used on invoice document. Use the postmeta metakeys as placeholders within double curly brackets, for example {{_billing_first_name}} for showing the order billing first name', 'yith-woocommerce-pdf-invoice' ),
            'default' => __ ( '{{_billing_first_name}} {{_billing_last_name}}
{{_billing_address_1}}
{{_billing_postcode}}{{_billing_city}}
{{_billing_country}}
SSN: {{_billing_vat_ssn}}
VAT: {{_billing_vat_number}}
{{_billing_phone}}
{{_billing_email}}', 'yith-woocommerce-pdf-invoice' ),
        ),
        'invoice_notes'                         => array (
            'name' => __ ( 'Invoice notes', 'yith-woocommerce-pdf-invoice' ),
            'type' => 'textarea',
            'id'   => 'ywpi_invoice_notes',
            'css'  => 'width:80%; height: 90px;',
            'desc' => __ ( 'Set the text to show as notes on invoices.', 'yith-woocommerce-pdf-invoice' ),

        ),
        'invoice_footer'                        => array (
            'name' => __ ( 'Invoice footer', 'yith-woocommerce-pdf-invoice' ),
            'type' => 'textarea',
            'id'   => 'ywpi_invoice_footer',
            'css'  => 'width:80%; height: 90px;',
            'desc' => __ ( 'Set the text to show as footer on invoices.', 'yith-woocommerce-pdf-invoice' ),
        ),
        'pro_forma_notes'                       => array (
            'name' => __ ( 'Pro-Forma Invoice notes', 'yith-woocommerce-pdf-invoice' ),
            'type' => 'textarea',
            'id'   => 'ywpi_pro_forma_notes',
            'css'  => 'width:80%; height: 90px;',
            'desc' => __ ( 'Set the text to show as notes on Pro-Forma invoices.', 'yith-woocommerce-pdf-invoice' ),

        ),
        'pro_forma_footer'                      => array (
            'name' => __ ( 'Pro-Forma invoice footer', 'yith-woocommerce-pdf-invoice' ),
            'type' => 'textarea',
            'id'   => 'ywpi_pro_forma_footer',
            'css'  => 'width:80%; height: 90px;',
            'desc' => __ ( 'Set the text to show as footer on Pro-Forma invoices.', 'yith-woocommerce-pdf-invoice' ),
        ),
        'show_company_name'                     => array (
            'name'          => __ ( 'Visible sections', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => 'start',
            'id'            => 'ywpi_show_company_name',
            'desc'          => __ ( 'Show company name.', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'show_company_logo'                     => array (
            'name'          => __ ( 'Show company logo', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_show_company_logo',
            'desc'          => __ ( 'Show company logo.', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'show_company_details'                  => array (
            'name'          => __ ( 'Show company details', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_show_company_details',
            'desc'          => __ ( 'Show company details.', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'show_invoice_notes'                    => array (
            'name'          => __ ( 'Show notes', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_show_invoice_notes',
            'desc'          => __ ( 'Show notes.', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'show_invoice_footer'                   => array (
            'name'          => __ ( 'Show footer', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => 'end',
            'id'            => 'ywpi_show_invoice_footer',
            'desc'          => __ ( 'Show footer.', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'show_invoice_column_picture'           => array (
            'name'            => __ ( 'Visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'            => 'checkbox',
            'checkboxgroup'   => 'start',
            'show_if_checked' => 'option',
            'id'              => 'ywpi_invoice_column_picture',
            'css'             => 'width:80%; height: 90px;',
            'desc'            => __ ( 'Product picture', 'yith-woocommerce-pdf-invoice' ),
            'default'         => 'yes',
        ),
        'show_invoice_column_SKU'               => array (
            'name'          => __ ( 'Invoice visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_invoice_column_SKU',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Product SKU', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'show_invoice_column_short_description' => array (
            'name'          => __ ( 'Invoice visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_invoice_column_short_description',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Short description', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'no',
        ),
        'show_invoice_column_variation'         => array (
            'name'          => __ ( 'Invoice visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_invoice_column_variation',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Product variation', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'show_invoice_column_quantity'          => array (
            'name'          => __ ( 'Invoice visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_invoice_column_quantity',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Quantity', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'show_invoice_column_product_price'     => array (
            'name'          => __ ( 'Invoice visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_invoice_column_product_price',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Product price', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'no',
        ),
        'show_invoice_column_regular_price'     => array (
            'name'          => __ ( 'Invoice visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_invoice_column_regular_price',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Regular price', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'show_invoice_column_sale_price'        => array (
            'name'          => __ ( 'Invoice visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_invoice_column_sale_price',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Sale price', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),

        'show_invoice_column_line_total'             => array (
            'name'          => __ ( 'Invoice visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_invoice_column_line_total',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Line total', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'show_invoice_column_tax'                    => array (
            'name'          => __ ( 'Invoice visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => 'end',
            'id'            => 'ywpi_invoice_column_tax',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Tax', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'section_section_template_invoice_end'       => array (
            'type' => 'sectionend',
            'id'   => 'ywpi_section_template_invoice_end',
        ),
        'section_template_shipping_list'             => array (
            'name' => __ ( 'Shipping list template settings', 'yith-woocommerce-pdf-invoice' ),
            'type' => 'title',
            'id'   => 'ywpi_section_template_shipping_list',
        ),
        'customer_shipping_details'                  => array (
            'name'    => __ ( 'Customer shipping details', 'yith-woocommerce-pdf-invoice' ),
            'type'    => 'textarea',
            'id'      => 'ywpi_customer_shipping_details',
            'css'     => 'width:80%; height: 90px;',
            'desc'    => __ ( 'Set the customer details to be used on invoice document. Use the postmeta metakeys as placeholders within double curly brackets, for example {{_shipping_first_name}} for showing the order shipping first name', 'yith-woocommerce-pdf-invoice' ),
            'default' => __ ( '{{_shipping_first_name}} {{_shipping_last_name}}
{{_shipping_address_1}}
{{_shipping_postcode}}{{_shipping_city}}
{{_shipping_country}}', 'yith-woocommerce-pdf-invoice' ),
        ),
        'shipping_list_notes'                        => array (
            'name' => __ ( 'Notes', 'yith-woocommerce-pdf-invoice' ),
            'type' => 'textarea',
            'id'   => 'ywpi_shipping_list_notes',
            'css'  => 'width:80%; height: 90px;',
            'desc' => __ ( 'Set the text to show as notes on shipping list documents.', 'yith-woocommerce-pdf-invoice' ),
        ),
        'shipping_list_footer'                       => array (
            'name' => __ ( 'Footer', 'yith-woocommerce-pdf-invoice' ),
            'type' => 'textarea',
            'id'   => 'ywpi_shipping_list_footer',
            'css'  => 'width:80%; height: 90px;',
            'desc' => __ ( 'Set the text to show as footer on shipping list documents.', 'yith-woocommerce-pdf-invoice' ),
        ),
        'shipping_list_show_company_name'            => array (
            'name'          => __ ( 'Visible section', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => 'start',
            'id'            => 'ywpi_shipping_list_show_company_name',
            'desc'          => __ ( 'Show company name.', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'shipping_list_show_company_logo'            => array (
            'name'          => __ ( 'Show company logo', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_shipping_list_show_company_logo',
            'desc'          => __ ( 'Show company logo.', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'shipping_list_show_company_details'         => array (
            'name'          => __ ( 'Show company details', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_shipping_list_show_company_details',
            'desc'          => __ ( 'Show company details.', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'shipping_list_show_order_totals'            => array (
            'name'          => __ ( 'Show order totals', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_shipping_list_show_order_totals',
            'desc'          => __ ( 'Show order totals.', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'shipping_list_show_notes'                   => array (
            'name'          => __ ( 'Show notes', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_shipping_list_show_notes',
            'desc'          => __ ( 'Show notes.', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'shipping_list_show_footer'                  => array (
            'name'          => __ ( 'Show footer', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => 'end',
            'id'            => 'ywpi_shipping_list_show_footer',
            'desc'          => __ ( 'Show footer.', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'shipping_list_column_picture'               => array (
            'name'            => __ ( 'Visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'            => 'checkbox',
            'checkboxgroup'   => 'start',
            'show_if_checked' => 'option',
            'id'              => 'ywpi_shipping_list_column_picture',
            'css'             => 'width:80%; height: 90px;',
            'desc'            => __ ( 'Product picture', 'yith-woocommerce-pdf-invoice' ),
            'default'         => 'yes',
        ),
        'shipping_list_column_SKU'                   => array (
            'name'          => __ ( 'shipping_list visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_shipping_list_column_SKU',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Product SKU', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'shipping_list_column_short_description'     => array (
            'name'          => __ ( 'shipping_list visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_shipping_list_column_short_description',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Short description', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'no',
        ),
        'shipping_list_column_variation'             => array (
            'name'          => __ ( 'shipping_list visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_shipping_list_column_variation',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Product variation', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'shipping_list_column_quantity'              => array (
            'name'          => __ ( 'shipping_list visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_shipping_list_column_quantity',
            'css'           => 'width:80%; hywpi_invoice_column_regular_priceeight: 90px;',
            'desc'          => __ ( 'Quantity', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'shipping_list_column_product_price'         => array (
            'name'          => __ ( 'shipping_list visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_shipping_list_column_product_price',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Product price', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'no',
        ),
        'shipping_list_column_regular_price'         => array (
            'name'          => __ ( 'shipping_list visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_shipping_list_column_regular_price',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Regular price', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'shipping_list_column_sale_price'            => array (
            'name'          => __ ( 'shipping_list visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_shipping_list_column_sale_price',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Sale price', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'shipping_list_column_line_total'            => array (
            'name'          => __ ( 'shipping_list visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => '',
            'id'            => 'ywpi_shipping_list_column_line_total',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Line total', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'shipping_list_column_tax'                   => array (
            'name'          => __ ( 'shipping_list visible columns', 'yith-woocommerce-pdf-invoice' ),
            'type'          => 'checkbox',
            'checkboxgroup' => 'end',
            'id'            => 'ywpi_shipping_list_column_tax',
            'css'           => 'width:80%; height: 90px;',
            'desc'          => __ ( 'Tax', 'yith-woocommerce-pdf-invoice' ),
            'default'       => 'yes',
        ),
        'section_section_template_shipping_list_end' => array (
            'type' => 'sectionend',
        ),
    ),
);

return $general_options;
