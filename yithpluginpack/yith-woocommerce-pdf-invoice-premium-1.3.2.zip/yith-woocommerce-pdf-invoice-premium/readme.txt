=== YITH WooCommerce PDF Invoice and Shipping List Premium ===

Contributors: yithemes
Tags: woocommerce, orders, woocommerce order, pdf, invoice, pdf invoice, delivery note, pdf invoices, automatic invoice, download, download invoice, bill order, billing, automatic billing, order invoice, billing invoice, new order, processing order, shipping list, shipping document, delivery, packing slip, transport document,  delivery, shipping, order, shop, shop invoice, customer, sell, invoices, email invoice, packing slips
Requires at least: 4.0
Tested up to: 4.4.2
Stable tag: 1.3.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= Version 1.3.2 - Released: Feb 18, 2016 =

* Updated: removed unused plugin options
* Fixed: warning on pro-forma document generation

= Version 1.3.1 - Released: Feb 17, 2016 =

* Fixed: wrong discount applied to the order totals

= Version 1.3.0 - Released: Feb 16, 2016 =

* Updated: plugin ready for WooCommerce 2.5
* Updated: invoice template can be override
* Added: YITH Multi Vendor compatibility: vendors can create their own invoices.
* Added: template system rewritten for improved performance and customization
* Added: customizable Customer billing details with third party postmeta

= Version 1.2.3 - Released: Dec 29, 2015 =

* Fixed: wrong discount calculation when price are entered inclusive of taxes

= Version 1.2.2 - Released: Dec 15, 2015 =

* Fixed: YITH Plugin Framework breaks updates on WordPress multisite
* Fixed: Missing localization for a string in invoice template

= Version 1.2.1 - Released: Dec 11, 2015 =

* Fixed: company logo not shown on invoice for DOMPDF issue

= Version 1.2.0 - Released: Dec 04, 2015 =

* Fixed: VAT number and SSN number not shown on invoice
* Updated: languages file

= Version 1.1.8 - Released: Nov 04, 2015 =

* Fixed: invoice generated and attached to emails not related to orders
* Updated : text-domain changed from ywpi to yith-woocommerce-pdf-invoice

= Version 1.1.7 - Released: Sep 30, 2015 =

* Fix: typo on invoice template
* Fix: wrong invoice number shown.

= Version 1.1.6 - Released: Sep 01, 2015 =

* Fix: removed deprecated WooCommerce_update_option_X hook.

= Version 1.1.5 - Released: Aug 27, 2015 =

* Tweak: update YITH Plugin framework.

= Version 1.1.4 - Released: Jul 28, 2015 =

* Added : new original product price column for invoices.

= Version 1.1.3 - Released: Jun 19, 2015 =

* Added : some placeholders for invoice prefix and suffix.

= Version 1.1.2 - Released: May 22, 2015 =

* Added : improved unicode support.

= Version 1.1.1 - Released: Apr 24, 2015 ==

* Tweak : invoice and pro-forma invoice template updated.

= Version 1.1.0 - Released: Apr 22, 2015 ==

* Fix : security issue (https://make.wordpress.org/plugins/2015/04/20/fixing-add_query_arg-and-remove_query_arg-usage/)
* Tweak : support up to Wordpress 4.2

= Version 1.0.5 - Released: Apr 20, 2015 ==

* Added : optionally display short description column.

= Version 1.0.4 - Released: Apr 15, 2015 ==

* Added : compatibility with WooThemes EU VAT Number plugin.

= Version 1.0.3 - Released: Apr 07, 2015 ==

* Fix : documents with greek text could not be rendered correctly.

= Version 1.0.2 - Released: Mar 05, 2015 ==

* Initial release