<?php
/**
 * The Template for invoice details
 *
 * Override this template by copying it to [your theme]/woocommerce/invoice/ywpi-invoice-details.php
 *
 * @author        Yithemes
 * @package       yith-woocommerce-pdf-invoice-premium/Templates
 * @version       1.0.0
 */

/** @var WC_Order $current_order */
/** @var YITH_Document $document */

//$current_order = YITH_YWPI_Order::get_order ( $document->order );
$current_order = $document->order;

$upload_dir = wp_upload_dir ();

$order_shipping_amount  = 0.00;
$order_fee_amount       = 0.00;
$order_fee_taxes_amount = 0.00;
?>

    <table class="invoice-details">
        <thead>
        <tr>
            <?php if ( ywpi_is_enabled_column_picture ( $document ) ) : ?>
                <th class="column-picture"></th>
            <?php endif; ?>

            <th class="column-product"><?php _e ( 'Product', 'yith-woocommerce-pdf-invoice' ); ?></th>

            <?php if ( ywpi_is_enabled_column_quantity ( $document ) ) : ?>
                <th class="column-quantity"><?php _e ( 'Qty', 'yith-woocommerce-pdf-invoice' ); ?></th>
            <?php endif; ?>

            <?php if ( ywpi_is_enabled_column_product_price ( $document ) ) : ?>
                <th class="column-price"><?php _e ( 'Product price', 'yith-woocommerce-pdf-invoice' ); ?></th>
            <?php endif; ?>

            <?php if ( ywpi_is_enabled_column_regular_price ( $document ) ) : ?>
                <th class="column-price"><?php _e ( 'Price', 'yith-woocommerce-pdf-invoice' ); ?></th>
            <?php endif; ?>

            <?php if ( ywpi_is_enabled_column_sale_price ( $document ) ) : ?>
                <th class="column-price"><?php _e ( 'Sale price', 'yith-woocommerce-pdf-invoice' ); ?></th>
            <?php endif; ?>

            <?php if ( ywpi_is_enabled_column_line_total ( $document ) ) : ?>
                <th class="column-price"><?php _e ( 'Line total', 'yith-woocommerce-pdf-invoice' ); ?></th>
            <?php endif; ?>

            <?php if ( ywpi_is_enabled_column_tax ( $document ) ) : ?>
                <th class="column-price"><?php _e ( 'Tax', 'yith-woocommerce-pdf-invoice' ); ?></th>
            <?php endif; ?>
        </tr>
        </thead>
        <tbody>
        <?php

        //  Store additional discount calculated from the original product price
        $product_discount       = 0.00;
        $product_original_price = 0.00;
        $product_regular_price  = 0.00;

        /** @var WC_Product $_product */
        $order_items = apply_filters ( 'yith_ywpi_get_order_items_for_invoice', $current_order->get_items (), $current_order );

        foreach ( $order_items as $item_id => $item ) {

            if ( isset( $item[ 'qty' ] ) ) {
                $price_per_unit      = $item[ "line_subtotal" ] / $item[ 'qty' ];
                $price_per_unit_sale = $item[ "line_total" ] / $item[ 'qty' ];
                $discount            = $price_per_unit - $price_per_unit_sale;
            }

            $tax      = $item[ "line_tax" ];
            $_product = apply_filters ( 'woocommerce_order_item_product', $current_order->get_product_from_item ( $item ), $item );

            /*  Fix for gift cards products that hasn't a regular price */
            if ( $_product instanceof WC_Product_Gift_Card ) {
                $product_regular_price = $price_per_unit;
            } else if ( $current_order->prices_include_tax ) {
                $product_regular_price = $_product->get_price_excluding_tax ( 1, $_product->regular_price );
            } else {
                $product_regular_price = $_product->regular_price;
            }

            $item_meta = new WC_Order_Item_Meta( $item[ 'item_meta' ], $_product );

            $variation_text = '';
            if ( ywpi_is_enabled_column_variation ( $document ) ) {
                if ( $metadata = $current_order->has_meta ( $item_id ) ) {
                    foreach ( $metadata as $meta ) {

                        // Skip hidden core fields
                        if ( in_array ( $meta[ 'meta_key' ], apply_filters ( 'woocommerce_hidden_order_itemmeta', array (
                            '_qty',
                            '_tax_class',
                            '_product_id',
                            '_variation_id',
                            '_line_subtotal',
                            '_line_subtotal_tax',
                            '_line_total',
                            '_line_tax',
                        ) ) ) ) {
                            continue;
                        }

                        // Skip serialised meta
                        if ( is_serialized ( $meta[ 'meta_value' ] ) ) {
                            continue;
                        }

                        // Get attribute data
                        if ( taxonomy_exists ( wc_sanitize_taxonomy_name ( $meta[ 'meta_key' ] ) ) ) {
                            $term                 = get_term_by ( 'slug', $meta[ 'meta_value' ], wc_sanitize_taxonomy_name ( $meta[ 'meta_key' ] ) );
                            $meta[ 'meta_key' ]   = wc_attribute_label ( wc_sanitize_taxonomy_name ( $meta[ 'meta_key' ] ) );
                            $meta[ 'meta_value' ] = isset( $term->name ) ? $term->name : $meta[ 'meta_value' ];
                        } else {
                            $meta[ 'meta_key' ] = apply_filters ( 'woocommerce_attribute_label', $meta[ 'meta_key' ], $meta[ 'meta_key' ] );
                        }

                        $variation_text .= sprintf ( '%s: %s ', $meta[ 'meta_key' ], $meta[ 'meta_value' ] );
                    }
                }
            }
            ?>

            <tr>
                <?php if ( ywpi_is_enabled_column_picture ( $document ) ): ?>
                    <td class="column-picture">
                        <!-- Show picture if related option is enabled -->

                        <?php $product_image = str_replace ( $upload_dir[ "baseurl" ], $upload_dir[ "basedir" ],
                            ( $_product->get_image_id () ? current ( wp_get_attachment_image_src ( $_product->get_image_id (),
                                'thumbnail' ) ) : wc_placeholder_img_src () ) );
                        ?>

                        <img src="<?php echo $product_image; ?>"/>
                    </td>
                <?php endif; ?>

                <td class="column-product">
                    <!-- Show product title -->
                    <?php echo $item[ 'name' ]; ?>
                    <br>

                    <?php if ( ywpi_is_enabled_column_variation ( $document ) ) : ?>
                        <?php echo $variation_text; ?>
                    <?php endif; ?>

                    <?php if ( ywpi_is_enabled_column_sku ( $document ) ) : ?>
                        <?php if ( is_object ( $_product ) && $_product->get_sku () ) {
                            echo "SKU: " . esc_html ( $_product->get_sku () );
                        } ?>
                    <?php endif; ?>

                    <?php if ( ywpi_is_enabled_column_short_description ( $document ) && ( ! empty( $_product->post->post_excerpt ) ) ) :
                        echo '<span class="product-short-description">' . $_product->post->post_excerpt . '</span>';
                    endif; ?>
                </td>

                <?php if ( ywpi_is_enabled_column_quantity ( $document ) ) : ?>
                    <td class="column-quantity">
                        <?php echo ( isset( $item[ 'qty' ] ) ) ? esc_html ( $item[ 'qty' ] ) : ''; ?>
                    </td>
                <?php endif; ?>

                <?php if ( ywpi_is_enabled_column_product_price ( $document ) ) : ?>
                    <td class="column-price">
                        <?php

                        $product_discount += $item[ 'qty' ] * ( $product_regular_price - (double)$price_per_unit );
                        $product_original_price += $item[ 'qty' ] * $product_regular_price;

                        echo wc_price ( $product_regular_price );
                        ?>
                    </td>
                <?php endif; ?>

                <?php if ( ywpi_is_enabled_column_regular_price ( $document ) ) : ?>
                    <td class="column-price">
                        <?php echo wc_price ( $price_per_unit ); ?>
                    </td>
                <?php endif; ?>

                <?php if ( ywpi_is_enabled_column_sale_price ( $document ) ) : ?>
                    <td class="column-price">
                        <?php echo wc_price ( $price_per_unit_sale ); ?>
                    </td>
                <?php endif; ?>

                <?php if ( ywpi_is_enabled_column_line_total ( $document ) ) : ?>
                    <td class="column-price">
                        <?php echo wc_price ( $item[ "line_total" ] ); ?>
                    </td>
                <?php endif; ?>

                <?php if ( ywpi_is_enabled_column_tax ( $document ) ) : ?>
                    <td class="column-price">
                        <?php echo wc_price ( $tax ); ?>
                    </td>
                <?php endif; ?>
            </tr>

            <?php
        } // foreach;

        if ( ywpi_is_visible_fee_details_section ( $document ) ) :
            $order_fee = apply_filters ( 'yith_ywpi_get_order_fee_for_invoice', $current_order->get_items ( 'fee' ), $current_order );
            foreach ( $order_fee as $item_id => $item ) {
                $order_fee_amount += $item[ 'line_total' ];
                $order_fee_taxes_amount += $item[ 'line_tax' ];
                ?>

                <tr class="border-top">
                    <?php if ( ywpi_is_enabled_column_picture ( $document ) ) : ?>
                        <td class="column-picture">
                        </td>
                    <?php endif; ?>

                    <td class="column-product">
                        <?php echo ! empty( $item[ 'name' ] ) ? esc_html ( $item[ 'name' ] ) : __ ( 'Fee', 'yith-woocommerce-pdf-invoice' ); ?>
                    </td>

                    <?php if ( ywpi_is_enabled_column_quantity ( $document ) ) : ?>
                        <td class="column-quantity">
                        </td>
                    <?php endif; ?>

                    <?php if ( ywpi_is_enabled_column_product_price ( $document ) ) : ?>
                        <td class="column-price">
                            <?php echo wc_price ( $item[ 'line_total' ] ); ?>
                        </td>
                    <?php endif; ?>

                    <?php if ( ywpi_is_enabled_column_regular_price ( $document ) ) : ?>
                        <td class="column-price">
                        </td>
                    <?php endif; ?>

                    <?php if ( ywpi_is_enabled_column_sale_price ( $document ) ) : ?>
                        <td class="column-price">
                        </td>
                    <?php endif; ?>

                    <?php if ( ywpi_is_enabled_column_line_total ( $document ) ) : ?>
                        <td class="column-price">

                            <?php echo wc_price ( $item[ 'line_total' ] ); ?>

                        </td>
                    <?php endif; ?>

                    <?php if ( ywpi_is_enabled_column_tax ( $document ) ) : ?>
                        <td class="column-price">
                            <?php echo wc_price ( $item[ 'line_tax' ] ); ?>
                        </td>
                    <?php endif; ?>

                </tr>

                <?php
            }   // foreach
        endif;

        if ( ywpi_is_visible_shipping_details_section ( $document ) ) :

            $order_shipping = apply_filters ( 'yith_ywpi_get_order_shipping_for_invoice', $current_order->get_items ( 'shipping' ), $current_order );

            foreach ( $order_shipping as $item_id => $item ) {
                if ( isset( $item[ 'cost' ] ) ) {
                    $order_shipping_amount += wc_round_tax_total ( $item[ 'cost' ] );
                }
                ?>

                <tr>
                    <?php if ( ywpi_is_enabled_column_picture ( $document ) ) : ?>
                        <td class="column-picture">
                        </td>
                    <?php endif; ?>

                    <td class="column-product">
                        <?php echo ! empty( $item[ 'name' ] ) ? esc_html ( $item[ 'name' ] ) : __ ( 'Shipping', 'yith-woocommerce-pdf-invoice' ); ?>
                    </td>

                    <?php if ( ywpi_is_enabled_column_quantity ( $document ) ) : ?>
                        <td class="column-quantity">
                        </td>
                    <?php endif; ?>

                    <?php if ( ywpi_is_enabled_column_product_price ( $document ) ) : ?>

                        <td class="column-price">
                            <?php echo ( isset( $item[ 'cost' ] ) ) ? wc_price ( wc_round_tax_total ( $item[ 'cost' ] ) ) : ''; ?>

                        </td>
                    <?php endif; ?>

                    <?php if ( ywpi_is_enabled_column_regular_price ( $document ) ) : ?>
                        <td class="column-price">
                        </td>
                    <?php endif; ?>

                    <?php if ( ywpi_is_enabled_column_sale_price ( $document ) ) : ?>
                        <td class="column-price">
                        </td>
                    <?php endif; ?>

                    <?php if ( ywpi_is_enabled_column_line_total ( $document ) ) : ?>
                        <td class="column-price">
                            <?php echo ( isset( $item[ 'cost' ] ) ) ? wc_price ( wc_round_tax_total ( $item[ 'cost' ] ) ) : ''; ?>
                        </td>
                    <?php endif; ?>

                    <?php
                    $taxes      = 0;
                    $taxes_list = maybe_unserialize ( $item[ 'taxes' ] );
                    foreach ( $taxes_list as $tax_id => $tax_item ) {
                        $taxes += $tax_item;
                    }
                    $order_shipping_amount += wc_round_tax_total ( $taxes );

                    if ( ywpi_is_enabled_column_tax ( $document ) ) : ?>
                        <td class="column-price">
                            <?php
                            echo ( wc_price ( wc_round_tax_total ( $taxes ) ) );
                            ?>
                        </td>
                    <?php endif; ?>

                </tr>

                <?php
            };
        endif;

        ?>
        </tbody>
    </table>

<?php if ( ywpi_is_visible_order_totals ( $document ) ) :

    $_order_subtotal = $current_order->get_subtotal () + /*$current_order->get_total_discount ()*/
        + $product_discount + $current_order->get_total_shipping () + $order_fee_amount;
    $_order_subtotal = apply_filters ( 'yith_ywpi_invoice_subtotal', $_order_subtotal, $current_order, $product_discount, $order_fee_amount );

    $_order_discount = apply_filters ( 'yith_ywpi_invoice_total_discount', $current_order->get_total_discount () + $product_discount, $current_order, $product_discount );

    $_order_taxes = 'yes' == get_option ( 'woocommerce_calc_taxes' ) ? apply_filters ( 'yith_ywpi_invoice_tax_totals', $current_order->get_tax_totals (), $current_order ) : array();

    $_order_taxes_total = 0.00;
    foreach ( $_order_taxes as $code => $tax ) {
        $_order_taxes_total += $tax->amount;
    }
    $_order_total = apply_filters ( 'yith_ywpi_invoice_total', $_order_subtotal - $_order_discount + $_order_taxes_total );

    ?>
    <table>
        <tr>
            <td class="column1">

            </td>
            <td class="column2">
                <table class="invoice-totals">
                    <tr class="invoice-details-subtotal">
                        <td class="column-product"><?php _e ( "Subtotal", 'yith-woocommerce-pdf-invoice' ); ?></td>
                        <td class="column-total"><?php echo wc_price ( $_order_subtotal ); ?></td>
                    </tr>

                    <tr>
                        <td class="column-product"><?php _e ( "Discount", 'yith-woocommerce-pdf-invoice' ); ?></td>
                        <td class="column-total"><?php echo wc_price ( $_order_discount ); ?></td>
                    </tr>

                    <?php if ( 'yes' == get_option ( 'woocommerce_calc_taxes' ) ) :

                        foreach ( $_order_taxes as $code => $tax ) : ?>
                            <tr class="invoice-details-vat">
                                <td class="column-product"><?php echo $tax->label; ?>:</td>
                                <td class="column-total"><?php echo wc_price ( $tax->amount ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>

                    <tr class="invoice-details-total">
                        <td class="column-product"><?php _e ( "Total", 'yith-woocommerce-pdf-invoice' ); ?></td>
                        <td class="column-total"><?php echo wc_price ( $_order_total ); ?></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
<?php endif; ?>