<?php
/**
 * The Template for invoice
 *
 * Override this template by copying it to [your theme]/woocommerce/invoice/ywpi-invoice-template.php
 *
 * @author        Yithemes
 * @package       yith-woocommerce-pdf-invoice-premium/Templates
 * @version       1.0.0
 */

if ( ! defined ( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

/** @var YITH_Document $document */

?>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
    <?php
    /**
     * yith_ywpi_invoice_template_head hook
     *
     * @hooked add_style_files - 10 (add css file based on type of current document
     */
    do_action ( 'yith_ywpi_invoice_template_head', $document );
    ?>
</head>

<body>


<div class="invoice-document">
    <?php echo apply_filters ( 'yith_ywpi_document_template_title', __ ( 'Document', 'yith-woocommerce-pdf-invoice' ), $document ); ?>
    <div class="company-header">
        <table>
            <tr>
                <td class="invoice-from-section">
                    <?php
                    /**
                     * yith_ywpi_invoice_template_sender hook
                     *
                     * @hooked show_invoice_template_sender - 10 (Render and show data to "sender section" on invoice template)
                     */
                    do_action ( 'yith_ywpi_invoice_template_sender', $document );
                    ?>

                </td>
                <td class="invoice-logo">
                    <?php
                    /**
                     * yith_ywpi_invoice_template_company_logo hook
                     *
                     * @hooked show_invoice_template_company_logo - 10 (Show company logo on invoice template)
                     */
                    do_action ( 'yith_ywpi_invoice_template_company_logo', $document );
                    ?>
                </td>
            </tr>

        </table>

    </div>

    <div class="invoice-header">
        <table>
            <tr>
                <td class="invoice-to-section">
                    <?php
                    /**
                     * yith_ywpi_invoice_template_customer_data hook
                     *
                     * @hooked show_invoice_template_customer_details - 10 (Show data of customer on invoice template)
                     */
                    do_action ( 'yith_ywpi_invoice_template_customer_data', $document );
                    ?>
                </td>
                <td class="invoice-data">
                    <?php
                    /**
                     * show_template_document_data hook
                     *
                     * @hooked show_invoice_template_customer_details - 10 (Show data of customer on invoice template)
                     */
                    do_action ( 'show_template_document_data', $document );
                    ?>
                </td>
            </tr>
        </table>
    </div>

    <div class="invoice-content">
        <?php
        /**
         * yith_ywpi_invoice_template_products_list hook
         *
         * @hooked show_invoice_products_list_template - 10 (Show products list)
         */
        do_action ( 'yith_ywpi_invoice_template_products_list', $document );
        ?>
    </div>

    <?php
    /**
     * yith_ywpi_invoice_template_footer hook
     *
     * @hooked show_document_footer_template - 10 (add data on footer)
     */
    do_action ( 'yith_ywpi_invoice_template_footer', $document );
    ?>

</div>
</body>
</html>