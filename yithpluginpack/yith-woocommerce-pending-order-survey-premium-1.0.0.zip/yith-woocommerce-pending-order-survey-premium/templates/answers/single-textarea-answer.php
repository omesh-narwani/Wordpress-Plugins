<?php
if( !defined( 'ABSPATH' ) )
    exit;

?>
<div class="pending_textareacontent">
    <span class="dashicons dashicons-edit"></span>
    <textarea name="pending_textarea" class="textarea pending_field" placeholder="<?php _e('Enter your answer here',
        'yith-woocommerce-pending-order-survey' );?>"></textarea>
</div>