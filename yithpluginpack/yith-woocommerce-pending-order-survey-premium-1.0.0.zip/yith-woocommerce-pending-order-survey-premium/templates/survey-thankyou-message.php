<?php
if( !defined('ABSPATH'))
    exit;
?>
<div id="survey_thankyou_content" class="woocommerce" style="display: none" title="<?php _e('Survey sent','yith-woocommerce-pending-order-survey' );?>">

    <div class="woocommerce-message"><?php _e('Thanks for answering this survey!',
            'yith-woocommerce-pending-order-survey' );?></div>
</div>
