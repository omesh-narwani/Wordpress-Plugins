﻿=== YITH WooCommerce Points and Rewards  ===

Contributors: yithemes
Tags: points, rewards, Points and Rewards, point, woocommerce, yith, point collection, reward, awards, credits, multisite, advertising, affiliate, beans, coupon, credit, Customers, discount, e-commerce, ecommerce, engage, free, incentive, incentivize, loyalty, loyalty program, marketing, promoting, referring, retention, woocommerce, woocommerce extension, WooCommerce Plugin
Requires at least: 3.5.1
Tested up to: 4.4.2
Stable tag: 1.0.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

YITH WooCommerce Points and Rewards allows you to add a rewarding program to your site and encourage your customers collecting points.

== Description ==

Have you ever started collecting shopping points? What was your reaction? Most of us are really motivated in storing as many points as possible, because so we can get more and often we do not care about spending more because, if we do, we can have a better reward. Hasn't this happened to you too? That's what you get by putting into your site a point and reward programme: loyalising your customers, encouraging them to buy always from your shop and being rewarded for their loyalty.
If you think that reward programmes were only prerogative of big shopping centres or supermarkets, you're have to change your mind, because now you can add such a programme to your own e-commerce shop too. How? Simple, with YITH WooCommerce Points and Rewards: easy to setup and easy to understand for your customers!



== Installation ==
Important: First of all, you have to download and activate WooCommerce plugin, which is mandatory for YITH WooCommerce Points and Rewards to be working.

1. Unzip the downloaded zip file.
2. Upload the plugin folder into the `wp-content/plugins/` directory of your WordPress site.
3. Activate `YITH WooCommerce Points and Rewards` from Plugins page.


= Configuration =
YITH WooCommerce Points and Rewards will add a new tab called "Points and Rewards" in "YIT Plugins" menu item.
There, you will find all Yithemes plugins with quick access to plugin setting page.


== Changelog ==

= Version 1.0.8 - Released: Feb 11, 2016 =
Added: filter ywpar_get_product_point_earned that let third party plugin to set the point earned by specific product

= 1.0.7 =
Added: Shortcode yith_ywpar_points_list to show the list of points of a user
Added: Option to hide points in my account page
Fixed: Pagination on Customer's Points list

= 1.0.6 =
Fixed: Calculation points when coupons are used

= 1.0.5 =
Added: Option to remove points when coupons are used
Added: Earning Points in a manual order
Added: In Customer's Points tab all customers are showed also without points
Added: Compatibility with YITH WooCommerce Multi Vendor Premium hidden the points settings on products for vendors
Fixed: Removed Fatal in View Points if the order do not exists
Fixed: Conflict js with YITH Dynamic Pricing and Discounts
Fixed: Refund points calculation for partial refund
Fixed: Extra points double calculation

= 1.0.4 =
Added: Compatibility with WooCommerce 2.5 RC1
Fixed: Redeem points also if the button "Apply discount" is not clicked
Fixed: Calculation points on a refund order
Fixed: Update Points content

= 1.0.3 =
Added: Compatibility with Wordpress 4.4
Fixed: Extra points options
Fixed: Reviews assigment points for customers
Fixed: String translations
Updated: Changed Text Domain from 'ywpar' to 'yith-woocommerce-points-and-rewards'
Updated: Plugin Framework

= 1.0.2 =
Fixed: Enable/Disable Option
Fixed: Double points assigment
Update: Plugin Framework


= 1.0.1 =
Added: Minimun amount to reedem
Added: Italian Translation

= 1.0.0 =
Initial release