jQuery(document).ready( function($){
    "use strict";

    $('.ywpar-button-message').on('click', function(e){
        e.preventDefault();
        $('.ywpar_apply_discounts_container').slideToggle();
    });

    $('#ywpar_apply_discounts').on('click', function(e){
        e.preventDefault();
        $('#ywpar_input_points_check').val(1);
        $(this).parents('form').submit();
    })

});