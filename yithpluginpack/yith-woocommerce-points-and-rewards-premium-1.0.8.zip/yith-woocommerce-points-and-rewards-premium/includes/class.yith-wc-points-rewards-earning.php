<?php

if ( ! defined ( 'ABSPATH' ) || ! defined ( 'YITH_YWPAR_VERSION' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Implements features of YITH WooCommerce Points and Rewards
 *
 * @class   YYITH_WC_Points_Rewards_Earning
 * @package YITH WooCommerce Points and Rewards
 * @since   1.0.0
 * @author  Yithemes
 */
if ( ! class_exists ( 'YITH_WC_Points_Rewards_Earning' ) ) {

    class YITH_WC_Points_Rewards_Earning {

        /**
         * Single instance of the class
         *
         * @var \YITH_WC_Points_Rewards_Earning
         */
        protected static $instance;

        /**
         * Returns single instance of the class
         *
         * @return \YITH_WC_Points_Rewards_Earning
         * @since 1.0.0
         */
        public static function get_instance () {
            if ( is_null ( self::$instance ) ) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function __construct () {

            //add point when
            add_action ( 'woocommerce_payment_complete', array ( $this, 'add_order_points' ) );
            add_action ( 'woocommerce_order_status_on-hold_to_completed', array ( $this, 'add_order_points' ) );
            add_action ( 'woocommerce_order_status_processing', array ( $this, 'add_order_points' ) );
            add_action ( 'woocommerce_order_status_completed', array ( $this, 'add_order_points' ) );
            add_action ( 'woocommerce_order_status_failed_to_processing', array ( $this, 'add_order_points' ) );
            add_action ( 'woocommerce_order_status_failed_to_completed', array ( $this, 'add_order_points' ) );

            //add point for review
            add_action ( 'comment_post', array ( $this, 'add_order_points_with_review' ), 10, 2 );
            add_action ( 'wp_set_comment_status', array ( $this, 'add_order_points_with_review' ), 10, 2 );


            //remove point when the order is refunded or cancelled
            if ( YITH_WC_Points_Rewards ()->get_option ( 'remove_point_order_deleted' ) == 'yes' ) {
                add_action ( 'woocommerce_order_status_cancelled', array ( $this, 'remove_order_points' ) );
                //add_action( 'woocommerce_order_status_refunded', array( $this, 'remove_order_points' ) );
                add_action ( 'woocommerce_order_status_cancelled_to_completed', array ( $this, 'add_order_points' ) );
            }

            if ( YITH_WC_Points_Rewards ()->get_option ( 'remove_point_refund_order' ) == 'yes' ) {

                add_action ( 'woocommerce_order_partially_refunded', array ( $this, 'remove_order_points_refund' ), 11, 2 );
                add_action ( 'woocommerce_order_fully_refunded', array ( $this, 'remove_order_points_refund' ), 11, 2 );

                add_action ( 'wp_ajax_nopriv_woocommerce_delete_refund', array ( $this, 'refund_delete' ), 9, 2 );
                add_action ( 'wp_ajax_woocommerce_delete_refund', array ( $this, 'refund_delete' ), 9, 2 );
            }

            //extrapoint to registration

            add_action ( 'woocommerce_created_customer', array ( $this, 'extrapoints_to_new_customer' ), 10, 2 );
        }

        /**
         * Calculate the points of a product/variation for a single item
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  int $points
         */
        public function calculate_product_points ( $product_id ) {

            $product = wc_get_product ( $product_id );

            if ( ! is_object ( $product ) ) {
                return 0;
            }

            $points_updated = false;
            $points         = 0;

            $point_earned            = get_post_meta ( $product_id, '_ywpar_point_earned', true );
            $point_earned_dates_from = get_post_meta ( $product_id, '_ywpar_point_earned_dates_from', true );
            $point_earned_dates_to   = get_post_meta ( $product_id, '_ywpar_point_earned_dates_to', true );

            if ( $point_earned != '' && $this->is_ondate ( $point_earned_dates_from, $point_earned_dates_to ) ) {

                $is_percent = strpos ( $point_earned, '%' );

                if ( $is_percent !== false ) {
                    $point_earned = str_replace ( '%', '', $point_earned );
                    $points       = $this->get_point_earned ( $product, 'product' ) * $point_earned / 100;
                } else {
                    $points = $point_earned;
                }

                $points_updated = true;
            }

            if ( ! $points_updated ) {
                if ( $product->is_type ( 'variation' ) ) {
                    $categories = get_the_terms ( $product->id, 'product_cat' );
                } else {
                    $categories = get_the_terms ( $product_id, 'product_cat' );
                }

                if ( ! empty( $categories ) ) {
                    $points = 0; //reset the global point

                    foreach ( $categories as $term ) {
                        $point_earned            = get_woocommerce_term_meta ( $term->term_id, 'point_earned', true );
                        $point_earned_dates_from = get_woocommerce_term_meta ( $term->term_id, 'point_earned_dates_from', true );
                        $point_earned_dates_to   = get_woocommerce_term_meta ( $term->term_id, 'point_earned_dates_to', true );

                        if ( $point_earned != '' && $this->is_ondate ( $point_earned_dates_from, $point_earned_dates_to ) ) {

                            $is_percent = strpos ( $point_earned, '%' );
                            if ( $is_percent !== false ) {
                                $point_earned   = str_replace ( '%', '', $point_earned );
                                $current_points = floor ( $this->get_point_earned ( $product, 'product' ) * $point_earned / 100 );
                            } else {
                                $current_points = $point_earned;
                            }

                            $points         = ( $current_points > $points ) ? $current_points : $points;
                            $points_updated = true;
                        }
                    }
                }
            }
            if ( ! $points_updated ) {
                $points = $this->get_point_earned ( $product, 'product' );
            }

            //  Let third party plugin to change the points earned for this product
            return apply_filters ( 'ywpar_get_product_point_earned', $points, $product );
        }

        /**
         * Calculate the total points in the carts
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  int $points
         */
        public function calculate_points_on_cart () {

            $items      = WC ()->cart->get_cart ();
            $tot_points = 0;

            foreach ( $items as $item => $values ) {
                $product_id    = ( isset( $values[ 'variation_id' ] ) && $values[ 'variation_id' ] != 0 ) ? $values[ 'variation_id' ] : $values[ 'product_id' ];
                $product_point = $this->calculate_product_points ( $product_id );
                $tot_points += $product_point * $values[ 'quantity' ];
            }

            if ( WC ()->cart->applied_coupons && YITH_WC_Points_Rewards ()->get_option ( 'remove_points_coupon' ) == 'yes' && isset( WC ()->cart->discount_cart ) && WC ()->cart->discount_cart > 0 ) {
                $remove_points     = 0;
                $conversion_points = $this->get_conversion_option ();
                if ( $conversion_points[ 'money' ] * $conversion_points[ 'points' ] != 0 ) {
                    $remove_points += floor ( WC ()->cart->discount_cart / $conversion_points[ 'money' ] * $conversion_points[ 'points' ] );
                }
                $tot_points -= $remove_points;
            }

            $tot_points = ( $tot_points < 0 ) ? 0 : $tot_points;

            return apply_filters ( 'ywpar_calculate_points_on_cart', $tot_points );
        }

        /**
         * Check the validate on an interval of date
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  int $points
         */
        public function is_ondate ( $datefrom, $dateto ) {
            $now = time ();


            if ( $datefrom == '' && $dateto == '' ) {
                return true;
            }

            //fix the $dateto
            $dateto += ( 24 * 60 * 60 ) - 1;

            if ( $datefrom == '' && $dateto != '' && $now <= $dateto ) {
                return true;
            }

            if ( $dateto == '' && $datefrom != '' && $now >= $datefrom ) {
                return true;
            }

            $ondate = ( ( $datefrom != '' && $now >= $datefrom ) && ( $dateto != '' && $now <= $dateto ) ) ? true : false;

            return $ondate;
        }

        /**
         * Add points to the order from order_id
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  void
         */
        public function add_order_points ( $order_id ) {

            $order = wc_get_order ( $order_id );

            if ( YITH_WC_Points_Rewards ()->get_option ( 'hide_point_system_to_guess' ) == 'yes' && $order->customer_user == 0 ) {
                return;
            }

            $is_set = get_post_meta ( $order_id, '_ywpar_points_earned', true );

            $tot_points = 0;

            //return if the points are just calculated
            if ( $is_set != '' ) {
                return;
            }

            $order_items = $order->get_items ();

            if ( ! empty( $order_items ) ) {
                foreach ( $order_items as $order_item ) {

                    $product_id = ( $order_item[ 'variation_id' ] != 0 ) ? $order_item[ 'variation_id' ] : $order_item[ 'product_id' ];

                    $item_points = $this->calculate_product_points ( $product_id );

                    $tot_points += $item_points * $order_item[ 'qty' ];
                }
            }

            $coupons = $order->get_used_coupons ();
            if ( sizeof ( $coupons ) > 0 && YITH_WC_Points_Rewards ()->get_option ( 'remove_points_coupon' ) == 'yes' ) {
                $remove_points     = 0;
                $conversion_points = $this->get_conversion_option ();
                if ( $order->get_total_discount () ) {
                    if ( $conversion_points[ 'money' ] * $conversion_points[ 'points' ] != 0 ) {
                        $remove_points += floor ( $order->get_total_discount () / $conversion_points[ 'money' ] * $conversion_points[ 'points' ] );
                    }
                }


                $tot_points -= $remove_points;
            }

            $tot_points = ( $tot_points < 0 ) ? 0 : $tot_points;


            //update order meta and add note to the order
            update_post_meta ( $order_id, '_ywpar_points_earned', $tot_points );
            update_post_meta ( $order_id, '_ywpar_conversion_points', $this->get_conversion_option () );

            $order->add_order_note ( sprintf ( __ ( 'Customer earned %d %s for this purchase.' ), $tot_points, YITH_WC_Points_Rewards ()->get_option ( 'points_label_plural' ) ), 0 );

            $user_id = $order->user_id;

            if ( $user_id > 0 ) {
                $this->add_points ( $user_id, $tot_points, 'order_completed', $order_id );
                $this->extra_points ( array ( 'num_of_orders', 'amount_spent', 'points' ), $user_id );
            }
        }

        /**
         * Remove points to the order from order_id
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  void
         */
        public function remove_order_points ( $order_id ) {

            $point_earned = get_post_meta ( $order_id, '_ywpar_points_earned', true );

            if ( $point_earned == '' ) {
                return;
            }

            $order   = wc_get_order ( $order_id );
            $user_id = $order->user_id;

            $points = $point_earned;
            $action = 'order_' . $order->get_status ();

            if ( $user_id > 0 ) {
                $current_point = get_user_meta ( $user_id, '_ywpar_user_total_points', true );
                $new_point     = ( $current_point - $points > 0 ) ? ( $current_point - $points ) : 0;
                update_user_meta ( $user_id, '_ywpar_user_total_points', $new_point );
                update_post_meta ( $order_id, '_ywpar_points_earned', $point_earned - $points );
                YITH_WC_Points_Rewards ()->register_log ( $user_id, $action, $order_id, - $points );

                $order->add_order_note ( sprintf ( __ ( 'Removed %d %s for order %s.' ), - $points, YITH_WC_Points_Rewards ()->get_option ( 'points_label_plural' ), YITH_WC_Points_Rewards ()->get_action_label ( $action ) ), 0 );
            }

        }


        /**
         * Add point to the order if the refund is deleted
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  void
         */
        public function refund_delete () {
            check_ajax_referer ( 'order-item', 'security' );


            $refund_id = absint ( $_POST[ 'refund_id' ] );

            if ( $refund_id && 'shop_order_refund' === get_post_type ( $refund_id ) ) {
                $order_id = wp_get_post_parent_id ( $refund_id );

            }

            $point_earned = get_post_meta ( $order_id, '_ywpar_points_earned', true );

            if ( $point_earned == '' ) {
                return;
            }

            $order          = wc_get_order ( $order_id );
            $order_subtotal = $order->get_subtotal ();
            $user_id        = $order->user_id;

            $refund_obj    = new WC_Order_Refund( $refund_id );
            $refund_amount = $refund_obj->get_refund_amount ();

            if ( $refund_amount > 0 ) {

                if ( $refund_amount > $order_subtotal ) {
                    //shipping must be removed from
                    $order_shipping_total = $order->get_total_shipping ();
                    $refund_amount        = $refund_amount - $order_shipping_total;
                }

                $conversion_points = get_post_meta ( $order_id, '_ywpar_conversion_points', true );
                if ( $conversion_points == '' ) {
                    $conversion_points = $this->get_conversion_option ();
                }
                $points = $refund_amount / $conversion_points[ 'money' ] * $conversion_points[ 'points' ];
                $action = 'refund_deleted';

                if ( $user_id > 0 ) {
                    $current_point = get_user_meta ( $user_id, '_ywpar_user_total_points', true );
                    update_user_meta ( $user_id, '_ywpar_user_total_points', $current_point + $points );
                    update_post_meta ( $order_id, '_ywpar_points_earned', $points + $point_earned );
                    YITH_WC_Points_Rewards ()->register_log ( $user_id, $action, $order_id, $points );
                    $order->add_order_note ( sprintf ( __ ( 'Added %d %s for cancelled refund.' ), $points, YITH_WC_Points_Rewards ()->get_option ( 'points_label_plural' ) ), 0 );
                }
            }

        }

        /**
         * Remove points to the order if there's a partial refund
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  void
         */
        public function remove_order_points_refund ( $order_id, $refund_id ) {


            $point_earned          = get_post_meta ( $order_id, '_ywpar_points_earned', true );
            $total_points_refunded = get_post_meta ( $order_id, '_ywpar_total_points_refunded', true );

            if ( $point_earned == '' ) {
                return false;
            }

            $refund_obj = new WC_Order_Refund( $refund_id );

            $refund_amount  = $refund_obj->get_refund_amount ();
            $order          = wc_get_order ( $order_id );
            $order_total    = $order->get_total ();
            $order_subtotal = $order->get_subtotal ();
            $user_id        = $order->user_id;

            if ( $refund_amount > 0 ) {

                if ( $refund_amount > $order_subtotal ) {
                    //shipping must be removed from
                    $order_shipping_total = $order->get_total_shipping ();
                    $refund_amount        = $refund_amount - $order_shipping_total;
                }

                $conversion_points = get_post_meta ( $order_id, '_ywpar_conversion_points', true );

                if ( $conversion_points == '' ) {
                    $conversion_points = $this->get_conversion_option ();
                }

                if ( $refund_amount == abs ( $order_total ) ) {
                    $points = $point_earned;
                } else {
                    $points = floor ( $refund_amount / $conversion_points[ 'money' ] * $conversion_points[ 'points' ] );
                }

                //fix the points to refund calculation if points are more of the gap
                $gap    = $point_earned - $total_points_refunded;
                $points = ( $points > $gap ) ? $gap : $points;

                $action = 'order_refund';
                $total_points_refunded += $points;

                if ( $user_id > 0 ) {
                    $current_point = get_user_meta ( $user_id, '_ywpar_user_total_points', true );
                    $new_point     = ( $current_point - $points > 0 ) ? ( $current_point - $points ) : 0;
                    update_user_meta ( $user_id, '_ywpar_user_total_points', $new_point );
                    update_post_meta ( $order_id, '_ywpar_total_points_refunded', $total_points_refunded );
                    YITH_WC_Points_Rewards ()->register_log ( $user_id, $action, $order_id, - $points );
                    $order->add_order_note ( sprintf ( __ ( 'Removed %d %s for order refund.' ), $points, YITH_WC_Points_Rewards ()->get_option ( 'points_label_plural' ) ), 0 );
                }

            }
        }


        /**
         * Return the global points of an object
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  int
         */
        public function get_point_earned ( $object, $type = 'order' ) {

            $conversion = $this->get_conversion_option ();
            $price      = 0;
            switch ( $type ) {
                case 'order':
                    $price = $object->get_total ();
                    break;
                case 'product':
                    $price = ( get_option ( 'woocommerce_tax_display_cart' ) == 'excl' ) ? $object->get_price_excluding_tax () : $object->get_price_including_tax ();
                    break;
                default:

            }

            $points = $price / $conversion[ 'money' ] * $conversion[ 'points' ];

            return floor ( $points );
        }

        /**
         * Return the global points of an object
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  void
         */
        public function get_conversion_option () {

            $role_conversion_enabled = YITH_WC_Points_Rewards ()->get_option ( 'enable_conversion_rate_for_role' );
            $conversion_rate_level   = YITH_WC_Points_Rewards ()->get_option ( 'conversion_rate_level' );
            $conversion              = YITH_WC_Points_Rewards ()->get_option ( 'earn_points_conversion_rate' );

            if ( $role_conversion_enabled == 'yes' && is_user_logged_in () ) {
                $current_user    = wp_get_current_user ();
                $conversion_rate = 0;
                if ( ! empty( $current_user->roles ) ) {
                    foreach ( $current_user->roles as $role ) {
                        $c = YITH_WC_Points_Rewards ()->get_option ( 'earn_points_role_' . $role );
                        if ( $c[ 'points' ] != '' && $c[ 'money' ] != '' && $c[ 'money' ] != 0 ) {
                            $current_conversion_rate = abs ( $c[ 'points' ] / $c[ 'money' ] );
                            if ( ( $conversion_rate_level == 'high' && $current_conversion_rate >= $conversion_rate ) || ( $conversion_rate_level == 'low' && $current_conversion_rate < $conversion_rate ) ) {
                                $conversion_rate = $current_conversion_rate;
                                $conversion      = $c;
                            }
                        }
                    }
                }
            }

            $conversion[ 'money' ]  = ( empty( $conversion[ 'money' ] ) ) ? 1 : $conversion[ 'money' ];
            $conversion[ 'points' ] = ( empty( $conversion[ 'points' ] ) ) ? 1 : $conversion[ 'points' ];

            return apply_filters ( 'ywpar_conversion_points_rate', $conversion );
        }

        /**
         * Add extra points to the user
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  void
         */
        public function extra_points ( $type = array (), $user_id ) {

            if ( empty( $type ) ) {
                return false;
            }

            $extra_points     = 0;
            $user_extrapoint  = get_user_meta ( $user_id, '_ywpar_extrapoint', true );
            $current_points   = get_user_meta ( $user_id, '_ywpar_user_total_points', true );
            $extrapoint_rules = YITH_WC_Points_Rewards ()->get_option ( 'extra_points' );
            $action           = '';
            $counter          = 0;

            if ( empty( $extrapoint_rules ) ) {
                return;
            }

            foreach ( $extrapoint_rules as $rule ) {
                if ( ! in_array ( $rule[ 'option' ], $type ) ) {
                    continue;
                }

                $extra_points = 0;

                $flag   = true;
                $repeat = isset( $rule[ 'repeat' ] ) ? $rule[ 'repeat' ] : 0;

                if ( ! empty( $user_extrapoint ) ) {
                    foreach ( $user_extrapoint as $ue_item ) {
                        if ( ! $repeat ) {
                            if ( $ue_item[ 'option' ] == $rule[ 'option' ] && $ue_item[ 'value' ] == $rule[ 'value' ] && $ue_item[ 'points' ] == $rule[ 'points' ] ) {
                                $flag = false;
                            }
                        } else {
                            $counter = ( isset( $ue_item[ 'counter' ] ) ) ? $ue_item[ 'counter' ] : 0;
                        }
                    }
                }


                if ( $flag ) {
                    switch ( $rule[ 'option' ] ) {
                        case 'points':

                            $usable_points = $current_points;

                            if ( $repeat == 1 && $counter != 0 ) {
                                //calculate the number of points from the last points extra earning
                                $usable_points = $this->get_usable_points ( $user_id );
                            }

                            if ( $usable_points >= $rule[ 'value' ] ) {
                                $extra_points = $rule[ 'points' ];
                                $counter ++;
                            }

                            break;
                        case 'amount_spent':
                            $usable_amount = $this->get_total_orders_amount ( $user_id );

                            if ( $repeat == 1 && $counter != 0 ) {
                                $usable_amount = $usable_amount - $counter * $rule[ 'value' ];
                            }

                            if ( $usable_amount >= $rule[ 'value' ] ) {
                                $extra_points = $rule[ 'points' ];
                                $counter ++;
                            }
                            break;

                        case 'num_of_orders':
                            $usable_num_of_order = $this->count_orders ( $user_id );

                            if ( $repeat == 1 && $counter != 0 ) {
                                $usable_num_of_order = $usable_num_of_order - $counter * $rule[ 'value' ];
                            }
                            if ( $usable_num_of_order >= $rule[ 'value' ] ) {
                                $extra_points = $rule[ 'points' ];
                                $counter ++;
                            }
                            break;
                        case 'reviews':

                            $review_num      = 0;
                            $usable_comments = get_comments ( array ( 'status' => 'approve', 'user_id' => $user_id, 'post_type' => 'product', 'number' => '' ) );
                            if ( ! empty( $usable_comments ) ) {
                                $review_num = count ( $usable_comments );
                                if ( $repeat == 1 && $counter != 0 ) {
                                    $review_num = $review_num - $counter * $rule[ 'value' ];
                                }
                            }
                            if ( $review_num >= $rule[ 'value' ] ) {
                                $extra_points = $rule[ 'points' ];
                                $counter ++;
                            }

                            $action = __ ( 'Reviews', 'yith-woocommerce-points-and-rewards' );
                            break;
                        case 'registration':

                            if ( $rule[ 'value' ] != '' ) {
                                $extra_points = $rule[ 'points' ];
                                $counter ++;
                            }

                            break;
                        default:
                    }


                    if ( $extra_points > 0 ) {
                        $rule[ 'counter' ] = $counter;
                        $user_extrapoint[] = $rule;

                        update_user_meta ( $user_id, '_ywpar_extrapoint', $user_extrapoint );
                        $this->add_points ( $user_id, $extra_points, $rule[ 'option' ] . '_exp', $action );
                        $current_points += $extra_points;
                    }


                }

            }

        }

        /**
         * Return usable points
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  void
         */
        public function get_usable_points ( $user_id ) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'yith_ywpar_points_log';
            $from_id    = 1;
            $query      = "SELECT id  FROM  $table_name where user_id = $user_id AND action='points_exp' ORDER BY date DESC LIMIT 1";
            $res        = $wpdb->get_row ( $query );

            if ( ! empty( $res ) ) {
                $from_id = $res->id;
            }
            $query = "SELECT SUM( ywpar_points.amount) as usable_points FROM $table_name as ywpar_points where user_id = $user_id AND id > $from_id";
            $res   = $wpdb->get_row ( $query );

            if ( ! empty( $res ) ) {
                return $res->usable_points;
            }
        }

        /**
         * Add Point to the user
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  void
         */
        public function add_points ( $user_id, $points, $action, $order_id ) {
            $current_point = get_user_meta ( $user_id, '_ywpar_user_total_points', true );
            update_user_meta ( $user_id, '_ywpar_user_total_points', $current_point + $points );
            YITH_WC_Points_Rewards ()->register_log ( $user_id, $action, $order_id, $points );
        }

        public function count_orders ( $user_id ) {
            return get_user_meta ( $user_id, '_order_count', true );
            /* $args = array(
                 'numberposts' => - 1,
                 'post_type'   => 'shop_order',
                 'post_status' => 'wc-completed',
                 'meta_key'    => '_customer_user',
                 'meta_value'  => $user_id,
             );

             $orders = get_posts( $args );
             return count( $orders );*/
        }

        public function get_total_orders_amount ( $user_id ) {

            return get_user_meta ( $user_id, '_money_spent', true );
            /*$args = array(
                'numberposts' => - 1,
                'post_type'   => 'shop_order',
                'post_status' => 'wc-completed',
                'meta_key'    => '_customer_user',
                'meta_value'  => $user_id,
            );

            $orders = get_posts( $args );
            $amount = 0;
            if ( !empty( $orders ) ) {
                foreach ( $orders as $order ) {
                    $order_obj = wc_get_order( $order->ID );
                    $amount += $order_obj->get_total();
                }
            }

            return $amount;*/
        }

        public function add_order_points_with_review ( $comment_ID, $status ) {
            //only if the review is approved assign the point to the user
            if ( ( $status !== 'approve' && $status != 1 ) || ! is_user_logged_in () ) {
                return;
            }

            $comment = get_comment ( $comment_ID );

            //only if is a review
            $post_type = get_post_type ( $comment->comment_post_ID );

            if ( 'product' != $post_type ) {
                return;
            }


            //check if the review is setted as extra-point rule
            $extrapoint_rules = YITH_WC_Points_Rewards ()->get_option ( 'extra_points' );

            if ( ! is_array ( $extrapoint_rules ) || array_search ( 'reviews', array_column ( $extrapoint_rules, 'option' ) ) === false ) {
                return;
            }

            $this->extra_points ( array ( 'reviews' ), $comment->user_id );


        }

        public function extrapoints_to_new_customer ( $customer_id, $new_customer_data ) {
            //check if the review is setted as extra-point rule
            $extrapoint_rules = YITH_WC_Points_Rewards ()->get_option ( 'extra_points' );

            if ( ! is_array ( $extrapoint_rules ) || array_search ( 'registration', array_column ( $extrapoint_rules, 'option' ) ) === false ) {
                return;
            }

            $this->extra_points ( array ( 'registration' ), $customer_id );


        }
    }


}

/**
 * Unique access to instance of YITH_WC_Points_Rewards_Earning class
 *
 * @return \YITH_WC_Points_Rewards_Earning
 */
function YITH_WC_Points_Rewards_Earning () {
    return YITH_WC_Points_Rewards_Earning::get_instance ();
}

