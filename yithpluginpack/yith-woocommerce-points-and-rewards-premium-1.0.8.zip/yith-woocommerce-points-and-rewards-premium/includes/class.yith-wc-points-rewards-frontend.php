<?php

if ( ! defined ( 'ABSPATH' ) || ! defined ( 'YITH_YWPAR_VERSION' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Implements features of YITH WooCommerce Points and Rewards Frontend
 *
 * @class   YITH_WC_Points_Rewards_Frontend
 * @package YITH WooCommerce Points and Rewards
 * @since   1.0.0
 * @author  Yithemes
 */
if ( ! class_exists ( 'YITH_WC_Points_Rewards_Frontend' ) ) {

    class YITH_WC_Points_Rewards_Frontend {

        /**
         * Single instance of the class
         *
         * @var \YITH_WC_Points_Rewards_Frontend
         */
        protected static $instance;

        /**
         * Returns single instance of the class
         *
         * @return \YITH_WC_Points_Rewards_Frontend
         * @since 1.0.0
         */
        public static function get_instance () {
            if ( is_null ( self::$instance ) ) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function __construct () {

            if ( ! YITH_WC_Points_Rewards ()->is_enabled () ) {
                return;
            }

            add_action ( 'wp_enqueue_scripts', array ( $this, 'enqueue_styles_scripts' ) );

            if ( YITH_WC_Points_Rewards ()->get_option ( 'show_point_list_my_account_page' ) == 'yes' ) {
                add_action ( 'woocommerce_before_my_account', array ( $this, 'my_account_points' ) );
            }


            if ( YITH_WC_Points_Rewards ()->get_option ( 'hide_point_system_to_guess' ) == 'yes' && ! is_user_logged_in () ) {
                return;
            }


            if ( YITH_WC_Points_Rewards ()->get_option ( 'enabled_single_product_message' ) == 'yes' ) {
                $this->show_single_product_message_position ();
            }


            if ( YITH_WC_Points_Rewards ()->get_option ( 'enabled_cart_message' ) == 'yes' ) {
                add_action ( 'woocommerce_before_cart_contents', array ( $this, 'print_messages_in_cart' ) );
            }

            if ( YITH_WC_Points_Rewards ()->get_option ( 'enabled_checkout_message' ) == 'yes' ) {
                add_action ( 'woocommerce_before_checkout_form', array ( $this, 'print_messages_in_cart' ) );
            }

            if ( ! is_user_logged_in () ) {
                return;
            }


            if ( YITH_WC_Points_Rewards ()->get_option ( 'enabled_rewards_cart_message' ) == 'yes' ) {
                add_action ( 'woocommerce_before_cart_contents', array ( $this, 'print_rewards_message_in_cart' ) );
                add_action ( 'woocommerce_before_checkout_form', array ( $this, 'print_rewards_message_in_cart' ) );
            }


        }

        /**
         * Enqueue Scripts and Styles
         *
         * @return void
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function enqueue_styles_scripts () {
            wp_enqueue_script ( 'ywpar_frontend', YITH_YWPAR_ASSETS_URL . '/js/frontend' . YITH_YWPAR_SUFFIX . '.js', array ( 'jquery' ), YITH_YWPAR_VERSION, true );
            wp_enqueue_style ( 'ywpar_frontend', YITH_YWPAR_ASSETS_URL . '/css/frontend.css' );
        }

        /**
         * Print message in single product page
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  void
         */
        public function show_single_product_message () {

            global $product;
            $message = YITH_WC_Points_Rewards ()->get_option ( 'single_product_message' );

            $singular = YITH_WC_Points_Rewards ()->get_option ( 'points_label_singular' );
            $plural   = YITH_WC_Points_Rewards ()->get_option ( 'points_label_plural' );

            $product_points = YITH_WC_Points_Rewards_Earning ()->calculate_product_points ( $product->id );

            if ( $product_points == 0 ) {
                return;
            }

            $message = str_replace ( '{points}', $product_points, $message );
            if ( $product_points > 1 ) {
                $message = str_replace ( '{points_label}', $plural, $message );
            } else {
                $message = str_replace ( '{points_label}', $singular, $message );
            }

            echo '<div  class="yith-par-message">' . $message . '</div>';
        }

        /**
         * Set tthe position where display the message in single product
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  void
         */
        public function show_single_product_message_position () {
            //Table Pricing
            $position = YITH_WC_Points_Rewards ()->get_option ( 'single_product_message_position' );
            
            $priority_single_add_to_cart = has_action ( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart' );
            $priority_single_excerpt     = has_action ( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt' );
            
            switch ( $position ) {
                case 'before_add_to_cart':
                    if ( $priority_single_add_to_cart ) {
                        add_action ( 'woocommerce_single_product_summary', array ( $this, 'show_single_product_message' ), $priority_single_add_to_cart - 1 );
                    } else {
                        add_action ( 'woocommerce_single_product_summary', array ( $this, 'show_single_product_message' ), 28 );
                    }
                    break;
                case 'after_add_to_cart':
                    if ( $priority_single_add_to_cart ) {
                        add_action ( 'woocommerce_single_product_summary', array ( $this, 'show_single_product_message' ), $priority_single_add_to_cart + 1 );
                    } else {
                        add_action ( 'woocommerce_single_product_summary', array ( $this, 'show_single_product_message' ), 32 );
                    }
                    break;
                case 'before_excerpt':
                    if ( $priority_single_excerpt ) {
                        add_action ( 'woocommerce_single_product_summary', array ( $this, 'show_single_product_message' ), $priority_single_excerpt - 1 );
                    } else {
                        add_action ( 'woocommerce_single_product_summary', array ( $this, 'show_single_product_message' ), 18 );
                    }
                    break;
                case 'after_excerpt':
                    if ( $priority_single_excerpt ) {
                        add_action ( 'woocommerce_single_product_summary', array ( $this, 'show_single_product_message' ), $priority_single_excerpt + 1 );
                    } else {
                        add_action ( 'woocommerce_single_product_summary', array ( $this, 'show_single_product_message' ), 22 );
                    }
                    break;
                case 'after_meta':
                    $priority_after_meta = has_action ( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta' );
                    if ( $priority_after_meta ) {
                        add_action ( 'woocommerce_single_product_summary', array ( $this, 'show_single_product_message' ), $priority_after_meta + 1 );
                    } else {
                        add_action ( 'woocommerce_single_product_summary', array ( $this, 'show_single_product_message' ), 42 );
                    }
                default:
                    break;
            }

        }

        /**
         * Print a message in cart/checkout page
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  void
         */
        public function print_messages_in_cart () {
            $page = 'cart';
            if ( is_checkout () ) {
                $page = 'checkout';
            }
            $message = YITH_WC_Points_Rewards ()->get_option ( $page . '_message' );

            $singular = YITH_WC_Points_Rewards ()->get_option ( 'points_label_singular' );
            $plural   = YITH_WC_Points_Rewards ()->get_option ( 'points_label_plural' );

            $total_points = YITH_WC_Points_Rewards_Earning ()->calculate_points_on_cart ();

            if ( $total_points == 0 ) {
                return;
            }

            $message = str_replace ( '{points}', $total_points, $message );
            if ( $total_points > 1 ) {
                $message = str_replace ( '{points_label}', $plural, $message );
            } else {
                $message = str_replace ( '{points_label}', $singular, $message );
            }

            printf ( '<div id="yith-par-message-cart" class="woocommerce-cart-notice woocommerce-cart-notice-minimum-amount woocommerce-info">%s</div>', $message );

        }

        /**
         * Print rewards message in cart/checkout page
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  void
         */
        public function print_rewards_message_in_cart () {

            $coupons = WC ()->cart->get_applied_coupons ();

            if ( ! empty( $coupons ) ) {
                foreach ( $coupons as $coupon ) {
                    if ( $coupon == YITH_WC_Points_Rewards_Redemption ()->get_coupon_code () ) {
                        return;
                    }
                }
            }

            $message = YITH_WC_Points_Rewards ()->get_option ( 'rewards_cart_message' );
            $plural  = YITH_WC_Points_Rewards ()->get_option ( 'points_label_plural' );


            if ( is_user_logged_in () ) {

                $max_discount   = YITH_WC_Points_Rewards_Redemption ()->calculate_rewards_discount ();
                $minimum_amount = YITH_WC_Points_Rewards ()->get_option ( 'minimum_amount_to_redeem' );
                if ( $minimum_amount != 0 && WC ()->cart->subtotal < $minimum_amount ) {
                    return;
                }

                if ( $max_discount ) {

                    $max_points = YITH_WC_Points_Rewards_Redemption ()->get_max_points ();

                    $message = str_replace ( '{points_label}', $plural, $message );
                    $message = str_replace ( '{max_discount}', wc_price ( $max_discount ), $message );
                    $message = str_replace ( '{points}', $max_points, $message );
                    $message .= ' <a class="ywpar-button-message">' . __ ( 'Apply Discount', 'yith-woocommerce-points-and-rewards' ) . '</a>';
                    $message .= '<div class="clear"></div><div class="ywpar_apply_discounts_container"><form class="ywpar_apply_discounts" method="post">' . wp_nonce_field ( 'ywpar_apply_discounts', 'ywpar_input_points_nonce' ) . '
                                    <input type="hidden" name="ywpar_points_max" value="' . $max_points . '">
                                    <input type="hidden" name="ywpar_max_discount" value="' . $max_discount . '">
                                    <p class="form-row form-row-first">
                                        <input type="text" name="ywpar_input_points" class="input-text" placeholder="' . $max_points . '" id="ywpar-points-max" value="' . $max_points . '">
                                        <input type="hidden" name="ywpar_input_points_check" id="ywpar_input_points_check" value="0">
                                    </p>

                                    <p class="form-row form-row-last">
                                        <input type="submit" class="button" name="ywpar_apply_discounts" id="ywpar_apply_discounts" value="' . __ ( 'Apply Discounts', 'yith-woocommerce-points-and-rewards' ) . '">
                                    </p>

                                    <div class="clear"></div>
                                </form></div>';

                    printf ( '<div id="yith-par-message-cart" class="woocommerce-cart-notice woocommerce-cart-notice-minimum-amount woocommerce-info">%s</div>', $message );
                }
            }

        }

        /**
         * Add points section to my-account page
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  void
         */
        public function my_account_points () {
            wc_get_template ( 'myaccount/my-points-view.php' );
        }

    }


}

/**
 * Unique access to instance of YITH_WC_Points_Rewards_Frontend class
 *
 * @return \YITH_WC_Points_Rewards_Frontend
 */
function YITH_WC_Points_Rewards_Frontend () {
    return YITH_WC_Points_Rewards_Frontend::get_instance ();
}

