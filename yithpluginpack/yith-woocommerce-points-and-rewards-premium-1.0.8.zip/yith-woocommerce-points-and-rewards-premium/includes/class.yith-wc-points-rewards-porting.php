<?php

if ( !defined( 'ABSPATH' ) || !defined( 'YITH_YWPAR_VERSION' ) ) {
	exit; // Exit if accessed directly
}

/**
 * This class it used to migrate points from WooCommerce Points and Rewards to YITH WooCommerce Points and Rewards Premium
 *
 * @class   YITH_WC_Points_Rewards_Porting
 * @package YITH WooCommerce Points and Rewards
 * @since   1.0.0
 * @author  Yithemes
 */
if ( !class_exists( 'YITH_WC_Points_Rewards_Porting' ) ) {

	class YITH_WC_Points_Rewards_Porting {

		/**
		 * Single instance of the class
		 *
		 * @var \YITH_WC_Points_Rewards_Porting
		 */
		protected static $instance;



		/**
		 * Returns single instance of the class
		 *
		 * @return \YITH_WC_Points_Rewards_Porting
		 * @since 1.0.0
		 */
		public static function get_instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor
		 *
		 * Initialize plugin and registers actions and filters to be used
		 *
		 * @since  1.0.0
		 * @author Emanuela Castorina
		 */
		public function __construct() {

			//	add_action( 'init', array( $this, 'migrate_points') );

		}


		public function migrate_points( ){
			if( !class_exists('WC_Points_Rewards')){
				return;
			}

			$success = 0;

			$porting_done = get_option( "yith_ywpar_porting_done" );

			if( $porting_done ){
				return $success;
			}

			global $wpdb;
			$actions = array(
					'product-review'   => 'reviews_exp',
					'order-redeem'     => 'redeemed_points',
					'account-signup'   => 'registration_exp',
					'order-placed'     => 'order_completed',
					'expire'           => 'expired_points',
					'admin-adjustment' => 'admin_action',
					'order-cancelled' => 'order_refund',
			);

			// initialize the custom table names
			$user_points_log_db_tablename = $wpdb->prefix . 'wc_points_rewards_user_points_log';
			$user_points_db_tablename     = $wpdb->prefix . 'wc_points_rewards_user_points';


			$sql = "SELECT
					wplog.user_id as user_id,
					wplog.type as type,
					wplog.points as points,
					wplog.order_id as order_id,
					wplog.date as datelog,
					up.id as point_id,
					up.points_balance as points_balance,
					up.date as up_date
					FROM $user_points_log_db_tablename wplog LEFT JOIN $user_points_db_tablename up ON(wplog.user_points_id = up.id) WHERE 1 ";

			$results = $wpdb->get_results( $sql );

			$users = array();
			$counter = 0;

			if( $results ){

				$ywpar_table = $wpdb->prefix . 'yith_ywpar_points_log';
				$initial_query = "INSERT INTO $ywpar_table ( user_id, action, order_id, amount, date_earning, cancelled ) VALUES ";

				$values = array();
				$place_holders = array();
				$step = 100;

				foreach ( $results as $item ) {

					if( isset( $users[ $item->user_id] ) ){
						$users[ $item->user_id] = $users[ $item->user_id] + $item->points;
					}else{
						$users[ $item->user_id] = $item->points;
					}


					if( ! in_array( $item->type, array( 'expire', 'order-cancelled' ) ) ){
						array_push($values, $item->user_id,$actions[$item->type], $item->order_id ? $item->order_id : 0 ,$item->points, $item->datelog, '' );
						$place_holders[] = "('%d', '%s', '%d', '%d', '%s', '%s')";

					}else{
						array_push($values, $item->user_id,$actions[$item->type], $item->order_id ? $item->order_id : 0 ,$item->points, $item->up_date, $item->datelog);
						$place_holders[] = "('%d', '%s', '%d', '%d', '%s', '%s')";

					}

					//					if( $item->order_id ){
					//						update_post_meta( $item->order_id, '_ywpar_points_earned', $item->points );
					//					}


					if( $counter%$step == 0 ){
						$initial_query .= implode(', ', $place_holders);
						$wpdb->query( $wpdb->prepare("$initial_query ", $values));

						$values = array();
						$place_holders = array();
						$initial_query = "INSERT INTO $ywpar_table ( user_id, action, order_id, amount, date_earning, cancelled ) VALUES ";

					}

					$counter++;
				}

				if ( ! empty( $place_holders ) ) {
					$initial_query .= implode( ', ', $place_holders );
					$wpdb->query( $wpdb->prepare( "$initial_query ", $values ) );
				}

			}
			if( $users ){
				foreach( $users as $user_id => $points){
					$current_point = get_user_meta( $user_id, '_ywpar_user_total_points', true);
					update_user_meta( $user_id, '_ywpar_user_total_points', $current_point + $points);
				}
			}

			update_option( "yith_ywpar_porting_done", true );

			return $counter;
		}




	}


}

/**
 * Unique access to instance of YITH_WC_Points_Rewards_Porting class
 *
 * @return \YITH_WC_Points_Rewards_Porting
 */
function YITH_WC_Points_Rewards_Porting() {
	return YITH_WC_Points_Rewards_Porting::get_instance();
}
