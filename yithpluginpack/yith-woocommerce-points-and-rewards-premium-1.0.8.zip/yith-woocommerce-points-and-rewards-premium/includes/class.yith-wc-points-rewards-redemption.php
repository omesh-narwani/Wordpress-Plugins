<?php

if ( !defined( 'ABSPATH' ) || !defined( 'YITH_YWPAR_VERSION' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Implements features of YITH WooCommerce Points and Rewards
 *
 * @class   YITH_WC_Points_Rewards_Redemption
 * @package YITH WooCommerce Points and Rewards
 * @since   1.0.0
 * @author  Yithemes
 */
if ( !class_exists( 'YITH_WC_Points_Rewards_Redemption' ) ) {

    class YITH_WC_Points_Rewards_Redemption {

        /**
         * Single instance of the class
         *
         * @var \YITH_WC_Points_Rewards_Redemption
         */
        protected static $instance;

        protected $label_coupon = 'ywpar_discount';

        protected $max_points = 0;

        protected $max_discount = 0;

        protected $args = array();

        /**
         * Returns single instance of the class
         *
         * @return \YITH_WC_Points_Rewards_Redemption
         * @since 1.0.0
         */
        public static function get_instance() {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function __construct() {

            add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'add_order_meta' ) );

            //remove points if are used in order
            add_action( 'woocommerce_checkout_order_processed', array( $this, 'deduce_order_points' ) );
            add_action( 'wp_loaded', array( $this, 'apply_discount' ), 30 );

            if ( is_user_logged_in() ) {
                add_filter( 'woocommerce_get_shop_coupon_data', array( $this, 'create_coupon_discount' ), 10, 2 );
                add_filter( 'woocommerce_cart_totals_coupon_label', array( $this, 'coupon_label' ) );
                add_filter( 'woocommerce_coupon_message', array( $this, 'coupon_rewards_message' ), 10, 3 );
            }

        }

        /**
         * Apply the discount to cart after that the user set the number of points
         **
         * @since  1.0.0
         * @author Emanuela Castorina
         * @return void
         */
        public function apply_discount() {

            if ( wp_verify_nonce( 'ywpar_input_points_nonce', 'ywpar_apply_discounts' ) || !isset($_POST['ywpar_input_points_check']) || $_POST['ywpar_input_points_check'] == 0  || !isset( $_POST['ywpar_points_max'] ) || !is_user_logged_in() ||  ( isset($_POST['coupon_code']) && $_POST['coupon_code']!='')  ) {
                return;
            }

            $max_points   = $_POST['ywpar_points_max'];
            $max_discount = $_POST['ywpar_max_discount'];
            $input_points = $_POST['ywpar_input_points'];


            if ( $input_points == 0 ) {
                return;
            }

            if ( $input_points > $max_points ) {
                $input_points = $max_points;
            }

            $conversion = $this->get_conversion_rate_rewards();
            $input_max_discount = $input_points / $conversion['points'] * $conversion['money'];

            if( $input_max_discount > $max_discount){
                $input_max_discount = $max_discount;
            }


            if ( $input_max_discount > 0 ) {
                WC()->session->set( 'ywpar_coupon_code_points', $input_points );
                WC()->session->set( 'ywpar_coupon_code_discount', $input_max_discount );
                WC()->cart->add_discount( $this->label_coupon );
            };
        }

        /**
         * Return the coupon code
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         * @return string
         */
        public function get_coupon_code() {
            return apply_filters( 'ywpar_label_coupon', $this->label_coupon );
        }

        /**
         * Return the coupon code attributes
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         * @return array
         */
        function create_coupon_discount( $args, $code ) {

            if ( $code == $this->get_coupon_code() ) {

                $this->args = array(
                    'amount'           =>  $this->get_discount_amount(),
                    'coupon_amount'    =>  $this->get_discount_amount(), // 2.2
                    'apply_before_tax' => 'yes',
                    'type'             => 'fixed_cart',
                    'free_shipping'    => 'no',
                    'individual_use'   => 'no',
                );
                return $this->args;

            }

            return $args;
        }

        /**
         * Set the coupon label in cart
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         * @return string
         */
        public function coupon_label( $label ) {
            if ( strstr( $label, $this->get_coupon_code() ) ) {
                $label = esc_html( __( 'Redeem points', 'yith-woocommerce-points-and-rewards' ) );
            }
            return $label;
        }

        /**
         * Set the message when the discount is applied with success
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         * @return string
         */
        public function  coupon_rewards_message( $message, $message_code, $coupon ) {
            if ( $message_code === WC_Coupon::WC_COUPON_SUCCESS && $coupon->code === $this->get_coupon_code() ) {
                return __( 'Reward Discount Applied Successfully', 'yith-woocommerce-points-and-rewards' );
            }
            else {
                return $message;
            }
        }

        /**
         * Return the discount amount
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         * @return float
         */
        public function get_discount_amount(  ) {
            $discount = 0;
            if ( WC()->session !== null ) {
                $discount =  WC()->session->get( 'ywpar_coupon_code_discount' );
            }

            return $discount;
        }

        /**
         * Register the coupon amount and points in the post meta of order
         * if there's a rewards
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         * @return float
         */
        public function add_order_meta( $order_id ) {
            $order        = wc_get_order( $order_id );
            $used_coupons = $order->get_used_coupons();

            //check if the coupon was used in the order
            if ( array_search( $this->get_coupon_code(), $used_coupons ) === false ) {
                return;
            }

            update_post_meta( $order_id, '_ywpar_coupon_amount', WC()->session->get( 'ywpar_coupon_code_discount' ) );
            update_post_meta( $order_id, '_ywpar_coupon_points', WC()->session->get( 'ywpar_coupon_code_points' ) );
        }

        /**
         * Deduct the point from the user total points
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         * @return void
         */
        public function deduce_order_points( $order_id ) {
            $order        = wc_get_order( $order_id );
            $used_coupons = $order->get_used_coupons();

            //check if the coupon was used in the order
            if ( array_search( $this->get_coupon_code(), $used_coupons ) === false ) {
                return;
            }

            $points          = get_post_meta( $order_id, '_ywpar_coupon_points', true );
            $discount_amount = get_post_meta( $order_id, '_ywpar_coupon_amount', true );
            $redemped_points = get_post_meta( $order_id, '_ywpar_redemped_points', true );


            if ( $redemped_points != '' ) {
                return;
            }

            if ( $order->user_id > 0 ) {
                $current_point                 = get_user_meta( $order->user_id, '_ywpar_user_total_points', true );
                $current_discount_total_amount = get_user_meta( $order->user_id, '_ywpar_user_total_discount', true );

                $new_point     = ( $current_point - $points > 0 ) ? ( $current_point - $points ) : 0;

                update_user_meta( $order->user_id, '_ywpar_user_total_points', $new_point );
                update_user_meta( $order->user_id, '_ywpar_user_total_discount', $current_discount_total_amount + $discount_amount );
                update_post_meta( $order_id, '_ywpar_redemped_points', $points );

                YITH_WC_Points_Rewards()->register_log( $order->user_id, 'redeemed_points', $order_id, - $points );

                $order->add_order_note( sprintf( __( '%d %s to get a reward' ), - $points, YITH_WC_Points_Rewards()->get_option( 'points_label_plural' ) ), 0 );
            }

        }

        /**
         * Return the conversion rate rewards based on the role of users
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         * @return float
         */
        public function get_conversion_rate_rewards() {
            $conversion            = YITH_WC_Points_Rewards()->get_option( 'rewards_conversion_rate' );
            $conversion['money'] = ( empty($conversion['money']) ) ? 1 : $conversion['money'];
            $conversion['points'] = ( empty($conversion['points']) ) ? 1 : $conversion['points'];

            $conversion_rate_level = YITH_WC_Points_Rewards()->get_option( 'rewards_points_level' );

            if ( is_user_logged_in() ) {
                $current_user    = wp_get_current_user();
                $conversion_rate = abs( $conversion['points'] / $conversion['money'] );
                if ( YITH_WC_Points_Rewards()->get_option( 'rewards_points_for_role' ) == 'yes' ) {
                    if ( !empty( $current_user->roles ) ) {
                        foreach ( $current_user->roles as $role ) {
                            $c = YITH_WC_Points_Rewards()->get_option( 'rewards_points_role_' . $role );
                            if ( $c['points'] != '' && $c['money'] != '' && $c['money'] != 0 ) {
                                $current_conversion_rate = abs( $c['points'] / $c['money'] );

                                if ( ( $conversion_rate_level == 'high' && $current_conversion_rate <= $conversion_rate ) || ( $conversion_rate_level == 'low' && $current_conversion_rate > $conversion_rate ) ) {
                                    $conversion_rate = $current_conversion_rate;
                                    $conversion      = $c;
                                }
                            }
                        }
                    }
                }
            }

            return apply_filters( 'ywpar_rewards_conversion_rate', $conversion );
        }


        /**
         * Calculate the points of a product/variation for a single item
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  int $points
         */
        public function calculate_rewards_discount() {


            $user_id       = get_current_user_id();
            $points_usable = get_user_meta( $user_id, '_ywpar_user_total_points', true );
            $conversion    = $this->get_conversion_rate_rewards();

            if( $points_usable <= 0 ){
                return false;
            }



            //get the items of cart
            $items              = WC()->cart->get_cart();
            $this->max_discount = 0;
            $this->max_points   = 0;

            foreach ( $items as $item => $values ) {
                $product_id    = ( isset( $values['variation_id'] ) && $values['variation_id'] != 0 ) ? $values['variation_id'] : $values['product_id'];
                $product_discount = $this->calculate_product_max_discounts( $product_id );
                if ( $product_discount != 0 ) {
                    $this->max_discount += $product_discount * $values['quantity'];

                }
            }

            $general_max_discount = YITH_WC_Points_Rewards()->get_option('max_points_discount');
            $subtotal = WC()->cart->subtotal;


            if( $subtotal <=   $this->max_discount ){
                $this->max_discount =  $subtotal ;
            }

            //check if there's a max discount amount
            if ( $general_max_discount != '' ) {
                $is_percent = strpos( $general_max_discount, '%' );
                if ( $is_percent === false ) {
                    $max_discount = ( $subtotal >= $general_max_discount ) ? $general_max_discount : $subtotal;
                }else {
                    $general_max_discount = str_replace('%', '', $general_max_discount);
                    $max_discount = $subtotal * $general_max_discount / 100;
                }

                if( $max_discount <   $this->max_discount ){
                    $this->max_discount =  $max_discount ;
                }
            }

            $this->max_points = floor( $this->max_discount / $conversion['money'] * $conversion['points']);

            if( $this->max_points > $points_usable){
                $this->max_points = $points_usable;
                $this->max_discount = $this->max_points / $conversion['points'] * $conversion['money'];
            }
            return  $this->max_discount;

        }

        public function calculate_product_max_discounts( $product_id ) {

            $product              = wc_get_product( $product_id );
            $max_discount         =  $product->get_price();
            $max_discount_updated = false;
            $general_max_discount = YITH_WC_Points_Rewards()->get_option('max_points_product_discount');
            $max_product_discount = get_post_meta( $product_id, '_ywpar_max_point_discount', true );

            if ( $max_product_discount != '' ) {
                $is_percent = strpos( $max_product_discount, '%');
                if ( $is_percent === false ) {
                    $max_discount = ( $product->get_price() >= $max_product_discount ) ? $max_product_discount : $product->get_price();
                }
                else {
                    $max_product_discount = str_replace('%', '', $max_product_discount);
                    $max_discount = $product->get_price() * $max_product_discount / 100;
                }
                $max_discount_updated = true;
            }

            if ( !$max_discount_updated ) {
                if ( $product->is_type( 'variation' ) ) {
                    $categories = get_the_terms( $product->id, 'product_cat' );
                }
                else {
                    $categories = get_the_terms( $product_id, 'product_cat' );
                }

                if ( !empty( $categories ) ) {
                    $max_discount = $product->get_price(); //reset the global discount

                    foreach ( $categories as $term ) {
                        $max_category_discount = get_woocommerce_term_meta( $term->term_id, 'max_point_discount', true );

                        if ( $max_category_discount != '' ) {

                            $is_percent = strpos( $max_category_discount, '%');

                            if ( $is_percent === false ) {
                                $max_discount = ( $product->get_price() >= $max_category_discount ) ? $max_category_discount : $product->get_price();
                            }
                            else {
                                $max_category_discount = str_replace('%', '', $max_category_discount);
                                $max_discount = $product->get_price() * $max_category_discount / 100;
                            }

                            $max_discount_updated = true;
                        }


                    }
                }
            }

            if ( !$max_discount_updated && $general_max_discount != '') {
                $is_percent = strpos( $general_max_discount, '%');
                if ( $is_percent === false ) {
                    $max_discount = ( $product->get_price() >= $general_max_discount ) ? $general_max_discount : $product->get_price();
                }
                else {
                    $general_max_discount = str_replace('%', '', $general_max_discount);
                    $max_discount = $product->get_price() * $general_max_discount / 100;

                }
            }

            return $max_discount;
        }

        /**
         * Return the max points that can be used in the cart fore rewards
         * must be called after the function calculate_points_and_discount
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  int
         */
        public function get_max_points() {
            return apply_filters( 'ywpar_rewards_max_points', $this->max_points );
        }

        /**
         * Return the max discount that can be used in the cart fore rewards
         * must be called after the function calculate_points_and_discount
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  float
         */
        public function get_max_discount() {
            return apply_filters( 'ywpar_rewards_max_discount', $this->max_discount );
        }
    }
}

/**
 * Unique access to instance of YITH_WC_Points_Rewards_Redemption class
 *
 * @return \YITH_WC_Points_Rewards_Redemption
 */
function YITH_WC_Points_Rewards_Redemption() {
    return YITH_WC_Points_Rewards_Redemption::get_instance();
}

