<?php

if ( !defined( 'ABSPATH' ) || !defined( 'YITH_YWPAR_VERSION' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Implements features of YITH WooCommerce Points and Rewards
 *
 * @class   YITH_WC_Points_Rewards
 * @package YITH WooCommerce Points and Rewards
 * @since   1.0.0
 * @author  Yithemes
 */
if ( !class_exists( 'YITH_WC_Points_Rewards' ) ) {

    class YITH_WC_Points_Rewards {

        /**
         * Single instance of the class
         *
         * @var \YITH_WC_Points_Rewards
         */
        protected static $instance;

		/**
         * @var string
         */
        public $plugin_options = 'yit_ywpar_options';


        /**
         * Returns single instance of the class
         *
         * @return \YITH_WC_Points_Rewards
         * @since 1.0.0
         */
        public static function get_instance() {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function __construct() {

            add_action( 'plugins_loaded', array( $this, 'plugin_fw_loader' ), 15 );

            /* general actions */
            add_filter( 'woocommerce_locate_core_template', array( $this, 'filter_woocommerce_template' ), 10, 3 );
            add_filter( 'woocommerce_locate_template', array( $this, 'filter_woocommerce_template' ), 10, 3 );

            if( ! $this->is_enabled() ){
                return false;
            }


            /* email actions and filter */
            add_filter( 'woocommerce_email_classes', array( $this, 'add_woocommerce_emails' ) );
            add_action( 'woocommerce_init', array( $this, 'load_wc_mailer' ) );
            add_action( 'wp_loaded', array( $this, 'set_cron') );

            /* compatibility with email template */
            if( defined('YITH_WCET_PREMIUM')){
                add_filter('yith_wcet_email_template_types', array($this, 'email_template_list'));
            }

            if( $this->get_option('enable_update_point_email') == 'yes' ){
                add_action( 'ywpar_cron', array( $this, 'send_email_update_points' ) );
            }

            //register widget
            add_action( 'widgets_init', array( $this, 'register_widgets' ) );

            //add shortcode
            add_shortcode( 'yith_ywpar_points', array( $this, 'add_shortcode' ) );
            add_shortcode( 'yith_ywpar_points_list', array( $this, 'add_shortcode_list' ) );


            if( class_exists( 'YWSBS_Multivendor' ) ){
                add_filter( 'ywpar_enable_product_meta', array( $this, 'ywpar_multivendor_compatibility'));
            }


        }



        /**
         * Load YIT Plugin Framework
         *
         * @since  1.0.0
         * @return void
         * @author Emanuela Castorina
         */
        public function is_enabled(){

            $enabled = $this->get_option('enabled');

            if( $enabled == 'yes'){
                return true;
            }

            return false;
        }


        /**
         * Set Cron
         *
         * Set ywpar_cron action
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function set_cron() {
            if ( !wp_next_scheduled( 'ywpar_cron' ) ) {
                wp_schedule_event( time(), 'daily', 'ywpar_cron' );
            }
        }

        /**
         * Load YIT Plugin Framework
         *
         * @since  1.0.0
         * @return void
         * @author Emanuela Castorina
         */
        public function plugin_fw_loader() {
            if ( ! defined( 'YIT_CORE_PLUGIN' ) ) {
                global $plugin_fw_data;
                if( ! empty( $plugin_fw_data ) ){
                    $plugin_fw_file = array_shift( $plugin_fw_data );
                    require_once( $plugin_fw_file );
                }
            }
        }


		/**
         * @param            $user_id
         * @param            $action
         * @param            $order_id
         * @param            $amount
         * @param bool|false $data_earning
         * @param bool|false $expired
         */
        public function register_log( $user_id, $action, $order_id, $amount, $data_earning = false, $expired = false ){
            global $wpdb;
            $date = date( "Y-m-d H:i:s" );
            $table_name = $wpdb->prefix . 'yith_ywpar_points_log';
            $args = array(
                'user_id'      => $user_id,
                'action'       => $action,
                'order_id'     => $order_id,
                'amount'       => $amount,
                'date_earning' => ( $data_earning ) ? $data_earning : $date
            );

            if( $expired ){
                $args['cancelled'] = $date;
            }

            $wpdb->insert( $table_name, $args );
        }

        /**
         * Get options from db
         *
         * @access public
         * @since 1.0.0
         * @author  Emanuela Castorina
         * @param $option string
         * @return mixed
         */
        public function get_option( $option ) {
            // get all options
            $options = get_option( $this->plugin_options );

            if( isset( $options[ $option ] ) ) {
                return $options[ $option ];
            }

            return false;
        }

        /**
         * Locate default templates of woocommerce in plugin, if exists
         *
         * @param $core_file     string
         * @param $template      string
         * @param $template_base string
         *
         * @return string
         * @since  1.0.0
         */
        public function filter_woocommerce_template( $core_file, $template, $template_base ) {

            $located = yith_ywpar_locate_template( $template );

            if ( $located ) {
                return $located;
            }
            else {
                return $core_file;
            }
        }

        /**
         * Filters woocommerce available mails, to add wishlist related ones
         *
         * @param $emails array
         *
         * @return array
         * @since 1.0
         */
        public function add_woocommerce_emails( $emails ) {
            $emails['YITH_YWPAR_Expiration'] = include( YITH_YWPAR_INC . 'emails/class.yith-ywpar-expiration.php' );
            $emails['YITH_YWPAR_Update_Points'] = include( YITH_YWPAR_INC . 'emails/class.yith-ywpar-update-points.php' );
            return $emails;
        }

        /**
         * Loads WC Mailer when needed
         *
         * @return void
         * @since 1.0
         */
        public function load_wc_mailer() {
            add_action( 'expired_points_mail', array( 'WC_Emails', 'send_transactional_email' ), 10 );
            add_action( 'update_points_mail', array( 'WC_Emails', 'send_transactional_email' ), 10 );
        }


		/**
         * @param $user_id
         *
         * @return array|null|object
         */
        public function get_history( $user_id ){
            global $wpdb;
            $table_name = $wpdb->prefix . 'yith_ywpar_points_log';
            $query = "SELECT ywpar_points.* FROM $table_name as ywpar_points where user_id = $user_id ORDER BY date_earning DESC LIMIT 0,15";
            $items = $wpdb->get_results($query);

            return $items;
        }

        /**
         * Get the label for an action
         *
         * @param $label     string
         *
         * @return string
         * @since  1.0.0
         */
        public function get_action_label( $label ) {
            $label = $this->get_option( 'label_' . $label );
            if ( !$label ) {
                return '';
            }

            return $label;
        }


		/**
         * @return bool
         */
        public function set_expired_points(  ) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'yith_ywpar_points_log';
            $date = date( "Y-m-d H:i:s" );
            $expire_date = $this->get_option('days_before_expiration');

            if( $expire_date == '' ||  $expire_date <= 0 ){
                return false;
            }

            $query = "SELECT * FROM $table_name where ( date_earning <= CURDATE() - INTERVAL $expire_date DAY ) AND amount > 0 AND cancelled IS NULL ORDER BY date_earning DESC";
            $items = $wpdb->get_results($query);

            if( !empty( $items ) ){
                foreach ( $items as $item ) {
                    $this->register_log( $item->user_id, 'expired_points', $item->order_id, - abs($item->amount), false, true );
                    $wpdb->update( $table_name, array('cancelled' => $date ), array('id' => $item->id ) );
                    $current_points   = get_user_meta( $item->user_id, '_ywpar_user_total_points', true );
                    update_user_meta( $item->user_id, '_ywpar_user_total_points', $current_points - $item->amount );
                }
            }

        }


		/**
         * @return bool
         */
        public function send_email_before_expiration(){
            global $wpdb;

            $table_name         = $wpdb->prefix . 'yith_ywpar_points_log';
            $expire_date        = $this->get_option( 'days_before_expiration' );
            $expire_date_string = strtotime( "+7 day", time() );
            $days_before_send   = $this->get_option( 'send_email_days_before' );
            $interval           = $expire_date - $days_before_send;

            if( $expire_date == '' ||  $expire_date <= 0 || $days_before_send == '' || $days_before_send <= 0 ){
                return false;
            }

            $email_content= $this->get_option( 'expiration_email_content' );

            $query = "SELECT * FROM $table_name where ( date_earning <= CURDATE() - INTERVAL $interval DAY ) AND amount > 0 AND cancelled IS NULL ORDER BY date_earning DESC";
            $items = $wpdb->get_results($query);
            $user_sent = array();
            if( !empty( $items ) ){
                foreach ( $items as $item ) {

                    $user = get_user_by( 'id', $item->user_id );
                    if( in_array( $item->user_id, $user_sent) ){
                        continue;
                    }

                    $current_points   = get_user_meta( $item->user_id, '_ywpar_user_total_points', true );

                    $email_content = str_replace('{username}', $user->user_login, $email_content);
                    $email_content = str_replace('{expiring_points}', abs($item->amount),  $email_content );
                    $email_content = str_replace('{label_points}', YITH_WC_Points_Rewards()->get_option( 'points_label_plural' ),  $email_content );
                    $email_content = str_replace('{expiring_date}', date_i18n( wc_date_format(), $expire_date_string ),  $email_content );
                    $email_content = str_replace('{total_points}', $current_points,  $email_content );

                    $args = array(
                        'user_email'     => $user->user_email,
                        'email_content'   => $email_content,
                        'expiration_day' => $expire_date
                    );

                    $user_sent[] = $item->user_id;

                    do_action( 'expired_points_mail', $args );

                }
            }
        }

		/**
         *
         */
        public function send_email_update_points(){
            global $wpdb;

            $table_name       = $wpdb->prefix . 'yith_ywpar_points_log';
            $query = "SELECT * FROM $table_name where ( date_earning >= CURDATE() - INTERVAL 1 DAY ) AND cancelled IS NULL GROUP BY user_id";

            $items = $wpdb->get_results($query);
            $email_content= $this->get_option( 'update_point_email_content' );

            if( !empty( $items ) ){
                $current_user_id = 0;

                foreach ( $items as $item ) {
                    if( $current_user_id != $item->user_id ){
                        $current_user_id = $item->user_id;
                    }

                    $query = "SELECT * FROM $table_name where ( date_earning >= CURDATE() - INTERVAL 1 DAY ) AND cancelled IS NULL and user_id = $current_user_id ORDER BY date_earning";
                    $history = $wpdb->get_results($query);

                    if( !empty( $history ) ){

                        $user = get_user_by( 'id', $current_user_id );
                        $current_points   = get_user_meta( $current_user_id, '_ywpar_user_total_points', true );

                        $email_content = str_replace('{username}', $user->user_login, $email_content);
                        $email_content = str_replace('{label_points}', strtolower( $this->get_option( 'points_label_plural' ) ),  $email_content );
                        $email_content = str_replace('{total_points}', $current_points,  $email_content );

                        ob_start();
                        wc_get_template( 'emails/latest-updates.php', array( 'history' => $history ) );

                        $args = array(
                            'user_email'    => $user->user_email,
                            'email_content' => str_replace('{latest_updates}', ob_get_clean(),  $email_content )
                        );


                        do_action( 'update_points_mail', $args );
                    }

                }

            }
        }

        /**
         * Add a new template to the YITH WooCommerce Email Templates Premium
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function email_template_list( $templates ){
            $templates[] = array(
                'id'        => 'ywpar_expiration',
                'name'      => __('YITH WooCommerce Points and Rewards - Email Expired Points','yith-woocommerce-points-and-rewards'),
            );

            $templates[] = array(
                'id'        => 'ywpar_update_points',
                'name'      => __('YITH WooCommerce Points and Rewards - Email Update Points','yith-woocommerce-points-and-rewards'),
            );

            return $templates;
        }



        /**
         * Register the widgets
         *
         * @since   1.0.0
         * @author  Emanuela Castorina
         * @return  void
         */
        public function register_widgets(){
            register_widget( 'YITH_YWPAR_Points_Rewards_Widget' );
        }


		/**
         * @param $number
         *
         * @return array
         */
        public function user_list_points( $number ) {
            $user_query = new WP_User_Query( array ( 'number'=> $number, 'meta_key' => '_ywpar_user_total_points', 'orderby'=>'meta_value_num', 'order' => 'DESC', 'fields' => array('ID', 'display_name') ) );
            $users = $user_query->get_results();
            return $users;
        }

		/**
         * @param $number
         *
         * @return array
         */
        public function user_list_discount( $number ) {
            $user_query = new WP_User_Query( array ( 'number'=> $number, 'meta_key' => '_ywpar_user_total_discount', 'orderby'=>'meta_value_num', 'order' => 'DESC', 'fields' => array('ID', 'display_name') ) );
            $users = $user_query->get_results();
            return $users;
        }


		/**
         * @param      $atts
         * @param null $content
         *
         * @return string|void
         */
        public function add_shortcode(  $atts, $content = null ) {

            if( !is_user_logged_in() ){
                return;
            }


            $a = shortcode_atts( array(
                'label'   =>  __( 'Your credit is ', 'yith-woocommerce-points-and-rewards' )
            ), $atts );


            $points   = get_user_meta( get_current_user_id(), '_ywpar_user_total_points', true );
            $points   = ( $points == '' ) ? 0 : $points;
            $singular = YITH_WC_Points_Rewards()->get_option( 'points_label_singular' );
            $plural   = YITH_WC_Points_Rewards()->get_option( 'points_label_plural' );


            ob_start();

            echo '<p>'. $a['label'] .' ';
            printf( _n( '<strong>%s</strong> '.$singular, '<strong>%s</strong> '.$plural, $points,  'yith-woocommerce-points-and-rewards' ), $points );
            echo '</p>';

            return ob_get_clean();


        }

        /**
         * @param      $atts
         * @param null $content
         *
         * @return string|void
         */
        public function add_shortcode_list(  $atts, $content = null ) {


            ob_start();

            wc_get_template( 'myaccount/my-points-view.php');

            return ob_get_clean();


        }



        /**
         * Add YITH WooCommerce Multi Vendor Premium Compatibility
         * @param $enable
         *
         * @return bool
         */
        public function ywpar_multivendor_compatibility( $enable ) {
            $vendor = yith_get_vendor( 'current', 'user' );

            if ( $vendor->is_valid() && $vendor->has_limited_access() ) {
                return false;
            }

            return $enable;
        }

    }


}

/**
 * Unique access to instance of YITH_WC_Points_Rewards class
 *
 * @return \YITH_WC_Points_Rewards
 */
function YITH_WC_Points_Rewards() {
    return YITH_WC_Points_Rewards::get_instance();
}

