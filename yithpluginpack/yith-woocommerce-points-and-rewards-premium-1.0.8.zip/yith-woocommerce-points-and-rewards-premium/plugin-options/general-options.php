<?php

$additional_options = array();
if( class_exists('WC_Points_Rewards')){
    $additional_options = array(
        'id'        => 'apply_points_from_wc_points_rewards',
        'name'      => __( 'Apply Points from WooCommerce Points and Rewards', 'yith-woocommerce-points-and-rewards' ),
        'desc'      => __( 'You can do this action only one time', 'yith-woocommerce-points-and-rewards' ),
        'type'      => 'points-previous-order',
        'show_data' => false,
        'std'       => ''
    );
}


$settings = array(

    'general' => array(

        'header'    => array(

            array(
                'name' => __( 'General Settings', 'yith-woocommerce-points-and-rewards' ),
                'type' => 'title'
            ),

            array( 'type' => 'close' )
        ),


        'settings' => array(

            array( 'type' => 'open' ),

            array(
                'id'      => 'enabled',
                'name'    => __( 'Enable Points and Rewards', 'yith-woocommerce-points-and-rewards' ),
                'desc'    => '',
                'type'    => 'on-off',
                'std'     => 'yes'
            ),

            array(
                'id'      => 'earn_points_conversion_rate',
                'name'    => __( 'Conversion Rate for Points earned', 'yith-woocommerce-points-and-rewards' ),
                'desc'    => '',
                'type'    => 'options-conversion',
                'std'     => array(
                    'points' => 1,
                    'money'  => 1
                )
            ),

            array(
                'id'      => 'rewards_conversion_rate',
                'name'    => __( 'Reward Conversion Rate', 'yith-woocommerce-points-and-rewards' ),
                'desc'    => '',
                'type'    => 'options-conversion',
                'std'     => array(
                    'points' => 100,
                    'money'  => 1
                )
            ),

            array(
                'id'      => 'max_points_discount',
                'name'    => __( 'Maximum point discount', 'yith-woocommerce-points-and-rewards' ),
                'desc'    => __('Set maximum product discount allowed in cart when redeeming points. Leave blank to disable.','yith-woocommerce-points-and-rewards'),
                'type'    => 'text',
                'std'     => ''
            ),

            array(
                'id'      => 'max_points_discount',
                'name'    => __( 'Maximum point discount', 'yith-woocommerce-points-and-rewards' ),
                'desc'    => __('Set maximum product discount allowed in cart when redeeming points. Leave blank to disable.','yith-woocommerce-points-and-rewards'),
                'type'    => 'text',
                'std'     => ''
            ),

            array(
                'id'      => 'max_points_product_discount',
                'name'    => __( 'Maximum point discount for single product', 'yith-woocommerce-points-and-rewards' ),
                'desc'    => __('Set maximum product discount allowed when redeeming points per-product. Leave blank to disable.','yith-woocommerce-points-and-rewards'),
                'type'    => 'text',
                'std'     => ''
            ),

            //from version 1.0.1
            array(
                'id'      => 'minimum_amount_to_redeem',
                'name'    => __( 'Minimum Amount to Redeem', 'yith-woocommerce-points-and-rewards' ),
                'desc'    => __('Set minimum amount to redeem points. Leave blank to disable.','yith-woocommerce-points-and-rewards'),
                'type'    => 'text',
                'std'     => ''
            ),

            array(
                'id'      => 'remove_point_order_deleted',
                'name'    => __( 'Enable point removal for cancelled orders', 'yith-woocommerce-points-and-rewards' ),
                'desc'    => '',
                'type'    => 'on-off',
                'std'     => 'yes'
            ),

            array(
                'id'      => 'remove_point_refund_order',
                'name'    => __( 'Enable point removal for total or partial refund', 'yith-woocommerce-points-and-rewards' ),
                'desc'    => '',
                'type'    => 'on-off',
                'std'     => 'yes'
            ),

            //1.0.5
            array(
                'id'      => 'remove_points_coupon',
                'name'    => __( 'Remove points when coupons are used', 'yith-woocommerce-points-and-rewards' ),
                'desc'    => __( 'If you use coupons, their value will be removed from cart total and consequently points gained will be reduced as well.', 'yith-woocommerce-points-and-rewards' ),
                'type'    => 'on-off',
                'std'     => 'yes'
            ),

            array(
                'id'      => 'hide_point_system_to_guess',
                'name'    => __( 'Hide points message for guess', 'yith-woocommerce-points-and-rewards' ),
                'desc'    => __( 'If checked hide points messages in single products, cart and checkout', 'yith-woocommerce-points-and-rewards' ),
                'type'    => 'on-off',
                'std'     => 'yes'
            ),

            array(
                'id'      => 'show_point_list_my_account_page',
                'name'    => __( 'Show points in "My Account" page', 'yith-woocommerce-points-and-rewards' ),
                'desc'    => __( 'If checked show the points list "My Account" page', 'yith-woocommerce-points-and-rewards' ),
                'type'    => 'on-off',
                'std'     => 'yes'
            ),

            array(
                'id'      => 'apply_points_previous_order',
                'name'    => __( 'Apply Points to Previous Orders', 'yith-woocommerce-points-and-rewards' ),
                'desc'    => __('Starting from - Optional: Leave blank to apply to all orders', 'yith-woocommerce-points-and-rewards'),
                'type'    => 'points-previous-order',
                'show_data' => true,
                'std'     => ''
            ),


        )
    )
);

if ( ! empty( $additional_options ) ) {
    $settings['general']['settings'][] = $additional_options;
}
$settings['general']['settings'][] = array( 'type' => 'close' );
return apply_filters( 'yith_ywpar_panel_settings_options', $settings );