<?php

return array(
    'options' => array(
        'reviews'       => __( 'Reviews', 'yith-woocommerce-points-and-rewards' ),
        'num_of_orders' => __( 'Number of orders', 'yith-woocommerce-points-and-rewards' ),
        'amount_spent'  => __( 'Amount spent', 'yith-woocommerce-points-and-rewards' ),
        'points'        => __( 'Number of points', 'yith-woocommerce-points-and-rewards' ),
        'registration'  => __( 'Registration on shop', 'yith-woocommerce-points-and-rewards' ),
    ),


);
