<?php
/**
 * HTML Template Email YITH WooCommerce Points and Rewards
 *
 * @package YITH WooCommerce Points and Rewards
 * @since   1.0.0
 * @version 1.0.0
 * @author  Yithemes
 */


if ( defined( 'YITH_WCET_PREMIUM' ) ) {
    $mail_type = "ywpar_expiration";
    do_action( 'yith_wcet_email_header', $email_heading, $mail_type );
    $template = get_option( 'yith-wcet-email-template-' . $mail_type );
}
else {
    do_action( 'woocommerce_email_header', $email_heading );
}
?>
<?php echo $email_content ?>

<?php
if (defined('YITH_WCET_PREMIUM')) {
    do_action( 'yith_wcet_email_footer', $mail_type );
}else{
    do_action( 'woocommerce_email_footer' );
}
?>