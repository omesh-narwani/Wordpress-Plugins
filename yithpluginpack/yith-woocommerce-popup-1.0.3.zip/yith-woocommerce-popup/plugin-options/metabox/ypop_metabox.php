<?php
/**
 * Created by PhpStorm.
 * User: Your Inspiration
 * Date: 20/01/2015
 * Time: 12:04
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly


$array_form = array();
$active_plugins     = array(
    'none' => __( 'Select a form type', 'ypop' ),
);

if ( function_exists( 'YIT_Contact_Form' ) ) {
    $active_plugins['yit-contact-form'] = __( 'YIT Contact Form', 'ypop' );
}

if ( function_exists( 'wpcf7_contact_form' ) ) {
    $active_plugins['contact-form-7'] = __( 'Contact Form 7', 'ypop' );
}


if ( !empty( $active_plugins ) || function_exists( 'YIT_Contact_Form' ) || function_exists( 'wpcf7_contact_form' ) ) {

    $array_form['form-type'] = array(
        'label' => __( 'Request form', 'ypop' ),
        'desc' => __( 'Choose one. You can also add forms from YIT Contact Form or Contact Form 7 that must be installed and activated.', 'ypop' ),
        'type' => 'select',
        'options' => $active_plugins,
        'std' => 'none',
    );

    $array_form['form-contact-form-7'] = array(
        'label' => __( 'Contact form 7', 'ypop' ),
        'desc' => __( 'Choose the form to display', 'ypop' ),
        'type' => 'select',
        'options' => yith_ypop_wpcf7_get_contact_forms(),
        'std' => '',
        'deps'     => array(
            'ids' => '_form-type',
            'values' => 'contact-form-7'
        )

    );

    $array_form['form-yit-contact-form'] = array(
        'label' => __( 'YIT Contact Form', 'ypop' ),
        'desc' => __( 'Choose the form to display', 'ypop' ),
        'type' => 'select',
        'options' => yith_ypop_get_contact_forms(),
        'std' => '',
        'deps'     => array(
            'ids' => '_form-type',
            'values' => 'yit-contact-form'
        )
    );



} else {

    $no_form_plugin     =  __( 'To use this feature, YIT Contact Form or Contact Form 7 must be installed and activated.', 'ypop' );

}

$type_of_content = array(
    'text'       => __( 'Text', 'ypop' ),
    'newsletter' => __( 'Newsletter', 'ypop' ),
    'form'       => __( 'Form', 'ypop' ),
    'social'     => __( 'Social network', 'ypop' ),
);

if ( function_exists( 'WC' ) ) {
    $type_of_content['woocommerce'] = __( 'WooCommerce', 'ypop' );
}

$integration_types =  YITH_Popup_Newsletter()->get_integration();
$options = array(
    'label'    => __( 'Popup Settings', 'ypop' ),
    'pages'    => 'yith_popup',
    'context'  => 'normal', //('normal', 'advanced', or 'side')
    'priority' => 'default',
    'tabs' => array(
        /*************************************
         * CONTENT TAB
         *************************************/
        'content'       => array(
            'label'  => __( 'Content', 'ypop' ),
            'fields' => apply_filters( 'ypop_content_metabox', array(

                /*************************************
                 * GENERAL OPTIONS
                 *************************************/
                'enable_popup'   => array(
                    'label'   => __( 'Enable popup', 'ypop' ),
                    'desc'    => '',
                    'type'    => 'onoff',
                    'std'     => 'yes'

                ),
                'content_type'   => array(
                    'label'   => __( 'Content type', 'ypop' ),
                    'desc'    => __( 'Select the type of the content', 'ypop' ),
                    'type'    => 'select',
                    'std'     => 'newsletter',
                    'options' => $type_of_content
                ),

                /*************************************
                 * THEME 1 CONTENT
                 *************************************/
                'theme1_header'         => array(
                    'label' => __( 'Header', 'ypop' ),
                    'type'  => 'text',
                    'desc'  => __( 'Add the header content of the popup', 'ypop' ),
                    'std'   => __( 'SIGN UP TO OUR NEWSLETTER AND SAVE 25% OFF FOR YOUR NEXT PURCHASE', 'ypop' ),
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme1',
                    )
                ),
                'theme1_content'        => array(
                    'label' => __( 'Content', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the content of the popup', 'ypop' ),
                    'std'   => '<h3>Increase more than 500% of Email Subscribers!</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis viverra, urna vitae vehicula congue, purus nibh vestibulum lacus, sit amet tristique ante odio.</p>',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme1',
                    )
                ),
                'theme1_footer_content' => array(
                    'label' => __( 'Footer content', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the footer of the popup', 'ypop' ),
                    'std'   => '<img src="' . YITH_YPOP_TEMPLATE_URL . '/themes/theme1/images/icon-lock.png"> Your Information will never be shared with any third party.',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme1',
                    )
                ),

                /*************************************
                 * THEME 2 CONTENT
                 *************************************/
                'theme2_header_content' => array(
                    'label' => __( 'Header content', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the header content of the popup', 'ypop' ),
                    'std'   => '<h2 style="text-align: center;"><span style="color: #306582;">Get it NOW!</span></h2>
<p style="text-align: center;">Increase more than 700% of Email Subscribers!</p>',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_left_content'   => array(
                    'label' => __( 'Left content', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the left content of the popup', 'ypop' ),
                    'std'   => '<img class="aligncenter" src="' . YITH_YPOP_TEMPLATE_URL . '/themes/theme2/images/1.jpg" alt="1"  />',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_right_content'  => array(
                    'label' => __( 'Right content', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the right content of the popup', 'ypop' ),
                    'std'   => '',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_footer_content' => array(
                    'label' => __( 'Footer content', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the footer of the popup', 'ypop' ),
                    'std'   => '<img src="' . YITH_YPOP_TEMPLATE_URL . '/themes/theme2/images/icon-lock.png"> Your Information will never be shared with any third party.',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),

                /*************************************
                 * THEME 3 CONTENT
                 *************************************/
                'theme3_header_title' => array(
                    'label' => __( 'Header title', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the header content of the popup', 'ypop' ),
                    'std'   => 'SUMMER<br>SALES!',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme3',
                    )
                ),
                'theme3_right_content'  => array(
                    'label' => __( 'Right content', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the right content of the popup', 'ypop' ),
                    'std'   => '',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme3',
                    )
                ),
                'theme3_footer_content' => array(
                    'label' => __( 'Footer content', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the footer content of the popup', 'ypop' ),
                    'std'   => '<img src="' . YITH_YPOP_TEMPLATE_URL . '/themes/theme3/images/icon-lock.png"> Your Information will never be shared with any third party.',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme3',
                    )
                ),

                /*************************************
                 * THEME 4 CONTENT
                 *************************************/
                'theme4_header_title'   => array(
                    'label' => __( 'Header content', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the header content of the popup', 'ypop' ),
                    'std'   => '<h2>ARE YOU READY?<br>GET IT NOW!</h2><p>Increase more than 500% of Email Subscribers!</p>',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme4',
                    )
                ),
                'theme4_footer_content' => array(
                    'label' => __( 'Footer content', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the footer content of the popup', 'ypop' ),
                    'std'   => '',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme4',
                    )
                ),

                /*************************************
                 * THEME 5 CONTENT
                 *************************************/
                'theme5_header'         => array(
                    'label' => __( 'Header', 'ypop' ),
                    'type'  => 'text',
                    'desc'  => __( 'Add the header content of the popup', 'ypop' ),
                    'std'   => __( 'GREAT DISCOUNT ON MAKEUP!', 'ypop' ),
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme5',
                    )
                ),
                'theme5_left_content'   => array(
                    'label' => __( 'Left content', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the left content of the popup', 'ypop' ),
                    'std'   => '<img class="alignleft" src="' . YITH_YPOP_TEMPLATE_URL . '/themes/theme5/images/picture.jpg" />',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme5',
                    )
                ),
                'theme5_right_content'  => array(
                    'label' => __( 'Right content', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the right content of the popup', 'ypop' ),
                    'std'   => __( '<strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam placerat commodo quam, vel malesuada metus.</strong>
Suspendisse suscipit laoreet ante, ut posuere purus ultrices vitae. Etiam eget felis a diam tristique lacinia sed id lorem. Morbi sed quam ac odio ultricies condimentum non sit amet urna. ', 'ypop' ),
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme5',
                    )
                ),
                'theme5_footer_content' => array(
                    'label' => __( 'Footer content', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the footer content of the popup', 'ypop' ),
                    'std'   => '<img class="alignleft" src="' . YITH_YPOP_TEMPLATE_URL . '/themes/theme5/images/icon-lock.png"> Your Information will never be shared with any third party.',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme5',
                    )
                ),

                /*************************************
                 * THEME 6 CONTENT
                 *************************************/
                'theme6_left_content'   => array(
                    'label' => __( 'Left content', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the left content of the popup', 'ypop' ),
                    'std'   => '<img class="aligncenter" src="' . YITH_YPOP_TEMPLATE_URL . '/themes/theme6/images/header_left.png" />',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme6',
                    )
                ),
                'theme6_right_content'  => array(
                    'label' => __( 'Right content', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the right content of the popup', 'ypop' ),
                    'std'   => __( '<h2 style="color:#990000;">SPECIAL OFFER</h2><h4 style="color:#000000;">ON LEATHER RED BAG</h4>
<img class="aligncenter" src="' . YITH_YPOP_TEMPLATE_URL . '/themes/theme6/images/picture.jpg" /><p>Suspendisse suscipit laoreet ante, ut posuere purus ultrices vitae. <a href="#">Etiam eget felis a diam tristiq!</a></p>', 'ypop' ),
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme6',
                    )
                ),
                'theme6_footer_content' => array(
                    'label' => __( 'Footer content', 'ypop' ),
                    'type'  => 'textarea-editor',
                    'desc'  => __( 'Add the footer content of the popup', 'ypop' ),
                    'std'   => '',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme6',
                    )
                ),
            ) )
        ),
        /*************************************
         * LAYOUT TAB
         *************************************/
        'layout'        => array(
            'label'  => __( 'Layout', 'ypop' ),
            'fields' => apply_filters( 'ypop_layout_metabox', array(

                /*************************************
                 * THEME 1 LAYOUT
                 *************************************/

                'theme1_width'                        => array(
                    'label' => __( 'Width', 'ypop' ),
                    'type'  => 'number',
                    'desc'  => __( 'Select the width of the popup.', 'ypop' ),
                    'min'   => 10,
                    'max'   => 2000,
                    'std'   => 550,
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme1',
                    )
                ),
                'theme1_height'                       => array(
                    'label' => __( 'Height', 'ypop' ),
                    'type'  => 'number',
                    'desc'  => __( 'Select the height of the popup. Leave 0 to set it automatically', 'ypop' ),
                    'min'   => 0,
                    'max'   => 2000,
                    'std'   => 0,

                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme1',
                    )
                ),
                'theme1_body_bg_color'                => array(
                    'label' => __( 'Background color', 'ypop' ),
                    'desc'  => __( 'Select the background color of the popup', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme1',
                    )
                ),
                'theme1_header_bg_image'              => array(
                    'label' => __( 'Header background image', 'ypop' ),
                    'desc'  => __( 'Select the background image for the header', 'ypop' ),
                    'type'  => 'upload',
                    'std'   => YITH_YPOP_TEMPLATE_URL . '/themes/theme1/images/header.png',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme1',
                    )
                ),
                'theme1_header_height'                => array(
                    'label' => __( 'Header height', 'ypop' ),
                    'type'  => 'number',
                    'desc'  => __( 'Select the height of the header popup', 'ypop' ),
                    'min'   => 0,
                    'max'   => 2000,
                    'std'   => 159,
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme1',
                    )
                ),
                'theme1_header_color'                 => array(
                    'label' => __( 'Header color', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'desc'  => __( 'Select the color of the header', 'ypop' ),
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme1',
                    )
                ),
                'theme1_footer_bg_color'              => array(
                    'label' => __( 'Footer background color', 'ypop' ),
                    'desc'  => __( 'Select the background color of the footer', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#f4f4f4',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme1',
                    )
                ),
                'theme1_label_position'               => array(
                    'label'   => __( 'Position of the field title in newsletter content type', 'ypop' ),
                    'desc'    => __( 'Select the position of the label ', 'ypop' ),
                    'type'    => 'select',
                    'std'     => 'label',
                    'options' => array(
                        'label'       => __( 'Label', 'ypop' ),
                        'placeholder' => __( 'Placeholder', 'ypop' )
                    ),
                    'deps'    => array(
                        'ids'    => '_template_name',
                        'values' => 'theme1',
                    )
                ),
                'theme1_submit_button_bg_color'       => array(
                    'label' => __( 'Background color for submit button', 'ypop' ),
                    'desc'  => __( 'Select the background color for submit button', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ff8a00',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme1',
                    )
                ),
                'theme1_submit_button_bg_color_hover' => array(
                    'label' => __( 'Background color on hover for submit button', 'ypop' ),
                    'desc'  => __( 'Select the background color on hover for submit button', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#db7600',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme1',
                    )
                ),
                'theme1_submit_button_color'          => array(
                    'label' => __( 'Color for submit button', 'ypop' ),
                    'desc'  => __( 'Select the text color for submit button', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme1',
                    )
                ),
//                'theme1_submit_button_icon'           => array(
//                    'label'   => __( 'Icon for submit button', 'ypop' ),
//                    'desc'    => '',
//                    'type'    => 'iconlist',
//                    'options' => array(
//                        'select' => array(
//                            'icon'   => __( 'Theme Icon', 'ypop' ),
//                            'custom' => __( 'Custom Icon', 'ypop' ),
//                            'none'   => __( 'None', 'ypop' )
//                        ),
//                        'icon'   => ''
//                    ),
//                    'std'     => array(
//                        'select' => 'custom',
//                        'icon'   => 'retinaicon-font:retina-the-essentials-082',
//                        'custom' => YITH_YPOP_TEMPLATE_URL . '/themes/theme1/images/submit-icon.png',
//                    ),
//                    'deps'    => array(
//                        'ids'    => '_template_name',
//                        'values' => 'theme1',
//                    )
//                ),

                /*************************************
                 * THEME 2 LAYOUT
                 *************************************/

                'theme2_width'                        => array(
                    'label' => __( 'Width', 'ypop' ),
                    'type'  => 'number',
                    'desc'  => __( 'Select the width of the popup.', 'ypop' ),
                    'min'   => 0,
                    'max'   => 2000,
                    'std'   => 750,
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_height'                       => array(
                    'label' => __( 'Height', 'ypop' ),
                    'type'  => 'number',
                    'desc'  => __( 'Select the height of the popup. Leave 0 to set it automatically', 'ypop' ),
                    'min'   => 0,
                    'max'   => 2000,
                    'std'   => 670,
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_body_bg_color'                => array(
                    'label' => __( 'Background color', 'ypop' ),
                    'desc'  => __( 'Select the background color of the popup', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_content_bg_color'             => array(
                    'label' => __( 'Content background color', 'ypop' ),
                    'desc'  => __( 'Select the background color of the content', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#36c7d2',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_content_link_color'           => array(
                    'label' => __( 'Content link color', 'ypop' ),
                    'desc'  => __( 'Select the color for links', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_content_link_color_hover'     => array(
                    'label' => __( 'Content link hover color', 'ypop' ),
                    'desc'  => __( 'Select the color on hover for the link', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#306582',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_header_bg_image'              => array(
                    'label' => __( 'Header background image', 'ypop' ),
                    'desc'  => __( 'Select the background image for the header', 'ypop' ),
                    'type'  => 'upload',
                    'std'   => '',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_header_bg_color'              => array(
                    'label' => __( 'Header background color', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'desc'  => __( 'Select the color of the header', 'ypop' ),
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_header_height'                => array(
                    'label' => __( 'Header height', 'ypop' ),
                    'type'  => 'number',
                    'desc'  => __( 'Select the height of the header', 'ypop' ),
                    'min'   => 0,
                    'max'   => 2000,
                    'std'   => 0,
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_header_color'                 => array(
                    'label' => __( 'Header color', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#484848',
                    'desc'  => __( 'Select the color of the header', 'ypop' ),
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_header_border_bottom_color'   => array(
                    'label' => __( 'Header border color', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#e3e3e3',
                    'desc'  => __( 'Select the border color of the header', 'ypop' ),
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_footer_bg_color'              => array(
                    'label' => __( 'Footer background color', 'ypop' ),
                    'desc'  => __( 'Select the background color of the footer', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_label_position'               => array(
                    'label'   => __( 'Position of the field title in newsletter', 'ypop' ),
                    'desc'    => __( 'Select the position of the label ', 'ypop' ),
                    'type'    => 'select',
                    'std'     => 'placeholder',
                    'options' => array(
                        'label'       => __( 'Label', 'ypop' ),
                        'placeholder' => __( 'Placeholder', 'ypop' )
                    ),
                    'deps'    => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_submit_button_bg_color'       => array(
                    'label' => __( 'Background color for submit button', 'ypop' ),
                    'desc'  => __( 'Select the background color for submit button', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#eb5949',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_submit_button_bg_color_hover' => array(
                    'label' => __( 'Background color on hover for submit button', 'ypop' ),
                    'desc'  => __( 'Select the background color on hover for submit button', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#a01000',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
                'theme2_submit_button_color'          => array(
                    'label' => __( 'Color for submit button', 'ypop' ),
                    'desc'  => __( 'Select the text color for submit button', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme2',
                    )
                ),
//                'theme2_submit_button_icon'           => array(
//                    'label'   => __( 'Icon for submit button', 'ypop' ),
//                    'desc'    => '',
//                    'type'    => 'iconlist',
//                    'options' => array(
//                        'select' => array(
//                            'icon'   => __( 'Theme icon', 'ypop' ),
//                            'custom' => __( 'Custom icon', 'ypop' ),
//                            'none'   => __( 'None', 'ypop' )
//                        ),
//                        'icon'   => ''
//                    ),
//                    'std'     => array(
//                        'select' => 'custom',
//                        'icon'   => 'retinaicon-font:retina-the-essentials-082',
//                        'custom' => YITH_YPOP_TEMPLATE_URL . '/themes/theme3/images/submit-icon.png',
//                    ),
//                    'deps'    => array(
//                        'ids'    => '_template_name',
//                        'values' => 'theme2',
//                    )
//                ),

                /*************************************
                 * THEME 3 LAYOUT
                 *************************************/

                'theme3_width'                        => array(
                    'label' => __( 'Width', 'ypop' ),
                    'type'  => 'number',
                    'desc'  => __( 'Select the width of the popup.', 'ypop' ),
                    'min'   => 0,
                    'max'   => 2000,
                    'std'   => 750,
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme3',
                    )
                ),
                'theme3_height'                       => array(
                    'label' => __( 'Height', 'ypop' ),
                    'type'  => 'number',
                    'desc'  => __( 'Select the height of the popup. Leave 0 to set it automatically', 'ypop' ),
                    'min'   => 0,
                    'max'   => 2000,
                    'std'   => 510,
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme3',
                    )
                ),
                'theme3_bg_image'                     => array(
                    'label' => __( 'Background image', 'ypop' ),
                    'desc'  => __( 'Select the background image', 'ypop' ),
                    'type'  => 'upload',
                    'std'   => YITH_YPOP_TEMPLATE_URL . '/themes/theme3/images/bg.jpg',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme3',
                    )
                ),
                'theme3_body_bg_color'                => array(
                    'label' => __( 'Background color', 'ypop' ),
                    'desc'  => __( 'Select the background color of the popup', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#516fc8',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme3',
                    )
                ),
                'theme3_content_link_color'           => array(
                    'label' => __( 'Content link color', 'ypop' ),
                    'desc'  => __( 'Select the color for links', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme3',
                    )
                ),
                'theme3_content_link_color_hover'     => array(
                    'label' => __( 'Content link hover color', 'ypop' ),
                    'desc'  => __( 'Select the color on hover for the links', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ff6b43',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme3',
                    )
                ),
                'theme3_text_color'                   => array(
                    'label' => __( 'Text color', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#fff',
                    'desc'  => __( 'Select the color of the text', 'ypop' ),
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme3',
                    )
                ),
                'theme3_label_position'               => array(
                    'label'   => __( 'Position of the field title in newsletter', 'ypop' ),
                    'desc'    => __( 'Select the position of the label', 'ypop' ),
                    'type'    => 'select',
                    'std'     => 'placeholder',
                    'options' => array(
                        'label'       => __( 'Label', 'ypop' ),
                        'placeholder' => __( 'Placeholder', 'ypop' )
                    ),
                    'deps'    => array(
                        'ids'    => '_template_name',
                        'values' => 'theme3',
                    )
                ),
                'theme3_submit_button_bg_color'       => array(
                    'label' => __( 'Background color for submit button', 'ypop' ),
                    'desc'  => __( 'Select the background color for submit button', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ff6b43',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme3',
                    )
                ),
                'theme3_submit_button_bg_color_hover' => array(
                    'label' => __( 'Background color on hover for submit button', 'ypop' ),
                    'desc'  => __( 'Select the background color on hover for submit button', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ff4614',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme3',
                    )
                ),
                'theme3_submit_button_color'          => array(
                    'label' => __( 'Color for submit button', 'ypop' ),
                    'desc'  => __( 'Select the text color for submit button', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme3',
                    )
                ),
//                'theme3_submit_button_icon'           => array(
//                    'label'   => __( 'Icon for submit button', 'ypop' ),
//                    'desc'    => '',
//                    'type'    => 'iconlist',
//                    'options' => array(
//                        'select' => array(
//                            'icon'   => __( 'Theme icon', 'ypop' ),
//                            'custom' => __( 'Custom icon', 'ypop' ),
//                            'none'   => __( 'None', 'ypop' )
//                        ),
//                        'icon'   => ''
//                    ),
//                    'std'     => array(
//                        'select' => 'none',
//                        'icon'   => 'retinaicon-font:retina-the-essentials-082',
//                        'custom' => YITH_YPOP_TEMPLATE_URL . '/themes/theme3/images/submit-icon.png',
//                    ),
//                    'deps'    => array(
//                        'ids'    => '_template_name',
//                        'values' => 'theme3',
//                    )
//                ),

                /*************************************
                 * THEME 4 LAYOUT
                 *************************************/

                'theme4_width'                        => array(
                    'label' => __( 'Width', 'ypop' ),
                    'type'  => 'number',
                    'desc'  => __( 'Select the width of the popup.', 'ypop' ),
                    'min'   => 0,
                    'max'   => 2000,
                    'std'   => 750,
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme4',
                    )
                ),
                'theme4_height'                       => array(
                    'label' => __( 'Height', 'ypop' ),
                    'type'  => 'number',
                    'desc'  => __( 'Select the height of the popup. Leave 0 to set it automatically', 'ypop' ),
                    'min'   => 0,
                    'max'   => 2000,
                    'std'   => 380,
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme4',
                    )
                ),
                'theme4_bg_image'                     => array(
                    'label' => __( 'Background image', 'ypop' ),
                    'desc'  => __( 'Select the background image for the header', 'ypop' ),
                    'type'  => 'upload',
                    'std'   => YITH_YPOP_TEMPLATE_URL . '/themes/theme4/images/bg.jpg',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme4',
                    )
                ),
                'theme4_body_bg_color'                => array(
                    'label' => __( 'Background color', 'ypop' ),
                    'desc'  => __( 'Select the background color of the popup', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme4',
                    )
                ),
                'theme4_content_link_color'           => array(
                    'label' => __( 'Content link color', 'ypop' ),
                    'desc'  => __( 'Select the color for the links', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme4',
                    )
                ),
                'theme4_content_link_color_hover'     => array(
                    'label' => __( 'Content link hover color', 'ypop' ),
                    'desc'  => __( 'Select the color on hover for links', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ff4200',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme4',
                    )
                ),
                'theme4_text_color'                   => array(
                    'label' => __( 'Text color', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'desc'  => __( 'Select the color of the text', 'ypop' ),
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme4',
                    )
                ),
                'theme4_label_position'               => array(
                    'label'   => __( 'Position of the field title in newsletter', 'ypop' ),
                    'desc'    => __( 'Select the position of the label', 'ypop' ),
                    'type'    => 'select',
                    'std'     => 'placeholder',
                    'options' => array(
                        'label'       => __( 'Label', 'ypop' ),
                        'placeholder' => __( 'Placeholder', 'ypop' )
                    ),
                    'deps'    => array(
                        'ids'    => '_template_name',
                        'values' => 'theme4',
                    )
                ),
                'theme4_submit_button_bg_color'       => array(
                    'label' => __( 'Background color for submit button', 'ypop' ),
                    'desc'  => __( 'Select the background color for submit button', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ff4200',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme4',
                    )
                ),
                'theme4_submit_button_bg_color_hover' => array(
                    'label' => __( 'Background color on hoverfor submit button', 'ypop' ),
                    'desc'  => __( 'Select the background color on hover for submit button', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#912600',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme4',
                    )
                ),
                'theme4_submit_button_color'          => array(
                    'label' => __( 'Color for submit button', 'ypop' ),
                    'desc'  => __( 'Select the text color for submit button', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme4',
                    )
                ),
//                'theme4_submit_button_icon'           => array(
//                    'label'   => __( 'Icon for submit button', 'ypop' ),
//                    'desc'    => '',
//                    'type'    => 'iconlist',
//                    'options' => array(
//                        'select' => array(
//                            'icon'   => __( 'Theme icon', 'ypop' ),
//                            'custom' => __( 'Custom icon', 'ypop' ),
//                            'none'   => __( 'None', 'ypop' )
//                        ),
//                        'icon'   => ''
//                    ),
//                    'std'     => array(
//                        'select' => 'none',
//                        'icon'   => 'retinaicon-font:retina-the-essentials-082',
//                        'custom' => YITH_YPOP_TEMPLATE_URL . '/themes/theme4/images/submit-icon.png',
//                    ),
//                    'deps'    => array(
//                        'ids'    => '_template_name',
//                        'values' => 'theme4',
//                    )
//                ),

                /*************************************
                 * THEME 5 LAYOUT
                 *************************************/

                'theme5_width'                        => array(
                    'label' => __( 'Width', 'ypop' ),
                    'type'  => 'number',
                    'desc'  => __( 'Select the width of the popup.', 'ypop' ),
                    'min'   => 0,
                    'max'   => 2000,
                    'std'   => 750,
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme5',
                    )
                ),
                'theme5_height'                       => array(
                    'label' => __( 'Height', 'ypop' ),
                    'type'  => 'number',
                    'desc'  => __( 'Select the height of the popup. Leave 0 to set it automatically', 'ypop' ),
                    'min'   => 0,
                    'max'   => 2000,
                    'std'   => 525,
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme5',
                    )
                ),
                'theme5_body_bg_color'                => array(
                    'label' => __( 'Background color', 'ypop' ),
                    'desc'  => __( 'Select the background color of the popup', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme5',
                    )
                ),
				'theme5_border_color'                 => array(
					'label' => __( 'Border color', 'ypop' ),
					'type'  => 'colorpicker',
					'std'   => '#b68e67',
					'desc'  => __( 'Select the color of borders', 'ypop' ),
					'deps'  => array(
						'ids'    => '_template_name',
						'values' => 'theme5',
					)
				),

                'theme5_content_link_color'           => array(
                    'label' => __( 'Content link color', 'ypop' ),
                    'desc'  => __( 'Select the color for links', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#b68e67',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme5',
                    )
                ),
                'theme5_content_link_color_hover'     => array(
                    'label' => __( 'Content link hover color', 'ypop' ),
                    'desc'  => __( 'Select the color on hover for the links', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#b57434',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme5',
                    )
                ),
                'theme5_text_color'                   => array(
                    'label' => __( 'Text color', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#5c5c5c',
                    'desc'  => __( 'Select the color of the header', 'ypop' ),
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme5',
                    )
                ),
                'theme5_header_bg_image'              => array(
                    'label' => __( 'Header background image', 'ypop' ),
                    'desc'  => __( 'Select the background image for the header', 'ypop' ),
                    'type'  => 'upload',
                    'std'   => '',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme5',
                    )
                ),
                'theme5_header_bg_color'              => array(
                    'label' => __( 'Header background color', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'desc'  => __( 'Select the color of the header', 'ypop' ),
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme5',
                    )
                ),

                'theme5_label_position'               => array(
                    'label'   => __( 'Position of the field title in newsletter', 'ypop' ),
                    'desc'    => __( 'Select the position of the label', 'ypop' ),
                    'type'    => 'select',
                    'std'     => 'placeholder',
                    'options' => array(
                        'label'       => __( 'Label', 'ypop' ),
                        'placeholder' => __( 'Placeholder', 'ypop' )
                    ),
                    'deps'    => array(
                        'ids'    => '_template_name',
                        'values' => 'theme5',
                    )
                ),
                'theme5_submit_button_bg_color'       => array(
                    'label' => __( 'Background color for submit button', 'ypop' ),
                    'desc'  => __( 'Select the background color for submit button', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#b68e67',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme5',
                    )
                ),
                'theme5_submit_button_bg_color_hover' => array(
                    'label' => __( 'Background color on hover for submit button', 'ypop' ),
                    'desc'  => __( 'Select the background color on hover for submit button', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#9e7b5a',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme5',
                    )
                ),
                'theme5_submit_button_color'          => array(
                    'label' => __( 'Color for submit button', 'ypop' ),
                    'desc'  => __( 'Select the text color for submit button', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ffffff',
                    'deps'  => array(
                        'ids'    => '_template_name',
                        'values' => 'theme5',
                    )
                ),
//                'theme5_submit_button_icon'           => array(
//                    'label'   => __( 'Icon for submit button', 'ypop' ),
//                    'desc'    => '',
//                    'type'    => 'iconlist',
//                    'options' => array(
//                        'select' => array(
//                            'icon'   => __( 'Theme icon', 'ypop' ),
//                            'custom' => __( 'Custom icon', 'ypop' ),
//                            'none'   => __( 'None', 'ypop' )
//                        ),
//                        'icon'   => ''
//                    ),
//                    'std'     => array(
//                        'select' => 'custom',
//                        'icon'   => 'retinaicon-font:retina-the-essentials-082',
//                        'custom' => YITH_YPOP_TEMPLATE_URL . '/themes/theme5/images/submit-icon.png',
//                    ),
//                    'deps'    => array(
//                        'ids'    => '_template_name',
//                        'values' => 'theme5',
//                    )
//                ),

				/*************************************
				 * THEME 6 LAYOUT
				 *************************************/
				'theme6_width'                        => array(
					'label' => __( 'Width', 'ypop' ),
					'type'  => 'number',
					'desc'  => __( 'Select the width of the popup.', 'ypop' ),
					'min'   => 0,
					'max'   => 2000,
					'std'   => 750,
					'deps'  => array(
						'ids'    => '_template_name',
						'values' => 'theme6',
					)
				),
				'theme6_height'                       => array(
					'label' => __( 'Height', 'ypop' ),
					'type'  => 'number',
					'desc'  => __( 'Select the height of the popup. Leave 0 to set it automatically', 'ypop' ),
					'min'   => 0,
					'max'   => 2000,
					'std'   => 500,
					'deps'  => array(
						'ids'    => '_template_name',
						'values' => 'theme6',
					)
				),

				'theme6_body_bg_color_left'           => array(
					'label' => __( 'Background color on the left', 'ypop' ),
					'desc'  => __( 'Select the background color of the left side', 'ypop' ),
					'type'  => 'colorpicker',
					'std'   => '#990000',
					'deps'  => array(
						'ids'    => '_template_name',
						'values' => 'theme6',
					)
				),
				'theme6_content_left_link_color'           => array(
					'label' => __( 'Content link color on the left side', 'ypop' ),
					'desc'  => __( 'Select the color for the link on the left side', 'ypop' ),
					'type'  => 'colorpicker',
					'std'   => '#ffffff',
					'deps'  => array(
						'ids'    => '_template_name',
						'values' => 'theme6',
					)
				),
				'theme6_content_left_link_color_hover'     => array(
					'label' => __( 'Content link hover color on the left side ', 'ypop' ),
					'desc'  => __( 'Select the color for the link on hover on the left side', 'ypop' ),
					'type'  => 'colorpicker',
					'std'   => '#ffffff',
					'deps'  => array(
						'ids'    => '_template_name',
						'values' => 'theme6',
					)
				),
				'theme6_left_text_color'                   => array(
					'label' => __( 'Text color on the left side', 'ypop' ),
					'type'  => 'colorpicker',
					'std'   => '#ffffff',
					'desc'  => __( 'Select the color of the text on the left side', 'ypop' ),
					'deps'  => array(
						'ids'    => '_template_name',
						'values' => 'theme6',
					)
				),

				'theme6_body_bg_color_right'          => array(
					'label' => __( 'Background color on the right', 'ypop' ),
					'desc'  => __( 'Select the background color on the right side', 'ypop' ),
					'type'  => 'colorpicker',
					'std'   => '#ffffff',
					'deps'  => array(
						'ids'    => '_template_name',
						'values' => 'theme6',
					)
				),
				'theme6_content_right_link_color'           => array(
					'label' => __( 'Content link color on the right side', 'ypop' ),
					'desc'  => __( 'Select the color for the link on the right side', 'ypop' ),
					'type'  => 'colorpicker',
					'std'   => '#990000',
					'deps'  => array(
						'ids'    => '_template_name',
						'values' => 'theme6',
					)
				),
				'theme6_content_right_link_color_hover'     => array(
					'label' => __( 'Content link hover color on the right side', 'ypop' ),
					'desc'  => __( 'Select the color for the link on hover on the right side', 'ypop' ),
					'type'  => 'colorpicker',
					'std'   => '#990000',
					'deps'  => array(
						'ids'    => '_template_name',
						'values' => 'theme6',
					)
				),
				'theme6_right_text_color'                   => array(
					'label' => __( 'Text color on the right side', 'ypop' ),
					'type'  => 'colorpicker',
					'std'   => '#000000',
					'desc'  => __( 'Select the color of the text on the right side', 'ypop' ),
					'deps'  => array(
						'ids'    => '_template_name',
						'values' => 'theme6',
					)
				),

				'theme6_label_position'               => array(
					'label'   => __( 'Position of the field title in newsletter', 'ypop' ),
					'desc'    => __( 'Select the position of the title', 'ypop' ),
					'type'    => 'select',
					'std'     => 'placeholder',
					'options' => array(
						'label'       => __( 'Label', 'ypop' ),
						'placeholder' => __( 'Placeholder', 'ypop' )
					),
					'deps'    => array(
						'ids'    => '_template_name',
						'values' => 'theme6',
					)
				),

				'theme6_submit_button_bg_color'       => array(
					'label' => __( 'Background color for submit button', 'ypop' ),
					'desc'  => __( 'Select the background color for submit button', 'ypop' ),
					'type'  => 'colorpicker',
					'std'   => '#000000',
					'deps'  => array(
						'ids'    => '_template_name',
						'values' => 'theme6',
					)
				),
				'theme6_submit_button_bg_color_hover' => array(
					'label' => __( 'Background color on hover for submit button', 'ypop' ),
					'desc'  => __( 'Select the background color on hover for submit button', 'ypop' ),
					'type'  => 'colorpicker',
					'std'   => '#000000',
					'deps'  => array(
						'ids'    => '_template_name',
						'values' => 'theme6',
					)
				),
				'theme6_submit_button_color'          => array(
					'label' => __( 'Color for submit button', 'ypop' ),
					'desc'  => __( 'Select the text color for submit button', 'ypop' ),
					'type'  => 'colorpicker',
					'std'   => '#ffffff',
					'deps'  => array(
						'ids'    => '_template_name',
						'values' => 'theme6',
					)
				),

				'submit_button_icon'           => array(
					'label'   => __( 'Icon for submit button', 'ypop' ),
					'desc'    => '',
					'type'    => 'iconlist',
					'options' => array(
						'select' => array(
							'icon'   => __( 'Theme icon', 'ypop' ),
							'custom' => __( 'Custom icon', 'ypop' ),
							'none'   => __( 'None', 'ypop' )
						),
						'icon'   => ''
					),
					'std'     => array(
						'select' => 'none',
						'icon'   => 'retinaicon-font:retina-the-essentials-082',
						'custom' => YITH_YPOP_TEMPLATE_URL . '/themes/theme1/images/submit-icon.png',
					)
				),
                /*************************************
                 * COMMON LAYOUT OPTIONS
                 *************************************/
                'checkzone_bg_color'       => array(
                    'label' => __( 'Background color for the hiding text area', 'ypop' ),
                    'desc'  => __( 'Select the background color for the hiding text area', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => 'transparent'
                ),
                'checkzone_text_color'       => array(
                    'label' => __( 'Text color for the hiding text', 'ypop' ),
                    'desc'  => __( 'Select the text color for the hiding text', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#333333'
                ),


			) )
        ),
        'display'       => array(
            'label'  => __( 'Display Settings', 'ypop' ),
            'fields' => apply_filters( 'ypop_display_metabox', array(
                'position' => array(
                    'label' => __( 'Position', 'ypop' ),
                    'desc'  => '',
                    'type'  => 'select',
                    'options' => array(
                        'center'       => __( 'Center', 'ypop' ),
                        'left-top'     => __( 'Left Top', 'ypop' ),
                        'left-bottom'  => __( 'Left Bottom', 'ypop' ),
                        'right-top'    => __( 'Right Top', 'ypop' ),
                        'right-bottom' => __( 'Right Bottom', 'ypop' ),
                    ),
                    'std' => 'center'
                ),
                'sep'             => array(
                    'type' => 'sep'
                ),
                'overlay_opacity' => array(
                    'label' => __( 'Overlay opacity', 'ypop' ),
                    'desc'  => '',
                    'type'  => 'slider',
                    'min'   => 0,
                    'max'   => 100,
                    'step'  => 10,
                    'std'   => 50
                ),
                'overlay_color'   => array(
                    'label' => __( 'Overlay color', 'ypop' ),
                    'desc'  => '',
                    'type'  => 'colorpicker',
                    'std'   => '#000000',
                ),
                'sep1'             => array(
                    'type' => 'sep'
                ),
                'when_display' => array(
                    'label' => __( 'Choose when displaying the popup', 'ypop' ),
                    'desc'  => '',
                    'type'  => 'select',
                    'options' => array(
                        'load'           => __( 'As soon as the page has been loaded', 'ypop' ),
                        'leave-viewport' => __( 'When mouse leaves the browser viewport (Not available on mobile devices)', 'ypop' ),
                        'leave-page'     => __( 'When users try to leave the page.', 'ypop' ),
                        'external-link'  => __( 'When users click an external link', 'ypop' ),
                    ),
                    'std'   => 'load',
                ),

                'leave_page_message' => array(
                    'label' => __( 'Alert message', 'ypop' ),
                    'desc'  => '',
                    'type'  => 'text',
                    'std'   =>  __( 'Don\'t leave this page! A special offer is waiting for you!', 'ypop' ),
                    'deps'  => array(
                        'ids'    => '_when_display',
                        'values' => 'leave-page'
                    )
                ),

                'delay' => array(
                    'label' => __( 'Delay time before the popup appears', 'ypop' ),
                    'desc'  => __( 'in seconds', 'ypop'),
                    'type'  => 'text',
                    'std'   => '0',

                ),


            ) )
        ),
        'close'         => array(
            'label'  => __( 'Closing button', 'ypop' ),
            'fields' => apply_filters( 'ypop_close_metabox', array(
                'close_button_icon'             => array(
                    'label'   => __( 'Closing button icon', 'ypop' ),
                    'desc'    => __( 'Select the icon for closing button', 'ypop' ),
                    'type'    => 'select',
                    'options' => array(
                        'close1' => __( 'Closing button 1', 'ypop' ),
                        'close2' => __( 'Closing button 2', 'ypop' ),
                        'close3' => __( 'Closing button 3', 'ypop' ),
						'close4' => __( 'Closing button 4', 'ypop' ),
                        'custom' => __( 'Custom image', 'ypop' )
                    ),
                    'std'     => 'close1',
                ),
                'close_button_icon_preview'     => array(
                    'label' => '',
                    'type'  => 'preview',
                    'std'   => YITH_YPOP_ASSETS_URL . '/images/close-buttons/preview/close1.png',
                    'deps'  => array(
                        'ids'    => '_close_button_icon',
                        'values' => 'close1',
                    )
                ),
                'close_button_icon_preview2'    => array(
                    'label' => '',
                    'type'  => 'preview',
                    'std'   => YITH_YPOP_ASSETS_URL . '/images/close-buttons/preview/close2.png',
                    'deps'  => array(
                        'ids'    => '_close_button_icon',
                        'values' => 'close2',
                    )
                ),
                'close_button_icon_preview3'    => array(
                    'label' => '',
                    'type'  => 'preview',
                    'std'   => YITH_YPOP_ASSETS_URL . '/images/close-buttons/preview/close3.png',
                    'deps'  => array(
                        'ids'    => '_close_button_icon',
                        'values' => 'close3',
                    )
                ),
				'close_button_icon_preview4'    => array(
					'label' => '',
					'type'  => 'preview',
					'std'   => YITH_YPOP_ASSETS_URL . '/images/close-buttons/preview/close4.png',
					'deps'  => array(
						'ids'    => '_close_button_icon',
						'values' => 'close4',
					)
				),


                'close_button_custom_icon'      => array(
                    'label' => __( 'Closing button custom icon', 'ypop' ),
                    'desc'  => __( 'Upload the icon for closing button', 'ypop' ),
                    'type'  => 'upload',
                    'std'   => '',
                    'deps'  => array(
                        'ids'    => '_close_button_icon',
                        'values' => 'custom',
                    )
                ),

                'close_button_background_color' => array(
                    'label' => __( 'Closing button background color', 'ypop' ),
                    'desc'  => __( 'Select the background color of the closing button', 'ypop' ),
                    'type'  => 'colorpicker',
                    'std'   => '#ff8a00',
                ),

            ) )
        ),
        'customization' => array(
            'label'  => __( 'Customization', 'ypop' ),
            'fields' => apply_filters( 'ypop_customization_metabox', array(
                'ypop_css'        => array(
                    'label' => __( 'CSS', 'ypop' ),
                    'desc'  => '',
                    'type'  => 'textarea',
                    'std'   => '',
                ),
                'sep'             => array(
                    'type' => 'sep'
                ),
                'ypop_javascript' => array(
                    'label' => __( 'JavaScript', 'ypop' ),
                    'desc'  => '',
                    'type'  => 'textarea',
                    'std'   => '',
                ),
            ) )
        ),
        'newsletter'    => apply_filters( 'yith-popup-newsletter-metabox', array(
            'label'  => __( 'Newsletter', 'ypop' ),
            'fields' => array(
                'newsletter-integration'   => array(
                    'label'   => __( 'Form integration preset', 'ypop' ),
                    'desc'    => __( 'Select what kind of newsletter service you want to use, or set a custom form.', 'ypop' ),
                    'type'    => 'select',
                    'options' => $integration_types,
                    'std'     => 'custom'
                ),

                'newsletter-action'        => array(
                    'label' => __( 'Form action', 'ypop' ),
                    'desc'  => __( 'The attribute "action" of the form.', 'ypop' ),
                    'type'  => 'text',
                    'std'   => '',
                    'deps'  => array(
                        'ids'    => '_newsletter-integration',
                        'values' => 'custom'
                    )
                ),

                'newsletter-method'        => array(
                    'label'   => __( 'Request method', 'ypop' ),
                    'desc'    => __( 'The attribute "method" of the form.', 'ypop' ),
                    'type'    => 'select',
                    'options' => array(
                        'post' => __( 'POST', 'ypop' ),
                        'get'  => __( 'GET', 'ypop' )
                    ),
                    'std'     => 'post',
                    'deps'    => array(
                        'ids'    => '_newsletter-integration',
                        'values' => 'custom'
                    )
                ),

                'newsletter-show-name'     => array(
                    'label' => __( 'Show name field', 'ypop' ),
                    'desc'  => __( 'Show the "Name" field in the newsletter', 'ypop' ),
                    'type'  => 'onoff',
                    'std'   => 'no',
                    'deps'  => array(
                        'ids'    => '_newsletter-integration',
                        'values' => 'custom'
                    )
                ),

                'newsletter-name-label'    => array(
                    'label' => __( 'Name field label', 'ypop' ),
                    'desc'  => __( 'The label for "Name" field', 'ypop' ),
                    'type'  => 'text',
                    'std'   => 'Your Name',
                    'deps'  => array(
                        'ids'    => '_newsletter-integration',
                        'values' => 'custom'
                    )
                ),

                'newsletter-name-name'     => array(
                    'label' => __( '"Name" attribute of the Name field', 'ypop' ),
                    'desc'  => __( 'The "Name" attribute of the Name field.', 'ypop' ),
                    'type'  => 'text',
                    'std'   => 'ypop_name',
                    'deps'  => array(
                        'ids'    => '_newsletter-integration',
                        'values' => 'custom'
                    )
                ),

                'newsletter-email-label'   => array(
                    'label' => __( 'Email field label', 'ypop' ),
                    'desc'  => __( 'The label for the "Email" field', 'ypop' ),
                    'type'  => 'text',
                    'std'   => 'Email',
                    'deps'  => array(
                        'ids'    => '_newsletter-integration',
                        'values' => 'custom'
                    )
                ),

                'newsletter-email-name'    => array(
                    'label' => __( '"Name" attribute for Email field', 'ypop' ),
                    'desc'  => __( 'The attribute "Name" of the email address field.', 'ypop' ),
                    'type'  => 'text',
                    'std'   => 'ypop_email',
                    'deps'  => array(
                        'ids'    => '_newsletter-integration',
                        'values' => 'custom'
                    )
                ),

                'newsletter-submit-label'  => array(
                    'label' => __( 'Submit button label', 'ypop' ),
                    'desc'  => __( 'This field is not always used. It depends on the style of the form.', 'ypop' ),
                    'type'  => 'text',
                    'std'   => 'Add Me',
                    'deps'  => array(
                        'ids'    => '_newsletter-integration',
                        'values' => 'custom'
                    )
                ),

                'newsletter-hidden-fields' => array(
                    'label' => __( 'Hidden fields', 'ypop' ),
                    'desc'  => __( 'Type here all hidden field names and values in a serial way. Example: name1=value1&name2=value2.', 'ypop' ),
                    'type'  => 'text',
                    'std'   => '',
                    'deps'  => array(
                        'ids'    => '_newsletter-integration',
                        'values' => 'custom'
                    )
                ),
            )
        ) ),
        'form'          => apply_filters( 'yith-popup-form-metabox', array(
            'label'  => __( 'Form', 'ypop' ),
            'fields' => $array_form
        ) ),
        'social'        => apply_filters( 'yith-popup-social-metabox', array(
            'label'  => __( 'Social network', 'ypop' ),
            'fields' => array(
                'social_view_icon' => array(
                    'label' => __( 'Show social network sharing as icon', 'ypop' ),
                    'desc'  => __( 'Select this option to show social networks as icon, and not as text', 'ypop' ),
                    'type'  => 'onoff',
                    'std'   => 'yes'
                ),
                'facebook_button'  => array(
                    'label' => __( 'Show Facebook button', 'ypop' ),
                    'desc'  => '',
                    'type'  => 'onoff',
                    'std'   => 'yes'
                ),
                'facebook_url'     => array(
                    'label' => __( 'Facebook like URL', 'ypop' ),
                    'desc'  => __( 'Add the url for Facebook like, leave empty for link current page', 'ypop' ),
                    'type'  => 'text',
                    'std'   => '',
                    'deps'  => array(
                        'ids'    => '_facebook_button',
                        'values' => 'yes'
                    )
                ),
                'sep'              => array(
                    'type' => 'sep'
                ),

                'twitter_button'   => array(
                    'label' => __( 'Show Twitter', 'ypop' ),
                    'desc'  => '',
                    'type'  => 'onoff',
                    'std'   => 'yes'
                ),
                'twitter_url'      => array(
                    'label' => __( 'Twitter URL', 'ypop' ),
                    'desc'  => __( 'Add the URL for Twitter, leave empty for link current page', 'ypop' ),
                    'type'  => 'text',
                    'std'   => '',
                    'deps'  => array(
                        'ids'    => '_twitter_button',
                        'values' => 'yes'
                    )
                ),
                'sep1'             => array(
                    'type' => 'sep'
                ),

                'google_button'    => array(
                    'label' => __( 'Show Google + 1 Button', 'ypop' ),
                    'desc'  => '',
                    'type'  => 'onoff',
                    'std'   => 'yes'
                ),
                'google_url'       => array(
                    'label' => __( 'Google+ URL', 'ypop' ),
                    'desc'  => __( 'Add the URL for Google+, leave empty for link current page', 'ypop' ),
                    'type'  => 'text',
                    'std'   => '',
                    'deps'  => array(
                        'ids'    => '_google_button',
                        'values' => 'yes'
                    )
                ),

                'sep2'             => array(
                    'type' => 'sep'
                ),

                'linkedin_button'  => array(
                    'label' => __( 'Show LinkedIn Button', 'ypop' ),
                    'desc'  => '',
                    'type'  => 'onoff',
                    'std'   => 'yes'
                ),
                'linkedin_url'     => array(
                    'label' => __( 'LinkedIn URL', 'ypop' ),
                    'desc'  => __( 'Add the URL for LinkedIn, leave empty for link current page', 'ypop' ),
                    'type'  => 'text',
                    'std'   => '',
                    'deps'  => array(
                        'ids'    => '_linkedin_button',
                        'values' => 'yes'
                    )
                ),


                'sep3'             => array(
                    'type' => 'sep'
                ),

                'pinterest_button' => array(
                    'label' => __( 'Show Pinterest Button', 'ypop' ),
                    'desc'  => '',
                    'type'  => 'onoff',
                    'std'   => 'yes'
                ),
                'pinterest_url'    => array(
                    'label' => __( 'Pinterest URL', 'ypop' ),
                    'desc'  => __( 'Add the URL for Pinterest, leave empty for link current page', 'ypop' ),
                    'type'  => 'text',
                    'std'   => '',
                    'deps'  => array(
                        'ids'    => '_pinterest_button',
                        'values' => 'yes'
                    )
                ),
            )
        ) )
    )
);

if ( function_exists( 'WC' ) ) {
    $woocommerce_options = array(
        'woocommerce' => array(
            'label'  => __( 'WooCommerce', 'ypop' ),
            'fields' => apply_filters( 'ypop_woocommerce_metabox', array(
                    'ypop_product_from' => array(
                        'label'   => __( 'Choose a random product to show from', 'ypop' ),
                        'type'    => 'select',
                        'desc'     => '',
                        'options' => array(
                            'product'  => __( 'A products list', 'ypop' ),
                            'category' => __( 'Categories', 'ypop' ),
                            'onsale'   => __( 'Discounted items', 'ypop' ),
                            'featured' => __( 'Featured items', 'ypop' ),
                        )
                    ),
                    'ypop_products'     => array(
                        'label'    => __( 'Select products', 'ypop' ),
                        'desc'     => '',
                        'type'     => 'ajax-products',
                        'multiple' => true,
                        'options'  => array(),
                        'std'      => array(),
                        'deps'     => array(
                            'ids'    => '_ypop_product_from',
                            'values' => 'product',
                        )
                    ),
                    'ypop_category'     => array(
                        'label'    => __( 'Select categories', 'ypop' ),
                        'desc'     => '',
                        'type'     => 'chosen',
                        'multiple' => true,
                        'options'  => ypop_get_shop_categories( false ),
                        'std'      => array(),
                        'deps'     => array(
                            'ids'    => '_ypop_product_from',
                            'values' => 'category',
                        )
                    ),

                    'show_title' => array(
                        'label' => __( 'Show name of product', 'ypop' ),
                        'desc'  => '',
                        'type'  => 'checkbox',
                        'std'   => 'yes'
                    ),


                    'show_thumbnail' => array(
                        'label' => __( 'Show thumbnail of product', 'ypop' ),
                        'desc'  => '',
                        'type'  => 'checkbox',
                        'std'   => 'yes'
                    ),

                    'show_price' => array(
                        'label' => __( 'Show price of product', 'ypop' ),
                        'desc'  => '',
                        'type'  => 'checkbox',
                        'std'   => 'yes'
                    ),

                    'show_add_to_cart' => array(
                        'label' => __( 'Show Add to Cart', 'ypop' ),
                        'desc'  => '',
                        'type'  => 'checkbox',
                        'std'   => 'yes'
                    ),
                    'redirect_after_add_to_cart'    =>  array(
                       'label'  => __( 'Redirect user', 'ypop'),
                        'desc'  => '',
                        'type'  => 'select',
                        'options'   => array( 'none'=> __('None','ypop' ),'home'=> __( 'Home', 'ypop'), 'same_page' => __( 'Current Page', 'ypop' ), 'product_page' => __( 'Product Page', 'ypop' ) ),
                        'std'   => 'home'

                    ),

                    'add_to_cart_label' => array(
                        'label' => __( '"Add to cart" Label', 'ypop' ),
                        'desc'  => '',
                        'type'  => 'text',
                        'std'   => __('Add to cart', 'ypop')
                    ),


                    'show_summary' => array(
                        'label' => __( 'Show summary', 'ypop' ),
                        'desc'  => '',
                        'type'  => 'checkbox',
                        'std'   => 'yes'
                    ),



                )
            )
        )
    );

    $options['tabs'] = array_merge( $options['tabs'], $woocommerce_options );
}

return $options;


