=== YITH WooCommerce Product Bundles ===

== Changelog ==

= 1.0.14 =

* Tweak: fixed widget bug

= 1.0.13 =

* Added: support to WooCommerce 2.5
* Tweak: fixed html price from-to

= 1.0.12 =

* Added: automatic set virtual for bundle if it contains only virtual products
* Added: support to WooCommerce 2.5 RC2
* Tweak: fixed cart item count

= 1.0.11 =

* Added: WPML compatibility

= 1.0.10 =

* Tweak: fixed tax calculation for bundles with per-price-items options enabled
* Tweak: fixed items count in cart

= 1.0.9 =

* Added: compatibility with WordPress 4.4
* Added: compatibility with WooCommerce 2.4.12
* Tweak: added icon for bundle products in admin product list
* Tweak: fixed SKU bug in bundles with variable items

= 1.0.8 =

* Added: shortcode to bundled items and add to cart button
* Tweak: fixed price calculation for bundle product with variables and discount

= 1.0.7 =

* Fixed: minor bugs

= 1.0.6 =

* Fixed: minor bugs

= 1.0.5 =

* Fixed: minor bugs

= 1.0.4 =

* Added: Support to WordPress 4.3
* Fixed: minor bugs

= 1.0.3 =

* Fixed: minor bug

= 1.0.2 =

* Added: Support to WordPress 4.2.4
* Added: Support to WooCommerce 2.4.4

= 1.0.1 =

* Added: autoupdate price on Bundle single product page
* Added: setting to hide/show bundled items in WC Reports

= 1.0.0 =

* Initial release