<?php
if ( !defined( 'ABSPATH' ) || !defined( 'YITH_WCPB_PREMIUM' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Implements features of FREE version of YITH WooCommerce Product Bundles
 *
 * @class   YITH_WCPB_Frontend_Premium
 * @package YITH WooCommerce Product Bundles
 * @since   1.0.0
 * @author  Yithemes
 */


if ( !class_exists( 'YITH_WCPB_Frontend_Premium' ) ) {
    /**
     * Frontend class.
     * The class manage all the Frontend behaviors.
     *
     * @since 1.0.0
     */
    class YITH_WCPB_Frontend_Premium extends YITH_WCPB_Frontend {

        private $check_cart_contents = false;

        /**
         * Returns single instance of the class
         *
         * @return \YITH_WCPB_Frontend_Premium
         * @since 1.0.0
         */
        public static function get_instance() {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        /**
         * Constructor
         *
         * @access public
         * @since  1.0.0
         */
        public function __construct() {
            parent::__construct();
            add_filter( 'woocommerce_cart_item_thumbnail', array( $this, 'woocommerce_cart_item_thumbnail' ), 10, 3 );
            add_filter( 'woocommerce_cart_item_visible', array( $this, 'woocommerce_cart_item_visible' ), 10, 3 );
            add_filter( 'woocommerce_widget_cart_item_visible', array( $this, 'woocommerce_cart_item_visible' ), 10, 3 );
            add_filter( 'woocommerce_cart_item_name', array( $this, 'woocommerce_cart_item_name' ), 10, 3 );

            add_filter( 'woocommerce_get_price_html', array( $this, 'woocommerce_get_price_html' ), 10, 2 );

            add_action( 'widgets_init', array( $this, 'register_widgets' ) );

            add_action( 'wp_ajax_yith_wcpb_get_bundle_total_price', array( $this, 'ajax_get_bundle_total_price' ) );
            add_action( 'wp_ajax_nopriv_yith_wcpb_get_bundle_total_price', array( $this, 'ajax_get_bundle_total_price' ) );

            add_action( 'woocommerce_after_calculate_totals', array( $this, 'woocommerce_check_cart_items' ) );
            YITH_WCPB_Shortcodes();
        }

        /**
         * before creating order with bundle product
         * edit price and tax in cart for bundle product and its items
         */
        public function woocommerce_check_cart_items() {

            if ( !is_checkout() )
                return;

            if ( $this->check_cart_contents ) {
                WC()->cart->cart_contents = $this->check_cart_contents;

                return;
            }

            $cart          = WC()->cart;
            $cart_contents = $cart->cart_contents;

            foreach ( $cart_contents as $item_key => $item ) {
                if ( isset( $item[ 'cartstamp' ] ) && isset( $item[ 'bundled_items' ] ) && isset( $item[ 'data' ] ) && ( $item[ 'data' ]->per_items_pricing ) ) {
                    // BUNDLE
                    $bundled_items = $item[ 'bundled_items' ];

                    $line_total        = 0;
                    $line_subtotal     = 0;
                    $line_tax          = 0;
                    $line_subtotal_tax = 0;
                    $line_tax_data     = array(
                        'total'    => array(),
                        'subtotal' => array(),
                    );

                    foreach ( $bundled_items as $bundled_item_key ) {
                        if ( isset( $cart_contents[ $bundled_item_key ] ) ) {
                            $bundled_item = $cart_contents[ $bundled_item_key ];
                            if ( isset( $bundled_item[ 'line_total' ] ) ) {
                                $line_total += $bundled_item[ 'line_total' ];
                                $bundled_item[ 'line_total' ] = 0;
                            }
                            if ( isset( $bundled_item[ 'line_subtotal' ] ) ) {
                                $line_subtotal += $bundled_item[ 'line_subtotal' ];
                                $bundled_item[ 'line_subtotal' ] = 0;
                            }
                            if ( isset( $bundled_item[ 'line_tax' ] ) ) {
                                $line_tax += $bundled_item[ 'line_tax' ];
                                $bundled_item[ 'line_tax' ] = 0;
                            }
                            if ( isset( $bundled_item[ 'line_subtotal_tax' ] ) ) {
                                $line_subtotal_tax += $bundled_item[ 'line_subtotal_tax' ];
                                $bundled_item[ 'line_subtotal_tax' ] = 0;
                            }
                            if ( isset( $bundled_item[ 'line_tax_data' ] ) ) {
                                $bundle_tax_data = $bundled_item[ 'line_tax_data' ];
                                foreach ( $bundle_tax_data as $type => $values ) {
                                    foreach ( $values as $t_index => $t_value ) {
                                        $line_tax_data[ $type ][ $t_index ] = isset( $line_tax_data[ $type ][ $t_index ] ) ? $line_tax_data[ $type ][ $t_index ] + $t_value : $t_value;
                                    }
                                }
                                $bundled_item[ 'line_tax_data' ] = array();
                            }
                            $cart_contents[ $bundled_item_key ] = $bundled_item;
                        }
                    }
                    $cart_contents[ $item_key ][ 'line_tax' ]          = $line_tax;
                    $cart_contents[ $item_key ][ 'line_subtotal_tax' ] = $line_subtotal_tax;
                    $cart_contents[ $item_key ][ 'line_tax_data' ]     = $line_tax_data;
                    $cart_contents[ $item_key ][ 'line_total' ]        = $line_total;
                    $cart_contents[ $item_key ][ 'line_subtotal' ]     = $line_subtotal;
                }
            }
            $this->check_cart_contents = $cart_contents;
            WC()->cart->cart_contents  = $cart_contents;
        }


        public function ajax_get_bundle_total_price() {
            if ( isset( $_POST[ 'bundle_id' ] ) ) {

                $product = wc_get_product( $_POST[ 'bundle_id' ] );
                if ( $product->product_type != 'yith_bundle' )
                    die();

                $array_qty = isset( $_POST[ 'array_qty' ] ) ? $_POST[ 'array_qty' ] : array();
                $array_opt = isset( $_POST[ 'array_opt' ] ) ? $_POST[ 'array_opt' ] : array();
                $array_var = isset( $_POST[ 'array_var' ] ) ? $_POST[ 'array_var' ] : array();

                $price = $product->get_per_item_price_tot_with_params( $array_qty, $array_opt, $array_var );

                echo apply_filters( 'yith_wcpb_ajax_get_bundle_total_price', $price );
            }
            die();
        }

        /**
         * register Widget for bundle products
         *
         * @access public
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function register_widgets() {
            register_widget( 'YITH_WCPB_Bundle_Widget' );
        }

        /**
         * hide thumbnail in cart if it's requested
         *
         * @access public
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function woocommerce_cart_item_thumbnail( $thumbnail, $cart_item, $cart_item_key ) {
            if ( !isset( $cart_item[ 'bundled_by' ] ) )
                return $thumbnail;

            $hide_thumbnail = isset( $cart_item[ 'yith_wcpb_hide_thumbnail' ] ) ? $cart_item[ 'yith_wcpb_hide_thumbnail' ] : 0;

            if ( $hide_thumbnail )
                return '';

            return $thumbnail;
        }

        /**
         * hide item in cart and cart widget if it's requested
         *
         * @access public
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function woocommerce_cart_item_visible( $value, $cart_item, $cart_item_key ) {
            if ( !isset( $cart_item[ 'bundled_by' ] ) )
                return $value;

            $hidden = isset( $cart_item[ 'yith_wcpb_hidden' ] ) ? $cart_item[ 'yith_wcpb_hidden' ] : 0;
            if ( $hidden )
                return false;

            return true;
        }

        /**
         * Modify title of bundled products
         *
         * @access public
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function woocommerce_cart_item_name( $title, $cart_item, $cart_item_key ) {
            if ( !isset( $cart_item[ 'bundled_by' ] ) )
                return $title;

            $_product = $cart_item[ 'data' ];

            $custom_title = isset( $cart_item[ 'yith_wcpb_title' ] ) ? $cart_item[ 'yith_wcpb_title' ] : $title;

            if ( $_product->is_visible() ) {
                $custom_title = '<a href="' . $_product->get_permalink( $cart_item ) . '">' . $custom_title . ' </a>';
            }

            return $custom_title;
        }

        /**
         * get template for Bundle Product add to cart in product page [PREMIUM]
         *
         * @access public
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function woocommerce_yith_bundle_add_to_cart() {
            global $product;
            $bundled_items = $product->get_bundled_items();
            wc_get_template( 'single-product/add-to-cart/yith-bundle.php', array(
                'available_variations' => $product->get_available_bundle_variations(),
                'attributes'           => $product->get_bundle_variation_attributes(),
                'selected_attributes'  => $product->get_selected_bundle_variation_attributes(),
                'bundled_items'        => $bundled_items
            ), '', YITH_WCPB_TEMPLATE_PATH . '/premium/' );
        }


        /**
         * create item data [create the cartstamp if not exist]
         *
         * @access public
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function woocommerce_add_cart_item_data( $cart_item_data, $product_id ) {
            $terms        = get_the_terms( $product_id, 'product_type' );
            $product_type = !empty( $terms ) && isset( current( $terms )->name ) ? sanitize_title( current( $terms )->name ) : 'simple';

            if ( $product_type != 'yith_bundle' ) {
                return $cart_item_data;
            }

            if ( isset( $cart_item_data[ 'cartstamp' ] ) && isset( $cart_item_data[ 'bundled_items' ] ) ) {
                return $cart_item_data;
            }

            $product = wc_get_product( $product_id );
            if ( !$product instanceof WC_Product_Yith_Bundle )
                return $cart_item_data;

            $bundled_items = $product->get_bundled_items();

            if ( empty( $bundled_items ) ) {
                return $cart_item_data;
            }

            $cartstamp = array();

            foreach ( $bundled_items as $bundled_item_id => $bundled_item ) {
                if ( !$bundled_item instanceof YITH_WC_Bundled_Item )
                    continue;

                $bundled_optional_checked = isset ( $_REQUEST[ apply_filters( 'woocommerce_product_yith_bundle_field_prefix', '', $product_id ) . 'yith_bundle_optional_' . $bundled_item_id ] ) ? true : false;
                if ( $bundled_item->is_optional() && !$bundled_optional_checked ) {
                    continue;
                }

                $id                   = $bundled_item->product_id;
                $bundled_product_type = $bundled_item->product->product_type;

                $bundled_product_quantity = isset ( $_REQUEST[ apply_filters( 'woocommerce_product_yith_bundle_field_prefix', '', $product_id ) . 'yith_bundle_quantity_' . $bundled_item_id ] ) ? absint( $_REQUEST[ apply_filters( 'woocommerce_product_yith_bundle_field_prefix', '', $product_id ) . 'yith_bundle_quantity_' . $bundled_item_id ] ) : $bundled_item->get_quantity();

                $cartstamp[ $bundled_item_id ][ 'product_id' ]     = $id;
                $cartstamp[ $bundled_item_id ][ 'type' ]           = $bundled_product_type;
                $cartstamp[ $bundled_item_id ][ 'quantity' ]       = $bundled_product_quantity;
                $cartstamp[ $bundled_item_id ][ 'hide_thumbnail' ] = $bundled_item->hide_thumbnail;
                $cartstamp[ $bundled_item_id ][ 'hidden' ]         = $bundled_item->hidden;
                $cartstamp[ $bundled_item_id ][ 'title' ]          = $bundled_item->title;
                $cartstamp[ $bundled_item_id ][ 'discount' ]       = $bundled_item->discount;

                // VARIABLE 
                if ( $bundled_product_type === 'variable' ) {
                    if ( isset( $cart_item_data[ 'cartstamp' ][ $bundled_item_id ][ 'attributes' ] ) && isset( $_GET[ 'order_again' ] ) ) {
                        $cartstamp[ $bundled_item_id ][ 'attributes' ]   = $cart_item_data[ 'cartstamp' ][ $bundled_item_id ][ 'attributes' ];
                        $cartstamp[ $bundled_item_id ][ 'variation_id' ] = $cart_item_data[ 'cartstamp' ][ $bundled_item_id ][ 'variation_id' ];
                        continue;
                    }

                    $attr_stamp = array();
                    $attributes = ( array )maybe_unserialize( get_post_meta( $id, '_product_attributes', true ) );

                    foreach ( $attributes as $attribute ) {
                        if ( !$attribute[ 'is_variation' ] ) {
                            continue;
                        }
                        $taxonomy = 'attribute_' . sanitize_title( $attribute[ 'name' ] );

                        $value = sanitize_title( trim( stripslashes( $_REQUEST[ 'yith_bundle_' . $taxonomy . '_' . $bundled_item_id ] ) ) );

                        if ( $attribute[ 'is_taxonomy' ] ) {
                            $attr_stamp[ $taxonomy ] = $value;
                        } else {
                            // For custom attributes, get the name from the slug
                            $options = array_map( 'trim', explode( WC_DELIMITER, $attribute[ 'value' ] ) );
                            foreach ( $options as $option ) {
                                if ( sanitize_title( $option ) == $value ) {
                                    $value = $option;
                                    break;
                                }
                            }
                            $attr_stamp[ $taxonomy ] = $value;
                        }
                    }
                    $cartstamp[ $bundled_item_id ][ 'attributes' ]   = $attr_stamp;
                    $cartstamp[ $bundled_item_id ][ 'variation_id' ] = $_REQUEST[ 'yith_bundle_variation_id_' . $bundled_item_id ];
                }

                $cartstamp[ $bundled_item_id ] = apply_filters( 'woocommerce_yith_bundled_item_cart_item_identifier', $cartstamp[ $bundled_item_id ], $bundled_item_id );
            }

            $cart_item_data[ 'cartstamp' ]     = $cartstamp;
            $cart_item_data[ 'bundled_items' ] = array();

            return $cart_item_data;
        }

        /**
         * Add to cart for Product Bundle
         *
         * @access public
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function woocommerce_add_to_cart( $cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data ) {
            if ( isset( $cart_item_data[ 'cartstamp' ] ) && !isset( $cart_item_data[ 'bundled_by' ] ) ) {
                $bundled_items_cart_data = array(
                    'bundled_by' => $cart_item_key
                );

                foreach ( $cart_item_data[ 'cartstamp' ] as $bundled_item_id => $bundled_item_stamp ) {
                    $bundled_item_cart_data                               = $bundled_items_cart_data;
                    $bundled_item_cart_data[ 'bundled_item_id' ]          = $bundled_item_id;
                    $bundled_item_cart_data[ 'discount' ]                 = $bundled_item_stamp[ 'discount' ];
                    $bundled_item_cart_data[ 'yith_wcpb_hide_thumbnail' ] = $bundled_item_stamp[ 'hide_thumbnail' ];
                    $bundled_item_cart_data[ 'yith_wcpb_hidden' ]         = $bundled_item_stamp[ 'hidden' ];
                    $bundled_item_cart_data[ 'yith_wcpb_title' ]          = $bundled_item_stamp[ 'title' ];

                    $item_quantity        = $bundled_item_stamp[ 'quantity' ];
                    $i_quantity           = $item_quantity * $quantity;
                    $prod_id              = $bundled_item_stamp[ 'product_id' ];
                    $bundled_product_type = $bundled_item_stamp[ 'type' ];

                    if ( $bundled_product_type === 'simple' ) {
                        $variation_id = '';
                        $variations   = array();
                    } elseif ( $bundled_product_type === 'variable' ) {
                        $variation_id = $bundled_item_stamp[ 'variation_id' ];
                        $variations   = $bundled_item_stamp[ 'attributes' ];
                    }

                    $bundled_item_cart_key = $this->bundled_add_to_cart( $product_id, $prod_id, $i_quantity, $variation_id, $variations, $bundled_item_cart_data );

                    if ( $bundled_item_cart_key && !in_array( $bundled_item_cart_key, WC()->cart->cart_contents[ $cart_item_key ][ 'bundled_items' ] ) ) {
                        WC()->cart->cart_contents[ $cart_item_key ][ 'bundled_items' ][] = $bundled_item_cart_key;
                        WC()->cart->cart_contents[ $cart_item_key ][ 'yith_parent' ]     = $cart_item_key;
                    }
                }
            }
        }


        /**
         *
         *
         * @access public
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function woocommerce_add_cart_item( $cart_item, $cart_key ) {

            $cart_contents = WC()->cart->cart_contents;

            if ( isset( $cart_item[ 'bundled_by' ] ) ) {
                $bundle_cart_key = $cart_item[ 'bundled_by' ];
                if ( isset( $cart_contents[ $bundle_cart_key ] ) ) {
                    $parent = $cart_contents[ $bundle_cart_key ][ 'data' ];

                    if ( $parent->per_items_pricing == false ) {
                        $cart_item[ 'data' ]->price = 0;
                    } else {
                        $discount                   = $cart_item[ 'discount' ] * $cart_item[ 'data' ]->get_regular_price() / 100;
                        $cart_item[ 'data' ]->price = $cart_item[ 'data' ]->get_regular_price() - $discount;
                    }
                }
            }

            return $cart_item;
        }

        /**
         * get cart item from session
         *
         * @access public
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function woocommerce_get_cart_item_from_session( $cart_item, $item_session_values, $cart_item_key ) {
            $cart_contents = !empty( WC()->cart ) ? WC()->cart->cart_contents : '';
            if ( isset( $item_session_values[ 'bundled_items' ] ) && !empty( $item_session_values[ 'bundled_items' ] ) )
                $cart_item[ 'bundled_items' ] = $item_session_values[ 'bundled_items' ];

            if ( isset( $item_session_values[ 'cartstamp' ] ) ) {
                $cart_item[ 'cartstamp' ] = $item_session_values[ 'cartstamp' ];
            }

            if ( isset( $item_session_values[ 'bundled_by' ] ) ) {
                $cart_item[ 'bundled_by' ]      = $item_session_values[ 'bundled_by' ];
                $cart_item[ 'bundled_item_id' ] = $item_session_values[ 'bundled_item_id' ];
                $bundle_cart_key                = $cart_item[ 'bundled_by' ];

                if ( isset( $cart_contents[ $bundle_cart_key ] ) ) {
                    $parent          = $cart_contents[ $bundle_cart_key ][ 'data' ];
                    $bundled_item_id = $cart_item[ 'bundled_item_id' ];
                    if ( $parent->per_items_pricing == false ) {
                        $cart_item[ 'data' ]->price = 0;
                    } else {
                        $discount                   = isset( $cart_item[ 'discount' ] ) ? $cart_item[ 'discount' ] * $cart_item[ 'data' ]->get_regular_price() / 100 : 0;
                        $cart_item[ 'data' ]->price = $cart_item[ 'data' ]->get_regular_price() - $discount;

                    }
                }
            }

            return $cart_item;
        }


        /**
         * remove cart item price for bundled product
         *
         * @access public
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function woocommerce_cart_item_price( $price, $cart_item, $cart_item_key ) {

            if ( isset( $cart_item[ 'bundled_by' ] ) ) {
                return '';
            }

            if ( isset( $cart_item[ 'bundled_items' ] ) ) {
                if ( $cart_item[ 'data' ]->per_items_pricing == true ) {
                    $bundled_items_price = 0;

                    $bundle_quantity = intval( $cart_item[ 'quantity' ] );

                    foreach ( $cart_item[ 'bundled_items' ] as $bundled_item_key ) {

                        if ( !isset( WC()->cart->cart_contents[ $bundled_item_key ] ) ) {
                            continue;
                        }

                        $item_values = WC()->cart->cart_contents[ $bundled_item_key ];
                        $product     = $item_values[ 'data' ];

                        $item_quantity      = intval( $item_values[ 'quantity' ] / $bundle_quantity );
                        $bundled_item_price = get_option( 'woocommerce_tax_display_cart' ) === 'excl' ? $product->get_price_excluding_tax( $item_quantity ) : $product->get_price_including_tax( $item_quantity );

                        $bundled_items_price += $bundled_item_price;
                    }

                    $price = wc_price( $bundled_items_price );
                }


            }

            return $price;
        }

        /**
         * remove cart item subtotal for bundled product
         *
         * @access public
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function bundles_item_subtotal( $subtotal, $cart_item, $cart_item_key ) {

            if ( isset( $cart_item[ 'bundled_by' ] ) ) {
                return '';
            }

            if ( isset( $cart_item[ 'bundled_items' ] ) ) {

                $bundled_items_price     = 0;
                $contains_recurring_fees = false;
                $bundle_price            = get_option( 'woocommerce_tax_display_cart' ) === 'excl' ? $cart_item[ 'data' ]->get_price_excluding_tax( $cart_item[ 'quantity' ] ) : $cart_item[ 'data' ]->get_price_including_tax( $cart_item[ 'quantity' ] );

                foreach ( $cart_item[ 'bundled_items' ] as $bundled_item_key ) {

                    if ( !isset( WC()->cart->cart_contents[ $bundled_item_key ] ) ) {
                        continue;
                    }

                    $item_values = WC()->cart->cart_contents[ $bundled_item_key ];
                    $item_id     = $item_values[ 'bundled_item_id' ];
                    $product     = $item_values[ 'data' ];

                    $bundled_item_price = get_option( 'woocommerce_tax_display_cart' ) === 'excl' ? $product->get_price_excluding_tax( $item_values[ 'quantity' ] ) : $product->get_price_including_tax( $item_values[ 'quantity' ] );

                    $bundled_item = $cart_item[ 'data' ]->get_bundled_item( $item_id );

                    $bundled_items_price += $bundled_item_price;
                }

                $subtotal = $this->format_product_subtotal( $cart_item[ 'data' ], $bundle_price + $bundled_items_price );
            }


            return $subtotal;
        }

        public function format_product_subtotal( $product, $subtotal ) {

            $cart = WC()->cart;

            $taxable = $product->is_taxable();

            // Taxable
            if ( $taxable ) {

                if ( $cart->tax_display_cart == 'excl' ) {

                    $product_subtotal = wc_price( $subtotal );

                    if ( $cart->prices_include_tax && $cart->tax_total > 0 ) {
                        $product_subtotal .= ' <small class="tax_label">' . WC()->countries->ex_tax_or_vat() . '</small>';
                    }

                } else {

                    $product_subtotal = wc_price( $subtotal );

                    if ( !$cart->prices_include_tax && $cart->tax_total > 0 ) {
                        $product_subtotal .= ' <small class="tax_label">' . WC()->countries->inc_tax_or_vat() . '</small>';
                    }
                }

                // Non-taxable
            } else {
                $product_subtotal = wc_price( $subtotal );
            }

            return $product_subtotal;
        }

        public function woocommerce_get_price_html( $price, $product ) {
            if ( $product->product_type != 'yith_bundle' )
                return $price;

            if ( !$product->per_items_pricing )
                return $price;

            // - - - - PER ITEM PRICING - - - - 

            $from = $product->get_per_item_price_tot_max( true );
            $to   = $product->get_per_item_price_tot();

            if ( $from > $to ) {
                $price = $product->get_price_html_from_to( $from, $to ) . $product->get_price_suffix();

                return $price;
            }

            return wc_price( $to ) . $product->get_price_suffix();

        }

        /**
         * woocommerce Validation Bundle Product for add to cart
         *
         * @access public
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function woocommerce_add_to_cart_validation( $add_flag, $product_id, $product_quantity, $variation_id = '', $variations = array(), $cart_item_data = array() ) {
            //echo '<pre>'; var_dump($_REQUEST); echo '</pre>'; die();
            $product      = wc_get_product( $product_id );
            $product_type = $product->product_type;

            if ( $product_type == "yith_bundle" ) {
                if ( get_option( 'woocommerce_manage_stock' ) == 'yes' ) {

                    $bundled_items = $product->get_bundled_items();
                    if ( $bundled_items ) {
                        foreach ( $bundled_items as $bundled_item ) {
                            $bundled_prod = $bundled_item->get_product();

                            // if is optional -> Continue
                            $optional_checked = isset( $_REQUEST[ 'yith_bundle_optional_' . $bundled_item->item_id ] ) ? true : false;
                            if ( $bundled_item->optional && !$optional_checked )
                                continue;

                            $bundled_item_id = $bundled_item->item_id;

                            // VARIABLE
                            if ( $bundled_prod->product_type === 'variable' ) {
                                if ( isset( $cart_item_data[ 'cartstamp' ][ $bundled_item_id ][ 'variation_id' ] ) ) {

                                    $variation_id = $cart_item_data[ 'cartstamp' ][ $bundled_item_id ][ 'variation_id' ];

                                } elseif ( isset( $_REQUEST[ 'yith_bundle_variation_id_' . $bundled_item->item_id ] ) ) {

                                    $variation_id = $_REQUEST[ 'yith_bundle_variation_id_' . $bundled_item->item_id ];
                                }

                                if ( isset( $variation_id ) && is_numeric( $variation_id ) && $variation_id > 1 ) {

                                    if ( get_post_meta( $variation_id, '_price', true ) === '' ) {

                                        wc_add_notice( sprintf( __( '&quot;%1$s&quot; cannot be added to the cart. The selected variation of &quot;%2$s&quot; cannot be purchased.', 'yith-wcpb' ), get_the_title( $product_id ), $bundled_item->product->get_title() ), 'error' );

                                        return false;
                                    }

                                    $b_variation = $bundled_prod->get_child( $variation_id );
                                    //echo '<pre>'; var_dump($b_variation->has_enough_stock( intval( $bundled_item->get_quantity() ) * intval( $product_quantity ) )); echo '</pre>';
                                    // Purchasable
                                    if ( !$b_variation->is_purchasable() ) {
                                        wc_add_notice( sprintf( __( '&quot;%1$s&quot; cannot be added to the cart because &quot;%2$s&quot; cannot be purchased at the moment.', 'yith-wcpb' ), get_the_title( $product_id ), $bundled_item->get_raw_title() ), 'error' );

                                        return false;
                                    }

                                    if ( !$b_variation->has_enough_stock( intval( $bundled_item->get_quantity() ) * intval( $product_quantity ) ) ) {
                                        wc_add_notice( __( 'You cannot add this quantity of items, because there are not enough in stock.', 'yith-wcpb' ), 'error' );

                                        return false;
                                    }

                                } else {
                                    wc_add_notice( sprintf( __( '&quot;%1$s&quot; cannot be added to the cart. Please choose an option for &quot;%2$s&quot;&hellip;', 'yith-wcpb' ), get_the_title( $product_id ), $bundled_item->product->get_title() ), 'error' );

                                    return false;
                                }
                            } else {

                                // Purchasable
                                if ( !$bundled_prod->is_purchasable() ) {
                                    wc_add_notice( sprintf( __( '&quot;%1$s&quot; cannot be added to the cart because &quot;%2$s&quot; cannot be purchased at the moment.', 'yith-wcpb' ), get_the_title( $product_id ), $bundled_item->get_raw_title() ), 'error' );

                                    return false;
                                }
                                if ( !$bundled_prod->has_enough_stock( intval( $bundled_item->get_quantity() ) * intval( $product_quantity ) ) ) {
                                    wc_add_notice( __( 'You cannot add this quantity of items, because there are not enough in stock.', 'yith-wcpb' ), 'error' );

                                    return false;
                                }
                            }
                        }
                    }
                }
            }

            return true;
        }


        /**
         * delete subtotal for bundled items in order
         *
         * @access public
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function woocommerce_order_formatted_line_subtotal( $subtotal, $item, $order ) {
            if ( isset( $item[ 'bundled_by' ] ) )
                return ''; // -> CHILD of bundle

            // PARENT or NOT BUNDLE PRODUCT
            return $subtotal;
        }

        /**
         * Find the parent of a bundled item in an order.
         *
         * @param  array    $item
         * @param  WC_Order $order
         *
         * @return array
         */
        function get_bundled_order_item_parent( $item, $order ) {
            // find container item
            foreach ( $order->get_items() as $order_item ) {

                if ( isset( $order_item[ 'yith_bundle_cart_key' ] ) )
                    $is_parent = $item[ 'bundled_by' ] == $order_item[ 'yith_bundle_cart_key' ] ? true : false;

                if ( $is_parent ) {
                    $parent_item = $order_item;

                    return $parent_item;
                }
            }

            return false;
        }

        /**
         * add meta in order
         *
         * @access public
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function woocommerce_add_order_item_meta( $item_id, $values, $cart_item_key ) {
            if ( isset( $values[ 'bundled_by' ] ) ) {
                wc_add_order_item_meta( $item_id, '_bundled_by', $values[ 'bundled_by' ] );
            } else {
                if ( isset( $values[ 'cartstamp' ] ) ) {
                    wc_add_order_item_meta( $item_id, '_cartstamp', $values[ 'cartstamp' ] );
                }
            }

            if ( isset( $values[ 'cartstamp' ] ) && !isset( $values[ 'bundled_by' ] ) ) {
                if ( isset( $values[ 'bundled_items' ] ) ) {
                    wc_add_order_item_meta( $item_id, '_bundled_items', $values[ 'bundled_items' ] );
                }

                if ( $values[ 'data' ]->per_items_pricing == true ) {
                    wc_add_order_item_meta( $item_id, '_per_items_pricing', 'yes' );
                } else {
                    wc_add_order_item_meta( $item_id, '_per_items_pricing', 'no' );
                }

                if ( $values[ 'data' ]->non_bundled_shipping == true ) {
                    wc_add_order_item_meta( $item_id, '_non_bundled_shipping', 'yes' );
                } else {
                    wc_add_order_item_meta( $item_id, '_non_bundled_shipping', 'no' );
                }

                wc_add_order_item_meta( $item_id, '_yith_bundle_cart_key', $cart_item_key );
            }
        }

        public function woocommerce_cart_shipping_packages( $packages ) {

            if ( !empty( $packages ) ) {
                foreach ( $packages as $package_key => $package ) {
                    if ( !empty( $package[ 'contents' ] ) ) {
                        foreach ( $package[ 'contents' ] as $cart_item => $cart_item_data ) {
                            if ( isset( $cart_item_data[ 'bundled_items' ] ) ) {
                                $bundle = clone $cart_item_data[ 'data' ];

                                if ( !$bundle->non_bundled_shipping ) {
                                    foreach ( $cart_item_data[ 'bundled_items' ] as $child_item_key ) {
                                        if ( isset( $package[ 'contents' ][ $child_item_key ] ) ) {
                                            unset( $packages[ $package_key ][ 'contents' ][ $child_item_key ] );
                                        }
                                    }
                                } else {
                                    // SINGULAR SHIPPING
                                    if ( isset( $cart_item_data[ 'yith_parent' ] ) ) {
                                        $parent_bundle_key = $cart_item_data[ 'yith_parent' ];
                                        if ( isset( $package[ 'contents' ][ $parent_bundle_key ] ) ) {
                                            unset( $packages[ $package_key ][ 'contents' ][ $parent_bundle_key ] );
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return $packages;
        }

        public function enqueue_scripts() {
            parent::enqueue_scripts();

            wp_enqueue_script( 'yith_wcpb_bundle_frontend_add_to_cart', YITH_WCPB_ASSETS_URL . '/js/frontend_add_to_cart.js', array( 'jquery', 'wc-add-to-cart-variation' ), '1.0.0', true );
            wp_localize_script( 'yith_wcpb_bundle_frontend_add_to_cart', 'ajax_obj', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
        }
    }
}
/**
 * Unique access to instance of YITH_WCPB_Frontend_Premium class
 *
 * @return \YITH_WCPB_Frontend_Premium
 * @since 1.0.0
 */
function YITH_WCPB_Frontend_Premium() {
    return YITH_WCPB_Frontend_Premium::get_instance();
}

?>
