<?php
/**
 * Product Bundle Class
 *
 * @author  Yithemes
 * @package YITH WooCommerce Product Bundles
 * @version 1.0.0
 */


if ( !defined( 'YITH_WCPB' ) ) {
    exit;
} // Exit if accessed directly

if ( !class_exists( 'WC_Product_Yith_Bundle' ) ) {
    /**
     * Product Bundle Object
     *
     * @since  1.0.0
     * @author Leanza Francesco <leanzafrancesco@gmail.com>
     */
    class WC_Product_Yith_Bundle extends WC_Product {

        public  $bundle_data;
        private $bundled_items;

        public $per_items_pricing;
        public $non_bundled_shipping;

        public $price_per_item_tot_max;
        public $price_per_item_tot;

        /**
         * __construct
         *
         * @access public
         *
         * @param mixed $product
         */
        public function __construct( $product ) {
            $this->product_type = 'yith_bundle';
            parent::__construct( $product );

            $id = $this->get_wpml_parent_id();

            $this->bundle_data = get_post_meta( $id, '_yith_wcpb_bundle_data', true );

            $this->per_items_pricing    = ( get_post_meta( $id, '_yith_wcpb_per_item_pricing', true ) == 'yes' ) ? true : false;
            $this->non_bundled_shipping = ( get_post_meta( $id, '_yith_wcpb_non_bundled_shipping', true ) == 'yes' ) ? true : false;

            if ( !empty( $this->bundle_data ) ) {
                $this->load_items();
            }

            if ( $this->per_items_pricing ) {
                $this->price = 0;
            }

            $this->price_per_item_tot_max = $this->get_per_item_price_tot_max();
            $this->price_per_item_tot     = $this->get_per_item_price_tot();

        }

        public function get_wpml_parent_id() {
            global $sitepress;

            $id = $this->id;

            if ( isset( $sitepress ) ) {
                $default_language = $sitepress->get_default_language();

                if ( function_exists( 'icl_object_id' ) ) {
                    $id = icl_object_id( $this->id, 'product', true, $default_language );
                } else if ( function_exists( 'wpml_object_id_filter' ) ) {
                    $id = wpml_object_id_filter( $this->id, 'product', true, $default_language );
                }
            }

            return $id;
        }

        /**
         * Load bundled items
         *
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        private function load_items() {
            $virtual = true;
            foreach ( $this->bundle_data as $b_item_id => $b_item_data ) {
                $b_item = new YITH_WC_Bundled_Item( $this, $b_item_id );
                if ( $b_item->exists() ) {
                    $this->bundled_items[ $b_item_id ] = $b_item;
                    //v( $b_item->product, $b_item->product->is_virtual(), '-------------' );
                    if ( !$b_item->product->is_virtual() ) {
                        $virtual = false;
                    }
                }
            }
            $this->virtual = $virtual;
        }


        /**
         * return bundled items array
         *
         * @return array
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function get_bundled_items() {
            return !empty( $this->bundled_items ) ? $this->bundled_items : array();
        }

        /**
         * Returns false if the product cannot be bought.
         *
         * @return bool
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function is_purchasable() {

            $purchasable = true;

            // Products must exist of course
            if ( !$this->exists() ) {
                $purchasable = false;

                // Other products types need a price to be set
            } elseif ( $this->get_price() === '' ) {
                $purchasable = false;

                // Check the product is published
            } elseif ( $this->post->post_status !== 'publish' && !current_user_can( 'edit_post', $this->id ) ) {
                $purchasable = false;
            }

            // Check the bundle items are purchasable

            $bundled_items = !empty( $this->bundled_items ) ? $this->bundled_items : false;
            if ( $bundled_items ) {
                foreach ( $bundled_items as $bundled_item ) {
                    if ( !$bundled_item->get_product()->is_purchasable() ) {
                        $purchasable = false;
                    }
                }
            }

            return apply_filters( 'woocommerce_is_purchasable', $purchasable, $this );
        }

        /**
         * Returns true if all items is in stock
         *
         * @return bool
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function all_items_in_stock() {
            $response = true;

            $bundled_items = !empty( $this->bundled_items ) ? $this->bundled_items : false;
            if ( $bundled_items ) {
                foreach ( $bundled_items as $bundled_item ) {
                    if ( !$bundled_item->get_product()->is_in_stock() ) {
                        $response = false;
                    }
                }
            }

            return $response;
        }

        /**
         * Return true if some item has quantity to choose
         *
         * @return  int
         */
        public function has_quantity_to_choose() {
            $bundled_items = !empty( $this->bundled_items ) ? $this->bundled_items : false;
            if ( $bundled_items ) {
                foreach ( $bundled_items as $bundled_item ) {
                    if ( $bundled_item->has_quantity_to_choose() ) {
                        return true;
                    }
                }
            }

            return false;
        }

        /**
         * Return true if some item is optional
         *
         * @return  int
         */
        public function has_optional() {
            $bundled_items = !empty( $this->bundled_items ) ? $this->bundled_items : false;
            if ( $bundled_items ) {
                foreach ( $bundled_items as $bundled_item ) {
                    if ( $bundled_item->is_optional() ) {
                        return true;
                    }
                }
            }

            return false;
        }

        /**
         * Returns true if one item at least is variable product.
         *
         * @return bool
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function has_variables() {
            $bundled_items = !empty( $this->bundled_items ) ? $this->bundled_items : false;
            if ( $bundled_items ) {
                foreach ( $bundled_items as $bundled_item ) {
                    if ( $bundled_item->has_variables() ) {
                        return true;
                    }
                }
            }

            return false;
        }

        /**
         * Get the add to cart url used in loops.
         *
         * @access public
         * @return string
         */
        public function add_to_cart_url() {
            $url = !$this->has_optional() && !$this->has_variables() && !$this->has_quantity_to_choose() && $this->is_purchasable() && $this->is_in_stock() && $this->all_items_in_stock() ? remove_query_arg( 'added-to-cart', add_query_arg( 'add-to-cart', $this->id ) ) : get_permalink( $this->id );

            return apply_filters( 'woocommerce_product_add_to_cart_url', $url, $this );
        }

        /**
         * Get the add to cart button text
         *
         * @access public
         * @return string
         */
        public function add_to_cart_text() {
            $text = !$this->has_optional() && !$this->has_variables() && !$this->has_quantity_to_choose() && $this->is_purchasable() && $this->is_in_stock() && $this->all_items_in_stock() ? __( 'Add to cart', 'woocommerce' ) : __( 'Read More', 'woocommerce' );

            return apply_filters( 'woocommerce_product_add_to_cart_text', $text, $this );
        }

        /**
         * Get the title of the post.
         *
         * @access public
         * @return string
         */
        public function get_title() {

            $title = $this->post->post_title;

            if ( $this->get_parent() > 0 ) {
                $title = get_the_title( $this->get_parent() ) . ' &rarr; ' . $title;
            }

            return apply_filters( 'woocommerce_product_title', $title, $this );
        }

        /**
         * Sync grouped products with the children lowest price (so they can be sorted by price accurately).
         *
         * @access public
         * @return void
         */
        public function grouped_product_sync() {
            if ( !$this->get_parent() )
                return;

            $children_by_price = get_posts( array(
                'post_parent'    => $this->get_parent(),
                'orderby'        => 'meta_value_num',
                'order'          => 'asc',
                'meta_key'       => '_price',
                'posts_per_page' => 1,
                'post_type'      => 'product',
                'fields'         => 'ids'
            ) );
            if ( $children_by_price ) {
                foreach ( $children_by_price as $child ) {
                    $child_price = get_post_meta( $child, '_price', true );
                    update_post_meta( $this->get_parent(), '_price', $child_price );
                }
            }

            delete_transient( 'wc_products_onsale' );

            do_action( 'woocommerce_grouped_product_sync', $this->id, $children_by_price );
        }


        public function get_bundled_item( $item_id ) {
            if ( !empty( $this->bundle_data ) && isset( $this->bundle_data[ $item_id ] ) ) {
                if ( isset( $this->bundled_items[ $item_id ] ) ) {
                    return $this->bundled_items[ $item_id ];
                } else {
                    return new YITH_WC_Bundled_Item( $item_id, $this );
                }
            }

            return false;
        }


        public function get_price() {

            if ( $this->per_items_pricing ) {
                return apply_filters( 'woocommerce_yith_bundle_get_price', (double)$this->price, $this );
            } else {
                return parent::get_price();
            }
        }


        /**
         * get the MAX price of product bundle
         *
         * @access public
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function get_per_item_price_tot_max( $apply_discount = false ) {

            if ( isset( $this->price_per_item_tot_max ) && !$apply_discount ) {
                return $this->price_per_item_tot_max;
            }

            $price = 0;
            if ( $this->per_items_pricing ) {
                $bundled_items_price = 0;

                $bundled_items = $this->bundled_items;

                foreach ( $bundled_items as $bundled_item ) {
                    if ( $bundled_item->is_optional() ) {
                        continue;
                    }

                    $product            = $bundled_item->product;
                    $bundled_item_price = 0;
                    if ( !$bundled_item->has_variables() ) {
                        // SIMPLE
                        $bundled_item_price = get_option( 'woocommerce_tax_display_cart' ) === 'excl' ? $product->get_price_excluding_tax( $bundled_item->min_quantity, $product->get_regular_price() ) : $product->get_price_including_tax( $bundled_item->min_quantity, $product->get_regular_price() );
                    } else {
                        // VARIABLE
                        $bundled_item_price = get_option( 'woocommerce_tax_display_cart' ) === 'excl' ? $product->get_price_excluding_tax( $bundled_item->min_quantity, $bundled_item->max_price ) : $product->get_price_including_tax( $bundled_item->min_quantity, $bundled_item->max_price );
                    }

                    if ( $apply_discount ) {
                        $discount = $bundled_item_price * $bundled_item->discount / 100;
                        $bundled_item_price -= $discount;
                        $bundled_items_price += $bundled_item_price;
                    } else {
                        $bundled_items_price += $bundled_item_price;
                    }
                }
                $price = $bundled_items_price;
            }

            return $price;
        }


        /**
         * get the MIN price of product bundle
         *
         * @access public
         * @since  1.0.0
         * @author Leanza Francesco <leanzafrancesco@gmail.com>
         */
        public function get_per_item_price_tot() {

            if ( isset( $this->price_per_item_tot ) ) {
                return $this->price_per_item_tot;
            }
            $price = 0;
            if ( $this->per_items_pricing ) {
                $bundled_items_price = 0;

                $bundled_items = $this->bundled_items;

                foreach ( $bundled_items as $bundled_item ) {
                    if ( $bundled_item->is_optional() ) {
                        continue;
                    }

                    $product            = $bundled_item->product;
                    $bundled_item_price = 0;
                    if ( !$bundled_item->has_variables() ) {
                        // SIMPLE
                        $bundled_item_price = get_option( 'woocommerce_tax_display_cart' ) === 'excl' ? $product->get_price_excluding_tax( $bundled_item->min_quantity, $product->get_regular_price() ) : $product->get_price_including_tax( $bundled_item->min_quantity, $product->get_regular_price() );
                    } else {
                        // VARIABLE
                        $bundled_item_price = get_option( 'woocommerce_tax_display_cart' ) === 'excl' ? $product->get_price_excluding_tax( $bundled_item->min_quantity, $bundled_item->min_price ) : $product->get_price_including_tax( $bundled_item->min_quantity, $bundled_item->min_price );
                    }
                    $discount = $bundled_item_price * $bundled_item->discount / 100;
                    $bundled_item_price -= $discount;
                    $bundled_items_price += $bundled_item_price;
                }
                $price = $bundled_items_price;
            }

            return $price;
        }

        public function get_price_html_from_to( $from, $to ) {
            if ( !$this->per_items_pricing  || !$this->has_variables() ) {
                return parent::get_price_html_from_to( $from, $to );
            } else {
                return wc_price( $to ) . '-' . wc_price( $from );
            }
        }


        public function get_per_item_price_tot_with_params( $array_quantity, $array_opt, $array_var ) {
            if ( !is_array( $array_quantity ) ) {
                return $this->price_per_item_tot;
            }

            $price = $this->price;
            if ( $this->per_items_pricing ) {
                $price               = 0;
                $bundled_items_price = 0;

                $bundled_items = $this->bundled_items;

                $loop = 0;

                foreach ( $bundled_items as $bundled_item ) {
                    if ( isset( $array_opt[ $loop ] ) && $array_opt[ $loop ] == '0' ) {
                        $loop++;
                        continue;
                    }

                    $product            = $bundled_item->product;
                    $bundled_item_price = 0;
                    if ( $product->product_type != 'variable' ) {
                        // SIMPLE
                        $bundled_item_price = get_option( 'woocommerce_tax_display_cart' ) === 'excl' ? $product->get_price_excluding_tax( $array_quantity[ $loop ], $product->get_regular_price() ) : $product->get_price_including_tax( $array_quantity[ $loop ], $product->get_regular_price() );
                    } else {
                        // VARIABLE
                        if ( isset( $array_var[ $loop ] ) ) {
                            $variation = $product->get_child( $array_var[ $loop ] );
                            if ( $variation )
                                $bundled_item_price = get_option( 'woocommerce_tax_display_cart' ) === 'excl' ? $variation->get_price_excluding_tax( $array_quantity[ $loop ], $variation->get_regular_price() ) : $variation->get_price_including_tax( $array_quantity[ $loop ], $variation->get_regular_price() ); else
                                $bundled_item_price = get_option( 'woocommerce_tax_display_cart' ) === 'excl' ? $product->get_price_excluding_tax( $array_quantity[ $loop ], $product->get_regular_price() ) : $product->get_price_including_tax( $array_quantity[ $loop ], $product->get_regular_price() );
                        } else {
                            $bundled_item_price = get_option( 'woocommerce_tax_display_cart' ) === 'excl' ? $product->get_price_excluding_tax( $array_quantity[ $loop ], $product->get_regular_price() ) : $product->get_price_including_tax( $array_quantity[ $loop ], $product->get_regular_price() );

                        }
                    }
                    $discount = $bundled_item_price * $bundled_item->discount / 100;
                    $bundled_item_price -= $discount;
                    $bundled_items_price += $bundled_item_price;
                    $loop++;
                }
                $price = $bundled_items_price;
            }

            //var_dump($bundled_items); die();
            return wc_price( $price );
        }


        /**
         * Gets product variation data which is passed to JS.
         *
         * @return array variation data array
         */
        public function get_available_bundle_variations() {

            if ( empty( $this->bundled_items ) ) {
                return array();
            }

            $bundle_variations = array();
            $price_zero        = !$this->per_items_pricing;
            foreach ( $this->bundled_items as $bundled_item )
                $bundle_variations[ $bundled_item->item_id ] = $bundled_item->get_product_variations( $price_zero );

            return $bundle_variations;
        }

        /**
         * Gets the attributes of all variable bundled items.
         *
         * @return array attributes array
         */
        public function get_bundle_variation_attributes() {

            if ( empty( $this->bundled_items ) ) {
                return array();
            }

            $bundle_attributes = array();

            foreach ( $this->bundled_items as $bundled_item ) {
                $bundle_attributes[ $bundled_item->item_id ] = $bundled_item->get_product_variation_attributes();
            }

            return $bundle_attributes;
        }

        public function get_selected_bundle_variation_attributes() {

            if ( empty( $this->bundled_items ) ) {
                return array();
            }

            $seleted_bundle_attributes = array();

            foreach ( $this->bundled_items as $bundled_item ) {
                $seleted_bundle_attributes[ $bundled_item->item_id ] = $bundled_item->get_selected_product_variation_attributes();
            }

            return $seleted_bundle_attributes;
        }


    }
}
?>