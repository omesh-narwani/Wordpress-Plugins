<?php

$settings = array(

	'settings'  => array(

		'general-options' => array(
			'title' => __( 'General Options', 'yith-wcpb' ),
			'type' => 'title',
			'desc' => '',
			'id' => 'yith-wcpb-general-options'
		),

        'show-bundled-items-in-report' => array(
            'id'        => 'yith-wcpb-show-bundled-items-in-report',
            'name'      => __( 'Show bundled items in Reports', 'yith-wcpb' ),
            'type'      => 'checkbox',
            'desc'      => __( 'Flag this option to show also the bundled items in WooCommerce Reports.', 'yith-wcpb' ),
            'default'   => 'no'
        ),

		'general-options-end' => array(
			'type'      => 'sectionend',
			'id'        => 'yith-wcqv-general-options'
		)

	)
);

return apply_filters( 'yith_wcpb_panel_settings_options', $settings );