=== YITH WooCommerce Product Countdown ===

Contributors: yithemes
Tags: woocommerce, products, themes, yit, yith, e-commerce, shop, count down, countdown, countdown clock, countdown timer, countdown widget, counter, counter clock, date countdown, date time, date timer, datetime, days until
Requires at least: 4.0
Tested up to: 4.4.2
Stable tag: 1.0.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= 1.0.8 =

* Fixed: issues while saving variations
* Tweak: countdown dates on dedicated post meta

= 1.0.7 =

* Added: compatibility with WooCommerce 2.5
* Added: column showing active countdowns in product page

= 1.0.6 =

* Tweak: Shortcode without specified ids shows all products with active countdown
* Updated: plugin core framework

= 1.0.5 =

* Updated: changed text domain from ywpc to yith-woocommerce-product-countdown
* Updated: changed all language file for the new text domain

= 1.0.4 =

* Updated: plugin core framework

= 1.0.3 =

* Fixed: Variation options save

= 1.0.2 =

* Added: Support for RTL languages

= 1.0.1 =

* Updated language file

= 1.0.0 =

* Initial release