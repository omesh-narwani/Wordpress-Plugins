=== YITH WooCommerce Product Slider Carousel ===

Contributors: yithemes
Tags: woocommerce, ecommerce, product carousel, shortcode, autoplay, animations, shop, yith, yit, yithemes
Requires at least: 3.5.1
Tested up to: 4.4
Stable tag: 1.0.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Changelog ==

= 1.0.7 =

* Added : z-index option in shortcode for multiple slider in the same page
* Updated: Language file

= 1.0.6 =

* Added: Compatibility with WPBackery Visual Composer
* Added: ywcps_add_classes_in_slider filter in product_slider_view_default.php

= 1.0.5 =

* Added: Compatibility with YITH WooCommerce Surveys
* Fixed: Show Metaboxes when is active YITH WooCommerce Surveys
* Updated: Plugin Framework

= 1.0.4 = 

* Updated: Plugin Framework 2.0

= 1.0.3 =

* Fixed: "Plugin is enabled but not effective" issue

= 1.0.2 =

Tweak: Increase max image for row to 6
Fixed: TinyMCE button for shortcodes

= 1.0.1 =

* Added: Support to WooCommerce 2.4
* Updated: Plugin core framework

= 1.0.0 =

* Initial release
