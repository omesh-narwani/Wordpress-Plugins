=== YITH WooCommerce Quick Export ===

Contributors: yithemes
Tags: export, data export, order export, customer export, coupon export, scheduled export, order backup, csv, customer backup, dropbox, dropbox backup, export dropbox
Requires at least: 3.5.1
Tested up to: 4.4.1
Stable tag: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= Version 1.0.2 - RELEASED: JAN 28, 2016 =

* Updated: change text-domain from ywqe to yith-woocommerce-quick-export
* Updated: YITH plugin FW to latest release
* Updated: WP up to 4.4.1
* Fixed: datepicker conflict with the CSS class selector
* Fixed: plugin pot file in /languages folder

= Version 1.0.1 - RELEASED: AUG 12, 2015 =

* Tweak: update YITH Plugin framework.

= Version 1.0.0 - RELEASED: MAY 27 , 2015 =

Initial release
