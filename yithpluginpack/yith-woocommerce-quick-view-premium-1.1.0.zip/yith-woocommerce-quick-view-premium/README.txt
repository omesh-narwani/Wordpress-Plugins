== Changelog ==

= 1.1.0 =

* Added: Compatibility with WooCommerce 2.5 BETA 3
* Added: Compatibility with WordPress 4.4
* Added: Compatibility with YITH WooCommerce One Click Checkout
* Added: Option for redirect to checkout after add to cart on quick view
* Updated: Change text domain to yith-wcqv to yith-woocommerce-quick-view
* Updated: Plugin Core
* Updated: Language file .pot

= 1.0.7 =

* Added: Option for view full description instead of short.
* Added: Option for load custom images template instead of the woocommerce one ( prevent themes error )
* Added: Shortcode to add quick view button [yith_quick_view product_id=""]
* Added: Compatibility with YITH WooCommerce Badge Management. Now badge works also in quick view.
* Added: Compatibility with YITH WooCommerce Wishlist. Now you can add the quick view button also on wishlist table ( works only with modal style activated )
* Added: Compatibility with YITH WooCommerce Zoom Magnifier. Now zoom magnifier works also in quick view.
* Added: Pre loader effect for quick view modal window
* Updated: Plugin Core

= 1.0.6 =

* Added: Compatibility with WooCommerce 2.4
* Added: Compatibility with YITH WooCommerce Color Label Variations Premium
* Updated: Plugin Core
* Updated: Language file

= 1.0.5 =

* Added: Compatibility with YITH WooCommerce Request a Quote
* Added: Compatibility with Contact Form 7

= 1.0.4 =

* Added: Option for disable quick view on mobile device
* Added: Now is possible overwrite quick view css from theme
* Added: Compatibility with Woocommerce Quantity Increment plugin
* Fixed: Now is possible to use cascading style in mobile also
* Fixed: Removed view details button in single product page
* Fixed: On select variation changes sku and image also
* Fixed: Minor Bugs
* Updated: Plugin Core
* Updated: Language file *.pot

= 1.0.3 =

* Added: Add to cart in ajax on quick view
* Added: Compatibility with YITH Infinite Scrolling Premium
* Added: Compatibility with YITH WooCommerce Ajax Navigation
* Fixed: Minor bug
* Updated: Plugin core framework

= 1.0.2 =

* Updated: Plugin core framework
* Tweak: Quick View Management
* Fixed: Minor Bugs
* Fixed: Modal class issue

= 1.0.1 =

Initial release