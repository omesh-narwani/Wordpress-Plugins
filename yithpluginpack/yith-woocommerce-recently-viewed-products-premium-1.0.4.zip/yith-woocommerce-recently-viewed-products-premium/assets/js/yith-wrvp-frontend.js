/**
 * frontend.js
 *
 * @author Your Inspiration Themes
 * @package YITH WooCommerce Recently Viewed Products
 * @version 1.0.0
 */

jQuery(document).ready(function($) {
    "use strict";

    var items = $( document ).find( '.yith-similar-products' );

    items.each( function(){

        var is_slider = $(this).data('slider'),
            autoplay = $(this).data('autoplay'),
            columns = $(this).data('columns');

        if( is_slider ) {
            $(this).find( '.products' ).slick({
                infinite: true,
                autoplay: autoplay,
                speed: 300,
                slidesToShow: columns,
                slidesToScroll: 4,
                responsive: [
                    {
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 3,
                            infinite: true
                        }
                    },
                    {
                        breakpoint: 767,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2
                        }
                    },
                    {
                        breakpoint: 360,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1
                        }
                    }
                ]
            });
        }
    });

    if( typeof ywrvp != 'undefined' ) {
        // ajax filter by cat
        $('.yith-wrvp-filters-cat').on('click', 'a.cat-link', function (ev) {

            ev.preventDefault();

            var t = $(this),
                t_wrapper = $(this).closest('.filter-cat'),
                container = $( '.yith-similar-products'),
                nav = $('.woocommerce-pagination'),
                cat_id = t_wrapper.hasClass('active') ? '0' : t.data( 'cat_id' ),
                data = {
                    ywrvp_cat_id: cat_id,
                    context: 'frontend'
                };

            $.ajax({
                url: ywrvp.url,
                type: 'GET',
                data: data,
                dataType: 'html',
                success: function( res ) {

                    container.html( $(res).find('.yith-similar-products') );
                    nav.html( $(res).find( '.woocommerce-pagination' ) );

                    t_wrapper.toggleClass('active').siblings().removeClass('active');

                    $(document).trigger('yith-wrvp-product-changed');
                }

            })

        });
    }
});