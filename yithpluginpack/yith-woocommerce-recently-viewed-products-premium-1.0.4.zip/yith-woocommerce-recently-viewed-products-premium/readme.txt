= 1.0.4 = 02/16/2016

Added: Integration of Google Analytics campaign for email link.
Added: Option for choose to show the shortcode on single product page
Updated: Plugin Core
Updated: Language file

= 1.0.3 = 02/05/2016

Added: Compatibility with YITH WooCommerce Email Template Premium.
Updated: Plugin Core

= 1.0.2 = 01/14/2016

Added: Compatibility with WooCommerce 2.5 RC.
Fixed: Responsive for products slider
Updated: Plugin Core
Updated: Language file

= 1.0.1 = 11/30/2015

Added: Link in email for unsubscribe to mailing list
Added: Track visit with IP for no logged in customer
Added: Option for get similar products by tags, categories ot both
Added: Specify View All link url instead of standard page link
Fixed: Scheduled emails are sent multiple times to customer
Updated: Plugin Core
Updated: Language file

= 1.0.0 = 10/13/2015

* Initial release