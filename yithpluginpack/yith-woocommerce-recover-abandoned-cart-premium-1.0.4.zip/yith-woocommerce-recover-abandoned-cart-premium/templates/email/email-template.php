<?php
/**
 * HTML Template Email Recover Abandoned Cart
 *
 * @package YITH WooCommerce Recover Abandoned Cart
 * @since   1.0.0
 * @author  Yithemes
 */

extract($args);


if (defined('YITH_WCET_PREMIUM')){

    $mail_type = "ywrac-template";
    do_action( 'yith_wcet_email_header', $email_heading, $mail_type);

    $template        = get_option( 'yith-wcet-email-template-' . $mail_type );
}else{
    do_action( 'woocommerce_email_header', $email_heading );
}

?>

<?php echo $email_content ?>

<?php
if (defined('YITH_WCET_PREMIUM')) {
    do_action( 'yith_wcet_email_footer', $mail_type );
}else{
    do_action( 'woocommerce_email_footer' );
}
?>
