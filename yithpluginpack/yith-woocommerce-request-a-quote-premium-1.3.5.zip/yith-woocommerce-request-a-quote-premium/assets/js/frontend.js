jQuery(document).ready( function($){
    "use strict";


    var $body = $('body'),
        $add_to_cart_el = $('.add-request-quote-button'),
        $widget = $('.widget_ywraq_list_quote'),
        $remove_item = $('.yith-ywraq-item-remove');


    /* Variation change */
    $.fn.yith_ywraq_variations = function() {

        var $product_id = $('[name|="product_id"]'),
            product_id = $product_id.val(),
            button = $('.add-to-quote-' + product_id).find('a'),
            $button_wrap = button.parents('.yith-ywraq-add-to-quote'),
            $variation_id = $('[name|="variation_id"]');

        button.parent().hide().removeClass('show');

        $variation_id.on('change', function () {
            if ( $(this).val() == '') {
                button.parent().hide().removeClass('show');
            } else {
                $.ajax({
                    type    : 'POST',
                    url     : ywraq_frontend.ajaxurl.toString().replace( '%%endpoint%%', 'yith_ywraq_action' ),
                    dataType: 'json',
                    data    : 'ywraq_action=variation_exist&variation_id=' + $variation_id.val() + '&product_id=' + $product_id.val(),
                    success : function (response) {
                        if (response.result === true) {
                            button.parent().hide().removeClass('show');
                            if ($('.yith_ywraq_add_item_browse-list-' + $product_id.val()).length == 0) {
                                if( response.label_browse != ''){
                                    $button_wrap.append('<div class="yith_ywraq_add_item_response-' + $product_id.val() + ' yith_ywraq_add_item_response_message">' + response.message + '</div>');
                                    $button_wrap.append('<div class="yith_ywraq_add_item_browse-list-' + $product_id.val() + ' yith_ywraq_add_item_browse_message"><a href="' + response.rqa_url + '">' + response.label_browse + '</a></div>');
                                }
                            }
                        } else {
                            $('.yith_ywraq_add_item_response-' + $product_id.val()).remove();
                            $('.yith_ywraq_add_item_browse-list-' + $product_id.val()).remove();
                            button.parent().show().addClass('show');
                        }
                    }
                });
            }

        });
    };

    if( $body.hasClass('single-product') ){
        $.fn.yith_ywraq_variations();
    }

    /* Add to cart element */
    $(document).on( 'click' ,'.add-request-quote-button', function(e){

        e.preventDefault();

        var $t = $(this),
            $t_wrap = $t.closest('.yith-ywraq-add-to-quote'),
            add_to_cart_info = 'ac',
            $cart_form = '';

        // find the form
        if( $t.closest( '.cart' ).length ){
            $cart_form = $t.closest( '.cart' );
        }
        else if( $t.siblings( '.cart' ).first().length ) {
            $cart_form = $t.siblings( '.cart' ).first();
        }
        else {
            $cart_form = $('.cart');
        }

        if ( $t.closest('ul.products').length > 0) {
            var $add_to_cart_el = $t.closest('li.product').find('input[name="add-to-cart"]'),
            $product_id_el = $t.closest('li.product').find('input[name="product_id"]');
        }else{
            var $add_to_cart_el = $t.closest('.product').find('input[name="add-to-cart"]'),
                $product_id_el = $t.closest('.product').find('input[name="product_id"]');
        }

        if ($add_to_cart_el.length > 0 && $product_id_el.length > 0) { //variable product
            add_to_cart_info = $cart_form.serialize();
        }else if ( $add_to_cart_el.length > 0 && $cart_form.length > 0) { //single product and form exists with cart class
            add_to_cart_info = $cart_form.serialize();
        }else if ( $add_to_cart_el.length == 0 && $cart_form.length > 0) { //single product and form exists with cart class
                add_to_cart_info = $cart_form.serialize();
        }else if ( $add_to_cart_el.length == 0) { //shop page - archive page
            add_to_cart_info = 'quantity=1';
        }

        add_to_cart_info += '&ywraq_action=add_item&product_id='+$t.data('product_id')+'&wp_nonce='+$t.data('wp_nonce');

        if( add_to_cart_info.indexOf('add-to-cart') >= 0){
            add_to_cart_info = add_to_cart_info.replace( 'add-to-cart', 'yith-add-to-cart');
        }
        $.ajax({
            type   : 'POST',
            url    : ywraq_frontend.ajaxurl.toString().replace( '%%endpoint%%', 'yith_ywraq_action' ),
            dataType: 'json',
            data   : add_to_cart_info,
            beforeSend: function(){
                $t.siblings( '.ajax-loading' ).css( 'visibility', 'visible' );
            },
            complete: function(){
                $t.siblings( '.ajax-loading' ).css( 'visibility', 'hidden' );
            },

            success: function (response) {
                    if( response.result == 'true' || response.result == 'exists'){

                        if( ywraq_frontend.go_to_the_list == 'yes' ){
                            window.location.href = response.rqa_url;
                        }else{
                            $t.parent().hide().removeClass('show').addClass('addedd');
                            var prod_id = ( typeof $product_id_el.val() == 'undefined') ? '' : '-'+$product_id_el.val();
                            $t_wrap.append( '<div class="yith_ywraq_add_item_response'+ prod_id +' yith_ywraq_add_item_response_message">' + response.message + '</div>');
                            $t_wrap.append( '<div class="yith_ywraq_add_item_browse-list'+prod_id+' yith_ywraq_add_item_browse_message"><a href="'+response.rqa_url+'">' + response.label_browse + '</a></div>');

                            if( $widget.length ){
                                $widget.ywraq_refresh_widget();
                            }
                        }


                    }else if( response.result == 'false' ){
                        $t_wrap.append( '<div class="yith_ywraq_add_item_response-'+$product_id_el.val()+'">' + response.message + '</div>');

                    }
            }
        });


    });

    /* Refresh the widget */
    $.fn.ywraq_refresh_widget = function(){
        $widget.each(function(){
            var $t = $(this),
                data_widget = $t.find('.yith-ywraq-list-widget-wrapper').data('instance') ;

            $.ajax({
                type   : 'POST',
                url    : ywraq_frontend.ajaxurl.toString().replace( '%%endpoint%%', 'yith_ywraq_action' ),
                data   : data_widget+'&ywraq_action=refresh_quote_list',
                beforeSend: function(){
                    $t.find( '.ajax-loading' ).css( 'visibility', 'visible' );
                    $t.find('.yith-ywraq-list').css('opacity', 0.5);
                },
                complete: function(){
                    $t.find( '.ajax-loading' ).css( 'visibility', 'hidden' );
                    $t.find('.yith-ywraq-list').css('opacity', 1);
                },
                success: function (response) {
                    $t.find('.yith-ywraq-list-widget-wrapper').html(response);
                }
            });
        })

    }

     /*Remove an item from rqa list*/
    $remove_item.on( 'click' , function(e){

        e.preventDefault();

        var $t = $(this),
            key = $t.data('remove-item'),
            form = $('#yith-ywraq-form'),
            remove_info = '';

        remove_info = 'ywraq_action=remove_item&key='+$t.data('remove-item')+'&wp_nonce='+$t.data('wp_nonce')+'&product_id='+$t.data('product_id');

        $.ajax({
            type   : 'POST',
            url    : ywraq_frontend.ajaxurl.toString().replace( '%%endpoint%%', 'yith_ywraq_action' ),
            dataType: 'json',
            data   : remove_info,
            beforeSend: function(){
                $t.siblings( '.ajax-loading' ).css( 'visibility', 'visible' );
            },
            complete: function(){
                $t.siblings( '.ajax-loading' ).css( 'visibility', 'hidden' );
            },

            success: function (response) {
                if( response === 1){
                    $("[data-remove-item='"+key+"']").parents('.cart_item').remove();
                    if( $('.cart_item').length === 0 ){
                        $('#yith-ywraq-form, .yith-ywraq-mail-form-wrapper').remove();
                        $('#yith-ywraq-message').text(ywraq_frontend.no_product_in_list);
                    }
                    if( $widget.length ){
                        $widget.ywraq_refresh_widget();
                    }
                }
            }
        });

        
    });

    var content_data = '';

    var $cform7 =  $('.wpcf7-submit').closest('.wpcf7');

    if( $cform7.length > 0 ){

        $(document).find('.wpcf7').each( function()
        {
            var $cform7 = $(this);
            var idform = $cform7.find('input[name="_wpcf7"]').val();

            if ( idform == ywraq_frontend.cform7_id ) {

                $cform7.on('wpcf7:mailsent', function () {
                    $.ajax({
                        type    : 'POST',
                        url     : ywraq_frontend.ajaxurl.toString().replace( '%%endpoint%%', 'yith_ywraq_order_action' ),
                        dataType: 'json',
                        data    : {
                            lang:   ywraq_frontend.current_lang,
                            ywraq_order_action: 'mail_sent_order_created'
                        },
                        success: function (response) {
                            if (response.rqa_url != '') {
                                window.location.href = response.rqa_url;
                            }
                        }
                    });
                });
            }
        });
    }


    var accepted_buttons = $('.quotes-actions').find('.accept');

    accepted_buttons.on('click', function(e){

        if( $(this).hasClass('pay') ){
            return true;
        }

        e.preventDefault();
        var $t = $(this),
            order_id = $t.parents('.quotes-actions').data('order_id'),
            request_info = 'ywraq_order_action=accept_order&order_id='+order_id;

        $.ajax({
            type   : 'POST',
            url    : ywraq_frontend.ajaxurl.toString().replace( '%%endpoint%%', 'yith_ywraq_order_action' ),
            dataType: 'json',
            data   : request_info,
            beforeSend: function(){
                $t.siblings( '.ajax-loading' ).css( 'visibility', 'visible' );
            },
            complete: function(){
                $t.siblings( '.ajax-loading' ).css( 'visibility', 'hidden' );
            },

            success: function (response) {
                if( response.result !== 0){
                    window.location.href = response.rqa_url;
                }else{

                }

            }
        });


    });


    var reject_buttons = $('.quotes-actions').find('.reject'),
        table = $('.my_account_quotes');

    reject_buttons.prettyPhoto({
        hook: 'data-rel',
        social_tools: false,
        theme: 'pp_woocommerce',
        horizontal_padding: 20,
        opacity: 0.8,
        deeplinking: false
    });

    reject_buttons.on('click', function(e){

        e.preventDefault();
        var $t = $(this),
            order_id = $t.parents('.quotes-actions').data('order_id'),
            modal = $('#modal-order-number'),
            request_info = 'action=yith_ywraq_order_action&ywraq_order_action=reject_order&order_id='+order_id;

        modal.text(order_id);
        $('.reject-quote-modal-button').attr('data-order_id', order_id);

        reject_buttons.prettyPhoto({
            hook: 'data-rel',
            social_tools: false,
            theme: 'pp_woocommerce',
            horizontal_padding: 20,
            opacity: 0.8,
            deeplinking: false
        });
/*

*/

    });

    $(document).on('click', '.close-quote-modal-button', function(e){
        e.preventDefault();
        $.prettyPhoto.close();
    });

    $(document).on('click', '.reject-quote-modal-button', function(e){

        e.preventDefault();
        var $t = $(this),
            order_id = $t.data('order_id'),
            modal = $('#modal-order-number'),
            table =$t.closest('body').find('.my_account_quotes'),
            row =table.find('[data-order_id="'+order_id+'"]').parent(),
            request_info = 'ywraq_order_action=reject_order&order_id='+order_id;


        $.ajax({
            type   : 'POST',
            url    : ywraq_frontend.ajaxurl.toString().replace( '%%endpoint%%', 'yith_ywraq_order_action' ),
            dataType: 'json',
            data   : request_info,
            beforeSend: function(){
                row.find( '.ajax-loading' ).css( 'visibility', 'visible' );
            },
            complete: function(){
                row.find( '.ajax-loading' ).css( 'visibility', 'hidden' );
            },

            success: function (response) {
                if( response.result !== 0){
                    //window.location.href = response.rqa_url;
                    row.find('.reject').hide();
                    row.find('.accept').hide();
                    row.find('.raq_status').removeClass('pending').addClass('rejected').text(response.status);
                    $.prettyPhoto.close();
                }

            }
        });
    });


    var request;
    $(document).on( 'click', '.input-text.qty.text', function(e){
        if( typeof request !== 'undefined' ){
            request.abort();
        }


        var $t = $(this),
            name = $t.attr('name'),
            value = $t.val(),
            item_keys = name.match(/[^[\]]+(?=])/g),
            request_info = 'ywraq_action=update_item_quantity&quantity='+value+'&key='+item_keys[0];

        request = $.ajax({
            type   : 'POST',
            url    : ywraq_frontend.ajaxurl.toString().replace( '%%endpoint%%', 'yith_ywraq_action' ),
            dataType: 'json',
            data   : request_info
        });

    });

});