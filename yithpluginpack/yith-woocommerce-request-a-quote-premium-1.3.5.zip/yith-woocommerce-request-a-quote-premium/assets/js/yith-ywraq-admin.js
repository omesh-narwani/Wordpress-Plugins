/**
* Javascript functions to administrator pane
*
* @package YITH Woocommerce Request A Quote
* @since   1.0.0
* @version 1.0.0
* @author  Yitheme
*/
jQuery(document).ready(function($) {
    "use strict";

    var select          = $( document).find( '.yith-ywraq-chosen' );

    select.each( function() {
        $(this).chosen({
            width: '350px',
            disable_search: true,
            multiple: true
        })
    });

    //Contact form selection
    var yit_contact_form   = $( 'select.yit-contact-form' ).parent().parent(),
        contact_form_7     = $( 'select.contact-form-7' ).parent().parent();

    $( 'select#ywraq_inquiry_form_type' ).change(function(){

        var option = $( 'option:selected', this ).val();

        switch( option ){
            case "yit-contact-form":
                yit_contact_form.show();
                contact_form_7.hide();
                break;
            case "contact-form-7":
                yit_contact_form.hide();
                contact_form_7.show();
                break;
            default:
                yit_contact_form.hide();
                contact_form_7.hide();
        }

    }).change();


    //Order functions

    $('#ywraq_submit_button').on('click', function(e){
        e.preventDefault();
        $('#_ywraq_safe_submit_field').val('send_quote');

       $(this).closest('form').submit();
    });

    //datepicker

        if( $('.metaboxes-tab #_ywcm_request_expire-container .panel-datepicker').length > 0){
            $('.metaboxes-tab #_ywcm_request_expire-container .panel-datepicker').each( function() {
                $.datepicker.setDefaults({
                    gotoCurrent: true,
                    dateFormat: 'yy-mm-dd'
                });
                $(this).datepicker('option','minDate',"1d");

            });
        }

});