<?php
if ( !defined( 'ABSPATH' ) || !defined( 'YITH_YWRAQ_VERSION' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Implements the YITH_YWRAQ_Order_Request class
 *
 *
 * @class    YITH_YWRAQ_Order_Request
 * @package  YITH Woocommerce Request A Quote
 * @since    1.0.0
 * @author   Yithemes
 */
class YITH_YWRAQ_Order_Request {


    /**
     * Array with Quote List datas
     */
    protected $_data = array();

    /**
     * Name of dynamic coupon
     */
    protected $label_coupon = 'quotediscount';

    protected $yit_contact_form_post = array();

    private $args_message = array();

    /**
     * Single instance of the class
     *
     * @var \YITH_YWRAQ_Order_Request
     */
    protected static $instance;

    /**
     * Returns single instance of the class
     *
     * @return \YITH_YWRAQ_Order_Request
     * @since 1.0.0
     */
    public static function get_instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     *
     * Initialize plugin and registers actions and filters to be used
     *
     * @since  1.0.0
     * @author Emanuela Castorina
     */
    public function __construct() {

        $this->_data['raq_order_status'] = array( 'wc-ywraq-new', 'wc-ywraq-pending', 'wc-ywraq-expired', 'wc-ywraq-rejected' );

        add_filter( 'woocommerce_cart_totals_coupon_label', array( $this, 'label_coupon' ), 10, 2 );
        add_filter( 'woocommerce_coupon_error', array( $this, 'manage_coupon_errors' ), 10, 3 );
        add_filter( 'woocommerce_coupon_message', array( $this, 'manage_coupon_message' ), 10, 3 );

        //set new order status
        add_action( 'init', array( $this, 'register_order_status' ) );
        add_filter( 'wc_order_statuses', array( $this, 'add_custom_status_to_order_statuses' ) );
        add_filter( 'wc_order_is_editable', array( $this, 'order_is_editable' ), 10, 2 );
        add_action( 'woocommerce_checkout_order_processed', array( $this, 'raq_processed' ), 10, 2 );

        //add custom metabox
        add_action( 'admin_init', array( $this, 'add_metabox' ), 1 );
        add_action( 'save_post', array( $this, 'change_status_quote' ), 1, 2 );
        add_action( 'woocommerce_process_shop_order_meta', array( $this, 'send_quote' ), 100, 2 );

        add_action( 'ywraq_process', array( $this, 'create_order' ), 10, 1 );
        add_filter( 'woocommerce_get_shop_coupon_data', array( $this, 'create_coupon_cart_discount' ), 10, 2 );

        //myaccount list quotes
        add_filter( 'woocommerce_my_account_my_orders_query', array( $this, 'my_account_my_orders_query' ) );
        add_action( 'woocommerce_before_my_account', array( $this, 'my_account_my_quotes' ) );

        /* ajax action */
        add_action( 'wc_ajax_yith_ywraq_order_action', array( $this, 'ajax' ) );

        add_filter( 'nonce_user_logged_out', array( $this, 'wpnonce_filter' ), 10, 2 );
        add_action( 'wp_loaded', array( $this, 'change_order_status' ) );
        add_action( 'ywraq_raq_message', array( $this, 'print_message' ), 10 );

        //if yit_contact_form is used
        if ( get_option( 'ywraq_inquiry_form_type' ) == 'yit-contact-form' ) {
            add_action( 'init', array( $this, 'yit_contact_form_before_sending_email' ), 9 );
            add_action( 'yit-sendmail-success', array( $this, 'yit_contact_form_after_sent_email' ) );
        }

        //change price on cart
        add_filter( 'woocommerce_add_cart_item', array($this, 'change_price') , 10, 2);
        add_filter( 'woocommerce_get_cart_item_from_session', array( $this, 'get_cart_item_from_session' ), 11, 2 );
        add_action( 'woocommerce_cart_calculate_fees', array( $this, 'add_cart_fee' ) );

        //add endpoint view-quote
        add_action( 'init', array( $this, 'add_endpoint') );
        add_action( 'template_redirect', array( $this, 'load_view_quote_page' ) );
        add_action( 'ywraq_view_quote', array( $this, 'check_permission_view_quote_page' ) );

        add_action( 'ywraq_time_validation', array( $this,'time_validation') );

        // contact form 7
        add_action( 'wpcf7_before_send_mail', array( $this, 'create_order_before_mail_cf7' ) );

     }


	/**
     * Add fee into cart after that the request was accepted
     *
     * @since 1.3.0
     * @return void
     */
    public function add_cart_fee() {
        $fees = WC()->session->get( 'request_quote_fee' );
        if ( $fees ) {
            foreach ( $fees as $fee ) {
                $taxable = ( $fee['line_subtotal_tax'] ) ? true : false;
                WC()->cart->add_fee( $fee['name'], $fee['line_total'], $taxable, $fee['line_total'] );
            }

        }
    }

    /**
     * Filter the wpnonce
     *
     * @param int    $uid
     * @param string $action
     *
     * @since 1.3.0
     * @return string
     */
    public function wpnonce_filter( $uid, $action ) {
        if ( strpos( 'accept-request-quote-', $action ) || strpos( 'reject-request-quote-', $action ) ) {
            return '';
        }

        return $uid;
    }

    /**
     * Return a $property defined in this class
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  mixed
     */
    public function __get( $property ) {

        if ( isset( $this->_data[$property] ) ) {
            return $this->_data[$property];
        }

    }

    /**
     * Add the endpoint for the page in my account to manage the order view
     *
     * @since 1.0.0
     */
    public function add_endpoint() {
        $view_quote = get_option( 'woocommerce_myaccount_view_quote_endpoint', 'view-quote' );
        $do_flush   = get_option( 'yith-ywraq-flush-rewrite-rules', 1 );

        add_rewrite_endpoint( $view_quote, EP_ROOT | EP_PAGES );

        if ( $do_flush ) {
            // change option
            update_option( 'yith-ywraq-flush-rewrite-rules', 0 );
            // the flush rewrite rules
            flush_rewrite_rules();
        }
    }

    /**
     * Load the page of saved cards
     *
     * @since 1.0.0
     */
    public function load_view_quote_page() {
        global $wp, $post;

        if ( !is_page( wc_get_page_id( 'myaccount' ) ) || !isset( $wp->query_vars['view-quote'] ) ) {
            return;
        }

        $order_id           = $wp->query_vars['view-quote'];
        $post->post_title   = sprintf( __( 'Quote #%s', 'yith-woocommerce-request-a-quote' ), $order_id );
        $post->post_content = WC_Shortcodes::shortcode_wrapper( array( $this, 'view_quote' ) );

        remove_filter( 'the_content', 'wpautop' );
    }

    /**
     * Show the quote detail
     *
     * @since 1.0.0
     */
    public function view_quote() {
        global $wp;
        if ( !is_user_logged_in() ) {
            wc_get_template( 'myaccount/form-login.php' );
        }
        else {
            $order_id = $wp->query_vars['view-quote'];
            wc_get_template( 'myaccount/view-quote.php',
                array( 'order_id'     => $order_id,
                       'current_user' => get_user_by( 'id', get_current_user_id() ) ), YITH_YWRAQ_DIR, YITH_YWRAQ_DIR );
        }
    }

    /**
     * Register Order Status
     *
     * @return void
     * @since  1.0
     * @author Emanuela Castorina
     */
    public function register_order_status() {
        register_post_status( 'wc-ywraq-new', array(
            'label'                     => __( 'New Quote Request', 'yith-woocommerce-request-a-quote' ),
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop( 'New Quote Request <span class="count">(%s)</span>', 'New Quote Requests <span class="count">(%s)</span>', 'yith-woocommerce-request-a-quote' )
        ) );

        register_post_status( 'wc-ywraq-pending', array(
            'label'                     => __( 'Pending Quote', 'yith-woocommerce-request-a-quote' ),
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop( 'Pending Quote <span class="count">(%s)</span>', 'Pending Quote <span class="count">(%s)</span>','yith-woocommerce-request-a-quote' )
        ) );


        register_post_status( 'wc-ywraq-expired', array(
            'label'                     => __( 'Expired Quote', 'yith-woocommerce-request-a-quote' ),
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop( 'Expired Quote <span class="count">(%s)</span>', 'Expired Quotes <span class="count">(%s)</span>','yith-woocommerce-request-a-quote' )
        ) );

        register_post_status( 'wc-ywraq-rejected', array(
            'label'                     => __( 'Rejected Quote', 'yith-woocommerce-request-a-quote' ),
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop( 'Rejected Quote <span class="count">(%s)</span>', 'Rejected Quote <span class="count">(%s)</span>','yith-woocommerce-request-a-quote' )
        ) );

    }

    /**
     * Add Custom Order Status to WC_Order
     *
     * @return array
     * @since  1.0
     * @author Emanuela Castorina
     */
    public function add_custom_status_to_order_statuses( $order_statuses ) {
        $order_statuses['wc-ywraq-new']      = __( 'New Quote Request', 'yith-woocommerce-request-a-quote' );
        $order_statuses['wc-ywraq-pending']  = __( 'Pending Quote', 'yith-woocommerce-request-a-quote' );
        $order_statuses['wc-ywraq-expired']  = __( 'Expired Quote', 'yith-woocommerce-request-a-quote' );
        $order_statuses['wc-ywraq-rejected'] = __( 'Rejected Quote', 'yith-woocommerce-request-a-quote' );

        return $order_statuses;
    }

    /**
     * Set custom status order editable
     *
     * @return bool
     * @since  1.0
     * @author Emanuela Castorina
     */
    public function order_is_editable( $editable, $order ) {
        if ( in_array( $order->get_status(), array( 'ywraq-new', 'ywraq-pending', 'ywraq-expired', 'ywraq-rejected' ) ) ) {
            return true;
        }
        return $editable;
    }

    /**
     * Update the price in the cart session
     *
     * @param array $cart_item
     * @param array $values
     *
     * @return array
     * @since  1.3.0
     * @author Emanuela Castorina
     */
    public function get_cart_item_from_session( $cart_item, $values ) {
        if ( ! isset( $cart_item['new_price'] ) ) {
            return $cart_item;
        }

        $cart_item['data']->price = $cart_item['new_price'];

        return $cart_item;
    }

    /**
     * Update the price in the cart session
     *
     * @param array $cart_item_data
     * @param array $cart_item_key
     *
     * @return array
     * @since  1.3.0
     * @author Emanuela Castorina
     */
    public function change_price( $cart_item_data, $cart_item_key ){
        if( ! isset($cart_item_data['new_price'] ) ){
            return $cart_item_data;
        }

        $cart_item_data['data']->price = $cart_item_data['new_price'];

        return $cart_item_data;
    }

    /**
     * Set custom status order editable
     *
     * @throws Exception
     * @since  1.0.0
     * @author Emanuela Castorina
     */
    public function create_order( $raq ) {

        if( ! defined('DOING_CREATE_RAQ_ORDER' ) ){
            define( 'DOING_CREATE_RAQ_ORDER', true );
        }

        $raq_content = $raq['raq_content'];

        if ( empty( $raq_content ) ) {
            return false;
        }

        if( isset( $raq['customer_id']) ){
            $customer_id = $raq['customer_id'];
        }else{
            $customer_id = get_current_user_id();
        }

        if( class_exists('WC_Subscriptions_Coupon')){
            remove_filter( 'woocommerce_get_discounted_price',  'WC_Subscriptions_Coupon::apply_subscription_discount_before_tax', 10);
            remove_filter( 'woocommerce_get_discounted_price','WC_Subscriptions_Coupon::apply_subscription_discount', 10);
        }

        $order = wc_create_order( $args = array(
            'status'      => 'ywraq-new',
            'customer_id' => apply_filters( 'ywraq_customer_id', $customer_id )
        ) );

        //save the customer message
        add_post_meta( $order->id, 'ywraq_customer_message', $raq['user_message'] );
        add_post_meta( $order->id, 'ywraq_customer_email', $raq['user_email'] );
        add_post_meta( $order->id, 'ywraq_customer_name', $raq['user_name'] );

        if( isset($raq['user_additional_field'] )){
            add_post_meta( $order->id, 'ywraq_customer_additional_field', $raq['user_additional_field'] );
        }

        if( isset($raq['user_additional_field_2'] )){
            add_post_meta( $order->id, 'ywraq_customer_additional_field_2', $raq['user_additional_field_2'] );
        }

        if( isset($raq['user_additional_field_3'] )){
            add_post_meta( $order->id, 'ywraq_customer_additional_field_3', $raq['user_additional_field_3'] );
        }

        if( isset($raq['attachment'] )){
            add_post_meta( $order->id, 'ywraq_customer_attachment', $raq['attachment'] );
        }

        if( isset($raq['other_email_content'])){
            add_post_meta( $order->id, 'ywraq_other_email_content', $raq['other_email_content'] );
        }

        if( isset($raq['billing-address'])){
            add_post_meta( $order->id, 'ywraq_billing_address', $raq['billing-address'] );
        }

        if( isset($raq['billing-phone'])){
            add_post_meta( $order->id, 'ywraq_billing_phone', $raq['billing-phone'] );
        }

        if( isset($raq['billing-vat'])){
            add_post_meta( $order->id, 'ywraq_billing_vat', $raq['billing-vat'] );
        }


        add_post_meta( $order->id, 'ywraq_raq_status', 'pending' );
        add_post_meta( $order->id, 'ywraq_raq', 'yes' );

        if ( defined( 'ICL_PLUGIN_PATH' ) && isset( $raq['lang']) && class_exists('YITH_YWRAQ_Multilingual_Email')  ) {
            update_post_meta( $order->id, 'wpml_language', $raq['lang'] );
        }

        $total     = 0;
        $tax_total = 0;

        $tax_rates      = array();
        $shop_tax_rates = array();

        foreach ( $raq_content as $item => $values ) {


            $_product = wc_get_product( isset( $values['variation_id'] ) ? $values['variation_id'] : $values['product_id'] );

            do_action('ywraq_order_adjust_price', $values, $_product);

            // Prices
            $base_price = $_product->get_price();
            $line_price = $_product->get_price() * $values['quantity'];

            // Tax data
            $taxes            = array();
            $discounted_taxes = array();

            // Get base tax rates
            if ( empty( $shop_tax_rates[$_product->tax_class] ) ) {
                $shop_tax_rates[$_product->tax_class] = WC_Tax::get_base_tax_rates( $_product->tax_class );
            }

            // Get item tax rates
            if ( empty( $tax_rates[$_product->get_tax_class()] ) ) {
                $tax_rates[$_product->get_tax_class()] = WC_Tax::get_rates( $_product->get_tax_class() );
            }

            if ( !$_product->is_taxable() ) {

                // Discounted Price (price with any pre-tax discounts applied)
                $discounted_price  = WC()->cart->get_discounted_price( $values, $base_price, true );
                $line_subtotal_tax = 0;
                $line_subtotal     = $line_price;
                $line_tax          = 0;
                $line_total        = WC_Tax::round( $discounted_price * $values['quantity'] );

                /**
                 * Prices include tax
                 */
            }elseif ( wc_prices_include_tax() ) {

                $base_tax_rates = $shop_tax_rates[$_product->tax_class];
                $item_tax_rates = $tax_rates[$_product->get_tax_class()];

                if ( $item_tax_rates !== $base_tax_rates ) {

                    // Work out a new base price without the shop's base tax
                    $taxes = WC_Tax::calc_tax( $line_price, $base_tax_rates, true, true );

                    // Now we have a new item price (excluding TAX)
                    $line_subtotal     = round( $line_price - array_sum( $taxes ), WC_ROUNDING_PRECISION );
                    $taxes             = WC_Tax::calc_tax( $line_subtotal, $item_tax_rates );
                    $line_subtotal_tax = array_sum( $taxes );

                    // Adjusted price (this is the price including the new tax rate)
                    $adjusted_price = ( $line_subtotal + $line_subtotal_tax ) / $values['quantity'];

                    // Apply discounts
                    $discounted_price = $this->get_discounted_price( $values, $adjusted_price, true );
                    $discounted_taxes = WC_Tax::calc_tax( $discounted_price * $values['quantity'], $item_tax_rates, true );
                    $line_tax         = array_sum( $discounted_taxes );
                    $line_total       = ( $discounted_price * $values['quantity'] ) - $line_tax;

                    /**
                     * Regular tax calculation (customer inside base and the tax class is unmodified
                     */
                }
                else {
                    // Work out a new base price without the item tax
                    $taxes = WC_Tax::calc_tax( $line_price, $item_tax_rates, true );

                    // Now we have a new item price (excluding TAX)
                    $line_subtotal     = $line_price - array_sum( $taxes );
                    $line_subtotal_tax = array_sum( $taxes );

                    // Calc prices and tax (discounted)
                    $discounted_price = $line_subtotal;
                    $discounted_taxes = WC_Tax::calc_tax( $discounted_price * $values['quantity'], $item_tax_rates, true );
                    $line_tax         = array_sum( $discounted_taxes );
                    $line_total       = ( $discounted_price * $values['quantity'] ) - $line_tax;

                }
            }
            /**
             * Prices exclude tax
             */
            else {

                $item_tax_rates = $tax_rates[$_product->get_tax_class()];

                // Work out a new base price without the shop's base tax
                $taxes = WC_Tax::calc_tax( $line_price, $item_tax_rates );

                // Now we have the item price (excluding TAX)
                $line_subtotal     = $line_price;
                $line_subtotal_tax = array_sum( $taxes );

                // Now calc product rates
                $discounted_price      = $line_subtotal;
                $discounted_taxes      = WC_Tax::calc_tax( $discounted_price * $values['quantity'], $item_tax_rates );
                $discounted_tax_amount = array_sum( $discounted_taxes );
                $line_tax              = $discounted_tax_amount;
                $line_total            = $discounted_price * $values['quantity'];


            }

            $variations = isset( $values['variations'] ) ? $values['variations'] : array();

            $item_id = $order->add_product(
                $_product,
                $values['quantity'],
                array(
                    'variation' => $variations,
                    'totals'    => array(
                        'subtotal'     => $line_subtotal,
                        'subtotal_tax' => $line_subtotal_tax,
                        'total'        => $line_total,
                        'tax'          => $line_tax,
                        'tax_data'     => array( 'total' => $discounted_taxes, 'subtotal' => $taxes ) // Since 2.2
                    )
                )
            );

            if ( !$item_id ) {
                throw new Exception( sprintf( __( 'Error %d: unable to create the order. Please try again.', 'yith-woocommerce-request-a-quote' ), 402 ) );
            }
            else {

                do_action('ywraq_order_item_meta', $values, $item_id);

                $total += $line_total;
                $tax_total += $line_tax;
            }
        }

        $order->set_total( $total + $tax_total );
        $order->update_taxes();
        WC()->session->set( 'raq_new_order', $order->id );

        do_action( 'ywraq_after_create_order', $order->id, $_POST );

        return $order->id;

    }

    /**
     * Add to cart the products in the request, add also a coupoun with the discount applied
     *
     * @throws Exception
     * @since  1.0.0
     * @author Emanuela Castorina
     */
    public function order_accepted( $order_id ) {

        WC()->cart->empty_cart( true );
        WC()->cart->get_cart_from_session();
        WC()->session->set( 'order_awaiting_payment', $order_id );

        // Clear current cart

        // Load the previous order - Stop if the order does not exist
        $order = wc_get_order( $order_id );

        if ( empty( $order->id ) ) {
            return;
        }

        $order->update_status( 'pending' );

        update_post_meta( $order->id, 'ywraq_raq_status', 'accepted' );

        $order_items    = $order->get_items();
        $minimum_amount = $order->get_subtotal();
        $order_discount = $order->get_total_discount();

        // Copy products from the order to the cart
        foreach ( $order_items as $order_key => $item ) {

            // Load all product info including variation data
            $product_id   = (int) $item['product_id'];
            $quantity     = (int) $item['qty'];
            $variation_id = (int) $item['variation_id'];
            $variations   = array();

            if ( $quantity > 1 ) {
                $new_price = $item['line_subtotal'] / $quantity;
            } else {
                $new_price = $item['line_subtotal'];
            }

            $cart_item_data = array(
                'new_price' => $new_price
            );

            $cart_item_data = apply_filters( 'ywraq_add_to_cart', $cart_item_data, $item );

            foreach ( $item['item_meta'] as $meta_name => $meta_value ) {
                if ( taxonomy_is_product_attribute( $meta_name ) ) {
                    $variations[$meta_name] = $meta_value[0];
                } elseif ( meta_is_product_attribute( $meta_name, $meta_value, $product_id ) ) {
                    $variations[$meta_name] = $meta_value[0];
                }
            }

            do_action( 'ywraq_before_add_to_cart_in_order_accepted' );

            $item_id = WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variations, $cart_item_data );

            if ( ! $item_id ) {
                if ( ( $item['line_subtotal'] - $item['line_total'] ) >= 0 ) {
                    $order_discount -= $item['line_subtotal'] - $item['line_total'];
                    $minimum_amount -= $item['line_subtotal'];
                }
            }

        }

        $fees = $order->get_fees();
        WC()->session->set( 'request_quote_fee', $fees );
      //  WC()->cart->calculate_totals();

        if ( $order_discount > 0 ) {
            $coupon = array(
                'coupon_amount'  => $order_discount,
                'minimum_amount' => $minimum_amount
            );

            WC()->session->set( 'request_quote_discount', $coupon );
            WC()->cart->add_discount( $this->label_coupon );
        }

        do_action( 'change_status_mail', array( 'order' => $order, 'status' => 'accepted' ) );

    }

    /**
     * Create Coupon
     *
     * @return array
     * @since  1.0.0
     * @author Emanuela Castorina
     */
    public function create_coupon_cart_discount( $args, $code ) {
        if ( $code == apply_filters( 'woocommerce_coupon_code', $this->label_coupon ) && isset( WC()->session->request_quote_discount ) ) {
            $args = WC()->session->request_quote_discount;
        }

        return $args;
    }

    /**
     * Add actions to WC Order Editor
     *
     * @return array
     * @since  1.0.0
     * @author Emanuela Castorina
     */
    public function add_order_actions( $actions ) {
        $actions['ywraq-send-quote'] = __( 'Send the Quote', 'yith-woocommerce-request-a-quote' );
        return $actions;
    }

    /**
     * Add metabox in the order editor
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  void
     */
    public function  add_metabox() {

        $args = require_once( YITH_YWRAQ_DIR . 'plugin-options/metabox/ywraq-metabox-order.php' );
        if ( ! function_exists( 'YIT_Metabox' ) ) {
            require_once( YITH_YWRAQ_DIR . 'plugin-fw/yit-plugin.php' );
        }
        $metabox = YIT_Metabox( 'yith-ywraq-metabox-order' );
        $metabox->init( $args );
    }

    /**
     * Send the quote to the customer
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  void
     */
    public function send_quote( $post_id, $post ) {

        if ( !isset( $_POST['yit_metaboxes'] ) || !isset( $_POST['yit_metaboxes']['_ywraq_safe_submit_field'] ) || $_POST['yit_metaboxes']['_ywraq_safe_submit_field'] != 'send_quote' ) {
            return;
        }

        $order = wc_get_order( $post_id );
        do_action( 'create_pdf', $order->id );
        do_action( 'send_quote_mail', $order->id );

    }

    /**
     * Change the status of the quote
     *
     * @param int $post_id
     *
     * @return void
     * @since 1.0.0
     */
    public function change_status_quote( $post_id ) {

        if ( ! isset( $_POST['yit_metaboxes'] ) || ! isset( $_POST['yit_metaboxes']['_ywraq_safe_submit_field'] ) || $_POST['yit_metaboxes']['_ywraq_safe_submit_field'] != 'send_quote' ) {
            return;
        }

        $order = wc_get_order( $post_id );

        if( $order  ){
            $order->update_status( 'ywraq-pending' );
        }

        return;

    }


    /**
     * Remove Quotes from Order query
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  array
     */
    public function my_account_my_orders_query( $args ) {

        $args['meta_query'] = array(
            array(
                'key'     => 'ywraq_raq_status',
                'compare' => 'NOT EXISTS',
            ),
        );

        $args['post_status'] = array_diff( $args['post_status'], $this->_data['raq_order_status'] );
        return $args;
    }

    /**
     * Add quotes list to my-account page
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  void
     */
    public function my_account_my_quotes() {
        wc_get_template( 'myaccount/my-quotes.php', null, YITH_YWRAQ_DIR, YITH_YWRAQ_DIR );
    }

    /**
     * Switch a ajax call
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  void
     */
    public function ajax() {
        if ( isset( $_POST['ywraq_order_action'] ) ) {
            if ( method_exists( $this, 'ajax_' . $_POST['ywraq_order_action'] ) ) {
                $s = 'ajax_' . $_POST['ywraq_order_action'];
                $this->$s();
            }
        }
    }

    public function create_order_before_mail_cf7( $cf ) {

        $form_id = get_option( 'ywraq_inquiry_contact_form_7_id' );

        if( isset( $_REQUEST['_wpcf7'] ) && $_REQUEST['_wpcf7'] == $form_id ) {
            $this->ajax_create_order( true );
        }
    }

    public function ajax_mail_sent_order_created() {

        $order_id = isset( $_COOKIE['yith_ywraq_order_id'] ) ? $_COOKIE['yith_ywraq_order_id'] : 0;

        if( ! $order_id ){
            yith_ywraq_add_notice( __( 'An error as occurred creating your request. Please try again.', 'yith-woocommerce-request-a-quote' ), 'error' );

            wp_send_json(
                array(
                    'rqa_url' => YITH_Request_Quote()->get_raq_page_url(),
                )
            );
        }

        wc_setcookie( 'yith_ywraq_order_id', 0, time() - HOUR_IN_SECONDS );
        YITH_Request_Quote()->clear_raq_list();


        if( is_user_logged_in() && $order_id ){
            yith_ywraq_add_notice( sprintf(__( 'Your request has been sent successfully. You can see details here: <a href="%s">#%s</a>', 'yith-woocommerce-request-a-quote' ), YITH_YWRAQ_Order_Request()->get_view_order_url($order_id), $order_id ), 'success' );
        }else{
            yith_ywraq_add_notice( __( 'Your request has been sent successfully.', 'yith-woocommerce-request-a-quote' ), 'success' );
        }

        wp_send_json(
            array(
                'rqa_url' => YITH_Request_Quote()->get_raq_page_url(),
            )
        );
    }

    /**
     * Called to create an order from a request sended with contact form 7
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  void
     */
    public function ajax_create_order( $is_cf7 = false ) {

        $exclude_params = apply_filters( 'ywraq-contact-form7-exclusion-list', array( '_wpcf7', '_wpcf7_version', '_wpcf7_locale', '_wpcf7_unit_tag', '_wpnonce', 'your-name', 'your-email', 'your-subject', 'your-message', 'action', 'ywraq_order_action',
            'billing-address', 'billing-phone', 'billing-vat', 'g-recaptcha-response', '_wpcf7_is_ajax_call' ) );

        $other_email_content = '';
        if( ! empty($_POST)  ){
            foreach ( $_POST as $key => $value ) {
                if( ! in_array( $key, $exclude_params ) ){
                    $other_email_content .= sprintf('<strong>%s</strong>: %s<br>', $key, $value);
                }
            }
        }

        $raq_content = YITH_Request_Quote()->get_raq_return();
        $args = array(
            'user_name'           => $_POST['your-name'],
            'user_email'          => $_POST['your-email'],
            'user_message'        => $_POST['your-message'],
            'other_email_content' => $other_email_content,
            'raq_content'         => $raq_content
        );

        if( isset( $_POST['billing-address'])){
            $args['billing-address'] =  $_POST['billing-address'];
        }

        if( isset( $_POST['billing-phone'])){
            $args['billing-phone'] =  $_POST['billing-phone'];
        }

        if( isset( $_POST['billing-vat'])){
            $args['billing-vat'] =  $_POST['billing-vat'];
        }

        if( isset( $_POST['lang'])){
            $args['lang'] =  $_POST['lang'];
        }


        $new_order = $this->create_order( $args );
        if( $new_order ){
            wc_setcookie( 'yith_ywraq_order_id', $new_order, 0 );
        }

        if( ! $is_cf7 ) {

            $this->ajax_mail_sent_order_created();
        }
    }

    /**
     * Change the status of Quote in 'accepted'
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  void
     */
    public function ajax_accept_order() {
        if ( !isset( $_POST['order_id'] ) ) {

            $message = __( 'An error occurred. Please, contact site administrator', 'yith-woocommerce-request-a-quote' );
            $result  = array(
                'result'  => 0,
                'message' => $message,
            );
        }
        else {
            $order = wc_get_order( $_POST['order_id'] );
            $this->order_accepted( $order->id );

            $result = array(
                'result'  => 1,
                'rqa_url' => function_exists('wc_get_checkout_url') ? wc_get_checkout_url() : WC()->cart->get_checkout_url(),
            );
        }

        wp_send_json(
            $result
        );
    }

    /**
     * Reject the quote
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  void
     */
    public function ajax_reject_order() {
        if ( !isset( $_POST['order_id'] ) ) {
            $message = __( 'An error occurred. Please, contact site administrator', 'yith-woocommerce-request-a-quote' );
            $result  = array(
                'result'  => 0,
                'message' => $message,
            );
        }
        else {
            $order          = wc_get_order( $_POST['order_id'] );
            $current_status = $order->get_status();

            $order->update_status( 'ywraq-rejected' );
            $args = array(
                'order' => $order,
                'status' => 'rejected'
            );
            do_action( 'change_status_mail', $args );
            $result = array(
                'result'  => 1,
                'status'  => __( 'rejected', 'yith-woocommerce-request-a-quote' ),
                'rqa_url' => function_exists('wc_get_checkout_url') ? wc_get_checkout_url() : WC()->cart->get_checkout_url(),
            );
        }

        wp_send_json(
            $result
        );
    }

    /**
     * Delete post meta ywraq_status
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  void
     */
    public function raq_processed( $order_id ) {
        delete_post_meta( $order_id, 'ywraq_raq_status' );
    }

    /**
     * Change the label of coupon
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  string
     */
    public function label_coupon( $string, $coupon ) {

        //change the label if the order is generated from a quote
        if ( $coupon->code != $this->label_coupon ) {
            return $string;
        }

        $label = esc_html( __( 'Discount:', 'yith-woocommerce-request-a-quote' ) );
        return $label;
    }

    /**
     * Manage the request from the email of customer
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  void
     */
    public function change_order_status() {
        if ( !isset( $_GET['raq_nonce'] ) || !isset( $_GET['status'] ) || !isset( $_GET['request_quote'] ) ) {
            return;
        }

        $status   = $_GET['status'];
        $order_id = $_GET['request_quote'];

        $order      = wc_get_order( $_GET['request_quote'] );
        $user_email = get_post_meta( $order_id, 'ywraq_customer_email', true );
        $this->is_expired( $order_id );
        $current_status = $order->get_status();

        $args = array(
            'message' => '',
        );
        if ( !ywraq_verify_token( $_GET['raq_nonce'], 'accept-request-quote', $order_id, $user_email ) && !ywraq_verify_token( $_GET['raq_nonce'], 'reject-request-quote', $order_id, $user_email ) ) {
            $args['message']    = sprintf( __( 'You do not have permission to read the quote', 'yith-woocommerce-request-a-quote' ), $order_id );
            $this->args_message = $args;
            return;
        }
        if ( $status == 'accepted' && ywraq_verify_token( $_GET['raq_nonce'], 'accept-request-quote', $order_id, $user_email ) ) {

            if ( in_array( $current_status, array( 'ywraq-pending', 'pending' ) ) ) {
                $this->order_accepted( $order_id );
                wp_safe_redirect( function_exists('wc_get_checkout_url') ? wc_get_checkout_url() : WC()->cart->get_checkout_url() );
                exit;
            }
            else {
                switch ( $current_status ) {
                    case 'ywraq-rejected':
                        $args['message'] = sprintf( __( 'Quote n. %d has been rejected and is not available', 'yith-woocommerce-request-a-quote' ), $order_id );
                        break;
                    case 'ywraq-expired':
                        $args['message'] = sprintf( __( 'Quote n. %d has expired and is not available', 'yith-woocommerce-request-a-quote' ), $order_id );
                        break;
                    default:
                        $args['message'] = sprintf( __( 'Quote n. %d can\'t be accepted because its status is: %s', 'yith-woocommerce-request-a-quote' ), $order_id, $current_status );
                        break;
                }
            }
        }
        else {
            if ( $current_status == 'ywraq-rejected' && $status == 'rejected' ) {
                $args['message'] = sprintf( __( 'Quote n. %d has been rejected', 'yith-woocommerce-request-a-quote' ), $order_id );
            }
            elseif ( $current_status == 'ywraq-expired' ) {
                $args['message'] = sprintf( __( 'Quote n. %d has expired and is not available', 'yith-woocommerce-request-a-quote' ), $order_id );
            }
            elseif ( $current_status != 'ywraq-pending' && $current_status != 'pending' ) {
                $args['message'] = sprintf( __( 'Quote n. %d can\'t be rejected because its status is: %s', 'yith-woocommerce-request-a-quote' ), $order_id, $current_status );
            }
            else {
                if ( !isset( $_GET['raq_confirm'] ) && !isset( $_GET['confirm'] ) && $status == 'rejected' && ywraq_verify_token( $_GET['raq_nonce'], 'reject-request-quote', $order_id, $user_email ) ) {
                    $args = array(
                        'status'        => $status,
                        'raq_nonce'     => $_GET['raq_nonce'],
                        'request_quote' => $order_id,
                        'raq_confirm'   => 'no'
                    );

                    wp_safe_redirect( add_query_arg( $args, YITH_Request_Quote()->get_raq_page_url() ) );
                    exit;
                }
                else {

                    if ( !isset( $_GET['confirm'] ) ) {
                        $args = array(
                            'status'    => 'rejected',
                            'raq_nonce' => $_GET['raq_nonce'],
                            'order_id'  => $_GET['request_quote'],
                            'confirm'   => 'no'
                        );

                    }
                    else {
                        $order->update_status( 'ywraq-rejected' );

                        $ar = array(
                            'order' => $order,
                            'status' => 'rejected'
                        );
                        do_action( 'change_status_mail', $ar );

                        $args['message'] = sprintf( __( 'The quote n. %d has been rejected', 'yith-woocommerce-request-a-quote' ), $order_id );
                    }
                }
            }
        }

        $this->args_message = $args;
    }

    /**
     * Print message in Request a Quote after that function change_order_status is called
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  void
     */
    public function print_message() {
        wc_get_template( 'request-quote-message.php', $this->args_message, YITH_YWRAQ_DIR, YITH_YWRAQ_DIR );
    }

    /**
     * Manage coupon errors
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  string
     */
    public function manage_coupon_errors( $err, $err_code, $obj ) {

        $order_id = WC()->session->order_awaiting_payment;

        if ( ! $this->is_quote( $order_id ) ) {
            return $err;
        }

        if ( $err_code == 101 ) {
            $err = apply_filters( 'ywraq_coupon_error', __( 'Sorry, you have changed content of your cart. Discount has now been removed from your order', 'yith-woocommerce-request-a-quote' ), $err_code, $obj );
        }

        return $err;
    }

    /**
     * Manage coupon message
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  string
     */
    public function manage_coupon_message( $msg, $msg_code, $obj ) {
        $order_id = WC()->session->order_awaiting_payment;

        if ( ! $this->is_quote( $order_id ) ) {
            return $msg;
        }

        $msg = '';
        if ( $msg_code == 200 ) {
            $msg = __( 'Discount applied successfully.', 'yith-woocommerce-request-a-quote' );
        } elseif ( $msg_code == 201 ) {
            $msg = __( 'Discount removed successfully.', 'yith-woocommerce-request-a-quote' );
        }

        return $msg;
    }

    /**
     * Check if an order is created from a request quote
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  bool
     */
    public function is_quote( $order_id ) {
        if ( get_post_meta( $order_id, 'ywraq_raq', true ) == 'yes' ) {
            return true;
        }

        return false;
    }

    /**
     * Check if an order is created from a request quote
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  bool
     */
    public function is_expired( $order_id ) {
        $order          = wc_get_order( $order_id );
        $current_status = $order->get_status();
        $ex_opt         = get_post_meta( $order_id, '_ywcm_request_expire', true );

        if ( $current_status == 'ywraq-expired' || $ex_opt == '' ) {
            return true;
        }

        //check if expired
        $expired_data = strtotime( $ex_opt ) + ( 24 * 60 * 60 ) - 1;
        if ( $expired_data < time() ) {
            $order->update_status( 'ywraq-expired' );

            return true;
        }

        return false;
    }

    /**
     * Function called from Cron to swich in
     * ywraq-expired order status the request expired
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  bool
     */
    public function time_validation() {
        $orders = get_posts( array(
            'numberposts' => - 1,
            'meta_query'  => array(
                array(
                    'key'     => '_ywcm_request_expire',
                    'value'   => '',
                    'compare' => '!='
                )
            ),
            'post_type'   => 'shop_order',
            'post_status' => array( 'wc-pending', 'wc-ywraq-pending' )
        ) );

        foreach ( $orders as $order ) {
            $expired_data = strtotime( get_post_meta( $order->ID, '_ywcm_request_expire', true ) );
            $expired_data += ( 24 * 60 * 60 ) - 1;
            if ( $expired_data < time() ) {
                wp_update_post( array( 'ID' => $order->ID, 'post_status' => 'wc-ywraq-expired' ) );
            }
        }
    }

    /**
     * Function called if yit-contact-form in used to send the request
     * grab the post array ad save it in $yit_contact_form_post
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  bool
     */
    public function yit_contact_form_before_sending_email() {
        if ( isset( $_POST['yit_contact'] ) ) {
            $this->yit_contact_form_post = $_POST['yit_contact'];
        }
    }

    /**
     * Function called if yit-contact-form in used to send the request
     * after the email is sent to administrator
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  bool
     */
    public function yit_contact_form_after_sent_email() {

        if ( !empty( $this->yit_contact_form_post ) && isset( $this->yit_contact_form_post['name'] ) && isset( $this->yit_contact_form_post['email'] ) ) {

            $args = array(
                'user_name'    => $this->yit_contact_form_post['name'],
                'user_email'   => $this->yit_contact_form_post['email'],
                'user_message' => isset( $this->yit_contact_form_post['message'] ) ? $this->yit_contact_form_post['message'] : '',
                'raq_content'  => YITH_Request_Quote()->get_raq_return()
            );

            $new_order = $this->create_order( $args );

           YITH_Request_Quote()->clear_raq_list();

            if( is_user_logged_in() ){
                yith_ywraq_add_notice( sprintf(__( 'Your request has been sent successfully. You can see details here: <a href="%s">#%s</a>', 'yith-woocommerce-request-a-quote' ), YITH_YWRAQ_Order_Request()->get_view_order_url($new_order), $new_order ), 'success' );
            }else{
                yith_ywraq_add_notice( __( 'Your request has been sent successfully.', 'yith-woocommerce-request-a-quote' ), 'success' );
            }

        }
        else {
            yith_ywraq_add_notice( __( 'An error has occurred. Please, contact site administrator.', 'yith-woocommerce-request-a-quote' ), 'error' );
        }

    }

    /**
     * Return the quote detail page
     *
     * @since   1.0.0
     * @author  Emanuela Castorina
     * @return  string
     */
    public function get_view_order_url( $order_id , $admin = false ) {
        if( $admin ){
            $view_order_url =  admin_url( 'post.php?post=' . $order_id . '&action=edit' );
        }else{
            $view_order_url = wc_get_endpoint_url( 'view-quote', $order_id, wc_get_page_permalink( 'myaccount' ) );
        }

        return apply_filters( 'ywraq_get_quote_order_url', $view_order_url, $order_id );
    }


}


/**
 * Unique access to instance of YITH_YWRAQ_Order_Request class
 *
 * @return \YITH_YWRAQ_Order_Request
 */
function YITH_YWRAQ_Order_Request() {
    return YITH_YWRAQ_Order_Request::get_instance();
}

YITH_YWRAQ_Order_Request();