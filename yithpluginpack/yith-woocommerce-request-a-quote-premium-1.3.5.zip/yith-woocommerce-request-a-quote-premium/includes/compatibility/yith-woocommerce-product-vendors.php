<?php

if ( !defined( 'ABSPATH' ) || !defined( 'YITH_YWRAQ_VERSION' ) ) {
	exit; // Exit if accessed directly
}


/**
 * YWRAQ_Multivendor class to add compatibility with YITH WooCommerce Multivendor
 *
 * @class   YWRAQ_Multivendor
 * @package YITH WooCommerce Request A Quote
 * @since   1.3.0
 * @author  Yithemes
 */
if ( ! class_exists( 'YWRAQ_Multivendor' ) ) {

	class YWRAQ_Multivendor {

		/**
		 * Single instance of the class
		 *
		 * @var \YWRAQ_Multivendor
		 */
		protected static $instance;


		/**
		 * @var string
		 */
		protected $current_order = '';


		/**
		 * Returns single instance of the class
		 *
		 * @return \YWRAQ_Multivendor
		 * @since 1.0.0
		 */
		public static function get_instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Constructor
		 *
		 * Initialize class and registers actions and filters to be used
		 *
		 * @since  1.3.0
		 * @author Emanuela Castorina
		 */
		public function __construct() {

			//Send request quote compaibility
			add_filter( 'ywraq_multivendor_email', array( $this, 'trigger_email_send_request' ), 15, 3 );

			add_action( 'ywraq_after_create_order', array( $this, 'create_suborder'), 10, 2);
			add_filter( 'woocommerce_new_order_data' , array( $this, 'change_status_to_suborder'));
			add_filter( 'woocommerce_hidden_order_itemmeta' , array( $this, 'add_hidden_order_itemmeta'));

			//Send request quote compatibility
			//add_filter( 'ywraq_multivendor_quote_email', array( $this, 'trigger_quote_email' ), 15, 2 );
			add_filter( 'woocommerce_order_get_items', array( $this, 'filter_order_items'), 10, 2);
			add_filter( 'woocommerce_admin_order_data_after_order_details', array( $this, 'update_order_totals'), 10);


//			if( 'yes' == get_option( 'yith_wpv_vendors_option_subscription_management', 'no' ) ){
//				add_action( 'admin_menu', array($this,'vendor_admin_init'), 4);
//				add_filter( 'yith_wpv_vendors_allowed_post_types', array( $this, 'add_allowed_post_types_for_vendors' ) );
//				add_filter( 'yith_wcmv_subscription_caps', array( $this, 'add_subscription_cap' ) );
//			}else{
//				remove_action( 'woocommerce_variation_options', array( YITH_WC_Subscription_Admin(), 'add_type_variation_options' ), 10, 3 );
//				remove_filter( 'product_type_options', array( YITH_WC_Subscription_Admin(), 'add_type_options' ) );
//			}
		}

		public function filter_order_items( $items, $order ) {

			if( ( defined('DOING_CREATE_RAQ_ORDER' ) &&  DOING_CREATE_RAQ_ORDER )  || ( ! get_post_meta( $order->id, 'ywraq_raq_status', true)  && $order->post->post_parent != 0 ) ){
				return $items;
			}

			$new_items = array();

			if( ! empty( $items ) ){
				foreach ( $items as $key => $item ) {
					if( isset( $item['product_id'] ) ){
						$vendor = yith_get_vendor( $item['product_id'], 'product' );
						if ( ! $vendor->is_valid() ) {
							$new_items[ $key ] = $item;
						}
					}else{
						$new_items[ $key ] = $item;
					}
				}
			}

//			var_dump( $new_items );
//			//die();
			return $new_items;
		}

		public function update_order_totals( $order ) {
			$order->calculate_totals();
		}

		/**
		 * Create suborders for vendors
		 *
		 * @param $order_id
		 * @param $posted
		 *
		 * @since  1.3.0
		 * @author Emanuela Castorina
		 */
		public function create_suborder( $order_id, $posted ) {
			$this->current_order = $order_id;
			YITH_Vendors()->orders->check_suborder( $order_id, $posted );
		}


		/**
		 * Set the status "New quote Request" to suborders
		 * @param array $args
		 *
		 * @return mixed
		 */
		public function change_status_to_suborder( $args ) {
			if ( $this->current_order && isset( $args['post_parent'] ) && $this->current_order == $args['post_parent'] ) {
				$args['post_status'] = 'wc-ywraq-new';
			}

			return $args;
		}


		/**
		 * Switch the products of the request to each vendors that are owner, or to administrator
		 *
		 * @param $return
		 * @param $args
		 * @param $email_class
		 *
		 * @return mixed
		 *
		 * @since  1.3.0
		 * @author Emanuela Castorina
		 */
		public function trigger_email_send_request( $return, $args, $email_class ) {

			$vendors_list = array();
			$admin_list   = array();
			if ( ! empty( $email_class->raq['raq_content'] ) ) {
				foreach ( $email_class->raq['raq_content'] as $raq_item => $item ) {
					$vendor = yith_get_vendor( $item['product_id'], 'product' );
					if ( $vendor->is_valid() ) {
						$vendors_list[$vendor->id][$raq_item] = $email_class->raq['raq_content'][$raq_item];
					} else {
						$admin_list[$raq_item] = $email_class->raq['raq_content'][$raq_item];
					}
				}
			}

			if ( ! empty( $vendors_list ) ) {
				foreach ( $vendors_list as $vendor_id => $raq_vendor ) {

					$email_class->raq['raq_content'] = $raq_vendor;
					$vendor                          = yith_get_vendor( $vendor_id, 'vendor' );

					if ( isset( $vendor->store_email ) && $vendor->store_email ) {
						$email_class->get_recipient = $vendor->store_email;
					} else {
						$owner_id = $vendor->get_owner();
						if ( ! empty( $owner_id ) ) {
							$owner                      = get_user_by( 'id', $owner_id );
							$email_class->get_recipient = $owner->user_email;
						}
					}

					$return = $email_class->send( $email_class->get_recipient, $email_class->get_subject(), $email_class->get_content(), $email_class->get_headers(), $email_class->get_attachments( $args['attachment'] ) );

				}
			}

			if ( ! empty( $admin_list ) ) {
				$email_class->raq['raq_content'] = $admin_list;
				$return                          = $email_class->send( $email_class->get_recipient(), $email_class->get_subject(), $email_class->get_content(), $email_class->get_headers(), $email_class->get_attachments( $args['attachment'] ) );
			}

			return $return;
		}

		/**
		 * Add hidden order itemmeta from Quote Email
		 * @param $itemmeta
		 *
		 * @return array
		 */
		public function add_hidden_order_itemmeta( $itemmeta  ) {
			$itemmeta[] = '_parent_line_item_id';
			$itemmeta[] = '_commission_id';

			return $itemmeta;
		}


		/**
		 * Overwrite the email
		 *
		 * @param $return
		 * @param $email
		 *
		 * @return mixed
		 */
		public function trigger_quote_email( $return, $email ) {

			return $return;
		}
	}

}

/**
 * Unique access to instance of YWRAQ_Multivendor class
 *
 * @return \YWRAQ_Multivendor
 */
function YWRAQ_Multivendor() {
	return YWRAQ_Multivendor::get_instance();
}

YWRAQ_Multivendor();