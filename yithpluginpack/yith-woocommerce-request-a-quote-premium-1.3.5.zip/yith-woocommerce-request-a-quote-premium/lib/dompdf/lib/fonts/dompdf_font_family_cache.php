<?php return array (
  'sans-serif' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Helvetica',
    'bold' => DOMPDF_FONT_DIR . 'Helvetica-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Helvetica-Oblique',
    'bold_italic' => DOMPDF_FONT_DIR . 'Helvetica-BoldOblique',
  ),
  'times' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Times-Roman',
    'bold' => DOMPDF_FONT_DIR . 'Times-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Times-Italic',
    'bold_italic' => DOMPDF_FONT_DIR . 'Times-BoldItalic',
  ),
  'times-roman' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Times-Roman',
    'bold' => DOMPDF_FONT_DIR . 'Times-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Times-Italic',
    'bold_italic' => DOMPDF_FONT_DIR . 'Times-BoldItalic',
  ),
  'courier' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Courier',
    'bold' => DOMPDF_FONT_DIR . 'Courier-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Courier-Oblique',
    'bold_italic' => DOMPDF_FONT_DIR . 'Courier-BoldOblique',
  ),
  'helvetica' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Helvetica',
    'bold' => DOMPDF_FONT_DIR . 'Helvetica-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Helvetica-Oblique',
    'bold_italic' => DOMPDF_FONT_DIR . 'Helvetica-BoldOblique',
  ),
  'zapfdingbats' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'ZapfDingbats',
    'bold' => DOMPDF_FONT_DIR . 'ZapfDingbats',
    'italic' => DOMPDF_FONT_DIR . 'ZapfDingbats',
    'bold_italic' => DOMPDF_FONT_DIR . 'ZapfDingbats',
  ),
  'symbol' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Symbol',
    'bold' => DOMPDF_FONT_DIR . 'Symbol',
    'italic' => DOMPDF_FONT_DIR . 'Symbol',
    'bold_italic' => DOMPDF_FONT_DIR . 'Symbol',
  ),
  'serif' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Times-Roman',
    'bold' => DOMPDF_FONT_DIR . 'Times-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Times-Italic',
    'bold_italic' => DOMPDF_FONT_DIR . 'Times-BoldItalic',
  ),
  'monospace' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Courier',
    'bold' => DOMPDF_FONT_DIR . 'Courier-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Courier-Oblique',
    'bold_italic' => DOMPDF_FONT_DIR . 'Courier-BoldOblique',
  ),
  'fixed' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Courier',
    'bold' => DOMPDF_FONT_DIR . 'Courier-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Courier-Oblique',
    'bold_italic' => DOMPDF_FONT_DIR . 'Courier-BoldOblique',
  ),
  'segoe' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'ca62b8dbf47b24df65c291a7b33ced62',
  ),
  'roboto slab' => 
  array (
    'normal' => DOMPDF_FONT_DIR . '5ffc7e496d2efff1121d16976e8578be',
    'bold' => DOMPDF_FONT_DIR . 'fa16cc67cfbb3d1319f7702b1bb90c84',
  ),
  'open sans' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'a32da215612cdbd93b93eb74bcab3b40',
    'bold' => DOMPDF_FONT_DIR . 'ec66c4851b9656cec2800868fb6ca4a3',
    'italic' => DOMPDF_FONT_DIR . 'e1ed1c78d201fe6255daee12e8820a6d',
    'bold_italic' => DOMPDF_FONT_DIR . 'c1583238aa915ad7e56d544a3a5f8f4e',
  ),
  'dejavu sans' =>
	  array (
		  'bold' => DOMPDF_FONT_DIR . 'DejaVuSans-Bold',
		  'bold_italic' => DOMPDF_FONT_DIR . 'DejaVuSans-BoldOblique',
		  'italic' => DOMPDF_FONT_DIR . 'DejaVuSans-Oblique',
		  'normal' => DOMPDF_FONT_DIR . 'DejaVuSans',
	  ),
  'dejavu sans mono' =>
	  array (
		  'bold' => DOMPDF_FONT_DIR . 'DejaVuSansMono-Bold',
		  'bold_italic' => DOMPDF_FONT_DIR . 'DejaVuSansMono-BoldOblique',
		  'italic' => DOMPDF_FONT_DIR . 'DejaVuSansMono-Oblique',
		  'normal' => DOMPDF_FONT_DIR . 'DejaVuSansMono',
	  ),
  'dejavu serif' =>
	  array (
		  'bold' => DOMPDF_FONT_DIR . 'DejaVuSerif-Bold',
		  'bold_italic' => DOMPDF_FONT_DIR . 'DejaVuSerif-BoldItalic',
		  'italic' => DOMPDF_FONT_DIR . 'DejaVuSerif-Italic',
		  'normal' => DOMPDF_FONT_DIR . 'DejaVuSerif',
	  ),
) ?>