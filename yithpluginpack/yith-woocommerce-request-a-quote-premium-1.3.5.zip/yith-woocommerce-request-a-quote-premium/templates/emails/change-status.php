<?php
/**
 * HTML Template Email Request a Quote
 *
 * @package YITH Woocommerce Request A Quote
 * @since   1.1.6
 * @version 1.1.8
 * @author  Yithemes
 */
$order_id = $order->id;

if ( defined( 'YITH_WCET_PREMIUM' ) ) {
    $mail_type = "ywraq_quote_status";
    do_action( 'yith_wcet_email_header', $email_heading, $mail_type );
    $template = get_option( 'yith-wcet-email-template-' . $mail_type );
}
else {
    do_action( 'woocommerce_email_header', $email_heading );
}
?>


<?php if( $status == 'accepted'): ?>
    <p><?php printf( __('The Proposal #%d has been accepted', 'yith-woocommerce-request-a-quote'), $order_id ) ?></p>
<?php else: ?>
    <p><?php printf( __('The Proposal #%d has been rejected', 'yith-woocommerce-request-a-quote'), $order_id ) ?></p>
<?php endif ?>
    <p></p>
    <p><?php printf( __( 'You can see details here: <a href="%s">#%s</a>', 'yith-woocommerce-request-a-quote' ),  admin_url( 'post.php?post='.$order_id.'&action=edit'), $order_id ) ?></p>



<?php
if (defined('YITH_WCET_PREMIUM')) {
    do_action( 'yith_wcet_email_footer', $mail_type );
}else{
    do_action( 'woocommerce_email_footer' );
}
?>