<?php
/**
 * HTML Template Email Request a Quote
 *
 * @package YITH Woocommerce Request A Quote
 * @since   1.0.0
 * @version 1.3.4
 * @author  Yithemes
 */
$order_id = $raq_data['order_id'];
$customer = get_post_meta( $order_id, '_customer_user', true);
$page_detail_admin = ( get_option('ywraq_quote_detail_link') == 'editor' ) ? true : false;

if (defined('YITH_WCET_PREMIUM')){
    $mail_type = "ywraq_email";
    do_action( 'yith_wcet_email_header', $email_heading, $mail_type);
    $template  = get_option( 'yith-wcet-email-template-' . $mail_type );
}else {
    do_action( 'woocommerce_email_header', $email_heading );
}

?>

<p><?php echo $email_description ?></p>


<?php
    wc_get_template( 'emails/request-quote-table.php', array(
        'raq_data'      => $raq_data
    ) );
?>
<p></p>

<?php if( $customer != 0 ): ?>
<p><?php printf( __( 'You can see details here: <a href="%s">#%s</a>', 'yith-woocommerce-request-a-quote' ), YITH_YWRAQ_Order_Request()->get_view_order_url($order_id, $page_detail_admin), $order_id ); ?></p>
<?php endif ?>

<?php if( ! empty( $raq_data['user_message']) ): ?>
<h2><?php _e( 'Customer\'s message', 'yith-woocommerce-request-a-quote' ); ?></h2>
    <p><?php echo $raq_data['user_message'] ?></p>
<?php endif ?>
<h2><?php _e( 'Customer\'s details', 'yith-woocommerce-request-a-quote' ); ?></h2>

<p><strong><?php _e( 'Name:', 'yith-woocommerce-request-a-quote' ); ?></strong> <?php echo $raq_data['user_name'] ?></p>
<p><strong><?php _e( 'Email:', 'yith-woocommerce-request-a-quote' ); ?></strong> <a href="mailto:<?php echo $raq_data['user_email']; ?>"><?php echo $raq_data['user_email']; ?></a></p>

<?php if( ! empty( $raq_data['user_additional_field']) || ! empty( $raq_data['user_additional_field_2']) || ! empty( $raq_data['user_additional_field_3']) ): ?>
<h2><?php _e( 'Customer\'s additional fields', 'yith-woocommerce-request-a-quote' ); ?></h2>

<?php if( ! empty( $raq_data['user_additional_field']) ): ?>
    <p><?php printf( '<strong>%s</strong>: %s', get_option('ywraq_additional_text_field_label'), $raq_data['user_additional_field'] ) ?></p>
<?php endif ?>

<?php if( ! empty( $raq_data['user_additional_field_2']) ): ?>
        <p><?php printf( '<strong>%s</strong>: %s', get_option('ywraq_additional_text_field_label_2'), $raq_data['user_additional_field_2'] ) ?></p>
<?php endif ?>

<?php if( ! empty( $raq_data['user_additional_field_3']) ): ?>
    <p><?php printf( '<strong>%s</strong>: %s', get_option('ywraq_additional_text_field_label_3'), $raq_data['user_additional_field_3'] ) ?></p>
<?php endif ?>

<?php endif ?>
<?php
if (defined('YITH_WCET_PREMIUM')) {
    do_action( 'yith_wcet_email_footer', $mail_type );
}else{
    do_action( 'woocommerce_email_footer' );
}
?>
