<?php
/**
 * Quote Detail
 *
 * Shows recent orders on the account page
 *
 * @package YITH Woocommerce Request A Quote
 * @since   1.0.0
 * @author  Yithemes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
YITH_YWRAQ_Order_Request()->is_expired( $order_id );

$order      = wc_get_order( $order_id );
$user_email = get_post_meta( $order_id, 'ywraq_customer_email', true );

if ( $order->get_user_id() != $current_user->ID ) {
	_e( 'You do not have permission to read the quote', 'yith-woocommerce-request-a-quote' );

	return;
}

if ( $order->get_status() == 'trash' ) {
	_e( 'This Quote was deleted by administrator ', 'yith-woocommerce-request-a-quote' );

	return;
}


$show_price = ( get_option( 'ywraq_hide_price' ) == 'yes' && $order->get_status() == 'ywraq-new' ) ? false : true;
if ( $order->get_status() == 'ywraq-new' ) {

	if ( catalog_mode_plugin_enabled() ) {
		foreach ( $order->get_items() as $item_id => $item ) {
			$_product   = apply_filters( 'woocommerce_order_item_product', $order->get_product_from_item( $item ), $item );
			$hide_price = apply_filters( 'yith_ywraq_hide_price_template', WC()->cart->get_product_subtotal( $_product, $raq['quantity'] ), $_product->id );
			if ( $hide_price == '' ) {
				$show_price = false;
			}
		}
	}
}

$exdata = get_post_meta( $order_id, '_ywcm_request_expire', true );


?>
<p>
	<strong><?php _e( 'Request date', 'yith-woocommerce-request-a-quote' ) ?></strong>: <?php echo date_i18n( wc_date_format(), strtotime( $order->order_date ) ) ?>
</p>
<?php if ( $order->get_status() == 'ywraq-pending' ): ?>
	<p class="ywraq-buttons">
		<?php
		$pdf_file = false;
		if ( file_exists( YITH_Request_Quote_Premium()->get_pdf_file_path( $order->id ) ) ) {
			$pdf_file = YITH_Request_Quote_Premium()->get_pdf_file_url( $order->id );
		}
		if ( get_option( 'ywraq_pdf_attachment' ) == 'yes' && get_option( 'ywraq_pdf_in_myaccount' ) == 'yes' && $pdf_file ) { ?>
			<a class="ywraq-big-button ywraq-pdf-file" href="<?php echo esc_url( $pdf_file ) ?>" target="_blank"><?php _e( 'Download PDF', 'yith-woocommerce-request-a-quote' ) ?></a>
		<?php } ?>

		<a class="ywraq-big-button ywraq-accept" href="<?php echo esc_url( add_query_arg( array( 'request_quote' => $order_id, 'status' => 'accepted', 'raq_nonce' => ywraq_get_token( 'accept-request-quote', $order_id, $user_email ) ), YITH_Request_Quote()->get_raq_page_url() ) ) ?>"><?php _e( 'Accept', 'yith-woocommerce-request-a-quote' ) ?></a>
		<a class="ywraq-big-button ywraq-reject" href="<?php echo esc_url( add_query_arg( array( 'request_quote' => $order_id, 'status' => 'rejected', 'raq_nonce' => ywraq_get_token( 'reject-request-quote', $order_id, $user_email ) ), YITH_Request_Quote()->get_raq_page_url() ) ) ?>"><?php _e( 'Reject', 'yith-woocommerce-request-a-quote' ) ?></a>
	</p>
<?php elseif ( $order->get_status() == 'pending' ) : ?>
	<p class="ywraq-buttons">
		<a class="ywraq-big-button ywraq-accept" href="<?php echo esc_url( add_query_arg( array( 'request_quote' => $order_id, 'status' => 'accepted', 'raq_nonce' => ywraq_get_token( 'accept-request-quote', $order_id, $user_email ) ), YITH_Request_Quote()->get_raq_page_url() ) ) ?>"><?php _e( 'Checkout', 'yith-woocommerce-request-a-quote' ) ?></a>
		<a class="ywraq-big-button ywraq-reject" href="<?php echo esc_url( add_query_arg( array( 'request_quote' => $order_id, 'status' => 'rejected', 'raq_nonce' => ywraq_get_token( 'reject-request-quote', $order_id, $user_email ) ), YITH_Request_Quote()->get_raq_page_url() ) ) ?>"><?php _e( 'Reject', 'yith-woocommerce-request-a-quote' ) ?></a>
	</p>
<?php else: ?>
	<p>
		<strong><?php echo __( 'Order Status:', 'yith-woocommerce-request-a-quote' ) ?></strong> <?php echo wc_get_order_status_name( $order->get_status() ) ?>
	</p>
<?php endif ?>
<h2><?php _e( 'Quote Details', 'yith-woocommerce-request-a-quote' ); ?></h2>

<?php if ( $exdata != '' ): ?>
	<p>
		<strong><?php _e( 'Expiration date', 'yith-woocommerce-request-a-quote' ) ?></strong>: <?php echo date_i18n( wc_date_format(), strtotime( $exdata ) ) ?>
	</p>
<?php endif ?>

<table class="shop_table order_details">
	<thead>
	<tr>
		<th class="product-name"><?php _e( 'Product', 'yith-woocommerce-request-a-quote' ); ?></th>
		<?php if ( $show_price ): ?>
			<th class="product-total"><?php _e( 'Total', 'yith-woocommerce-request-a-quote' ); ?></th><?php endif ?>
	</tr>
	</thead>
	<tbody>
	<?php
	if ( sizeof( $order->get_items() ) > 0 ) {

		foreach ( $order->get_items() as $item_id => $item ) {
			$_product = apply_filters( 'woocommerce_order_item_product', $order->get_product_from_item( $item ), $item );

			if ( version_compare( preg_replace( '/-beta-([0-9]+)/', '', WC()->version ), '2.4.0', '<' ) ) {
				$item_meta = new WC_Order_Item_Meta( $item['item_meta'], $_product );
			} else {
				$item_meta = new WC_Order_Item_Meta( $item, $_product );
			}

			$title = $_product->get_title();

			if ( $_product->get_sku() != '' && get_option( 'ywraq_show_sku' ) == 'yes' ) {
				$title .= apply_filters( 'ywraq_sku_label', __( ' SKU:', 'yith-woocommerce-request-a-quote' ) ) . $_product->get_sku();
			}

			if ( apply_filters( 'woocommerce_order_item_visible', true, $item ) ) {
				?>
				<tr class="<?php echo esc_attr( apply_filters( 'woocommerce_order_item_class', 'order_item', $item, $order ) ); ?>">
					<td class="product-name">
						<?php
						if ( $_product && ! $_product->is_visible() ) {
							echo apply_filters( 'woocommerce_order_item_name', $title, $item );
						} else {
							echo apply_filters( 'woocommerce_order_item_name', sprintf( '<a href="%s">%s</a>', get_permalink( $item['product_id'] ), $title ), $item );
						}

						echo apply_filters( 'woocommerce_order_item_quantity_html', ' <strong class="product-quantity">' . sprintf( '&times; %s', $item['qty'] ) . '</strong>', $item );

						// Allow other plugins to add additional product information here
						do_action( 'woocommerce_order_item_meta_start', $item_id, $item, $order );

						$item_meta->display();

						// Allow other plugins to add additional product information here
						do_action( 'woocommerce_order_item_meta_end', $item_id, $item, $order );
						?>
					</td>
					<td class="product-total">
						<?php
						if ( $show_price ):
							$subtotal = wc_price( $item['line_total'] );
							if ( get_option( 'ywraq_show_preview' ) == 'yes' ) {
								$subtotal = ( $item['line_subtotal'] != $item['line_total'] ) ? '<small><del>' . wc_price( $item['line_subtotal'] ) . '</del></small> ' . wc_price( $item['line_total'] ) : wc_price( $item['line_subtotal'] );
							}
							echo $subtotal;
						endif;
						?>
					</td>
				</tr>
				<?php
			}

			if ( $order->has_status( array( 'completed', 'processing' ) ) && ( $purchase_note = get_post_meta( $_product->id, '_purchase_note', true ) ) ) { ?>
				<tr class="product-purchase-note">
					<td colspan="3"><?php echo wpautop( do_shortcode( wp_kses_post( $purchase_note ) ) ); ?></td>
				</tr>
				<?php
			}
		}
	}

	do_action( 'woocommerce_order_items_table', $order );
	?>
	</tbody>
	<tfoot>
	<?php
	$has_refund = false;

	if ( $total_refunded = $order->get_total_refunded() ) {
		$has_refund = true;
	}

	if ( $totals = $order->get_order_item_totals() ) {

		foreach ( $totals as $key => $total ) {
			$value = $total['value'];

			?>
			<?php if ( $show_price ): ?>
				<tr>
					<th scope="row"><?php echo $total['label']; ?></th>
					<td><?php echo $value; ?></td>
				</tr>
			<?php endif ?>
			<?php
		}
	}
	?>
	</tfoot>
</table>

<?php do_action( 'woocommerce_order_details_after_order_table', $order ); ?>

<header>
	<h2><?php _e( 'Customer\'s details', 'yith-woocommerce-request-a-quote' ); ?></h2>
</header>
<table class="shop_table shop_table_responsive customer_details">
	<?php
	if ( $order->billing_email ) {
		echo '<tr><th>' . __( 'Email:', 'yith-woocommerce-request-a-quote' ) . '</th><td data-title="' . __( 'Email', 'yith-woocommerce-request-a-quote' ) . '">' . $order->billing_email . '</td></tr>';
	}

	if ( $order->billing_phone ) {
		echo '<tr><th>' . __( 'Telephone:', 'yith-woocommerce-request-a-quote' ) . '</th><td data-title="' . __( 'Telephone', 'yith-woocommerce-request-a-quote' ) . '">' . $order->billing_phone . '</td></tr>';
	}

	// Additional customer details hook
	do_action( 'woocommerce_order_details_after_customer_details', $order );
	?>
</table>


<header>
	<h2><?php _e( 'Additional Information', 'yith-woocommerce-request-a-quote' ); ?></h2>
</header>
<table class="shop_table shop_table_responsive customer_details">
	<?php

	// Check for customer note
	$customer_message = get_post_meta( $order->id, 'ywraq_customer_message', true );
	if ( '' != $customer_message ) { ?>
		<tr>
			<th scope="row"><?php _e( 'Customer\'s Message:', 'yith-woocommerce-request-a-quote' ); ?></th>
			<td><?php echo wptexturize( $customer_message ); ?></td>
		</tr>
	<?php } //
	$admin_message = get_post_meta( $order->id, '_ywcm_request_response', true );
	if ( '' != $admin_message ) { ?>
		<tr>
			<th scope="row"><?php _e( 'Administrator\'s Message:', 'yith-woocommerce-request-a-quote' ); ?></th>
			<td><?php echo wptexturize( $admin_message ); ?></td>
		</tr>
	<?php } ?>

</table>

<div class="clear"></div>
