<?php
/**
 * Quote Detail
 *
 * Shows recent orders on the account page
 *
 * @package YITH Woocommerce Request A Quote
 * @since   1.0.0
 * @author  Yithemes
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

$order = wc_get_order( $order_id );

$exdata = get_post_meta( $this->order->id, '_ywcm_request_expire', true );

?>
<h2><?php _e( 'Quote Details', 'yith-woocommerce-request-a-quote' ); ?></h2>

<p><strong><?php _e( 'Request date', 'yith-woocommerce-request-a-quote' ) ?></strong>: <?php echo date_i18n( wc_date_format(), strtotime( $this->order->order_date ) ) ?></p>
<?php if ( $exdata != '' ): ?>
    <p><strong><?php _e( 'Expiration date', 'yith-woocommerce-request-a-quote' ) ?></strong>: <?php echo  date_i18n( wc_date_format(), strtotime( $exdata ) ) ?></p>
<?php endif ?>


<table class="shop_table order_details">
    <thead>
    <tr>
        <th class="product-name"><?php _e( 'Product', 'yith-woocommerce-request-a-quote' ); ?></th>
        <th class="product-total"><?php _e( 'Total', 'yith-woocommerce-request-a-quote' ); ?></th>
    </tr>
    </thead>
    <tbody>
    <?php
    if ( sizeof( $order->get_items() ) > 0 ) {

        foreach( $order->get_items() as $item_id => $item ) {
            $_product  = apply_filters( 'woocommerce_order_item_product', $order->get_product_from_item( $item ), $item );
            if( version_compare( preg_replace( '/-beta-([0-9]+)/', '',  WC()->version ), '2.4.0', '<' )){
                $item_meta = new WC_Order_Item_Meta( $item['item-data'], $_product );
            }else{
                $item_meta = new WC_Order_Item_Meta( $item, $_product );
            }


            if ( apply_filters( 'woocommerce_order_item_visible', true, $item ) ) {
                ?>
                <tr class="<?php echo esc_attr( apply_filters( 'woocommerce_order_item_class', 'order_item', $item, $order ) ); ?>">
                    <td class="product-name">
                        <?php

                        $title = $_product->get_title();

                        if( $_product->get_sku() != '' && get_option('ywraq_show_sku') == 'yes' ){
                            $title .= apply_filters( 'ywraq_sku_label', __( ' SKU:', 'yith-woocommerce-request-a-quote' ) ) . $_product->get_sku();
                        }


                        if ( $_product && ! $_product->is_visible() ) {
                            echo apply_filters( 'woocommerce_order_item_name', $title, $item );
                        } else {
                            echo apply_filters( 'woocommerce_order_item_name', sprintf( '<a href="%s">%s</a>', get_permalink( $item['product_id'] ), $title ), $item );
                        }

                        echo apply_filters( 'woocommerce_order_item_quantity_html', ' <strong class="product-quantity">' . sprintf( '&times; %s', $item['qty'] ) . '</strong>', $item );

                        // Allow other plugins to add additional product information here
                        do_action( 'woocommerce_order_item_meta_start', $item_id, $item, $order );

                        $item_meta->display();

                        if ( $_product && $_product->exists() && $_product->is_downloadable() && $order->is_download_permitted() ) {

                            $download_files = $order->get_item_downloads( $item );
                            $i              = 0;
                            $links          = array();

                            foreach ( $download_files as $download_id => $file ) {
                                $i++;

                                $links[] = '<small><a href="' . esc_url( $file['download_url'] ) . '">' . sprintf( __( 'Download file%s', 'yith-woocommerce-request-a-quote' ), ( count( $download_files ) > 1 ? ' ' . $i . ': ' : ': ' ) ) . esc_html( $file['name'] ) . '</a></small>';
                            }

                            echo '<br/>' . implode( '<br/>', $links );
                        }

                        // Allow other plugins to add additional product information here
                        do_action( 'woocommerce_order_item_meta_end', $item_id, $item, $order );
                        ?>
                    </td>
                    <td class="product-total">

                        <?php echo $order->get_formatted_line_subtotal( $item ); ?>
                    </td>
                </tr>
            <?php
            }

            if ( $order->has_status( array( 'completed', 'processing' ) ) && ( $purchase_note = get_post_meta( $_product->id, '_purchase_note', true ) ) ) {
                ?>
                <tr class="product-purchase-note">
                    <td colspan="3"><?php echo wpautop( do_shortcode( wp_kses_post( $purchase_note ) ) ); ?></td>
                </tr>
            <?php
            }
        }
    }

    do_action( 'woocommerce_order_items_table', $order );
    ?>
    </tbody>
    <tfoot>
    <?php
    $has_refund = false;

    if ( $total_refunded = $order->get_total_refunded() ) {
        $has_refund = true;
    }

    if ( $totals = $order->get_order_item_totals() ) {
        foreach ( $totals as $key => $total ) {
            $value = $total['value'];

            // Check for refund
            if ( $has_refund && $key === 'order_total' ) {
                $refunded_tax_del = '';
                $refunded_tax_ins = '';

                // Tax for inclusive prices
                if ( wc_tax_enabled() && 'incl' == $order->tax_display_cart ) {

                    $tax_del_array = array();
                    $tax_ins_array = array();

                    if ( 'itemized' == get_option( 'woocommerce_tax_total_display' ) ) {

                        foreach ( $order->get_tax_totals() as $code => $tax ) {
                            $tax_del_array[] = sprintf( '%s %s', $tax->formatted_amount, $tax->label );
                            $tax_ins_array[] = sprintf( '%s %s', wc_price( $tax->amount - $order->get_total_tax_refunded_by_rate_id( $tax->rate_id ), array( 'currency' => $order->get_order_currency() ) ), $tax->label );
                        }

                    } else {
                        $tax_del_array[] = sprintf( '%s %s', wc_price( $order->get_total_tax(), array( 'currency' => $order->get_order_currency() ) ), WC()->countries->tax_or_vat() );
                        $tax_ins_array[] = sprintf( '%s %s', wc_price( $order->get_total_tax() - $order->get_total_tax_refunded(), array( 'currency' => $order->get_order_currency() ) ), WC()->countries->tax_or_vat() );
                    }

                    if ( ! empty( $tax_del_array ) ) {
                        $refunded_tax_del .= ' ' . sprintf( __( '(Includes %s)', 'yith-woocommerce-request-a-quote' ), implode( ', ', $tax_del_array ) );
                    }

                    if ( ! empty( $tax_ins_array ) ) {
                        $refunded_tax_ins .= ' ' . sprintf( __( '(Includes %s)', 'yith-woocommerce-request-a-quote' ), implode( ', ', $tax_ins_array ) );
                    }
                }

                $value = '<del>' . strip_tags( $order->get_formatted_order_total() ) . $refunded_tax_del . '</del> <ins>' . wc_price( $order->get_total() - $total_refunded, array( 'currency' => $order->get_order_currency() ) ) . $refunded_tax_ins . '</ins>';
            }
            ?>
            <tr>
                <th scope="row"><?php echo $total['label']; ?></th>
                <td><?php echo $value; ?></td>
            </tr>
        <?php
        }
    }

    // Check for refund
    if ( $has_refund ) { ?>
        <tr>
            <th scope="row"><?php _e( 'Refunded:', 'yith-woocommerce-request-a-quote' ); ?></th>
            <td>-<?php echo wc_price( $total_refunded, array( 'currency' => $order->get_order_currency() ) ); ?></td>
        </tr>
    <?php
    }

    // Check for customer note
    $customer_message = get_post_meta( $order->id, 'ywraq_customer_message', true );
    if ( '' != $customer_message ) { ?>
        <tr>
            <th scope="row"><?php _e( 'Customer\'s Message:', 'yith-woocommerce-request-a-quote' ); ?></th>
            <td><?php echo wptexturize( $customer_message ); ?></td>
        </tr>
    <?php } // Check for customer note
    $admin_message = get_post_meta( $order->id, '_ywcm_request_response', true );
    if ( '' != $admin_message ) { ?>
        <tr>
            <th scope="row"><?php _e( 'Administrator\'s Message:', 'yith-woocommerce-request-a-quote' ); ?></th>
            <td><?php echo wptexturize( $admin_message ); ?></td>
        </tr>
    <?php } ?>
    </tfoot>
</table>

<?php do_action( 'woocommerce_order_details_after_order_table', $order ); ?>

<header>
    <h2><?php _e( 'Customer\'s details', 'yith-woocommerce-request-a-quote' ); ?></h2>
</header>
<table class="shop_table shop_table_responsive customer_details">
    <?php
    if ( $order->billing_email ) {
        echo '<tr><th>' . __( 'Email:', 'yith-woocommerce-request-a-quote' ) . '</th><td data-title="' . __( 'Email', 'yith-woocommerce-request-a-quote' ) . '">' . $order->billing_email . '</td></tr>';
    }

    if ( $order->billing_phone ) {
        echo '<tr><th>' . __( 'Telephone:', 'yith-woocommerce-request-a-quote' ) . '</th><td data-title="' . __( 'Telephone', 'yith-woocommerce-request-a-quote' ) . '">' . $order->billing_phone . '</td></tr>';
    }

    // Additional customer details hook
    do_action( 'woocommerce_order_details_after_customer_details', $order );
    ?>
</table>


<header>
    <h2><?php _e( 'Additional Information', 'yith-woocommerce-request-a-quote' ); ?></h2>
</header>
<table class="shop_table shop_table_responsive customer_details">
    <?php

    // Check for customer note
    $customer_message = get_post_meta( $order->id, 'ywraq_customer_message', true );
    if ( '' != $customer_message ) { ?>
        <tr>
            <th scope="row"><?php _e( 'Customer\'s Message:', 'yith-woocommerce-request-a-quote' ); ?></th>
            <td><?php echo wptexturize( $customer_message ); ?></td>
        </tr>
    <?php } //
    $admin_message = get_post_meta( $order->id, '_ywcm_request_response', true );
    if ( '' != $admin_message ) { ?>
        <tr>
            <th scope="row"><?php _e( 'Administrator\'s Message:', 'yith-woocommerce-request-a-quote' ); ?></th>
            <td><?php echo wptexturize( $admin_message ); ?></td>
        </tr>
    <?php } ?>

</table>

<div class="clear"></div>
