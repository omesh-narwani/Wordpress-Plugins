﻿=== YITH WooCommerce Review For Discounts ===

Contributors: yithemes
Tags: woocommerce, products, themes, yit, yith, yithemes, e-commerce, shop, coupon, reward, discount, review, product review, woocommerce review
Requires at least: 4.0
Tested up to: 4.4.2
Stable tag: 1.0.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= 1.0.4 =

* Fixed: coupon expiry date based on website timezone

= 1.0.3 =

* Fixed: email visualization error

= 1.0.2 =

* Added: compatibility with WooCommerce 2.5

= 1.0.1 =

* Fixed: get send status on test email

= 1.0.0 =

* Initial release
