=== YITH WooCommerce Review Reminder ===

Contributors: yithemes
Tags: reviews, woocommerce, products, themes, yit, yith, e-commerce, shop, review, email reminder, request review, product review, woocommerce review
Requires at least: 4.0
Tested up to: 4.4.2
Stable tag: 1.1.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= 1.1.7 =

* Fixed: email not scheduling

= 1.1.6 =

* Fixed: get email status on sending

= 1.1.5 =

* New feature: Adding custom campaign parameters for Google Analytics to email links
* Added: E-mail scheduled date visible on metabox of each order
* Added: search field on "Schedule List" and "Blocklist" tabs
* Updated: language files
* Updated: plugin core framework
* Fixed: JS code improvements
* Fixed: minor bugs

= 1.1.4 =

* Added: compatibility with WooCommerce 2.5

= 1.1.3 =

* Fixed: italian translation file

= 1.1.2 =

* Fixed: unsubscribe page initialization makes conflict with some plugin
* Updated: plugin core framework

= 1.1.1 =

* Updated: changed text domain from ywrr to yith-woocommerce-review-reminder
* Updated: changed all language file for the new text domain

= 1.1.0 =

* Updated: plugin core framework

= 1.0.9 =

* Added: italian language file
* Updated: core framework

= 1.0.8 =

* Added: function yith_sanitize_tooltip for retrocompatibility

= 1.0.7 =

* Added: new file class-yith-custom-table.php
* Removed: old file class-yith-ywrr-custom-table.php

= 1.0.6 =

* Fixed: email images links
* Fixed: minor bugs

= 1.0.5 =

* Added: compatibility with YITH Essential Kit for WooCommerce #1

= 1.0.4 =

* New feature: customize product link in email template
* New feature: compatibility with YITH WooCommerce Email Templates
* Added: Support to WooCommerce 2.4
* Updated: Plugin core framework
* Fixed: Image sizes in email template
* Fixed: minor bugs


= 1.0.3 =

* Added: Screen options for Blocklist table
* New feature: Test Email Sending
* New Feature: Mandrill Integration
* New Feature: Schedulation table

= 1.0.2 =

* Fixed: Redirection bug in "Blocklist" tab bulk actions
* Fixed: E-mail template management

= 1.0.1 =

* Added: Woocommerce 2.3 support
* Tweak: String translation

= 1.0.0 =

* Initial release
