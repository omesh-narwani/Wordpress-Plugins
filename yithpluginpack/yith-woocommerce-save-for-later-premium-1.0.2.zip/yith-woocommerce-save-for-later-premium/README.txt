=== YITH WooCommerce Save For Later ===

Contributors: yithemes
Requires at least: 3.5.1
Tested up to: 4.4
Stable tag: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Documentation:

== Changelog ==

= 1.0.2 =

* Fixed : Hide "Save for Later" link in mini-cart

= 1.0.1 =

* Added: Support to WooCommerce 2.4
* Updated: Plugin core framework
* Added: variable product support

= 1.0.0 =

* Initial release