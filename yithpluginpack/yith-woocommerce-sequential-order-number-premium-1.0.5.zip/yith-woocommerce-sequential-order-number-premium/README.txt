=== YITH WooCommerce Sequential Order Number ===

Contributors: yithemes
Tags: order, woocommerce, numeration, order number, orders, shop, yith, yit, yithemes
Requires at least: 3.5.1
Tested up to: 4.4
Stable tag: 1.0.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Documentation:

== Changelog ==

= 1.0.5 =

* Added: Compatibility with YITH WooCommerce Request a Quote

= 1.0.4 =

* Updated: Plugin core framework

= 1.0.3 =

* Updated: Plugin core framework 2.0

= 1.0.2 =

* Added: Support to WooCommerce 2.4
* Updated: Plugin core framework

= 1.0.1 =

* Added: Italian language file

= 1.0.0 =

* Initial release