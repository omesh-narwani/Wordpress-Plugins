﻿=== YITH WooCommerce Share For Discounts ===

Contributors: yithemes
Tags: woocommerce, products, themes, yit, yith, yithemes, e-commerce, shop, coupon, reward, discount, social network, facebook, google, twitter, share, discount
Requires at least: 4.0
Tested up to: 4.4.1
Stable tag: 1.1.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= 1.1.4 =

* Fixed: session_start() conflict with some plugins

= 1.1.3 =

* Added: multiple discounts prevention
* Added: compatibility with WooCommerce 2.5

= 1.1.2 =

* New feature: default Facebook OpenGraph meta data

= 1.1.1 =

* Fixed: optimized JS file

= 1.1.0 =

* Fixed: compatibility with themes on cart and checkout pages
* Updated: plugin core framework

= 1.0.9 =

* Fixed: saving of automated removal of expired coupons option
* Updated: plugin core framework

= 1.0.8 =

* New feature: Automated removal of expired coupons created by the plugin
* Updated: plugin core framework
* Added: new file class-yith-wc-custom-textarea.php
* Removed: old file custom-textarea.php
* Fixed: Open Graph meta tag fixed

= 1.0.7 =

* Fixed: coupon error on checkout to guest users
* Fixed: Google+ button not showing
* Fixed: Facebook share callback

= 1.0.6 =

* Updated: plugin core framework

= 1.0.5 =

* Fixed: filters for title and message after sharing

= 1.0.4 =

* Updated: changed text domain from ywsfd to yith-woocommerce-share-for-discounts
* Updated: changed all language file for the new text domain
* Fixed: Modified error message on sharing item before adding it to cart
* Added: Italian Translation

= 1.0.3 =

* Added: Facebook and Google+ share buttons

= 1.0.2 =

* Initial release
