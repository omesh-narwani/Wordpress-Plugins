=== YITH WooCommerce Social Login Premium ===

Contributors: yithemes
Tags: social login, login, connect with social, woocommerce connect
Requires at least: 3.5.1
Tested up to: 4.2
Stable tag: 1.0.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

YITH WooCommerce Social login is a plugin that allows you to login to your e-commerce site through your Facebook or Twitter or Google+ account.



== Changelog ==
= 1.0.7 =
* Added: Support to WooCommerce 2.5 RC1
* Updated: Paypal library
* Updated: Plugin Core Framework

= 1.0.6 =
* Fixed: Catch the Exceptions when the login with provider is cancelled

= 1.0.5 =
* Added: Support to Wordpress 4.4
* Updated: Hybrid Library 2.6.0
* Updated: Changed Text Domain from 'ywsl' to 'yith-woocommerce-social-login'
* Updated: Plugin Core Framework

= 1.0.4 =
* Fixed: Called to WP_Widget construct
* Added: Support to WooCommerce 2.4.2
* Updated: Plugin Core Framework

= 1.0.3 =
* Fixed: Security issues

= 1.0.2 =
Fixed: Removed "read_friendlists" scope

= 1.0.1 =

Initial release