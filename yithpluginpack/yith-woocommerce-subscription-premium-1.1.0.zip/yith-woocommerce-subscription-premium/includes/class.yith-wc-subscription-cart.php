<?php

if ( !defined( 'ABSPATH' ) || !defined( 'YITH_YWSBS_VERSION' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Implements YWSBS_Subscription Cart Class
 *
 * @class   YWSBS_Subscription_Cart
 * @package YITH WooCommerce Subscription
 * @since   1.0.0
 * @author  Yithemes
 */
if ( !class_exists( 'YWSBS_Subscription_Cart' ) ) {

    class YWSBS_Subscription_Cart {

        /**
         * Single instance of the class
         *
         * @var \YWSBS_Subscription_Cart
         */
        protected static $instance;

        protected $prices_updates = false;


        /**
         * Returns single instance of the class
         *
         * @return \YWSBS_Subscription_Cart
         * @since 1.0.0
         */
        public static function get_instance() {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function __construct() {

            $this->prices_updates = false;

            //add_filter('woocommerce_cart_item_price', array($this, 'change_price_in_cart_html'), 90, 3);

            // Change prices and totals in cart
            add_action( 'woocommerce_cart_loaded_from_session', array( $this, 'change_prices' ), 99 );
            add_filter( 'woocommerce_cart_item_subtotal', array( $this, 'change_price_in_cart_html' ), 99, 3 );
            add_filter( 'woocommerce_cart_item_price', array( $this, 'change_price_in_cart_html' ), 99, 3 );
            add_filter( 'woocommerce_cart_needs_payment', array( $this, 'cart_needs_payment' ), 10, 2 );
            add_filter( 'ywsbs_signup_fee_in_cart', array( $this, 'change_signup_fee_in_cart' ), 10, 2 );
            add_filter( 'ywsbs_trial_in_cart', array( $this, 'change_trial_in_cart' ), 10, 2 );

        }



        public function change_prices($cart) {

            if ($this->prices_updates || empty($cart->cart_contents)) {
                return;
            }

            foreach ( $cart->cart_contents as $cart_item_key => $cart_item ) {
                $product = $cart_item['data'];
                $id = $product->product_type == 'variation' ? $product->variation_id : $product->id;

                if ( YITH_WC_Subscription()->is_subscription( $id ) ) {
                    $price        = $cart_item['data']->price;

                    $signup_fee   = apply_filters( 'ywsbs_signup_fee_in_cart', get_post_meta( $id, '_ywsbs_fee', true ), $cart_item );
                    $trial_period = apply_filters( 'ywsbs_trial_in_cart', get_post_meta( $id, '_ywsbs_trial_per', true ), $cart_item );

                    if ( $trial_period != '' && $trial_period != 0 ) {
                        $price = 0;
                    }

                    if ( $signup_fee != '' ) {
                        $price = floatval( $signup_fee ) + $price;
                    }

                    if ( $price != $cart_item['data']->price ) {
                        if ( isset( WC()->cart->cart_contents[$cart_item_key] ) ) {
                            WC()->cart->cart_contents[$cart_item_key]['data']->recurring_price = $cart_item['data']->price;
                            WC()->cart->cart_contents[$cart_item_key]['data']->price           = $price;
                        }
                    }

                }
            }

            $this->prices_updates = true;
        }

        public function get_formatted_subscription_price( $id, $is_subtotal, $quantity ) {

            $product       = wc_get_product( $id );

            $regular_price = $this->get_price( $id, $product->get_regular_price(), $quantity );
            $sale_price    = false;
            if ( $product->is_on_sale() ) {
                $sale_price = $this->get_price( $id, $product->get_sale_price(), $quantity );
            }

            if ($is_subtotal) {

            }else{

            }

        }

        public function change_price_in_cart_html(  $price_html, $cart_item, $cart_item_key ) {

            $product_id = !empty($cart_item['variation_id']) ? $cart_item['variation_id'] : $cart_item['product_id'];
            $product = wc_get_product($product_id);
            $price_html =  apply_filters('ywsbs_get_price_html', $product->get_price_html(), $cart_item, $product_id);


            return $price_html;



        }

        public function get_price( $product_id, $price, $quantity = 1 ) {
            // Load product object
            $product = wc_get_product( $product_id );

            $price = $product->get_regular_price();

            // Get correct price
            if ( get_option( 'woocommerce_tax_display_cart' ) ) {
                $price = $product->get_price_including_tax( $quantity, $price );
            }
            else {
                $price = $product->get_price_excluding_tax( $quantity, $price );
            }

            return (float) $price;
        }




        public function cart_has_subscription_with_signup(){
            foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {
                $product = $cart_item['data'];
                $id = $product->product_type == 'variation' ? $product->variation_id : $product->id;

                if ( YITH_WC_Subscription()->is_subscription( $id ) ) {
                    $fee = get_post_meta( $id, '_ywsbs_fee', true);
                    if( !empty($fee) && $fee > 0){
                        return true;
                    }
                }
            }

            return false;
        }

        /**
         * Check whether the cart needs payment even if the order total is $0
         *
         * @param bool $needs_payment
         * @param WC_Cart
         * @return bool
         */
        public static function cart_needs_payment( $needs_payment, $cart ) {

            if ( false === $needs_payment && YITH_WC_Subscription()->cart_has_subscriptions() && $cart->total == 0 ) {
                return true;
            }

            return $needs_payment;
        }

        /**
         * Check if there are subscription upgrade in progress and change the fee
         *
         * @param $fee float
         * @param $cart_item array
         *
         * @param WC_Cart
         * @return bool
         */
        public function change_signup_fee_in_cart( $fee, $cart_item ) {

            $signup_fee = $fee;

            /* UPGRADE PROCESS */
            //add fee is gap payment is available and choosed b user
            $product = $cart_item['data'];
            $id      = $product->product_type == 'variation' ? $product->variation_id : $product->id;

            $subscription_info = get_user_meta( get_current_user_id(), 'ywsbs_upgrade_' . $id, true );
            $gap_payment       = get_post_meta( $id, '_ywsbs_gap_payment', true );
            $pay_gap           = 0;

            if ( ! empty( $subscription_info ) && isset( $subscription_info['pay_gap'] ) ) {
                $pay_gap = $subscription_info['pay_gap'];
            }

            if ( $gap_payment == 'yes' && $pay_gap > 0 ) {
                //change the fee of the subscription adding the total amount of the previous rates
                $signup_fee += $pay_gap;
            }

            return $signup_fee;

        }

        /**
         * Check if there are subscription upgrade in progress and change the trial options
         * During the upgrade or downgrade the trial period will be nulled
         *
         * @param int $trial
         * @param array $cart_item
         *
         * @return int | string
         */
        public function change_trial_in_cart( $trial, $cart_item ) {

            $new_trial = $trial;


            $product = $cart_item['data'];
            $id      = $product->product_type == 'variation' ? $product->variation_id : $product->id;

            /* UPGRADE PROCESS */
            $subscription_upgrade_info = get_user_meta( get_current_user_id(), 'ywsbs_upgrade_' . $id, true );
            if( ! empty( $subscription_upgrade_info ) ){
                return '';
            }

            /* DOWNGRADE PROCESS */
            $subscription_downgrade_info =  get_user_meta( get_current_user_id(), 'ywsbs_trial_' . $id, true );
            if ( ! empty( $subscription_downgrade_info ) ) {
                $new_trial = $subscription_downgrade_info['trial_days'];
            }

            return $new_trial;

        }
    }


}

/**
 * Unique access to instance of YWSBS_Subscription_Cart class
 *
 * @return \YWSBS_Subscription_Cart
 */
function YWSBS_Subscription_Cart() {
    return YWSBS_Subscription_Cart::get_instance();
}
