<?php

if ( !defined( 'ABSPATH' ) || !defined( 'YITH_YWSBS_VERSION' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Implements YWSBS_Subscription_Coupons Class
 *
 * @class   YWSBS_Subscription_Coupons
 * @package YITH WooCommerce Subscription
 * @since   1.0.0
 * @author  Yithemes
 */
if ( !class_exists( 'YWSBS_Subscription_Coupons' ) ) {

    class YWSBS_Subscription_Coupons {

        /**
         * Single instance of the class
         *
         * @var \YWSBS_Subscription_Order
         */
        protected static $instance;

        protected $coupon_types = array();
        protected $coupon_error = '';



        /**
         * Returns single instance of the class
         *
         * @return \YWSBS_Subscription_Coupons
         * @since 1.0.0
         */
        public static function get_instance() {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function __construct() {

            $this->coupon_types = array( 'signup_percent', 'signup_fixed', 'recurring_percent', 'recurring_fixed' );
            // Add new coupons type to administrator
            add_filter( 'woocommerce_coupon_discount_types', array( $this, 'add_coupon_discount_types') );

            //Apply discounts to a product and get the discounted price (before tax is applied).
            add_filter( 'woocommerce_get_discounted_price', array( $this, 'get_discounted_price'), 10, 3 );

            // Validate coupons
            add_filter( 'woocommerce_coupon_is_valid', array( $this, 'validate_coupon') , 10, 2 );

        }


        public function add_coupon_discount_types( $coupons_type ) {
            $coupons_type['signup_percent'] = __('Subscription Signup % Discount','yith-woocommerce-subscription');
            $coupons_type['signup_fixed'] = __('Subscription Signup Discount','yith-woocommerce-subscription');
            $coupons_type['recurring_percent'] = __('Subscription Recurring % Discount','yith-woocommerce-subscription');
            $coupons_type['recurring_fixed'] = __('Subscription Recurring Discount','yith-woocommerce-subscription');

            return $coupons_type;
        }

        /**
         * Apply discounts to a product and get the discounted price (before tax is applied).
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function get_discounted_price(  $price, $cart_item, $cart  ) {

            $id = !empty($cart_item['variation_id']) ? $cart_item['variation_id'] : $cart_item['product_id'];
            if( !YITH_WC_Subscription()->is_subscription($id)){
                return $price;
            }

            $discount_cart = isset(  WC()->cart->discount_cart ) ? WC()->cart->discount_cart : 0;

            if ( ! empty( $cart->applied_coupons ) ) {
                foreach ( $cart->applied_coupons as $coupon_code ) {
                    $coupon = new WC_Coupon( $coupon_code );
                    if ( $coupon->apply_before_tax() && $coupon->is_valid() ) {
                        $fee = get_post_meta( $id, '_ywsbs_fee', true );

                        switch ( $coupon->discount_type ) {
                            case 'signup_percent':
                                if ( empty( $fee ) || $fee == 0 ) {
                                    break;
                                }

                            case 'recurring_percent':
                                $discount_amount = round( ( $price / 100 ) * $coupon->amount, WC()->cart->dp );
                                // add to discount totals
                                WC()->cart->discount_cart =  $discount_cart + $discount_amount * $cart_item['quantity'];
                                $this->increase_coupon_discount_amount( $coupon->code, $discount_amount * $cart_item['quantity'] );

                                $price = $price - $discount_amount;

                                break;
                            case 'signup_fixed':
                                if ( empty( $fee ) || $fee == 0 ) {
                                    break;
                                }

                            case 'recurring_fixed':
                                $discount_amount = ( $price < $coupon->amount ) ? $price : $coupon->amount;
                                // add to discount totals
                                WC()->cart->discount_cart =  $discount_cart + $discount_amount * $cart_item['quantity'];
                                $this->increase_coupon_discount_amount( $coupon->code, $discount_amount * $cart_item['quantity'] );
                                $price = $price - $discount_amount;
                                break;

                            default:
                        }
                    }
                }
            }

            if ( $price < 0 ) {
                $price = 0;
            }



            return $price;
        }




        /**
         * Check if coupon is valid
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function validate_coupon( $is_valid, $coupon  ) {

            $this->coupon_error = '';

            if( !in_array( $coupon->type, $this->coupon_types ) ) {
                return $is_valid;
            }

            // ignore non-subscription coupons
            if (  ! YITH_WC_Subscription()->cart_has_subscriptions() ) {
                $this->coupon_error = __( 'Sorry, this coupon can be used only if there is a subscription in the cart', 'yith-woocommerce-subscription' );
            }else {

                if(  in_array( $coupon->type, array( 'signup_percent', 'signup_fixed' ) ) && ! YWSBS_Subscription_Cart()->cart_has_subscription_with_signup() ){
                    $this->coupon_error = __( 'Sorry, this coupon can be used only if there is a subscription with signup fees', 'yith-woocommerce-subscription' );
                }
            }

            if ( ! empty($this->coupon_error ) ) {
                $is_valid = false;
                add_filter( 'woocommerce_coupon_error', array( $this, 'add_coupon_error'), 10 );
            }

            return $is_valid;
        }

        /**
         * Add coupon error if the coupon is not valid
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function add_coupon_error( $error  ) {
            if ( !empty( $this->coupon_error ) ) {
                $errors = $this->coupon_error;
            }

            return $errors;
        }


        /**
         * Total of coupon discounts
         *
         * @param mixed $coupon_code
         * @param mixed $amount
         * @return void
         */
        public function increase_coupon_discount_amount( $coupon_code, $amount ) {

            if ( empty( WC()->cart->coupon_discount_amounts[ $coupon_code ] ) ) {
                WC()->cart->coupon_discount_amounts[ $coupon_code ] = 0;
            }

            WC()->cart->coupon_discount_amounts[ $coupon_code ] = $amount;

        }


    }
}

/**
 * Unique access to instance of YWSBS_Subscription_Coupons class
 *
 * @return \YWSBS_Subscription_Coupons
 */
function YWSBS_Subscription_Coupons() {
    return YWSBS_Subscription_Coupons::get_instance();
}
