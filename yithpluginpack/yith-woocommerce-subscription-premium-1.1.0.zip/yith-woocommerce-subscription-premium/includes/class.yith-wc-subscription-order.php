<?php

if ( !defined( 'ABSPATH' ) || !defined( 'YITH_YWSBS_VERSION' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Implements YWSBS_Subscription_Order Class
 *
 * @class   YWSBS_Subscription_Order
 * @package YITH WooCommerce Subscription
 * @since   1.0.0
 * @author  Yithemes
 */
if ( !class_exists( 'YWSBS_Subscription_Order' ) ) {

    class YWSBS_Subscription_Order {

        /**
         * Single instance of the class
         *
         * @var \YWSBS_Subscription_Order
         */
        protected static $instance;

        /**
         * Array with the new subscription details
         *
         * @var array
         * @since 1.0.0
         */
        private $subscriptions_info = array();

        /**
         * Returns single instance of the class
         *
         * @return \YWSBS_Subscription_Order
         * @since 1.0.0
         */
        public static function get_instance() {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0.0
         */
        public function __construct() {

            // Save details of subscription
            add_action( 'woocommerce_create_order', array( $this, 'get_extra_subscription_meta' ), 10, 2 );
            add_action( 'woocommerce_add_order_item_meta', array( $this, 'add_subscription_order_item_meta' ), 10, 3 );

            // Add subscriptions from orders
            add_action( 'woocommerce_checkout_order_processed', array( $this, 'check_order_for_subscription'), 100, 2 );

            // Start subscription after payment received
            add_action( 'woocommerce_payment_complete', array( $this, 'payment_complete' ) );
            add_action( 'woocommerce_order_status_completed', array( $this, 'payment_complete' ) );
            add_action( 'woocommerce_order_status_processing', array( $this, 'payment_complete' ) );
            add_action( 'woocommerce_order_status_completed', array( $this, 'payment_complete' ) );
            if( get_option('ywsbs_delete_subscription_order_cancelled') == 'yes'){
                add_action( 'woocommerce_order_status_cancelled', array( $this, 'delete_subscriptions' ) );
            }

            //On refund of the main order cancel the subscription
            add_action( 'woocommerce_order_fully_refunded', array( $this, 'order_refunded' ), 10, 2 );
            add_action( 'woocommerce_order_status_refunded', array( $this, 'order_refunded' ), 10 );

            add_action( 'woocommerce_order_status_on-hold_to_completed', array( $this, 'reactive_subscription' ), 10);
            add_action( 'woocommerce_order_status_on-hold_to_processing', array( $this, 'reactive_subscription' ), 10);


            // If there's a subscription inside the order, even if the order total is $0, it still needs payment
            add_filter( 'woocommerce_order_needs_payment', array( $this, 'order_need_payment' ), 10, 3 );


        }


        /**
         * Save some info if a subscription is in the cart
         *
         * @access public
         *
         * @param  $order_id int
         * @param  $checkout object
         *
         */
        public function get_extra_subscription_meta( $order_id, $checkout ) {

            foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {

                $id = !empty($cart_item['variation_id']) ? $cart_item['variation_id'] : $cart_item['product_id'];
                $product = wc_get_product( $id );

                //if this subscription is a downgrade the old subscription will be cancelled
                $subscription_to_update_id = get_user_meta(get_current_user_id(), 'ywsbs_downgrade_'.$id, true);
                if( $subscription_to_update_id != '' ){
                    YITH_WC_Subscription()->cancel_subscription_after_upgrade( $subscription_to_update_id );
                   // delete_user_meta( get_current_user_id(), 'ywsbs_downgrade_'.$id );
                }


                if ( YITH_WC_Subscription()->is_subscription( $id ) ) {

                    if ( YITH_WC_Subscription()->debug_active ) {
                        YITH_WC_Subscription()->debug->add( 'ywsbs', 'find a subscription at create_order : ' . $order_id .' product_id : '. $id );
                    }

                    $new_cart = new WC_Cart();

                    $subscription_info = array(
                        'shipping' => array(),
                        'taxes' => array(),
                    );

                    if ( isset( $cart_item['variation'] ) ) {
                        $subscription_info['variation'] = $cart_item['variation'];
                    }


                    $new_cart_item_key = $new_cart->add_to_cart(
                        $cart_item['product_id'],
                        $cart_item['quantity'],
                        (isset($cart_item['variation_id']) ? $cart_item['variation_id'] : ''),
                        (isset($cart_item['variation']) ? $cart_item['variation'] : '')
                    );

                    $new_cart = apply_filters( 'ywsbs_add_cart_item_data', $new_cart, $new_cart_item_key, $cart_item );

                    $new_cart_item_keys = array_keys($new_cart->cart_contents);
                    $applied_coupons = WC()->cart->applied_coupons;

                    foreach($new_cart_item_keys as $new_cart_item_key) {
                        //shipping
                        if ($new_cart->needs_shipping() && $product->needs_shipping()) {
                            if ( method_exists( WC()->shipping, 'get_packages' ) ) {
                                $packages = WC()->shipping->get_packages();
                                foreach ( $packages as $key => $package ) {

                                    if ( isset( $package['rates'][ $checkout->shipping_methods[ $key ] ] ) ) {

                                        if (isset($package['contents'][$cart_item_key]) || isset($package['contents'][$new_cart_item_key])) {
                                            // This shipping method has the current subscription

                                            $shipping['method'] = $checkout->shipping_methods[$key];
                                            $shipping['destination'] = $package['destination'];

                                            break;
                                        }
                                    }

                                }

                                if ( !isset( $shipping ) ) {
                                    continue;
                                }

                                // Get packages based on renewal order details
                                $new_packages = apply_filters('woocommerce_cart_shipping_packages', array(
                                    0 => array(
                                        'contents'          => $new_cart->get_cart(),
                                        'contents_cost'     => isset($new_cart->cart_contents[$new_cart_item_key]['line_total']) ? $new_cart->cart_contents[$new_cart_item_key]['line_total'] : 0,
                                        'applied_coupons'   => $new_cart->applied_coupons,
                                        'destination'       => $shipping['destination'],
                                    ),
                                ));

                             //subscription_shipping_method_temp

                                $save_temp_session_values = array(
                                    'shipping_method_counts'    => WC()->session->get('shipping_method_counts'),
                                    'chosen_shipping_methods'   => WC()->session->get('chosen_shipping_methods'),
                                );

                                WC()->session->set( 'shipping_method_counts', array( 1 ) );
                                WC()->session->set( 'chosen_shipping_methods', array( $shipping['method'] ) );

                                add_filter( 'woocommerce_shipping_chosen_method', array( $this, 'change_shipping_chosen_method_temp' ) );
                                $this->subscription_shipping_method_temp = $shipping['method'];

                                WC()->shipping->calculate_shipping($new_packages);

                                remove_filter( 'woocommerce_shipping_chosen_method', array( $this, 'change_shipping_chosen_method_temp' ) );

                                unset( $this->subscription_shipping_method_temp );

                            }


                        }

                        foreach ( $applied_coupons as $coupon_code ) {
                            $coupon = new WC_Coupon( $coupon_code );

                            if ( $coupon->is_valid() && in_array( $coupon->discount_type, array( 'recurring_percent', 'recurring_fixed' ) ) ) {

                                $price     = $new_cart->cart_contents[$new_cart_item_key]['line_subtotal'];
                                $price_tax = $new_cart->cart_contents[$new_cart_item_key]['line_subtotal_tax'];
                                switch ( $coupon->discount_type ) {
                                    case 'recurring_percent':
                                        $discount_amount     = round( ( $price / 100 ) * $coupon->amount, WC()->cart->dp );
                                        $discount_amount_tax = round( ( $price_tax / 100 ) * $coupon->amount, WC()->cart->dp );
                                        break;
                                    case 'recurring_fixed':
                                        $discount_amount     = ( $price < $coupon->amount ) ? $price : $coupon->amount;
                                        $discount_amount_tax = 0;
                                        break;
                                }

                                $subscription_info['coupons'][] = array( 'coupon_code' => $coupon_code, 'discount_amount' => $discount_amount * $cart_item['quantity'], 'discount_amount_tax' =>$discount_amount_tax * $cart_item['quantity']);
                                $new_cart->applied_coupons[] = $coupon_code;
                            }
                        }


                        $new_cart->calculate_totals();

                        // Recalculate totals
                        //save some order settings
                        $subscription_info['order_shipping']     = wc_format_decimal( $new_cart->shipping_total );
                        $subscription_info['order_shipping_tax'] = wc_format_decimal( $new_cart->shipping_tax_total );
                        $subscription_info['cart_discount']      = wc_format_decimal( $new_cart->get_cart_discount_total() );
                        $subscription_info['cart_discount_tax']  = wc_format_decimal( $new_cart->get_cart_discount_tax_total() );
                        $subscription_info['order_discount']     = $new_cart->get_total_discount();
                        $subscription_info['order_tax']          = wc_format_decimal( $new_cart->tax_total );
                        $subscription_info['order_subtotal']     = wc_format_decimal( $new_cart->subtotal, get_option( 'woocommerce_price_num_decimals' ) );
                        $subscription_info['order_total']        = wc_format_decimal( $new_cart->total, get_option( 'woocommerce_price_num_decimals' ) );
                        $subscription_info['line_subtotal']      = wc_format_decimal( $new_cart->cart_contents[$new_cart_item_key]['line_subtotal'] );
                        $subscription_info['line_subtotal_tax']  = wc_format_decimal( $new_cart->cart_contents[$new_cart_item_key]['line_subtotal_tax'] );
                        $subscription_info['line_total']         = wc_format_decimal( $new_cart->cart_contents[$new_cart_item_key]['line_total'] );
                        $subscription_info['line_tax']           = wc_format_decimal( $new_cart->cart_contents[$new_cart_item_key]['line_tax'] );
                        $subscription_info['line_tax_data']      = $new_cart->cart_contents[$new_cart_item_key]['line_tax_data'];

                    }


                    // Get shipping details
                    if ($product->needs_shipping()) {

                        if (isset( $shipping['method'] ) && isset(WC()->shipping->packages[0]['rates'][$shipping['method']])) {

                            $method = WC()->shipping->packages[0]['rates'][$shipping['method']];
                            $subscription_info['shipping'] = array(
                                'name'      => $method->label,
                                'method_id' => $method->id,
                                'cost'      => wc_format_decimal($method->cost),
                                'taxes'      => $method->taxes,
                            );

                            // Set session variables to original values and recalculate shipping for original order which is being processed now
                            WC()->session->set('shipping_method_counts', $save_temp_session_values['shipping_method_counts']);
                            WC()->session->set('chosen_shipping_methods', $save_temp_session_values['chosen_shipping_methods']);
                            WC()->shipping->calculate_shipping(WC()->shipping->packages);
                        }


                    }

                    //CALCULATE TAXES
                    foreach ( $new_cart->get_tax_totals() as $rate_key => $rate ) {
                        $subscription_info['taxes'][] = array(
                            'name'                => $rate_key,
                            'rate_id'             => $rate->tax_rate_id,
                            'label'               => $rate->label,
                            'compound'            => absint( $rate->is_compound ? 1 : 0 ),
                            'tax_amount'          => wc_format_decimal( isset( $new_cart->taxes[$rate->tax_rate_id] ) ? $new_cart->taxes[$rate->tax_rate_id] : 0 ),
                            'shipping_tax_amount' => wc_format_decimal( isset( $new_cart->shipping_taxes[$rate->tax_rate_id] ) ? $new_cart->shipping_taxes[$rate->tax_rate_id] : 0 ),
                        );
                    }

                    if ( isset( $checkout->posted['payment_method'] ) && $checkout->posted['payment_method'] ) {
                        $enabled_gateways = WC()->payment_gateways->get_available_payment_gateways();

                        if ( isset( $enabled_gateways[$checkout->posted['payment_method']] ) ) {
                            $payment_method = $enabled_gateways[$checkout->posted['payment_method']];
                            $payment_method->validate_fields();
                            $subscription_info['payment_method']       = $payment_method->id;
                            $subscription_info['payment_method_title'] = $payment_method->get_title();
                        }
                    }


                    $this->subscriptions_info['cart'][$cart_item_key] = $subscription_info;


                }


            }


         }


        /**
         * Save the options of subscription in an array with order item id
         *
         * @access public
         *
         * @param  $item_id int
         * @param  $values array
         * @param  $cart_item_key int
         *
         * @return string
         */
        public function add_subscription_order_item_meta( $item_id, $values, $cart_item_key ) {

            if ( isset( $this->subscriptions_info['cart'][$cart_item_key] ) ) {
                $this->subscriptions_info['order'][$item_id] = $this->subscriptions_info['cart'][$cart_item_key];
                wc_add_order_item_meta( $item_id, '_subscription_info', $this->subscriptions_info['cart'][$cart_item_key], true );
                if ( YITH_WC_Subscription()->debug_active ) {
                    YITH_WC_Subscription()->debug->add( 'ywsbs', 'added _subscription_info meta for item_id : ' . $item_id . '  cart_item_key : ' . $cart_item_key );
                }
            }
        }


        /**
         * Overwrite chosen shipping method temp for calculate the subscription shippings
         *
         * @access public
         * @return string
         */
        public function change_shipping_chosen_method_temp( $method ) {
            return isset( $this->subscription_shipping_method_temp ) ? $this->subscription_shipping_method_temp : $method;
        }


        /**
         * Check in the order if there's a subscription and create it
         *
         * @access public
         *
         * @param  $order_id int
         * @param  $posted   array
         *
         * @return void
         */
        public function check_order_for_subscription( $order_id, $posted ) {

            $order = wc_get_order( $order_id );
            $order_items = $order->get_items();

            //check id the the subscriptions are created
            $subscriptions = get_post_meta( $order_id, 'subscriptions', true );

            if ( empty( $order_items ) || ! empty( $subscriptions ) ) {
                return;
            }

            foreach ( $order_items as $key => $order_item  ) {

                $_product = $order->get_product_from_item( $order_item );
                if ( $_product == false ) {
                    continue;
                }
                $id = isset( $_product->variation_id ) ? $_product->variation_id : $_product->id;

                $args = array();

                if( YITH_WC_Subscription()->is_subscription( $id ) ){

                    if ( YITH_WC_Subscription()->debug_active ) {
                        YITH_WC_Subscription()->debug->add( 'ywsbs', 'find a subscription at woocommerce_checkout_order_processed : ' . $order_id .' product_id : '. $id );
                    }

                    if ( ! isset( $this->subscriptions_info['order'][ $key ] ) ) {
                        continue;
                    }


                    $subscription_info = $this->subscriptions_info['order'][$key];


                    $max_length        = get_post_meta( $id, '_ywsbs_max_length', true );
                    $price_is_per      = get_post_meta( $id, '_ywsbs_price_is_per', true );
                    $price_time_option = get_post_meta( $id, '_ywsbs_price_time_option', true );
                    $fee               = get_post_meta( $id, '_ywsbs_fee', true );
                    $duration          = ( empty($max_length) ) ? '' : ywsbs_get_timestamp_from_option( 0, $max_length, $price_time_option );

                    // DOWNGRADE PROCESS
                    // Set a trial period for the new downgrade subscription so the next payment will be due at the expiration date of the previous subscription
                    if ( get_user_meta( get_current_user_id(), 'ywsbs_trial_' . $id, true ) != '' ) {
                        $trial_info        = get_user_meta( get_current_user_id(), 'ywsbs_trial_' . $id, true );
                        $trial_period      = $trial_info['trial_days'];
                        $trial_time_option = 'days';

                    } else {
                        $trial_period      = get_post_meta( $id, '_ywsbs_trial_per', true );
                        $trial_time_option = get_post_meta( $id, '_ywsbs_trial_time_option', true );
                    }

                    if ( $old_sub = get_user_meta( get_current_user_id(), 'ywsbs_downgrade_' . $id, true ) ) {
                        update_post_meta( $old_sub, 'ywsbs_swiched', 'yes' );
                    }

                    // UPGRADE PROCESS
                    // if the we are in the upgrade process and the prorate must be done
                    $subscription_old_id = $pay_gap = '';
                    $prorate_length      = get_post_meta( $id, '_ywsbs_prorate_length', true );
                    $gap_payment         = get_post_meta( $id, '_ywsbs_gap_payment', true );
                    $subscription_upgrade_info   = get_user_meta( get_current_user_id(), 'ywsbs_upgrade_' . $id, true );

                    if ( ! empty( $subscription_upgrade_info ) ) {
                        $subscription_old_id = $subscription_upgrade_info['subscription_id'];
                        $pay_gap             = $subscription_upgrade_info['pay_gap'];
                        $trial_period        = '';

                    }

                    if ( $prorate_length == 'yes' && ! empty( $max_length ) && $subscription_old_id != '' ) {

                        $old_sub         = ywsbs_get_subscription( $subscription_old_id );
                        $activity_period = $old_sub->get_activity_period();

                        if ( $price_time_option == $old_sub->price_time_option ) {
                            $new_max_length = $max_length - ceil( $activity_period / ywsbs_get_timestamp_from_option( 0, 1, $old_sub->price_time_option ) );
                        } else {
                            $new_duration   = ywsbs_get_days( $duration - $activity_period );
                            $new_max_length = $new_duration / ywsbs_get_timestamp_from_option( 0, 1, $price_time_option );
                        }

                        $max_length = abs( $new_max_length );
                    }

                    if( $gap_payment=='yes' && $pay_gap > 0 ){
                        //change the fee of the subscription adding the total amount of the previous rates
                        $fee =  $pay_gap;
                    }

                    // UPGRADE PROCESS
                    //if this subscription is an upgrade the old subscription will be cancelled
                    if ( $subscription_old_id != '' ) {
                        YITH_WC_Subscription()->cancel_subscription_after_upgrade( $subscription_old_id );
                        delete_user_meta( get_current_user_id(), 'ywsbs_upgrade_' . $id );
                        update_post_meta( $subscription_old_id->id, 'ywsbs_swiched', 'yes' );
                    }


                    // fill the array for subscription creation
                    $args = array(
                        'product_id'              => $order_item['product_id'],
                        'variation_id'            => $order_item['variation_id'],
                        'variation'               => ( isset( $subscription_info['variation'] ) ? $subscription_info['variation'] : '' ),
                        'product_name'            => $order_item['name'],

                        //order details
                        'order_id'                => $order_id,
                       // 'order_item_id'           => $key,
                        'order_ids'               => array( $order_id ),
                        'line_subtotal'           => $subscription_info['line_subtotal'],
                        'line_total'              => $subscription_info['line_total'],
                        'line_subtotal_tax'       => $subscription_info['line_subtotal_tax'],
                        'line_tax'                => $subscription_info['line_tax'],
                        'line_tax_data'           => $subscription_info['line_tax_data'],
                        'cart_discount'           => $subscription_info['cart_discount'],
                        'cart_discount_tax'       => $subscription_info['cart_discount_tax'],
                        'coupons'                 => ( isset( $subscription_info['coupons'] ) ) ? $subscription_info['coupons'] : '',
                        'order_total'             => $subscription_info['order_total'],
                        'subscription_total'      => $subscription_info['order_total'],
                        'order_tax'               => $subscription_info['order_tax'],
                        'order_subtotal'          => $subscription_info['order_subtotal'],
                        'order_discount'          => $subscription_info['order_discount'],
                        'order_shipping'          => $subscription_info['order_shipping'],
                        'order_shipping_tax'      => $subscription_info['order_shipping_tax'],
                        'subscriptions_shippings' => $subscription_info['shipping'],
                        'payment_method'          => $subscription_info['payment_method'],
                        'payment_method_title'    => $subscription_info['payment_method_title'],
                        'order_currency'          => get_post_meta( $order_id, '_order_currency', true ),
                        'prices_include_tax'      => get_post_meta( $order_id, '_prices_include_tax', true ),
                        //user details
                        'quantity'                => $order_item['qty'],
                        'user_id'                 => get_post_meta( $order_id, '_customer_user', true ),
                        'customer_ip_address'     => get_post_meta( $order_id, '_customer_ip_address', true ),
                        'customer_user_agent'     => get_post_meta( $order_id, '_customer_user_agent', true ),
                        //item subscription detail
                        'price_is_per'            => $price_is_per,
                        'price_time_option'       => $price_time_option,
                        'max_length'              => $max_length,
                        'trial_per'               => $trial_period,
                        'trial_time_option'       => $trial_time_option,
                        'fee'                     => $fee,
                        'num_of_rates'            => ( $max_length && $price_is_per ) ? $max_length / $price_is_per : '',
                        'billing_first_name'      => get_post_meta( $order_id, '_billing_first_name', true ),
                        'billing_last_name'       => get_post_meta( $order_id, '_billing_last_name', true ),
                        'billing_company'         => get_post_meta( $order_id, '_billing_company', true ),
                        'billing_address_1'       => get_post_meta( $order_id, '_billing_address_1', true ),
                        'billing_address_2'       => get_post_meta( $order_id, '_billing_address_2', true ),
                        'billing_city'            => get_post_meta( $order_id, '_billing_city', true ),
                        'billing_state'           => get_post_meta( $order_id, '_billing_state', true ),
                        'billing_postcode'        => get_post_meta( $order_id, '_billing_postcode', true ),
                        'billing_country'         => get_post_meta( $order_id, '_billing_country', true ),
                        'billing_email'           => get_post_meta( $order_id, '_billing_email', true ),
                        'billing_phone'           => get_post_meta( $order_id, '_billing_phone', true ),
                        'shipping_first_name'     => get_post_meta( $order_id, '_shipping_first_name', true ),
                        'shipping_last_name'      => get_post_meta( $order_id, '_shipping_last_name', true ),
                        'shipping_company'        => get_post_meta( $order_id, '_shipping_company', true ),
                        'shipping_address_1'      => get_post_meta( $order_id, '_shipping_address_1', true ),
                        'shipping_address_2'      => get_post_meta( $order_id, '_shipping_address_2', true ),
                        'shipping_city'           => get_post_meta( $order_id, '_shipping_city', true ),
                        'shipping_state'          => get_post_meta( $order_id, '_shipping_state', true ),
                        'shipping_postcode'       => get_post_meta( $order_id, '_shipping_postcode', true ),
                        'shipping_country'        => get_post_meta( $order_id, '_shipping_country', true ),


                    );

                    $subscription = new YWSBS_Subscription( '', $args );

                    $subscriptions = get_post_meta( $order_id, 'subscriptions', true );

                    //save the version of plugin in the order
                    update_post_meta( $order_id, '_ywsbs_order_version', YITH_YWSBS_VERSION );



                    if ( $subscription->id ) {
                        $subscriptions[] = $subscription->id;
                        update_post_meta( $order_id, 'subscriptions', $subscriptions );
                        $order->add_order_note( sprintf( __( 'A new subscription <a href="%s">#%s</a> has been created from this order', 'yith-woocommerce-subscription' ), admin_url( 'post.php?post=' . $subscription->id . '&action=edit' ), $subscription->id ) );

                        if ( YITH_WC_Subscription()->debug_active ) {
                            YITH_WC_Subscription()->debug->add( 'ywsbs', 'Created a new subscription ' . $subscription->id . ' for order: ' . $order_id );
                        }

                    }

                }


            }
        }


        /**
         * Actives a subscription after a payment is done
         *
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         *
         * @param $order_id
         *
         * @return void
         */
        public function payment_complete( $order_id ) {

            $subscriptions = get_post_meta( $order_id, 'subscriptions', true );

            if ( $subscriptions ) {
                foreach ( $subscriptions as $subscription_id ) {
                    $subscription = ywsbs_get_subscription( $subscription_id );

                    //check if the subscription exists
                    if( is_null( $subscription->post ) ){
                        continue;
                    }

                    //reset failed payment
                    update_post_meta( $subscription->order_id, 'failed_attemps', 0 );

                    $payed_order = is_array( $subscription->payed_order_list ) ? $subscription->payed_order_list : array();

                    if ( ! in_array( $order_id, $payed_order ) ){
                        if ( $subscription->renew_order != 0 && $subscription->renew_order == $order_id ) {
                            $subscription->update( $order_id );
                        }elseif ( $subscription->renew_order == 0 ) {
                            $subscription->start( $order_id );
                        }
                    }
                }
            }
        }

		/**
         * @param null $subscription
         *
         * @return string
         */
        public function get_renew_order_status( $subscription = null ){

            $new_status = 'on-hold';

            if ( ! is_null( $subscription ) && $subscription->payment_method == 'bacs' ) {
                $new_status = 'pending';
            }

            //the status must be register as wc status
            $status = apply_filters( 'ywsbs_renew_order_status', $new_status, $subscription );

            return $status;
        }

        /**
         * Create a new order for next payments of a subscription
         *
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         *
         * @param $subscription_id
         *
         * @return int
         * @throws Exception
         */
        public function renew_order( $subscription_id ) {

            $subscription = new YWSBS_Subscription( $subscription_id );
            $status = $this->get_renew_order_status( $subscription );

            $order = wc_create_order( $args = array(
                'status'      => $status,
                'customer_id' => $subscription->user_id
            ) );


            $args = array(
                'subscriptions'      => array( $subscription_id ),
                'billing_first_name' => $subscription->billing_first_name,
                'billing_last_name'  => $subscription->billing_last_name,
                'billing_company'    => $subscription->billing_company,
                'billing_address_1'  => $subscription->billing_address_1,
                'billing_address_2'  => $subscription->billing_address_2,
                'billing_city'       => $subscription->billing_city,
                'billing_state'      => $subscription->billing_state,
                'billing_postcode'   => $subscription->billing_postcode,
                'billing_country'    => $subscription->billing_country,
                'billing_email'      => $subscription->billing_email,
                'billing_phone'      => $subscription->billing_phone,

                'shipping_first_name' => $subscription->shipping_first_name,
                'shipping_last_name'  => $subscription->shipping_last_name,
                'shipping_company'    => $subscription->shipping_company,
                'shipping_address_1'  => $subscription->shipping_address_1,
                'shipping_address_2'  => $subscription->shipping_address_2,
                'shipping_city'       => $subscription->shipping_city,
                'shipping_state'      => $subscription->shipping_state,
                'shipping_postcode'   => $subscription->shipping_postcode,
                'shipping_country'    => $subscription->shipping_country,
                '_payment_method'     => $subscription->payment_method,

            );

            foreach ( $args as $key => $value  ) {
                if( $key == 'subscriptions'){
                    add_post_meta( $order->id, $key, $value );
                }
                add_post_meta( $order->id, '_'.$key, $value );
            }

            $_product = wc_get_product( ( isset( $subscription->variation_id ) && !empty( $subscription->variation_id ) ) ? $subscription->variation_id : $subscription->product_id );

            $total = 0;
            $tax_total = 0;

            $variations = array();

            $item_id = $order->add_product(
                $_product,
                $subscription->quantity,
                array(
                    'variation' => $variations,
                    'totals'    => array(
                        'subtotal'     => $subscription->line_subtotal,
                        'subtotal_tax' => $subscription->line_subtotal_tax,
                        'total'        => $subscription->line_total,
                        'tax'          => $subscription->line_tax,
                        'tax_data'     => maybe_unserialize($subscription->line_tax_data)
                    )
                )
            );


            add_option('ywsbs_item', print_r(array(
                'variation' => $variations,
                'totals'    => array(
                    'subtotal'     => $subscription->line_subtotal,
                    'subtotal_tax' => $subscription->line_subtotal_tax,
                    'total'        => $subscription->line_total,
                    'tax'          => $subscription->line_tax,
                    'tax_data'     => maybe_unserialize($subscription->line_tax_data)
                )
            ), true));

            if ( !$item_id ) {
                throw new Exception( sprintf( __( 'Error %d: unable to create the order. Please try again.','yith-woocommerce-subscription'), 402 ) );
            }
            else {
                $total += $subscription->line_total;
                $tax_total += $subscription->line_tax;
            }

            $shipping_cost = 0;


            //Shipping
            if ( !empty( $subscription->subscriptions_shippings ) ) {

                $shipping_item_id = wc_add_order_item( $order->id, array(
                    'order_item_name' => $subscription->subscriptions_shippings['method_id'],
                    'order_item_type' => 'shipping',
                ) );

                $shipping_cost = $subscription->subscriptions_shippings['cost'];
                $shipping_cost_tax = 0;

                wc_add_order_item_meta( $shipping_item_id, 'method_id', $subscription->subscriptions_shippings['method_id'] );
                wc_add_order_item_meta( $shipping_item_id, 'cost', wc_format_decimal( $shipping_cost ) );
                wc_add_order_item_meta( $shipping_item_id, 'taxes',  $subscription->subscriptions_shippings['taxes']);
                if( !empty($subscription->subscriptions_shippings['taxes'])){
                    foreach( $subscription->subscriptions_shippings['taxes'] as $tax_cost ){
                        $shipping_cost_tax += $tax_cost;
                    }
                }

                $order->set_total( wc_format_decimal( $shipping_cost ), 'shipping' );

            }

            $cart_discount_total = 0;
            $cart_discount_total_tax = 0;

            //coupons
            if( !empty( $subscription->coupons) ){
                foreach( $subscription->coupons  as $coupon ){
                    $order->add_coupon( $coupon['coupon_code'], $coupon['discount_amount'],  $coupon['discount_amount_tax']);
                    $cart_discount_total += $coupon['discount_amount'];
                    $cart_discount_total_tax += $coupon['discount_amount_tax'];
                }
            }

            $order->set_total( $cart_discount_total, 'cart_discount' );
            $order->set_total( $cart_discount_total_tax, 'cart_discount_tax' );

            // $order->set_total( $total + $tax_total + $shipping_cost + $shipping_cost_tax );
            $order->update_taxes();
            $totals = $order->calculate_totals();
            $order->set_total($totals);

            //attach the new order to the subscription
            $subscription->order_ids[] = $order->id;

            update_post_meta( $subscription->id,'order_ids', $subscription->order_ids );
            update_post_meta( $order->id, 'is_a_renew', 'yes' );

            $order->add_order_note( sprintf( __( 'This order has been created to renew subscription <a href="%s">#%s</a>', 'yith-woocommerce-subscription' ), admin_url( 'post.php?post=' . $subscription->id . '&action=edit' ), $subscription->id));

            YITH_WC_Activity()->add_activity( $subscription->id, 'renew-order', 'success', $order->id, sprintf(__('The order %d has been created for the subscription','yith-woocommerce-subscription'), $order->id));



            return $order->id;

        }

        /**
         * Cancel the subscription if the order is refunded
         *
         *
         * @since    1.0.1
         * @author   Emanuela Castorina
         *
         * @param $order_id
         * @param $refund_id
         *
         * @return int
         * @internal param $subscription_id
         *
         */
        public function order_refunded( $order_id, $refund_id = 0 ) {

            $subscriptions = get_post_meta( $order_id, 'subscriptions', true );

            if ( $subscriptions ) {
                foreach ( $subscriptions as $subscription_id ) {
                    $subscription = ywsbs_get_subscription( $subscription_id );
                    if ( is_null( $subscription ) ) {
                        continue;
                    }

                    if( $subscription->status == 'cancelled' ){
                        $subscription->set('end_date', current_time('timestamp') );
                        do_action('ywsbs_refund_subscription', $subscription);
                    }else{
                        $subscription->update_status( 'cancel-now', 'refund' );
                    }

                }
            }
        }


		/**
         * @param $order_id
         */
        public function reactive_subscription( $order_id  ) {
            $subscriptions = get_post_meta( $order_id, 'subscriptions', true );

            if ( $subscriptions ) {
                foreach ( $subscriptions as $subscription_id ) {
                    $subscription = ywsbs_get_subscription( $subscription_id );
                    if ( is_null( $subscription ) ) {
                        continue;
                    }

                    if( $subscription->status != 'cancelled' ){
                        $subscription->update_status( 'active', 'resumed' );
                    }

                }
            }
        }


        /**
         * Check if the new order have subscriptions
         *
         * @access public
         *
         * @return bool
         *
         * @since  1.0.0
         */
        public function the_order_have_subscriptions(){
            if( isset( WC()->cart ) ){
                foreach (WC()->cart->cart_contents as $cart_item_key => $cart_item) {
                    $id = !empty( $cart_item['variation_id'] ) ? $cart_item['variation_id'] : $cart_item['product_id'];
                    if ( YITH_WC_Subscription()->is_subscription( $id ) ) {
                        return true;
                    }
                }
            }

            return false;
        }

        /**
         * If there's a subscription inside the order, even if the order total is $0, it still needs payment
         *
         * @param $needs_payment        bool
         * @param $order                object
         * @param $valid_order_statuses array
         *
         * @return bool
         *
         * @since  1.0.0
         */
        public function order_need_payment( $needs_payment, $order, $valid_order_statuses ) {

            if ( ! $needs_payment && $this->the_order_have_subscriptions() && in_array( $order->status, $valid_order_statuses ) && 0 == $order->get_total() ) {
                return true;
            }

            return $needs_payment;

        }


		/**
         * Delete all subscription if an order change the status to cancelled
         *
         * @param $order_id
         */
        public function delete_subscriptions( $order_id ) {

            $is_a_renew = get_post_meta( $order_id, 'is_a_renew', 'yes' );

            $subscriptions = get_post_meta( $order_id, 'subscriptions', true);

            if ( empty( $subscriptions ) || $is_a_renew == 'yes') {
                return;
            }

            foreach ( $subscriptions as $subscription_id ) {
                $subscription = ywsbs_get_subscription( $subscription_id );
                //check if the subscription exists
                if( is_null( $subscription->post ) ){
                    continue;
                }

                $subscription->delete();

            }
        }

    }
}

/**
 * Unique access to instance of YWSBS_Subscription_Order class
 *
 * @return \YWSBS_Subscription_Order
 */
function YWSBS_Subscription_Order() {
    return YWSBS_Subscription_Order::get_instance();
}
