<?php

if ( !defined( 'ABSPATH' ) || !defined( 'YITH_YWSBS_VERSION' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Implements admin features of YITH WooCommerce Subscription
 *
 * @class   YITH_WC_Subscription
 * @package YITH WooCommerce Subscription
 * @since   1.0.0
 * @author  Yithemes
 */
if ( !class_exists( 'YITH_WC_Subscription' ) ) {

    class YITH_WC_Subscription {

        /**
         * Single instance of the class
         *
         * @var \YITH_WC_Subscription
         */
        protected static $instance;

        /**
         * Post name of subscription
         *
         * @var string
         */
        public $post_name =  'ywsbs_subscription';
		/**
         * @var bool
         */
        public $debug_active =  false;
		/**
         * @var WC_Logger
         */
        public $debug;

        /**
         * Returns single instance of the class
         *
         * @return \YITH_WC_Subscription
         * @since 1.0.0
         */
        public static function get_instance() {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        /**
         * Constructor
         *
         * Initialize plugin and registers actions and filters to be used
         *
         * @since  1.0.0
         */
        public function __construct() {
            add_action( 'plugins_loaded', array( $this, 'plugin_fw_loader' ), 15 );

            //Register plugin to licence/update system
            add_action( 'wp_loaded', array( $this, 'register_plugin_for_activation' ), 99 );
            add_action( 'admin_init', array( $this, 'register_plugin_for_updates' ) );

            if ( get_option( 'ywsbs_enabled' ) != 'yes' ) {
                return;
            }

            if( get_option( 'ywsbs_enable_log' ) == 'yes' ){
                $this->debug_active = true;
                $this->debug        = new WC_Logger();
            }

            /*save url site*/
            add_action( 'init', array( $this, 'save_site_url' ), 1 );
            add_action( 'admin_notices', array( $this, 'different_url_notification' ) );

            add_action( 'wp_loaded', array( $this, 'myaccount_actions' ), 90 );

            /* general actions */
            add_filter( 'woocommerce_locate_core_template', array( $this, 'filter_woocommerce_template' ), 10, 3 );
            add_filter( 'woocommerce_locate_template', array( $this, 'filter_woocommerce_template' ), 10, 3 );

            //custom styles and javascripts
            add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles_scripts' ), 11 );

            /*Load Singleton istances*/
            YWSBS_Subscription_Helper();
            YITH_WC_Activity();

            YWSBS_Subscription_Cron();
            YWSBS_Subscription_Order();
            YWSBS_Subscription_Cart();
            YWSBS_Subscription_Paypal();
            YWSBS_Subscription_Coupons();


            //My Account Subscription Sections
            add_action( 'woocommerce_before_my_account', array( $this, 'my_account_subscriptions' ) );
            add_action( 'woocommerce_order_details_after_order_table', array( $this, 'subscriptions_related' ) );
            add_shortcode( 'ywsbs_my_account_subscriptions', array( $this, 'my_account_subscriptions_shortcode' ) );

            //add endpoint view-quote
            $this->add_endpoint();
            add_action( 'template_redirect', array( $this, 'load_subscription_detail_page' ) );

            // Change product prices
            add_filter( 'woocommerce_get_price_html', array( $this, 'change_price_html' ), 10, 2 );
            add_filter( 'woocommerce_get_variation_price_html', array( $this, 'change_price_html' ), 10, 2 );

            //Add to cart label
            add_filter( 'woocommerce_product_single_add_to_cart_text', array( $this, 'change_add_to_cart_label'), 99, 2 );
            add_filter( 'add_to_cart_text', array( $this, 'change_add_to_cart_label' ), 99 );
            add_filter( 'woocommerce_product_add_to_cart_text', array( $this, 'change_add_to_cart_label' ), 99, 2 );
            add_filter( 'woocommerce_available_variation', array( $this, 'add_params_to_available_variation' ), 10, 3 );

            //Order detail
            add_filter( 'woocommerce_order_formatted_line_subtotal', array( $this, 'order_formatted_line_subtotal'), 10, 3 );

            // Ensure a subscription is never in the cart with products
            add_filter( 'woocommerce_add_to_cart_validation', array( $this, 'cart_item_validate' ), 10, 4 );

            //email settings
            add_filter( 'woocommerce_email_classes', array( $this, 'add_woocommerce_emails' ) );
            add_action( 'woocommerce_init', array( $this, 'load_wc_mailer' ) );

            //YITH WooCommerce Multivendor compatibility
            if ( defined( 'YITH_WPV_PREMIUM' ) ) {
                require_once( YITH_YWSBS_INC . 'compatibility/yith-woocommerce-product-vendors.php' );
                YWSBS_Multivendor();
            }


            //YITH WooCommerce Membership compatibility
            if ( defined( 'YITH_WCMBS_PREMIUM' ) ) {
                require_once( YITH_YWSBS_INC . 'compatibility/yith-woocommerce-membership.php' );
                YWSBS_Membership();
            }
        }

        /**
         * Enqueue styles and scripts
         *
         * @access public
         * @return void
         * @since  1.0.0
         */
        public function enqueue_styles_scripts() {

            $assets_path = str_replace( array( 'http:', 'https:' ), '', WC()->plugin_url() ) . '/assets/';

            // Prettyphoto for modal questions
            wp_enqueue_style( 'woocommerce_prettyPhoto_css', $assets_path . 'css/prettyPhoto.css' );
            wp_enqueue_style( 'yith_ywsbs_frontend', YITH_YWSBS_ASSETS_URL . '/css/frontend.css', YITH_YWSBS_VERSION );
            wp_enqueue_script( 'ywsbs-prettyPhoto', $assets_path . 'js/prettyPhoto/jquery.prettyPhoto' . YITH_YWSBS_SUFFIX . '.js', array( 'jquery' ), false, true );

            wp_enqueue_script( 'yith_ywsbs_frontend', YITH_YWSBS_ASSETS_URL . '/js/ywsbs-frontend' . YITH_YWSBS_SUFFIX . '.js', array(
                'jquery',
                'wc-add-to-cart-variation'
            ), YITH_YWSBS_VERSION, true );

            wp_localize_script( 'yith_ywsbs_frontend', 'yith_ywsbs_frontend', array(
                'add_to_cart_label' => get_option( 'ywsbs_add_to_cart_label' )
            ) );
        }


        /**
         * Add custom params to variations
         *
         * @access public
         *
         * @param $args      array
         * @param $product   object
         * @param $variation object
         *
         * @return array
         * @since  1.0.0
         */
        public function add_params_to_available_variation( $args, $product, $variation ) {

            if ( $this->is_subscription( $variation->variation_id ) ) {
                $args['is_subscription'] = true;
            } else {
                $args['is_subscription'] = false;
            }

            $is_switchable = get_post_meta( $variation->variation_id, '_ywsbs_switchable', true );
            if ( $is_switchable ) {
                $args['is_switchable'] = true;
            } else {
                $args['is_switchable'] = false;
            }

            return $args;
        }


        /**
         * Load YIT Plugin Framework
         *
         * @access public
         *
         * @return void
         * @since  1.0.0
         */
        public function plugin_fw_loader() {
            if ( ! defined( 'YIT_CORE_PLUGIN' ) ) {
                global $plugin_fw_data;
                if ( ! empty( $plugin_fw_data ) ) {
                    $plugin_fw_file = array_shift( $plugin_fw_data );
                    require_once( $plugin_fw_file );
                }
            }
        }


        /**
         * Locate default templates of woocommerce in plugin, if exists
         *
         * @access public
         *
         * @param $core_file     string
         * @param $template      string
         * @param $template_base string
         *
         * @return string
         * @since  1.0.0
         */
        public function filter_woocommerce_template( $core_file, $template, $template_base ) {
            $located = yith_ywsbs_locate_template( $template );
            if ( $located ) {
                return $located;
            } else {
                return $core_file;
            }
        }

        /**
         * Change price HTML to the product
         *
         * @access public
         *
         * @param $price        float
         * @param $product      object
         *
         * @return string
         * @since  1.0.0
         */
        public function change_price_html( $price, $product ) {

            $id = $product->product_type == 'variation' ? $product->variation_id : $product->id;

            if ( ! $this->is_subscription( $id ) ) {
                return $price;
            }

            $signup_fee =  get_post_meta( $id, '_ywsbs_fee', true );

            $trial_period      = get_post_meta( $id, '_ywsbs_trial_per', true );
            $trial_time_option = get_post_meta( $id, '_ywsbs_trial_time_option', true );

            $price_is_per      = get_post_meta( $id, '_ywsbs_price_is_per', true );
            $price_time_option = get_post_meta( $id, '_ywsbs_price_time_option', true );
            $max_length = get_post_meta( $id, '_ywsbs_max_length', true );


            $price_is_per_string = ( $price_is_per == 1 ) ? '' : $price_is_per;
            $price_time_option_string = ywsbs_get_price_per_string( $price_is_per,  $price_time_option );
            $price .= ' / ' . $price_time_option_string;


            if ( $product->product_type != 'variable' &&
                    (
                        ( $max_length && get_option( 'ywsbs_show_length_period' ) == 'yes' ) ||
                        ( $signup_fee && get_option( 'ywsbs_show_fee' ) == 'yes' ) ||
                        ( $trial_period && get_option( 'ywsbs_show_trial_period' ) == 'yes' )
                    )
            ) {

                if ( $max_length && get_option( 'ywsbs_show_length_period' ) == 'yes') {
                    $price .= __( ' for ', 'yith-woocommerce-subscription' ) . $max_length . ' ' . $price_time_option;
                }

                $and = false;
                $price .= ( $signup_fee ||  $trial_period ) ? __('<span class="ywsbs-price-detail"> + a ','yith-woocommerce-subscription') : '';

                if ( $signup_fee  && get_option( 'ywsbs_show_fee' ) == 'yes' ) {
                    $price .= $and ? __( ' and ', 'yith-woocommerce-subscription' ) : '';
                    $price .= __( ' sign-up fee of ', 'yith-woocommerce-subscription' ) . wc_price( $signup_fee );
                    $and = true;
                }

                if ( $trial_period && get_option( 'ywsbs_show_trial_period' ) == 'yes') {
                    $price .= $and ? __( ' and ', 'yith-woocommerce-subscription' ) : '';
                    $price .= __( ' free trial of ', 'yith-woocommerce-subscription' ) . $trial_period . ' ' . $trial_time_option;
                }

                $price .= ( $signup_fee ||  $trial_period ) ? '</span>' : '';
            }

            return apply_filters('ywsbs_change_price_html', $price, $product, $price_is_per, $price_time_option, $max_length, $signup_fee, $trial_period );
        }

        /**
         * Check if a product is a subscription
         *
         * @access public
         *
         * @param int $product_id
         *
         * @return bool
         * @since  1.0.0
         */
        public function is_subscription( $product_id ) {
            $is_subscription = get_post_meta( $product_id, '_ywsbs_subscription', true );
            $price_is_per    = get_post_meta( $product_id, '_ywsbs_price_is_per', true );
            return ( $is_subscription == 'yes' && $price_is_per != '' ) ? true : false;
        }

        /**
         * Check if in the cart there are subscription that needs shipping
         *
         * @access public
         *
         * @return bool
         * @since  1.0.0
         */
        public function cart_has_subscription_with_shipping() {

            $cart_has_subscription_with_shipping = false;

            $cart_contents = WC()->cart->cart_contents;
            if ( ! isset( $cart_contents ) || empty( $cart_contents ) ) {
                return $cart_has_subscription_with_shipping;
            }

            foreach ( $cart_contents as $cart_item ) {
                $product = $cart_item['data'];

                $id = $product->product_type == 'variation' ? $product->variation_id : $product->id;

                if ( $this->is_subscription( $id ) && $product->needs_shipping() ) {
                    $cart_has_subscription_with_shipping = true;
                }
            }

            return apply_filters( 'ywsbs_cart_has_subscription_with_shipping', $cart_has_subscription_with_shipping );
        }


        /**
         * Only a subscription can be added to the cart this method check if there's
         * a subscription in cart and remove the element if thenext product to add is another subscription
         *
         * @param $valid        bool
         * @param $product_id   int
         * @param $quantity     int
         * @param $variation_id int
         *
         * @return bool
         * @since  1.0.0
         */
        public function cart_item_validate( $valid, $product_id, $quantity, $variation_id = 0 ) {

            $id = ( ! empty( $variation_id ) ) ? $variation_id : $product_id;

            if ( $this->is_subscription( $id ) && $item_key = $this->cart_has_subscriptions() ) {

                $current_item = WC()->cart->get_cart_item( $item_key );

                $item_id = ( ! empty( $current_item['variation_id'] ) ) ? $current_item['variation_id'] : $current_item['product_id'];

                if ( $item_id != $id ) {
                    $this->clean_cart_from_subscriptions( $item_key );
                    $message = __( 'A subscription has been removed from your cart. You cannot purchase different subscriptions at the same time.', 'yith-woocommerce-subscription' );
                    wc_add_notice( $message, 'notice' );
                }
            }

            return $valid;
        }

        /**
         * Removes all subscription products from the shopping cart.
         *
         * @param $item_key int
         *
         * @return void
         * @since 1.0.0
         */
        public function clean_cart_from_subscriptions( $item_key ) {
            WC()->cart->set_quantity( $item_key, 0 );
        }

        /**
         * Check if in the cart there are subscription
         *
         * @return bool/int
         * @since  1.0.0
         */
        public function cart_has_subscriptions() {
            $contents = WC()->cart->cart_contents;
            if ( ! empty( $contents ) ) {
                foreach ( $contents as $item_key => $item ) {
                    $product = $item['data'];
                    $id      = $product->product_type == 'variation' ? $product->variation_id : $product->id;
                    if ( $this->is_subscription( $id ) ) {
                        return $item_key;
                    }
                }
            }

            return false;
        }

        /**
         * Check if in the order there are subscription
         *
         * @param  $order_id int
         *
         * @return bool
         * @since  1.0.0
         */
        public function order_has_subscription( $order_id ) {

            $order       = wc_get_order( $order_id );
            $order_items = $order->get_items();

            if ( empty( $order_items ) ) {
                return false;
            }

            foreach ( $order_items as $key => $order_item ) {
                $id = ( $order_item['variation_id'] ) ? $order_item['variation_id'] : $order_item['product_id'];

                if ( YITH_WC_Subscription()->is_subscription( $id ) ) {
                    return true;
                }
            }

            return false;
        }

        /**
         * Format the line in order details
         *
         * @param $subtotal float
         * @param $item     array
         * @param $order    object
         *
         * @return bool/int
         * @since  1.0.0
         */
        public function order_formatted_line_subtotal( $subtotal, $item, $order ) {

            $product_id = ( ! empty( $item['variation_id'] ) ) ? $item['variation_id'] : $item['product_id'];

            if ( ! $this->is_subscription( $product_id ) ) {
                return $subtotal;
            }

            $product = wc_get_product( $product_id );
            $subtotal = $product->get_price_html();


            return $subtotal;
        }

        /**
         * Change add to cart label in subscription product
         *
         * @param $label      float
         * @param $product    object
         *
         * @return bool/int
         * @since  1.0.0
         */
        public function change_add_to_cart_label( $label, $product = null ) {
            $new_label = get_option( 'ywsbs_add_to_cart_label' );

            if ( is_null( $product ) ) {
                global $product;
            }

            $id = $product->product_type == 'variation' ? $product->variation_id : $product->id;

            if ( $product->product_type == 'variable' ) {
                $attributes = $product->get_variation_default_attributes();
                $default_attributes = array();
                foreach ( $attributes as $key => $value ) {
                    $default_attributes['attribute_' . $key] = $value;
                }

                $id = $product->get_matching_variation( $default_attributes );
            }


            if ( $new_label && $this->is_subscription( $id ) ) {
                $label = $new_label;
            }

            return $label;
        }

        /**
         * Add subscription section to my-account page
         *
         * @since   1.0.0
         * @return  void
         */
        public function my_account_subscriptions(){
            wc_get_template( 'myaccount/my-subscriptions-view.php');
        }

        /**
         * Add subscription section to my-account page
         *
         * @since   1.0.0
         * @return  void
         */
        public function my_account_subscriptions_shortcode(){
            ob_start();
            wc_get_template( 'myaccount/my-subscriptions-view.php');
            return ob_get_clean();
        }

        /**
         * Add subscription section to my-account page
         *
         * @since   1.0.0
         *
         * @param $order
         */
        public function subscriptions_related( $order ) {
            wc_get_template( 'myaccount/subscriptions-related.php', array( 'order' => $order ) );
        }

        /**
         * Add the endpoint for the page in my account to manage the subscription view
         *
         * @since 1.0.0
         */
        public function add_endpoint() {
            WC()->query->query_vars['view-subscription'] = get_option( 'woocommerce_myaccount_view_subscription_endpoint', 'view-subscription' );
        }

        /**
         * Load the page of subscription
         *
         * @since 1.0.0
         */
        public function load_subscription_detail_page() {
            global $wp, $post;

            if ( !is_page( wc_get_page_id( 'myaccount' ) ) || !isset( $wp->query_vars['view-subscription'] ) ) {
                return;
            }

            $subscription_id    = $wp->query_vars['view-subscription'];
            $post->post_title   = sprintf( __( 'Subscription #%s', 'yith-woocommerce-subscription' ), $subscription_id );
            $post->post_content = WC_Shortcodes::shortcode_wrapper( array( $this, 'view_subscription' ) );

            remove_filter( 'the_content', 'wpautop' );        
        }

        /**
         * Show the quote detail
         *
         * @since 1.0.0
         */
        public function view_subscription() {
            global $wp;
            if ( !is_user_logged_in() ) {
                wc_get_template( 'myaccount/form-login.php' );
            }
            else {
                $subscription_id = $wp->query_vars['view-subscription'];
                $subscription = new YWSBS_Subscription( $subscription_id );
                wc_get_template( 'myaccount/view-subscription.php',
                    array( 'subscription' => $subscription,
                           'user'            => get_user_by( 'id', get_current_user_id() ) ) );
            }
        }


        /**
         * Change the status of subscription from myaccount page
         *
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function myaccount_actions() {

            if ( isset( $_REQUEST['change_status'] ) && isset( $_REQUEST['subscription'] ) && isset( $_REQUEST['_wpnonce'] ) ) {

                $subscription = ywsbs_get_subscription( $_REQUEST['subscription'] );
                $new_status   = $_REQUEST['change_status'];




                if ( wp_verify_nonce( $_REQUEST['_wpnonce'], $subscription->id ) === false ) {
                    wc_add_notice( __( 'This subscription cannot be updated. Contact us for info','yith-woocommerce-subscription'), 'error' );
                }

                if ( empty( $subscription ) || $subscription->user_id != get_current_user_id() ) {
                    wc_add_notice( __( 'You seem to have already purchased this subscription ', 'yith-woocommerce-subscription' ), 'error' );
                }

                if ( $new_status == 'renew' ) {
                    $this->renew_the_subscription( $subscription );
                    $checkout_url =  ( function_exists( 'wc_get_checkout_url') ) ? wc_get_checkout_url() : WC()->cart->get_checkout_url();
                    wp_redirect( $checkout_url );
                    exit;
                }

                $this->manual_change_status( $new_status, $subscription, 'customer' );
                wp_redirect( $subscription->get_view_subscription_url() );

                exit;

            } elseif ( isset( $_REQUEST['switch-variation'] ) && isset( $_REQUEST['subscription_id'] ) && isset( $_REQUEST['_wpnonce'] ) ) {

                $subscription = ywsbs_get_subscription( $_REQUEST['subscription_id'] );

                if ( wp_verify_nonce( $_REQUEST['_wpnonce'], 'switch-variation' ) === false ) {
                    wc_add_notice( __( 'This subscription cannot be switched. Contact us for info', 'yith-woocommerce-subscription' ), 'error' );
                }

                $variation_to_switch             = $_REQUEST['switch-variation'];
                $variation_to_switch_priority    = get_post_meta( $variation_to_switch, '_ywsbs_switchable_priority', true );
                $variation_to_switch_gap_payment = get_post_meta( $variation_to_switch, '_ywsbs_gap_payment', true );

                $current_variation_priority = get_post_meta(  $subscription->variation_id, '_ywsbs_switchable_priority', true );
                $current_variation_priority = ( $current_variation_priority ) ? $current_variation_priority : 0;

                update_post_meta( $subscription->id, 'ywsbs_swiched', 'yes' );

                if ( $variation_to_switch_priority <= $current_variation_priority ) {
                    $this->downgrade_process( $subscription->variation_id, $variation_to_switch, $subscription );
                } else {
                    $pay_gap = ( isset( $_REQUEST['pay-gap'] ) && $variation_to_switch_gap_payment == 'yes' ) ? $_REQUEST['pay-gap-price'] : 0;
                    $this->upgrade_process( $subscription->variation_id, $variation_to_switch, $subscription, $pay_gap );
                }

            }

        }

        /**
         * Start the downgrade process
         *
         * @param int                $from_id      current variation id
         * @param int                $to_id        variation to switch
         * @param YWSBS_Subscription $subscription current subscription
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         * @return bool
         */
        public function downgrade_process( $from_id, $to_id, $subscription ){
            //retrieve the days left to the next payment or to the expiration data
            $left_time = $subscription->get_left_time_to_next_payment();
            $days = ywsbs_get_days($left_time);

            if ( $left_time <= 0 && $days > 1 ) {
                add_user_meta( $subscription->user_id, 'ywsbs_upgrade_'.$to_id, array( 'subscription_id' => $subscription->id, 'pay_gap' => 0)  );
            } elseif( $left_time > 0) {
                add_user_meta( $subscription->user_id, 'ywsbs_downgrade_'.$to_id, $subscription->id  );
                add_user_meta( $subscription->user_id, 'ywsbs_trial_'.$to_id, array('subscription_id' => $subscription->id, 'trial_days' => $days )  );
            }

            $variation = wc_get_product( $to_id );
            if ( ! apply_filters( 'woocommerce_add_to_cart_validation', true, $subscription->product_id, $subscription->quantity, $to_id, $variation->get_variation_attributes() ) ) {
                wc_add_notice( __( 'This subscription cannot be switched. Contact us for info','yith-woocommerce-subscription' ), 'error' );
                return;
            }
            WC()->cart->add_to_cart( $subscription->product_id, $subscription->quantity, $to_id, $variation->get_variation_attributes() );
            $checkout_url =  ( function_exists( 'wc_get_checkout_url') ) ? wc_get_checkout_url() : WC()->cart->get_checkout_url();

            wp_redirect( $checkout_url );
            exit;
        }

        /**
         * Start the upgrade process
         *
         * @param int                $from_id      current variation id
         * @param int                $to_id        variation to switch
         * @param YWSBS_Subscription $subscription current subscription
         *
         * @param                    $pay_gap
         *
         * @return bool
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function upgrade_process( $from_id, $to_id, $subscription, $pay_gap ) {

            add_user_meta( $subscription->user_id, 'ywsbs_upgrade_' . $to_id, array( 'subscription_id' => $subscription->id, 'pay_gap' => $pay_gap) , true );

            $variation = wc_get_product( $to_id );

            if ( ! apply_filters( 'woocommerce_add_to_cart_validation', true, $subscription->product_id, $subscription->quantity, $to_id, $variation->get_variation_attributes() ) ) {
                wc_add_notice( __( 'This subscription cannot be switched. Contact us for info', 'yith-woocommerce-subscription' ), 'error' );
                return;
            }

            WC()->cart->add_to_cart( $subscription->product_id, $subscription->quantity, $to_id, $variation->get_variation_attributes() );
            $checkout_url = ( function_exists( 'wc_get_checkout_url') ) ? wc_get_checkout_url() : WC()->cart->get_checkout_url();
            wp_redirect( $checkout_url );
            exit;

        }

        /**
         * Cancel the subscription
         *
         * @param int $subscription_id subscription to cancel
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         * @return bool
         */
        public function cancel_subscription_after_upgrade( $subscription_id ){

            $subscription = ywsbs_get_subscription( $subscription_id );

            if( ! apply_filters('ywsbs_cancel_recurring_payment', true, $subscription ) ){
                $this->add_notice( __('This subscription cannot be cancelled. You cannot switch to related subscriptions', 'yith-woocommerce-subscription'), 'error' );
                return false;
            }

            $subscription->update_status('cancelled', 'customer');
            $subscription->status = 'cancelled';
            do_action( 'ywsbs_subscription_cancelled_mail', $subscription);

            YITH_WC_Activity()->add_activity( $subscription->id, 'switched', 'success', 0 , __('Subscription cancelled due to switch', 'yith-woocommerce-subscription') );
        }

        /**
         * Update the old subscription after the downgrade
         *
         * @param int $subcription_id subscription to update
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         * @return bool
         */
        public function update_subscription_after_downgrade( $subcription_id ){

            $subscription = ywsbs_get_subscription($subcription_id);

            if( ! apply_filters('ywsbs_cancel_recurring_payment', true, $subscription ) ){
                $this->add_notice( __('This subscription cannot be cancelled. You cannot switch to a related subscription', 'yith-woocommerce-subscription'), 'error' );
                return false;
            }

            //the current subscription will be expired to the last payment
            if( $subscription->payment_due_date ){
                $subscription->set( 'expired_date', $subscription->payment_due_date);
                $subscription->set( 'payment_due_date', false );
                YITH_WC_Activity()->add_activity( $subscription->id, 'switched', 'success', $subscription->order_id , __('Expiration date of this subscription changed due to downgrade', 'yith-woocommerce-subscription') );
            }else{
                YITH_WC_Activity()->add_activity( $subscription->id, 'switched', 'success', $subscription->order_id , __('Subscription will be forced to expire due to downgrade', 'yith-woocommerce-subscription') );
            }

            //if there's a pending order for this subscription change the status of the order to cancelled
            if( $subscription->renew_order ){
                $order = wc_get_order( $subscription->renew_order );
                if( $order ){
                    $order->update_status('cancelled');
                    $order->add_order_note( sprintf(__( 'This order has been cancelled because subscription #%d has been downgraded', 'yith-woocommerce-subscription' ), $subscription->id));
                }
            }
        }

        /**
         * Renew the subscription
         *
         * @param YWSBS_Subscription $subscription subscription to renew
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         * @return void
         */
        public function renew_the_subscription( $subscription ){
            WC()->cart->add_to_cart($subscription->product_id, $subscription->quantity, $subscription->variation_id);
        }

        /**
         * Change the status of subscription manually
         *
         * @param string             $new_status
         * @param YWSBS_Subscription $subscription
         * @param string             $from
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         * @return bool
         */
        public function manual_change_status( $new_status, $subscription, $from=''  ) {
            switch( $new_status ){
                case 'active':
                    if( ! $subscription->can_be_active() ){
                        $this->add_notice( __('This subscription cannot be activated', 'yith-woocommerce-subscription' ), 'error' );
                    }else{
                        //change the status to cancelled
                        $subscription->update_status('active', $from);
                        $this->add_notice( __('This subscription is now active', 'yith-woocommerce-subscription'), 'success' );
                    }
                    break;
                case 'overdue':
                    if( ! $subscription->can_be_overdue() ){
                        $this->add_notice( __('This subscription cannot be in status overdue', 'yith-woocommerce-subscription' ), 'error' );
                    }else{
                        //change the status to cancelled
                        $subscription->update_status('overdue', $from);
                        $this->add_notice( __('This subscription is now in overdue status', 'yith-woocommerce-subscription'), 'success' );
                    }
                    break;
                case 'suspended':
                    if( ! $subscription->can_be_suspended() ){
                        $this->add_notice( __('This subscription cannot be in status suspended', 'yith-woocommerce-subscription' ), 'error' );
                    }else{
                        //change the status to cancelled
                        $subscription->update_status('suspended', $from);
                        $this->add_notice( __('This subscription is now suspended', 'yith-woocommerce-subscription'), 'success' );
                    }
                    break;
                case 'cancelled':
                    if( ! $subscription->can_be_cancelled() ){
                        $this->add_notice( __('This subscription cannot be cancelled', 'yith-woocommerce-subscription' ), 'error' );
                    }else{

                        // filter added to gateway payments
                        if( ! apply_filters('ywsbs_cancel_recurring_payment', true, $subscription ) ){
                            $this->add_notice( __('This subscription cannot be cancelled', 'yith-woocommerce-subscription'), 'error' );
                            return false;
                        }

                        //change the status to cancelled
                        $subscription->update_status('cancelled', $from);

                        $this->add_notice( __('This subscription is now cancelled', 'yith-woocommerce-subscription'), 'success' );

                    }
                    break;
                case 'cancel-now':
                    if( ! $subscription->can_be_cancelled() ){
                        $this->add_notice( __('This subscription cannot be cancelled', 'yith-woocommerce-subscription'), 'error' );
                    }else{

                        // filter added to gateway payments
                        if( ! apply_filters('ywsbs_cancel_recurring_payment', true, $subscription ) ){
                            $this->add_notice( __('This subscription cannot be cancelled', 'yith-woocommerce-subscription'), 'error' );
                            return false;
                        }

                        //change the status to cancelled
                        $subscription->update_status('cancel-now', $from);
                        $this->add_notice( __('This subscription is now cancelled', 'yith-woocommerce-subscription'), 'success' );
                    }
                    break;
                case 'paused':
                    if( ! $subscription->can_be_paused() ){
                        $this->add_notice( __('This subscription cannot be paused', 'yith-woocommerce-subscription'), 'error' );
                    }else{

                        // filter added to gateway payments
                        if( ! apply_filters('ywsbs_suspend_recurring_payment', true, $subscription ) ){
                            $this->add_notice( __('This subscription cannot be paused', 'yith-woocommerce-subscription'), 'error' );
                            return false;
                        }

                        $result = $subscription->update_status( 'paused', $from );
                        $subscription->status = 'paused';
                        $this->add_notice( __('This subscription is now paused', 'yith-woocommerce-subscription'), 'success' );

                    }
                    break;
                case 'resumed':
                    if( ! $subscription->can_be_resumed() ){
                        $this->add_notice( __('This subscription cannot be resumed', 'yith-woocommerce-subscription'), 'error' );
                    }else{
                        // filter added to gateway payments
                        if( ! apply_filters('ywsbs_resume_recurring_payment', true, $subscription ) ){
                            $this->add_notice( __('This subscription cannot be resumed', 'yith-woocommerce-subscription'), 'error' );
                            return false;
                        }
                         $subscription->update_status('resume', $from);
                         $subscription->status = 'active';
                         $this->add_notice(__('This subscription is now active', 'yith-woocommerce-subscription'), 'success' );
                    }

                    break;
                default:
            }

        }

        /**
         * Return overdue time period
         *
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function overdue_time(){
            if( get_option('ywsbs_enable_overdue_period') != 'yes' && get_option('ywsbs_overdue_period')=='' ){
                return false;
            }else{
                return get_option('ywsbs_overdue_period') * 84600;
            }
        }

        /**
         * Return suspension time period
         *
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         */
        public function suspension_time(){
            if( get_option('ywsbs_enable_suspension_period') != 'yes' && get_option('ywsbs_suspension_period')=='' ){
                return false;
            }else{
                return get_option('ywsbs_suspension_period') * 84600;
            }
        }

        /**
         * Print a message in my account page
         *
         *
         * @since  1.0.0
         * @author Emanuela Castorina
         *
         * @param $message
         * @param $type
         */
        public function add_notice( $message, $type ) {
            if( !is_admin()){
                wc_add_notice( $message, $type );
            }
        }

        /**
         * Filters woocommerce available mails
         *
         * @param $emails array
         *
         * @access public
         *
         * @return array
         * @since 1.0.0
         */
        public function add_woocommerce_emails( $emails ) {
            require_once( YITH_YWSBS_INC . 'emails/class.yith-wc-customer-subscription.php' );
            $emails['YITH_WC_Subscription_Status']                      = include( YITH_YWSBS_INC . 'emails/class.yith-wc-subscription-status.php' );
            $emails['YITH_YWSBS_Customer_Subscription_Cancelled']       = include( YITH_YWSBS_INC . 'emails/class.yith-wc-customer-subscription-cancelled.php' );
            $emails['YITH_YWSBS_Customer_Subscription_Suspended']       = include( YITH_YWSBS_INC . 'emails/class.yith-wc-customer-subscription-suspended.php' );
            $emails['YITH_YWSBS_Customer_Subscription_Expired']         = include( YITH_YWSBS_INC . 'emails/class.yith-wc-customer-subscription-expired.php' );
            $emails['YITH_YWSBS_Customer_Subscription_Before_Expired']  = include( YITH_YWSBS_INC . 'emails/class.yith-wc-customer-subscription-before-expired.php' );
            $emails['YITH_YWSBS_Customer_Subscription_Paused']          = include( YITH_YWSBS_INC . 'emails/class.yith-wc-customer-subscription-paused.php' );
            $emails['YITH_YWSBS_Customer_Subscription_Resumed']         = include( YITH_YWSBS_INC . 'emails/class.yith-wc-customer-subscription-resumed.php' );
            $emails['YITH_YWSBS_Customer_Subscription_Request_Payment'] = include( YITH_YWSBS_INC . 'emails/class.yith-wc-customer-subscription-request-payment.php' );
            $emails['YITH_WC_Customer_Subscription_Payment_Done']       = include( YITH_YWSBS_INC . 'emails/class.yith-wc-customer-subscription-payment-done.php' );
            return $emails;
        }

        /**
         * Loads WC Mailer when needed
         *
         * @access public
         *
         * @return void
         * @since 1.0.0
         */
        public function load_wc_mailer(){

            //Administrator
            add_action( 'ywsbs_subscription_admin_mail', array( 'WC_Emails', 'send_transactional_email' ), 10 );

            //Customers
            add_action( 'ywsbs_customer_subscription_cancelled_mail', array( 'WC_Emails', 'send_transactional_email' ), 10 );
            add_action( 'ywsbs_customer_subscription_expired_mail', array( 'WC_Emails', 'send_transactional_email' ), 10 );
            add_action( 'ywsbs_customer_subscription_before_expired_mail', array( 'WC_Emails', 'send_transactional_email' ), 10 );
            add_action( 'ywsbs_customer_subscription_suspended_mail', array( 'WC_Emails', 'send_transactional_email' ), 10 );
            add_action( 'ywsbs_customer_subscription_resumed_mail', array( 'WC_Emails', 'send_transactional_email' ), 10 );
            add_action( 'ywsbs_customer_subscription_paused_mail', array( 'WC_Emails', 'send_transactional_email' ), 10 );
            add_action( 'ywsbs_customer_subscription_request_payment_mail', array( 'WC_Emails', 'send_transactional_email' ), 10 );
            add_action( 'ywsbs_customer_subscription_payment_done_mail', array( 'WC_Emails', 'send_transactional_email' ), 10 );

        }



        /**
         * Save main site URL if not set
         *
         * @access public
         * @return void
         *
         * @since  1.0.0
         */
        public function save_site_url() {
            $ywsbs_site_url = get_option( 'ywsbs_site_url' );
            if ( empty( $ywsbs_site_url ) ) {
                $this->save_option_site_url( $this->get_site_url() );
            }
        }


        /**
         * Checks if the WordPress site URL has changed for the site subscriptions.
         * Useful for checking if automatic payments should be processed.
         *
         * @access public
         * @return void
         *
         * @since  1.0.0
         */
        public function check_different_url() {

            $has_changed = ( get_site_url() !== $this->get_site_url() ) ? true : false;

            return apply_filters( 'ywsbs_has_different_url', $has_changed );
        }

        /**
         * Get main site URL with placeholder in the middle
         *
         * @access public
         * @return string
         *
         * @since  1.0.0
         */
        public function get_site_url() {
            $current_site_url = get_site_url();

            return substr_replace( $current_site_url, '***YWSBS***', strlen( $current_site_url ) / 2, 0 );
        }

        /**
         * Save main site URL so we can disable some actions on sandox websites
         *
         * @access public
         *
         * @param string $url
         *
         * @return void
         *
         * @since  1.0.0
         */
        public function save_option_site_url( $url ) {
            update_option( 'ywsbs_site_url', $url );
        }


        /**
         * Check if is main site URL so we can disable some actions on sandox websites
         *
         * @access public
         * @return bool
         */
        public function is_main_site() {
            $is_main_site = false;

            $current_site_url = get_site_url();

            // Make sure we have saved original URL, otherwise treat as duplicate site
            $ywsbs_site_url = get_option( 'ywsbs_site_url' );
            if ( ! empty( $ywsbs_site_url ) ) {
                $main_site_url = set_url_scheme( str_replace( '***YWSBS***', '', get_option( 'ywsbs_site_url' ) ) );

                $is_main_site = ( $current_site_url == $main_site_url ) ? true : false;
            }

            return $is_main_site;
        }


        /**
         * Display Admin Notice if there's a different site URL
         *
         * @access public
         * @return void
         *
         * @since  1.0.0
         */
        public function different_url_notification() {
            if ( ! current_user_can( 'manage_options' ) ) {
                return;
            }

            $ignore = get_option( 'ywsbs_ignore_different_url' );


            if ( isset( $_POST['ywsbs_confirm_main_site_url'] ) || isset( $_POST['ywsbs_hide_different_site_url_warning'] ) ) {
                if ( $_POST['ywsbs_confirm_main_site_url'] == 'change' ) {
                    $this->save_option_site_url( $this->get_site_url() );
                } elseif ( $_POST['ywsbs_hide_different_site_url_warning'] == 'ignore' ) {
                    update_option( 'ywsbs_ignore_different_url', $this->get_site_url() );
                }
            } elseif ( ! $this->is_main_site() && ( $ignore || $ignore != $this->get_site_url() ) ) {
                include( YITH_YWSBS_TEMPLATE_PATH . '/admin/different-site-url-notice.php' );
            }

        }

        /**
         * Register plugins for activation tab
         *
         * @return void
         * @since    1.0.0
         * @author   Andrea Grillo <andrea.grillo@yithemes.com>
         */
        public function register_plugin_for_activation() {
            if ( ! class_exists( 'YIT_Plugin_Licence' ) ) {
                require_once YITH_YWSBS_DIR . 'plugin-fw/licence/lib/yit-licence.php';
                require_once YITH_YWSBS_DIR . 'plugin-fw/licence/lib/yit-plugin-licence.php';
            }
            YIT_Plugin_Licence()->register( YITH_YWSBS_INIT, YITH_YWSBS_SECRET_KEY,YITH_YWSBS_SLUG );
        }

        /**
         * Register plugins for update tab
         *
         * @return void
         * @since  1.0.0
         * @author Andrea Grillo <andrea.grillo@yithemes.com>
         */
        public function register_plugin_for_updates() {
            if( ! class_exists( 'YIT_Upgrade' ) ) {
                require_once YITH_YWSBS_DIR.'plugin-fw/lib/yit-upgrade.php';
            }
            YIT_Upgrade()->register( YITH_YWSBS_SLUG, YITH_YWSBS_INIT );
        }


    }
}

/**
 * Unique access to instance of YITH_WC_Subscription class
 *
 * @return \YITH_WC_Subscription
 */
function YITH_WC_Subscription() {
    return YITH_WC_Subscription::get_instance();
}
