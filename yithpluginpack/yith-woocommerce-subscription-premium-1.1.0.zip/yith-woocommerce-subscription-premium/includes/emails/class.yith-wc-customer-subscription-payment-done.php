<?php
if ( !defined( 'ABSPATH' ) || !defined( 'YITH_YWSBS_VERSION' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Send Email to Customer
 *
 * @class   YITH_WC_Customer_Subscription_Payment_Done
 * @package YITH WooCommerce Subscription
 * @since   1.0.0
 * @author  Yithemes
 */
if ( !class_exists( 'YITH_WC_Customer_Subscription_Payment_Done' ) ) {

    /**
     * YITH_WC_Customer_Subscription_Payment_Done
     *
     * @since 1.0.0
     */
    class YITH_WC_Customer_Subscription_Payment_Done extends YITH_WC_Customer_Subscription {

        /**
         * Constructor method, used to return object of the class to WC
         *
         * @since 1.0.0
         */
        public function __construct() {
            $this->id          = 'ywsbs_customer_subscription_payment_done';
            $this->title       = __( 'Subscription Payment Made', 'yith-woocommerce-subscription' );
            $this->description = __( 'This email is sent to the customer when the shop owner receives the payment', 'yith-woocommerce-subscription' );
            $this->email_type  = 'html';
            $this->heading     = __( 'Subscription payment received', 'yith-woocommerce-subscription' );
            $this->subject     = __( 'Subscription payment received', 'yith-woocommerce-subscription' );

            // Call parent constructor
            parent::__construct();



        }

        /**
         * Method triggered to send email
         *
         * @param int $subscription
         *
         * @return void
         * @since  1.0
         * @author Emanuela Castorina <emanuela.castorina@yithemes.com>
         */
        public function trigger( $subscription ) {


            $this->recipient = $subscription->billing_email;

            // Check if this email type is enabled, recipient is set
            if ( !$this->is_enabled() || !$this->get_recipient() ) {
                return;
            }

            $this->object = $subscription;

            $this->template_variables = array(
                'subscription'  => $this->object,
                'email_heading' => $this->get_heading(),
                'sent_to_admin' => false,
                'email'         => $this
            );


            $return = $this->send( $this->get_recipient(), $this->get_subject(), $this->get_content_html(), $this->get_headers(), $this->get_attachments( ) );
        }

        /**
         * Get HTML content for the mail
         *
         * @return string HTML content of the mail
         * @since  1.0
         * @author Emanuela Castorina <emanuela.castorina@yithemes.com>
         */
        public function get_content_html() {
            ob_start();
            wc_get_template( $this->template_html, $this->template_variables );
            return ob_get_clean();
        }


    }
}


// returns instance of the mail on file include
return new YITH_WC_Customer_Subscription_Payment_Done();