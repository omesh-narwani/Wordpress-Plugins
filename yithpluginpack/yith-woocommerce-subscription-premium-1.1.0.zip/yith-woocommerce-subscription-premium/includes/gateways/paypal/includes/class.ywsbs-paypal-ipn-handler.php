<?php
if ( !defined( 'ABSPATH' ) || !defined( 'YITH_YWSBS_VERSION' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Implements YWSBS_PayPal_IPN_Handler Class
 *
 * @class   YWSBS_PayPal_IPN_Handler
 * @package YITH WooCommerce Subscription
 * @since   1.0.1
 * @author  Yithemes
 */
if ( !class_exists( 'YWSBS_PayPal_IPN_Handler' ) ) {

	class YWSBS_PayPal_IPN_Handler extends WC_Gateway_Paypal_IPN_Handler {


		protected $transaction_types = array(
			'subscr_signup', 'subscr_payment', 'subscr_modify', 'subscr_failed', 'subscr_eot', 'subscr_cancel', 'recurring_payment_suspended_due_to_max_failed_payment','recurring_payment_skipped'
		);

		/**
		 * Constructor
		 *
		 * Initialize plugin and registers actions and filters to be used
		 *
		 * @since  1.0.0
		 * @author Emanuela Castorina
		 */
		public function __construct(  $sandbox = false, $receiver_email = '' ) {

			add_action( 'valid-paypal-standard-ipn-request', array( $this, 'valid_response' ), 0 );
			$this->receiver_email = $receiver_email;
		}

		/**
		 * There was a valid response
		 * @param  array $posted Post data after wp_unslash
		 */
		public function valid_response( $posted ) {

			if ( ! empty( $posted['custom'] ) && ( $order = $this->get_paypal_order( $posted['custom'] ) ) ) {

				WC_Gateway_Paypal::log( 'Found order #' . $order->id );
				WC_Gateway_Paypal::log( 'Txn Type: ' . $posted['txn_type'] );

				$this->process_paypal_request(  $order, $posted );

			}
		}

		/**
		 * Handle a completed payment
		 * @param  WC_Order $order
		 */
		protected function process_paypal_request( $order, $posted ) {
			/*if ( $order->has_status( 'completed' ) ) {
				WC_Gateway_Paypal::log( 'Aborting, Order #' . $order->id . ' is already complete.' );
				exit;
			}*/

			if ( ! $this->validate_transaction_type( $posted['txn_type'] ) ) {
				return;
			}

			$this->validate_currency( $order, $posted['mc_currency'] );

			$this->validate_receiver_email( $order, $posted['receiver_email'] );
			$this->save_paypal_meta_data( $order, $posted );

			$this->paypal_ipn_request( $posted );
		}


		protected function get_order_info( $args ) {
			if ( isset( $args['custom'] ) ) {
				$order_info = json_decode( $args['custom'], true );
			}
			return $order_info;
		}

		/**
		 * Catch the paypal ipn request for subscription
		 *
		 * @param array $ipn_args
		 *
		 * @throws Exception
		 */
		protected function paypal_ipn_request( $ipn_args ) {


			//check if the order has the same order_key
			$order_info = $this->get_order_info( $ipn_args );
			$order = wc_get_order( $order_info['order_id'] );
			if ( $order->order_key != $order_info['order_key'] ) {
				WC_Gateway_Paypal::log( 'YSBS - Order keys do not match' );
				return;
			}



			//check if the transaction has been processed
			$order_transaction_ids = get_post_meta( $order->id, '_paypal_transaction_ids', true );
			$order_transactions    = $this->is_a_valid_transaction( $order_transaction_ids, $ipn_args );
			if ( $order_transactions ) {
				update_post_meta( $order->id, '_paypal_transaction_ids', $order_transactions );
			} else {
				return;
			}


			//get the subscriptions of the order
			$subscriptions = get_post_meta( $order->id, 'subscriptions', true );

			if ( empty( $subscriptions ) ) {
				WC_Gateway_Paypal::log( 'YSBS - IPN subscription payment error - ' . $order->id . ' haven\'t subscriptions' );
				return;
			} else {
				WC_Gateway_Paypal::log( 'YSBS - Subscription ' . print_r( $subscriptions, true ) );
			}

			$valid_order_statuses = array( 'on-hold', 'pending', 'failed', 'cancelled' );



			switch ( $ipn_args['txn_type'] ) {
				case 'subscr_signup':
					update_post_meta( $order->id, 'Subscriber ID', $ipn_args['subscr_id'] );
					update_post_meta( $order->id, 'Subscriber first name', $ipn_args['first_name'] );
					update_post_meta( $order->id, 'Subscriber last name', $ipn_args['last_name'] );
					update_post_meta( $order->id, 'Subscriber address', $ipn_args['payer_email'] );
					update_post_meta( $order->id, 'Payment type', $ipn_args['payment_type'] );


					$order->add_order_note( __( 'IPN subscription started', 'yith-woocommerce-subscription' ) );

					if ( isset( $ipn_args['mc_amount1'] ) && $ipn_args['mc_amount1'] == 0 ) {
						$order->payment_complete( $ipn_args['txn_id'] );
					}

					foreach ( $subscriptions as $subscription_id ) {
						$subscription = new YWSBS_Subscription( $subscription_id );
						$subscription->set( 'paypal_transaction_id', $ipn_args['txn_id'] );
						$subscription->set( 'paypal_subscriber_id', $ipn_args['subscr_id'] );
					}

					break;
				case 'subscr_payment':

					if ( 'completed' == strtolower( $ipn_args['payment_status'] ) ) {

						foreach ( $subscriptions as $subscription_id ) {
							$subscription = new YWSBS_Subscription( $subscription_id );

							$transaction_ids = get_post_meta( $subscription_id, '_paypal_transaction_ids', true );
							$transactions    = $this->is_a_valid_transaction( $transaction_ids, $ipn_args );
							if ( $transactions ) {
								update_post_meta( $subscription_id, '_paypal_transaction_ids', $transactions );
							} else {
								break;
							}

							$last_order    = false;
							$pending_order = $subscription->renew_order;

							if ( intval( $pending_order ) ) {
								$last_order = wc_get_order( $pending_order );
							}

							if ( isset( $ipn_args['mc_gross'] ) ) {
								if ( $last_order ) {
									$this->validate_amount( $last_order, $ipn_args['mc_gross'] );
								} elseif ( $order->has_status( $valid_order_statuses ) ) {
									$this->validate_amount( $order, $ipn_args['mc_gross'] );
								}
							}


							if ( $subscription->status == 'pending' || ! $last_order || $order->has_status( $valid_order_statuses ) ) {

								update_post_meta( $order->id, 'Subscriber ID', $ipn_args['subscr_id'] );
								update_post_meta( $order->id, 'Subscriber first name', $ipn_args['first_name'] );
								update_post_meta( $order->id, 'Subscriber last name', $ipn_args['last_name'] );
								update_post_meta( $order->id, 'Subscriber address', $ipn_args['payer_email'] );
								update_post_meta( $order->id, 'Subscriber payment type', $ipn_args['payment_type'] );
								update_post_meta( $order->id, 'Payment type', wc_clean( $ipn_args['payment_type'] ) );
								$order->add_order_note( __( 'IPN subscription payment completed.', 'yith-woocommerce-subscription' ) );
								$order->payment_complete( $ipn_args['txn_id'] );

							} elseif ( $last_order ) {

								update_post_meta( $last_order->id, 'Subscriber ID', $ipn_args['subscr_id'] );
								update_post_meta( $last_order->id, 'Subscriber first name', $ipn_args['first_name'] );
								update_post_meta( $last_order->id, 'Subscriber last name', $ipn_args['last_name'] );
								update_post_meta( $last_order->id, 'Subscriber address', $ipn_args['payer_email'] );
								update_post_meta( $last_order->id, 'Subscriber payment type', $ipn_args['payment_type'] );
								update_post_meta( $last_order->id, 'Payment type', wc_clean( $ipn_args['payment_type'] ) );
								$last_order->add_order_note( __( 'IPN subscription payment completed.', 'yith-woocommerce-subscription' ) );
								$last_order->payment_complete( $ipn_args['txn_id'] );

							} else {

								//if the renew_order is not created try to create it
								$new_order_id = YWSBS_Subscription_Order()->renew_order( $subscription->id );
								$new_order    = wc_get_order( $new_order_id );

								if ( isset( $ipn_args['mc_gross'] ) ) {
									$this->validate_amount( $new_order, $ipn_args['mc_gross'] );
								}

								$subscription->set( 'renew_order', $new_order_id );
								update_post_meta( $new_order_id, 'Subscriber ID', $ipn_args['subscr_id'] );
								update_post_meta( $new_order_id, 'Subscriber first name', $ipn_args['first_name'] );
								update_post_meta( $new_order_id, 'Subscriber last name', $ipn_args['last_name'] );
								update_post_meta( $new_order_id, 'Subscriber address', $ipn_args['payer_email'] );
								update_post_meta( $new_order_id, 'Subscriber payment type', $ipn_args['payment_type'] );
								update_post_meta( $new_order_id, 'Payment type', wc_clean( $ipn_args['payment_type'] ) );

								$new_order->add_order_note( __( 'IPN subscription payment completed.', 'yith-woocommerce-subscription' ) );
								$new_order->payment_complete( $ipn_args['txn_id'] );

							}

							$subscription->set( 'paypal_transaction_id', $ipn_args['txn_id'] );
							$subscription->set( 'paypal_subscriber_id', $ipn_args['subscr_id'] );

						}

					}
					if ( 'pending' == strtolower( $ipn_args['payment_status'] ) && 'echeck' == strtolower( $ipn_args['payment_type'] ) ) {

						foreach ( $subscriptions as $subscription_id ) {
							$transaction_ids = get_post_meta( $subscription_id, '_paypal_transaction_ids', true );
							$transactions    = $this->is_a_valid_transaction( $transaction_ids, $ipn_args );
							if ( $transactions ) {
								update_post_meta( $subscription_id, '_paypal_transaction_ids', $transactions );
							} else {
								break;
							}
							update_post_meta( $subscription_id, 'start_date', current_time('timestamp') );
							update_post_meta( $subscription_id, 'payment_type', $ipn_args['payment_type'] );
						}
					}
					break;

				case 'subscr_modify':

					break;

				case 'subscr_failed':
					if ( isset( $ipn_args['subscr_id'] ) ) {
						$paypal_sub_id = $ipn_args['subscr_id'];
						$order_sub_id  = get_post_meta( $order->id, 'Subscriber ID', true );

						if ( $paypal_sub_id != $order_sub_id ) {
							WC_Gateway_Paypal::log( 'YSBS - IPN subscription failed request ignored - new PayPal Profile ID linked to this subscription, for order ' . $order->id );
						}else{
							$subscriptions = get_post_meta( $order->id, 'subscriptions', true );

							if ( empty( $subscriptions ) ) {
								WC_Gateway_Paypal::log( 'YSBS - IPN subscription failed payment request ignored - order ' . $order->id . ' doesn\'t not subscriptions' );
							}

							foreach ( $subscriptions as $subscription_id ) {

								$subscription = ywsbs_get_subscription( $subscription_id );

								$transaction_ids = get_post_meta( $subscription_id, '_paypal_transaction_ids', true );
								$transactions    = $this->is_a_valid_transaction( $transaction_ids, $ipn_args );
								if ( $transactions ) {
									update_post_meta( $subscription_id, '_paypal_transaction_ids', $transactions );
								} else {
									break;
								}

								//update the number of failed attemp
								$failed_attemp = get_post_meta( $order->id, 'failed_attemps', true );
								update_post_meta( $order->id, 'failed_attemps', $failed_attemp + 1 );

								YITH_WC_Activity()->add_activity( $subscription_id, 'failed-payment', 'success', $order->id, sprintf( __( 'Failed payment for order %d', 'yith-woocommerce-subscription' ), $order->id ) );

								if( get_option('ywsbs_suspend_for_failed_recurring_payment') == 'yes' ){

									$subscription->update_status( 'suspended', 'paypal' );

									YITH_WC_Activity()->add_activity( $subscription_id, 'suspended', 'success', $order->id,  __( 'Subscription has been suspendend for failed payment', 'yith-woocommerce-subscription' ) );

								}

								$order->add_order_note( __( 'YSBS - IPN Failed payment', 'yith-woocommerce-subscription' ) );

								// Subscription Cancellation Completed

								WC_Gateway_Paypal::log( 'YSBS -IPN Failed payment' . $order->id );

							}
						}


					}
					break;
				case 'recurring_payment_skipped':
					if ( isset( $ipn_args['recurring_payment_id'] ) ) {

						$paypal_sub_id = $ipn_args['recurring_payment_id'];
						$order_sub_id  = get_post_meta( $order->id, 'Subscriber ID', true );

						if ( $paypal_sub_id != $order_sub_id ) {
							WC_Gateway_Paypal::log( 'YSBS - IPN subscription failed payment - new PayPal Profile ID linked to this subscription, for order ' . $order->id );
						} else {
							$subscriptions = get_post_meta( $order->id, 'subscriptions', true );

							if ( empty( $subscriptions ) ) {
								WC_Gateway_Paypal::log( 'YSBS - IPN subscription failed payment request ignored - order ' . $order->id . ' doesn\'t not subscriptions' );
							}

							foreach ( $subscriptions as $subscription_id ) {

								$subscription = ywsbs_get_subscription( $subscription_id );

								$transaction_ids = get_post_meta( $subscription_id, '_paypal_transaction_ids', true );
								$transactions    = $this->is_a_valid_transaction( $transaction_ids, $ipn_args );
								if ( $transactions ) {
									update_post_meta( $subscription_id, '_paypal_transaction_ids', $transactions );
								} else {
									break;
								}

								//update the number of failed attemp
								$failed_attemp = get_post_meta( $order->id, 'failed_attemps', true );
								update_post_meta( $order->id, 'failed_attemps', $failed_attemp + 1 );

								YITH_WC_Activity()->add_activity( $subscription_id, 'failed-payment', 'success', $order->id, sprintf( __( 'Failed payment for order %d', 'yith-woocommerce-subscription' ), $order->id ) );

								if( get_option('ywsbs_suspend_for_failed_recurring_payment') == 'yes' ){

									$subscription->update_status( 'suspended', 'paypal' );

									YITH_WC_Activity()->add_activity( $subscription_id, 'suspended', 'success', $order->id,  __( 'Subscription has been suspendend for failed payment', 'yith-woocommerce-subscription' ) );

								}

								$order->add_order_note( __( 'YSBS - IPN Failed payment', 'yith-woocommerce-subscription' ) );

								// Subscription Cancellation Completed

								WC_Gateway_Paypal::log( 'YSBS -IPN Failed payment' . $order->id );

							}
						}
					}
					break;

				case 'subscr_eot':
					/*subscription expired*/
					break;

				case 'recurring_payment_suspended_due_to_max_failed_payment':
					if( isset($ipn_args['recurring_payment_id'])){
						$paypal_sub_id = $ipn_args['recurring_payment_id'];
						$order_sub_id  = get_post_meta( $order->id, 'Subscriber ID', true );

						if ( $paypal_sub_id != $order_sub_id ) {
							WC_Gateway_Paypal::log( 'YSBS - IPN subscription failed request ignored - new PayPal Profile ID linked to this subscription, for order ' . $order->id );
						} else {
							$subscriptions = get_post_meta( $order->id, 'subscriptions', true );

							if ( empty( $subscriptions ) ) {
								WC_Gateway_Paypal::log( 'YSBS - IPN subscription cancellation for failed request ignored - order ' . $order->id . ' doesn\'t not subscriptions' );
							}

							foreach ( $subscriptions as $subscription_id ) {

								$transaction_ids = get_post_meta( $subscription_id, '_paypal_transaction_ids', true );
								$transactions    = $this->is_a_valid_transaction( $transaction_ids, $ipn_args );
								if ( $transactions ) {
									update_post_meta( $subscription_id, '_paypal_transaction_ids', $transactions );
								} else {
									break;
								}

								$subscription = new YWSBS_Subscription( $subscription_id );

								//update the number of failed attemp
								$failed_attemp = get_post_meta( $order->id, 'failed_attemps', true );
								update_post_meta( $order->id, 'failed_attemps', $failed_attemp + 1 );

								$subscription->cancel();
								YITH_WC_Activity()->add_activity( $subscription->id, 'cancelled', 'success', $order->id, __( 'Subscription cancelled due to max number of failed payment attempts', 'yith-woocommerce-subscription' ) );

								$order->add_order_note( __( 'YSBS - IPN subscription cancelled due to max number of failed payment attempts', 'yith-woocommerce-subscription' ) );

								// Subscription Cancellation Completed
								WC_Gateway_Paypal::log( 'YSBS -IPN subscription cancelled due to max number of failed payment attempts' . $order->id );
							}
						}

					}

				case 'subscr_cancel':
					/*subscription cancelled*/
					$paypal_sub_id = $ipn_args['subscr_id'];
					$order_sub_id  = get_post_meta( $order->id, 'Subscriber ID', true );

					if ( $paypal_sub_id != $order_sub_id ) {
						WC_Gateway_Paypal::log( 'YSBS - IPN subscription cancellation request ignored - new PayPal Profile ID linked to this subscription, for order ' . $order->id );
					} else {
						$subscriptions = get_post_meta( $order->id, 'subscriptions', true );

						if ( empty( $subscriptions ) ) {
							WC_Gateway_Paypal::log( 'YSBS - IPN subscription cancellation request ignored - order ' . $order->id . ' doesn\'t not subscriptions' );
						}

						foreach ( $subscriptions as $subscription_id ) {

							$transaction_ids = get_post_meta( $subscription_id, '_paypal_transaction_ids', true );
							$transactions    = $this->is_a_valid_transaction( $transaction_ids, $ipn_args );
							if ( $transactions ) {
								update_post_meta( $subscription_id, '_paypal_transaction_ids', $transactions );
							} else {
								break;
							}

							$subscription = new YWSBS_Subscription( $subscription_id );
							$subscription->cancel( false );
							YITH_WC_Activity()->add_activity( $subscription->id, 'cancelled', 'success', $order->id, __( 'Subscription cancelled by gateway', 'yith-woocommerce-subscription' ) );

							$order->add_order_note( __( 'YSBS - IPN subscription cancelled for the order.', 'yith-woocommerce-subscription' ) );

							// Subscription Cancellation Completed
							WC_Gateway_Paypal::log( 'YSBS -IPN subscription cancelled for order ' . $order->id );

						}
					}

					break;
				default:
			}



		}




		protected function is_a_valid_transaction( $transaction_ids, $ipn_args  ) {

			//check if the ipn request as been processed
			if ( isset( $ipn_args['ipn_track_id'] ) ) {
				$track_id = $ipn_args['txn_type'] . '-' . $ipn_args['ipn_track_id'];
				if ( empty( $transaction_ids ) || ! in_array( $track_id, $transaction_ids ) ) {
					$transaction_ids[] = $track_id;
				} else {
					if ( $this->debug ) {
						$this->wclog->add( 'paypal', 'YSBS - Subscription IPN Error: IPN ' . $track_id . ' message has already been correctly handled.' );
					}
					return false;
				}
			}

			//check if the ipn request as been processed
			if ( isset( $ipn_args['txn_id'] ) ) {
				$transaction_id = $ipn_args['txn_id'] . '-' . $ipn_args['txn_type'];

				if ( isset( $ipn_args['payment_status'] ) ) {
					$transaction_id .= '-' . $ipn_args['payment_status'];
				}
				if ( empty( $transaction_ids ) || ! in_array( $transaction_id, $transaction_ids ) ) {
					$transaction_ids[] = $transaction_id;
				} else {
					if ( $this->debug ) {
						$this->wclog->add( 'paypal', 'YSBS - Subscription IPN Error: IPN ' . $transaction_id . ' message has already been correctly handled.' );
					}

					return false;
				}
			}

			return $transaction_ids;

		}

		/**
		 * Check for a valid transaction type
		 * @param  string $txn_type
		 */
		protected function validate_transaction_type( $txn_type ) {

			if ( ! in_array( strtolower( $txn_type ), $this->transaction_types ) ) {
				//WC_Gateway_Paypal::log( 'Aborting, Invalid type:' . $txn_type );
				return false;
			}

			return true;
		}

	}

}
