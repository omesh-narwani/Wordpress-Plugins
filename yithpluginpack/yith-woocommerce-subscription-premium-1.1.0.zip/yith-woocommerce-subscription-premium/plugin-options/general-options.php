<?php

$settings = array(

    'general' => array(

            'section_general_settings'     => array(
                'name' => __( 'General settings', 'yith-woocommerce-subscription' ),
                'type' => 'title',
                'id'   => 'ywsbs_section_general'
            ),

            'enabled' => array(
                'name'    =>  __( 'Enable Subscription', 'yith-woocommerce-subscription' ),
                'desc'    => '',
                'id'      => 'ywsbs_enabled',
                'type'    => 'checkbox',
                'default' => 'yes'
            ),

            'add_to_cart_label' => array(
                'name'    => __( '"Add to cart" label in subscription products', 'yith-woocommerce-subscription' ),
                'desc'    => '',
                'id'      => 'ywsbs_add_to_cart_label',
                'type'    => 'text',
                'default' => __( 'Subscribe', 'yith-woocommerce-subscription' ),
            ),



            'allow_customer_renew_subscription' => array(
                'name'    => __( 'Allow customer to renew subscriptions', 'yith-woocommerce-subscription' ),
                'desc'    => '',
                'id'      => 'ywsbs_allow_customer_renew_subscription',
                'type'    => 'checkbox',
                'default' => 'yes'
            ),

            'delete_subscription_order_cancelled' => array(
                'name'    =>  __( 'Delete subscription if the main order is cancelled', 'yith-woocommerce-subscription' ),
                'desc'    => '',
                'id'      => 'ywsbs_delete_subscription_order_cancelled',
                'type'    => 'checkbox',
                'default' => 'no'
            ),

            'enable_log' => array(
                'name'    =>  __( 'Enable Log', 'yith-woocommerce-subscription' ),
                'desc'    => '',
                'id'      => 'ywsbs_enable_log',
                'type'    => 'checkbox',
                'default' => 'no'
            ),

            'section_end_form'=> array(
                'type'              => 'sectionend',
                'id'                => 'ywsbs_section_general_end_form'
            ),


            'section_overdue_settings'     => array(
                'name' => __( 'Overdue settings', 'yith-woocommerce-subscription' ),
                'type' => 'title',
                'id'   => 'ywsbs_section_overdue'
            ),



            'enable_overdue_period' => array(
                'name'    =>  __( 'Enable Overdue time', 'yith-woocommerce-subscription' ),
                'desc'    => '',
                'id'      => 'ywsbs_enable_overdue_period',
                'type'    => 'checkbox',
                'default' => 'no'
            ),

            'overdue_period' => array(
                'name'    => __( 'Overdue subscriptions', 'yith-woocommerce-subscription' ),
                'desc'    => __('days','yith-woocommerce-subscription'),
                'id'      => 'ywsbs_overdue_period',
                'type'    => 'text',
                'default' => '',
            ),

            'overdue_start_period' => array(
                'name'    => __( 'Overdue pending payment subscriptions after ........ hour(s)', 'yith-woocommerce-subscription' ),
                'desc'    => __('hours','yith-woocommerce-subscription'),
                'id'      => 'ywsbs_overdue_start_period',
                'type'    => 'text',
                'default' => '',
            ),


            'section_end_overdue_form'=> array(
                'type'              => 'sectionend',
                'id'                => 'ywsbs_section_overdue_end_form'
            ),



            'section_suspend_settings'     => array(
                'name' => __( 'Suspension settings', 'yith-woocommerce-subscription' ),
                'type' => 'title',
                'id'   => 'ywsbs_section_suspension'
            ),


            'suspend_for_failed_recurring_payment' => array(
                'name'    =>  __( 'Suspend a subscription if a recurring payment fail', 'yith-woocommerce-subscription' ),
                'desc'    => '',
                'id'      => 'ywsbs_suspend_for_failed_recurring_payment',
                'type'    => 'checkbox',
                'default' => 'yes'
            ),


            'enable_suspension_period' => array(
                'name'    =>  __( 'Enable Suspended subscriptions', 'yith-woocommerce-subscription' ),
                'desc'    => '',
                'id'      => 'ywsbs_enable_suspension_period',
                'type'    => 'checkbox',
                'default' => 'no'
            ),


            'suspension_period' => array(
                'name'    => __( 'Suspended subscriptions', 'yith-woocommerce-subscription' ),
                'desc'    => __('days','yith-woocommerce-subscription'),
                'id'      => 'ywsbs_suspension_period',
                'type'    => 'text',
                'default' => '',
            ),

            'suspension_start_period' => array(
                'name'    => __( 'Suspend pending payment subscriptions after ........ hour(s)', 'yith-woocommerce-subscription' ),
                'desc'    => __('hours','yith-woocommerce-subscription'),
                'id'      => 'ywsbs_suspension_start_period',
                'type'    => 'text',
                'default' => '',
            ),

            'section_end_suspension_form'=> array(
                'type'              => 'sectionend',
                'id'                => 'ywsbs_section_suspend_end_form'
            ),


            'section_cancel_settings'     => array(
                'name' => __( 'Cancel settings', 'yith-woocommerce-subscription' ),
                'type' => 'title',
                'id'   => 'ywsbs_section_cancel'
            ),

            'allow_customer_cancel_subscription' => array(
                'name'    => __( 'Allow customer to cancel subscriptions', 'yith-woocommerce-subscription' ),
                'desc'    => '',
                'id'      => 'ywsbs_allow_customer_cancel_subscription',
                'type'    => 'checkbox',
                'default' => 'no'
            ),


            'cancel_start_period' => array(
                'name'    => __( 'Cancel pending payment subscriptions after ........ hour(s)', 'yith-woocommerce-subscription' ),
                'desc'    => __('hours','yith-woocommerce-subscription'),
                'id'      => 'ywsbs_cancel_start_period',
                'type'    => 'text',
                'default' => '',
            ),


            'section_end_cancel_form'=> array(
                'type'              => 'sectionend',
                'id'                => 'ywsbs_section_cancel_end_form'
            ),


            'section_price_settings'     => array(
                'name' => __( 'Price settings', 'yith-woocommerce-subscription' ),
                'type' => 'title',
                'id'   => 'ywsbs_section_price'
            ),

            'show_trial_period' => array(
                'name'    =>  __( 'Show trial period', 'yith-woocommerce-subscription' ),
                'desc'    => '',
                'id'      => 'ywsbs_show_trial_period',
                'type'    => 'checkbox',
                'default' => 'yes'
            ),

            'show_fee' => array(
                'name'    =>  __( 'Show fee info', 'yith-woocommerce-subscription' ),
                'desc'    => '',
                'id'      => 'ywsbs_show_fee',
                'type'    => 'checkbox',
                'default' => 'yes'
            ),

            'show_length_period' => array(
                'name'    =>  __( 'Show total subscription length', 'yith-woocommerce-subscription' ),
                'desc'    => '',
                'id'      => 'ywsbs_show_length_period',
                'type'    => 'checkbox',
                'default' => 'no'
            ),




            'section_end_price_form'=> array(
                'type'              => 'sectionend',
                'id'                => 'ywsbs_section_end_price_form'
            ),

        )

);

return apply_filters( 'yith_ywsbs_panel_settings_options', $settings );