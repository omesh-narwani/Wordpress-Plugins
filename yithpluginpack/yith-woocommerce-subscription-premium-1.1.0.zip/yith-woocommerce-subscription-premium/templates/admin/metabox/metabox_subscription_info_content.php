<?php

/**
 * Metabox for Subscription Info Content
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

?>

<div id="subscription-data" class="panel">

    <h2><?php printf(__('Subscription #%d details', 'yith-woocommerce-subscription'), $subscription->id) ?> <span class="status <?php echo $subscription->status ?>"><?php echo $subscription->status ?></span></h2>
    <p class="subscription_number"> <?php echo $subscription->product_name ?> </p>
    <p class="subscription_number"> <?php echo $subscription->get_formatted_recurring() ?> </p>

    <div class="subscription_data_column_container">
        <div class="subscription_data_column">
            <h4>General Details</h4>

            <p class="form-field form-field-wide"><label><?php  _e( '<strong>Started date</strong>:', 'yith-woocommerce-subscription') ?></label>
                <?php echo ( $subscription->start_date ) ? date_i18n( wc_date_format(), $subscription->start_date ).' '.date_i18n(__( wc_time_format()), $subscription->start_date ) : ''; ?>
            </p>

            <p class="form-field form-field-wide"><label><?php  _e( '<strong>Expired date</strong>:', 'yith-woocommerce-subscription') ?></label>
                <?php echo ( $subscription->expired_date ) ? date_i18n( wc_date_format(), $subscription->expired_date ).' '.date_i18n(__( wc_time_format()), $subscription->expired_date ) : ''; ?>
            </p>

            <p class="form-field form-field-wide"><label><?php  _e( '<strong>Payment due date</strong>:', 'yith-woocommerce-subscription') ?></label>
                <?php echo ( $subscription->payment_due_date ) ? date_i18n( wc_date_format(), $subscription->payment_due_date ).' '.date_i18n(__( wc_time_format()), $subscription->payment_due_date ) : ''; ?>
            </p>

            <?php if( $subscription->cancelled_date != ''): ?>
            <p class="form-field form-field-wide"><label><?php  _e( '<strong>Cancelled date</strong>:', 'yith-woocommerce-subscription') ?></label>
                <?php echo ( $subscription->cancelled_date ) ? date_i18n( wc_date_format(), $subscription->cancelled_date ).' '.date_i18n(__( wc_time_format()), $subscription->cancelled_date ) : ''; ?>
            </p>
            <?php endif ?>

            <?php if( $subscription->end_date != ''): ?>
                <p class="form-field form-field-wide"><label><?php  _e( '<strong>End date</strong>:', 'yith-woocommerce-subscription') ?></label>
                    <?php echo ( $subscription->end_date ) ? date_i18n( wc_date_format(), $subscription->end_date ).' '.date_i18n(__( wc_time_format()), $subscription->end_date ) : ''; ?>
                </p>
            <?php endif ?>

            <?php if( $subscription->payed_order_list != ''): ?>
                <p class="form-field form-field-wide"><label><?php  _e( '<strong>Payed Order List</strong>:', 'yith-woocommerce-subscription') ?></label>
                   <?php foreach ( $subscription->payed_order_list as $order ) : ?>
                       <a href="<?php echo admin_url( 'post.php?post=' . $order . '&action=edit' ) ?>">#<?php echo $order ?></a>
                   <?php endforeach;
                   ?>
                </p>
            <?php endif ?>

            <p class="form-field form-field-wide"><label><?php  _e( '<strong>Payment Method</strong>:', 'yith-woocommerce-subscription') ?></label>
                <?php echo $subscription->payment_method_title  ?>
            </p>
            <?php if( $subscription->transaction_id != ''): ?>
            <p class="form-field form-field-wide"><label><?php  _e( '<strong>Transaction ID</strong>:', 'yith-woocommerce-subscription') ?></label>
                <?php echo $subscription->transaction_id  ?>
            </p>
            <?php endif ?>
        </div>
        <div class="subscription_data_column">
            <h4><?php _e('Billing Details', 'yith-woocommerce-subscription') ?></h4>
            <div class="address"><p><strong><?php _e('Address:', 'yith-woocommerce-subscription') ?></strong><?php
                    echo WC()->countries->get_formatted_address( array(
                        'first_name'    => $subscription->billing_first_name,
                        'last_name'     => $subscription->billing_last_name,
                        'company'       => $subscription->billing_company,
                        'address_1'     => $subscription->billing_address_1,
                        'address_2'     => $subscription->billing_address_2,
                        'city'          => $subscription->billing_city,
                        'state'         => $subscription->billing_state,
                        'postcode'      => $subscription->billing_postcode,
                        'country'       => $subscription->billing_country
                    ))
                    ?></p>

                 <p><strong><?php _e('Email:', 'yith-woocommerce-subscription') ?></strong> <a href="mailto:<?php echo $subscription->billing_email ?>"><?php echo $subscription->billing_email ?></a></p>
                 <p><strong><?php _e('Phone:', 'yith-woocommerce-subscription') ?></strong> <?php echo $subscription->billing_phone ?></p>
            </div>
        </div>

        <div class="subscription_data_column">
            <h4><?php _e('Shipping Details', 'yith-woocommerce-subscription') ?></h4>

            <div class="address"><p><strong><?php _e( 'Address:', 'yith-woocommerce-subscription' ) ?></strong><?php
                    echo WC()->countries->get_formatted_address( array(
                        'first_name' => $subscription->shipping_first_name,
                        'last_name'  => $subscription->shipping_last_name,
                        'company'    => $subscription->shipping_company,
                        'address_1'  => $subscription->shipping_address_1,
                        'address_2'  => $subscription->shipping_address_2,
                        'city'       => $subscription->shipping_city,
                        'state'      => $subscription->shipping_state,
                        'postcode'   => $subscription->shipping_postcode,
                        'country'    => $subscription->shipping_country
                    ) )
                    ?></p>

                <?php $shipping = $subscription->subscriptions_shippings;

                if( !empty($shipping) ): ?>
                    <p><strong><?php _e( 'Shipping method:', 'yith-woocommerce-subscription' ) ?></strong>
                    <?php echo $shipping['name'];
                    endif ?>
                </p>
            </div>
        </div>
    </div>
    <div class="clear"></div>
</div>