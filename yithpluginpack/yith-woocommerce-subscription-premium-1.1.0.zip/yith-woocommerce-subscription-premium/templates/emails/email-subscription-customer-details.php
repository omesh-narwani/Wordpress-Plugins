<?php
/**
 * HTML Template for Customer Detail
 *
 * @package YITH WooCommerce Subscription
 * @since   1.0.0
 * @author  Yithemes
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<h3><?php _e( 'Customer\'s details', 'yith-woocommerce-subscription' ); ?></h3>

<?php if ( $subscription->billing_email ) : ?>
    <p>
        <strong><?php _e( 'Email:', 'yith-woocommerce-subscription' ); ?></strong> <?php echo esc_html( $subscription->billing_email ); ?>
    </p>
<?php endif; ?>

<?php if ( $subscription->billing_phone ) : ?>
    <p>
        <strong><?php _e( 'Telephone:', 'yith-woocommerce-subscription' ); ?></strong> <?php echo esc_html( $subscription->billing_phone ); ?>
    </p>
<?php endif; ?>
