<?php
/**
 * This is the email sent to the administrator when the subscription changes status
 *
 * @package YITH WooCommerce Subscription
 * @since   1.0.0
 * @author  Yithemes
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

do_action( 'woocommerce_email_header', $email_heading, $email );

?>


	<p><?php printf( __( 'The status of subscription #%d has changed to <strong>%s</strong>', 'yith-woocommerce-subscription' ), $subscription->id, $subscription->status ); ?></p>

	<h2><a class="link" href="<?php echo admin_url( 'post.php?post=' . $subscription->id . '&action=edit' ); ?>"><?php printf( __( 'Subscription #%s', 'yith-woocommerce-subscription'), $subscription->id ); ?></a> (<?php printf( '<time datetime="%s">%s</time>', date_i18n( 'c', time()), date_i18n( wc_date_format(), time() )); ?>)</h2>


	<table cellspacing="0" cellpadding="6" style="width: 100%; border: 1px solid #eee;" border="1" bordercolor="#eee">
		<thead>
		<tr>
			<th scope="col" style="text-align:left; border: 1px solid #eee;"><?php _e( 'Product', 'yith-woocommerce-subscription' ); ?></th>
			<th scope="col" style="text-align:left; border: 1px solid #eee;"><?php _e( 'Subtotal', 'yith-woocommerce-subscription' ); ?></th>
		</tr>
		</thead>
		<tbody>
		<tr>
			<td scope="col" style="text-align:left;">
				<a href="<?php echo get_permalink( $subscription->product_id ) ?>"><?php echo $subscription->product_name ?></a><?php echo ' x ' . $subscription->quantity ?>
			</td>

			<td scope="col" style="text-align:left;"><?php echo wc_price( $subscription->line_total ) ?></td>
		</tr>

		</tbody>
		<tfoot>
		<?php if ( $subscription->line_tax != 0 ): ?>
			<tr>
				<th scope="row"><?php _e( 'Item Tax:', 'yith-woocommerce-subscription' ) ?></th>
				<td><?php echo wc_price( $subscription->line_tax ) ?></td>
			</tr>
		<?php endif ?>
		<tr>
			<th scope="row"><?php _e( 'Subtotal:', 'yith-woocommerce-subscription' ) ?></th>
			<td><?php echo wc_price( $subscription->line_total + $subscription->line_tax ) ?></td>
		</tr>

		<?php
		if ( !empty( $subscription->subscriptions_shippings ) ) :?>
			<tr>
				<th scope="row"><?php _e( 'Shipping:', 'yith-woocommerce-subscription' ) ?></th>
				<td><?php echo wc_price( $subscription->subscriptions_shippings['cost'] ) . sprintf( __( '<small> via %s</small>', 'yith-woocommerce-subscription' ), $subscription->subscriptions_shippings['name'] ); ?></td>
			</tr>
			<?php
			if ( !empty( $subscription->order_shipping_tax ) ) :
				?>
				<tr>
					<th scope="row"><?php _e( 'Shipping Tax:', 'yith-woocommerce-subscription' ) ?></th>
					<td colspan="2"><?php echo wc_price( $subscription->order_shipping_tax ); ?></td>
				</tr>
				<?php
			endif;
		endif;
		?>
		<tr>
			<th scope="row"><?php _e( 'Total:', 'yith-woocommerce-subscription' ) ?></th>
			<td colspan="2"><?php echo wc_price( $subscription->subscription_total ); ?></td>
		</tr>
		</tfoot>
	</table>
<?php if ( !empty( $subscription->order_ids ) ): ?>
	<h3><?php _e( 'Related Orders', 'yith-woocommerce-subscription' ); ?></h3>
	<p>
	<?php
	foreach ( $subscription->order_ids as $order_id ) :
		$order      = wc_get_order( $order_id );
		if( ! $order ){
			printf( __( '<p>Order #%d</p>', 'yith-woocommerce-subscription') , $order_id );
		}
		$item_count = $order->get_item_count();
	?>
	<a href="<?php echo esc_url( $order->get_view_order_url() ); ?>">
			<?php echo _x( '#', 'hash before order number', 'yith-woocommerce-subscription' ) . $order->get_order_number(); ?>
		</a>
		<?php endforeach ?></p>
<?php endif ?>

	<h3><?php _e( 'Customer\'s details', 'yith-woocommerce-subscription' ); ?></h3>

<?php if ( $subscription->billing_email ) : ?>
	<p>
		<strong><?php _e( 'Email:', 'yith-woocommerce-subscription' ); ?></strong> <?php echo esc_html( $subscription->billing_email ); ?>
	</p>
<?php endif; ?>

<?php if ( $subscription->billing_phone ) : ?>
	<p>
		<strong><?php _e( 'Telephone:', 'yith-woocommerce-subscription' ); ?></strong> <?php echo esc_html( $subscription->billing_phone ); ?>
	</p>
<?php endif; ?>


<?php
	do_action( 'woocommerce_email_footer', $email );
