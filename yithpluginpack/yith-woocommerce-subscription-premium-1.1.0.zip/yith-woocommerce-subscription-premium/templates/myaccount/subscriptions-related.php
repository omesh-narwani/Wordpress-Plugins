<?php
/**
 * My Account Subscriptions Section of YITH WooCommerce Subscription
 *
 * @package YITH WooCommerce Subscription
 * @since   1.0.0
 * @author  Yithemes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$subscriptions = get_post_meta( $order->id, 'subscriptions', true);

if( empty( $subscriptions ) ) {
	return;
}
?>
	<h2><?php echo apply_filters( 'ywsbs_my_account_subscription_title', __( 'Related Subscriptions', 'yith-woocommerce-subscription' ) ); ?></h2>

<?php if ( $subscriptions ) :

	?>
	<table class="shop_table ywsbs_subscription_table my_account_orders">
		<thead>
		<tr>
			<th class="ywsbs-subscription-product"><?php _e( 'Product', 'yith-woocommerce-subscription' ); ?></th>
			<th class="ywsbs-subscription-status"><?php _e( 'Status', 'yith-woocommerce-subscription' ); ?></th>
			<th class="ywsbs-subscription-recurring"><?php _e( 'Recurring', 'yith-woocommerce-subscription' ); ?></th>
			<th class="ywsbs-subscription-start-date"><?php _e( 'Start date', 'yith-woocommerce-subscription' ); ?></th>
			<th class="ywsbs-subscription-payment-date"><?php _e( 'Next Payment Due Date', 'yith-woocommerce-subscription' ); ?></th>
			<th class="ywsbs-subscription-action-view"></th>
			<?php if( get_option('allow_customer_cancel_subscription') == 'yes' ): ?>
				<th class="ywsbs-subscription-action-delete"></th>
			<?php endif ?>
		</tr>
		</thead>
		<tbody>
		<?php foreach ( $subscriptions as $subscription_post ) :
			$subscription = new YWSBS_Subscription( $subscription_post );
			$next_payment_due_date = ( !in_array( $subscription->status, array( 'paused', 'cancelled') )  && $subscription->payment_due_date) ? date_i18n( wc_date_format(), $subscription->payment_due_date ) : '';
			$start_date = ( $subscription->start_date ) ? date_i18n( wc_date_format(), $subscription->start_date ) : '';
			?>


			<tr class="ywsbs-item">
				<td class="ywsbs-subscription-product">
					<a href="<?php echo get_permalink( $subscription->product_id ) ?>"><?php echo $subscription->product_name ?></a><?php echo ' x '. $subscription->quantity  ?>
				</td>

				<td class="ywsbs-subscription-status">
					<span class="status <?php echo $subscription->status ?>"><?php echo $subscription->status ?></span>
				</td>

				<td class="ywsbs-subscription-recurring">
					<?php echo $subscription->get_formatted_recurring() ?>
				</td>

				<td class="ywsbs-subscription-start-date">
					<?php echo $start_date ?>
				</td>

				<td class="ywsbs-subscription-payment-date">
					<?php echo $next_payment_due_date ?>
				</td>

				<td class="ywsbs-subscription-action-view">
					<a href="<?php echo $subscription->get_view_subscription_url() ?>" class="<?php echo apply_filters('ywsbs_button_class', 'button') ?>"><?php echo __('View','yith-woocommerce-subscription') ?></a>
				</td>
				<?php if( get_option('ywsbs_allow_customer_cancel_subscription') == 'yes' ): ?>
					<td class="ywsbs-subscription-action-delete">
						<?php if(  $subscription->can_be_cancelled() ): ?>
							<a href="#cancel-subscription-modal"  class="button cancel-subscription-button" data-rel="prettyPhoto" data-id="<?php echo $subscription->id ?>" data-url="<?php echo esc_url( $subscription->get_change_status_link('cancelled') ) ?>"><?php _e( 'Cancel', 'yith-woocommerce-subscription' ) ?></a>
						<?php endif ?>
					</td>
				<?php endif ?>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
<?php endif;?>

<!-- SUBSCRIPTION CANCEL POPUP OPENER -->
<div id="cancel-subscription-modal" class="hide-modal myaccount-modal-cancel" >
	<p><?php _e( 'Do you really want to cancel subscription?', 'yith-woocommerce-subscription' ) ?></p>
	<p>
		<a class="ywsbs-button button my-account-cancel-quote-modal-button" data-id="" href="#"><?php _e( 'Yes, I want to cancel the subscription', 'yith-woocommerce-subscription' ) ?></a>
		<a class="ywsbs-button button close-subscription-modal-button" href="#"><?php _e( 'Close', 'yith-woocommerce-subscription' ) ?></a>
	</p>
</div>