=== YITH WooCommerce Tab Manager ===

Contributors: yithemes
Tags: tab, woocommerce, product, custom tab, e-commerce, ecommerce, commerce, global tab, product tab, tab manager, tabs, shop, yith, yit, yithemes
Requires at least: 3.5.1
Tested up to: 4.4
Stable tag: 1.1.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Documentation: http://yithemes.com/docs-plugins/yith-woocommerce-tab-manager/

== Changelog ==

= 1.1.5 =

* Fixed: show google map in first tab

= 1.1.4 =

* Fixed : hide empty tabs in frontend
* Updated: Plugin Framework

= 1.1.3 =

* Added: Support to WooCommerce 2.5
* Updated: Plugin Framework

= 1.1.2 =

* Fixed: Minor Bugs

= 1.1.1 =

* Added: option for add custom style
* Updated: Language File
* Updated: Plugin framework

= 1.1.0 =

* Added: Show, hide, or customize WooCommerce tabs
* Updated: Language file
* Changed: Text Domain

= 1.0.6 =

* Fixed: Plugin framework loader

= 1.0.5 =

* Tweak: Performance improved with new plugin core 2.0

= 1.0.4 =

* Added: Support to WooCommerce 2.4
* Added: FontAwesome 4.3
* Updated: Plugin core framework

= 1.0.3 =

* Added: WooCommerce 2.3.13 compatibility
* Fixed: Duplicate Tabs issue with WPML

= 1.0.2 =

* Fixed: menu position conflict

= 1.0.1 =

* Initial release