/**
 * Created by Your Inspiration on 15/04/2015.
 */

jQuery(document).ready(function($){
    var initializeMap = function( gmap ){

        var zoom_map=gmap.data('zoom'),
            addr=gmap.data('address');
        gmap.gmap3({
            map   : {
                options: {
                    zoom             : zoom_map,
                    disableDefaultUI         : true,
                    mapTypeControl           : false,
                    panControl               : false,
                    zoomControl              : false,
                    scaleControl             : false,
                    streetViewControl        : false,
                    rotateControl            : false,
                    rotateControlOptions     : false,
                    overviewMapControl       : false,
                    overviewMapControlOptions: false
                },
                address: addr
            },
            marker: {
                address: addr
            }
        });
    };

    $('#tab-faqs-container .tab-faq-wrapper').click(function () {
        var text = $(this).find('div.tab-faq-item');

        if (text.is(':hidden')) {
            text.slideDown('200');
            $(this).find('span').addClass('opened').removeClass('closed');
        } else {
            text.slideUp('200');
            $(this).find('span').addClass('closed').removeClass('opened');
        }

    });
    /*MAP*/

    $('.ywtm_map').each(function(){

        var parent = $(this).parent().parent();

        if( parent.css('display') == 'block')
            initializeMap( $( this ));
    });

    $('.woocommerce-tabs ul.tabs li a').on( 'click', function(  ) {
        var tab = $(this),
            tabs_wrapper = tab.closest( '.woocommerce-tabs'),
            tabcon = $( 'div' + tab.attr( 'href' ), tabs_wrapper);

        if( tabcon.find('#tab-map').length > 0 ){

            var map = tabcon.find('#tab-map');

            initializeMap( map );
         }
    });

});
