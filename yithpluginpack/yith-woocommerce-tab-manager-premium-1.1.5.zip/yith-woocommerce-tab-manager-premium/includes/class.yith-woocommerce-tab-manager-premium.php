<?php
if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * Implements features of PREMIUM version of YITH WooCommerce Tab Manager plugin
 *
 * @class   YITH_WC_Tab_Manager_Premium
 * @package Yithemes
 * @since   1.0.0
 * @author  Your Inspiration Themes
 *
 */

if (!class_exists('YITH_WC_Tab_Manager_Premium')) {

    class YITH_WC_Tab_Manager_Premium extends YITH_WC_Tab_Manager
    {

        /* Priority Tab penalty
        * @var int
        */
        protected $priority = 0;


        public function __construct()
        {

            parent::__construct();

            $this->includes();
            YWTM_Icon();
            YWTM_Product_Tab();


            /* filter for add custom column (type)*/
            add_filter('yith_add_column_tab', array( $this, 'add_tab_type_column' ), 10 );

            add_action( 'admin_init', array( $this, 'add_layout_tab_metabox' ), 15 );
            add_action( 'admin_enqueue_scripts', array( $this, 'add_select_category_script' ) );
            add_action( 'admin_enqueue_scripts', array( $this, 'admin_product_script' ) );
            add_action( 'admin_enqueue_scripts', array( $this, 'multiple_metabox_script' ) );
            add_action( 'wp_ajax_yith_json_search_product_categories', array( $this, 'json_search_product_categories' ), 10 );
            add_filter( 'yit_fw_metaboxes_type_args', array( $this, 'add_custom_metaboxes' ) );
            add_action( 'wp_print_scripts', array($this, 'print_custom_style' ) );

            // register plugin to licence/update system
            add_action( 'wp_loaded', array( $this, 'register_plugin_for_activation' ), 99 );
            add_action( 'admin_init', array( $this, 'register_plugin_for_updates' ) );


            if ( get_option( 'ywtm_enable_plugin' ) == 'yes' ) {

                //add tabs to woocommerce
                add_filter( 'woocommerce_product_tabs', array( $this, 'show_or_hide_woocommerce_tab' ), 20 );
            }


        }

        /**
         * Returns single instance of the class
         *
         * @return \YITH_WTM
         * @since 1.0.0
         */
        public static function get_instance()
        {


            if (is_null(self::$instance)) {
                self::$instance = new self($_REQUEST);
            }

            return self::$instance;
        }

        /**
         * includes file
         */
        private function includes()
        {

            include_once('class-ywtm-icon.php');
            include_once('yith-tab-manager-actions.php');
            include_once('class.yith-product-tab.php');
            include_once('yith-tab-manager-functions.php');

        }

        /**Include admin script
         * @author YITHEMES
         * @since 1.0.0
         * @use admin_enqueue_scripts
         */
        public function admin_product_script()
        {
            wp_enqueue_script('yit-tab-manager-script', YWTM_ASSETS_URL . 'js/backend/admin_tab_product.js', array('jquery'), YWTM_VERSION, true);
        }




        /**
         * add_tab_metabox
         * Register metabox for global tab
         * @author Yithemes
         * @since 1.0.0
         */
        public function  add_layout_tab_metabox()
        {
            $args = include_once(YWTM_INC . '/metabox/tab-layout-metabox.php');

            if (!function_exists('YIT_Metabox')) {
                require_once('plugin-fw/yit-plugin.php');
            }
            $metabox = YIT_Metabox('yit-tab-manager-setting');
            $metabox->add_tab($args, 'after', 'settings');


        }

        /**Add the column "Tab Type" at the Table
         * @param $columns
         * @return mixed
         */
        public function add_tab_type_column($columns)
        {

            unset($columns['date']);
            $columns['tab_type'] = __('Tab type', 'yith-woocommerce-tab-manager');
            $columns['date'] = __('Date', 'yith-woocommerce-tab-manager');

            return $columns;
        }


        /**
         * Print the content columns
         * @param $column
         * @param $post_id
         */
        public function custom_columns($column, $post_id)
        {

            parent::custom_columns($column, $post_id);

            switch ($column) {
                case 'tab_type' :
                    $type = get_post_meta($post_id, '_ywtm_tab_type', true);

                    if (empty($type) || $type == 'global')
                        echo 'global';

                    else echo $type;

                    break;
            }
        }

        /**get_tab_types
         *
         * return type tabs
         *
         * @author Yithemes
         * @since 1.0.0
         * @return array
         */
        public function get_tab_types()
        {

            $tab_type = array(
                'global' => __('Global Tab', 'yith-woocommerce-tab-manager'),
                'category' => __('Category Tab', 'yith-woocommerce-tab-manager'),
                'product' => __('Product Tab', 'yith-woocommerce-tab-manager')
            );

            return $tab_type;

        }

        /**return layout type of tabs
         * @author YITHEMES
         * @since 1.0.0
         * @return mixed|void
         */
        public function get_layout_types()
        {

            $tab_layout_types = apply_filters('yith_add_layout_tab', array(

                    'default' => __('Editor', 'yith-woocommerce-tab-manager'),
                    'video' => __('Video Gallery', 'yith-woocommerce-tab-manager'),
                    'gallery' => __('Image Gallery', 'yith-woocommerce-tab-manager'),
                    'faq' => __('FAQ', 'yith-woocommerce-tab-manager'),
                    'download' => __('Download', 'yith-woocommerce-tab-manager'),
                    'map' => __('Map', 'yith-woocommerce-tab-manager'),
                    'contact' => __('Contact', 'yith-woocommerce-tab-manager'),
                    'shortcode' => __('Shortcode', 'yith-woocommerce-tab-manager')

                )
            );

            return $tab_layout_types;
        }


        /**
         * add_tabs_woocommerce
         *
         * @since 1.0.0
         * @param $tabs
         * @return mixed
         * @use woocommerce_product_tabs filter
         */
        public function add_tabs_woocommerce($tabs){

            global $product;

            $yith_tabs = $this->get_tabs();
            $prefix = 'ywtm';
            foreach ($yith_tabs as $tab) {

                $tab_type = get_post_meta($tab["id"], '_ywtm_tab_type', true);
                $icon = get_post_meta($tab['id'], '_ywtm_icon_tab', true);


                switch ($tab_type) {

                    case  'product' :

                        $products = get_post_meta($tab["id"], '_ywtm_tab_product', true);
                        if ($products)
                            foreach ($products as $id_prod) {
                                $key = $prefix.'_'.$tab["id"];
                                if( $id_prod == $product->id && !$this->is_empty( $key ) ) {

                                    $tabs[$key] = $this->set_single_tab($tab['title'], $icon, $tab['priority'], 'put_content_tabs');
                                }
                            }

                        break;

                    case 'category':

                        $categories = get_post_meta($tab["id"], '_ywtm_tab_category', true);

                        $cat_product = wp_get_post_terms($product->id, 'product_cat', array("fields" => "ids"));

                        foreach ($categories as $id_cat) {
                            $key = $prefix.'_'.$tab["id"];
                            if (in_array($id_cat, $cat_product) && !$this->is_empty( $key ) ) {

                                $tabs[$key] = $this->set_single_tab($tab['title'], $icon, $tab['priority'], 'put_content_tabs');
                            }
                        }

                        break;

                    default :
                        $key = $prefix.'_'.$tab["id"];
                        if(!$this->is_empty( $key ) )
                            $tabs[$key] = $this->set_single_tab($tab['title'], $icon, $tab['priority'], 'put_content_tabs');

                        break;
                }

                add_filter('woocommerce_product_' . $prefix . '_' . $tab["id"] . '_tab_title', array($this, 'decode_html_tab'), 10, 2);

            }

            return $tabs;
        }

        /** set_single_tab
         *
         * @param $title
         * @param $priority
         * @param $callback
         * @return array
         */
        protected function set_single_tab($title, $icon, $priority, $callback)
        {
            $tab_icon = '';
            if (!empty($icon)) {

                switch ($icon['select']) {
                    case 'icon' :
                        $tab_icon = '<span class="ywtm_icon"' . YWTM_Icon()->get_icon_data($icon['icon']) . '"></span>';
                        break;
                    case 'custom' :
                        $tab_icon = '<span class="custom_icon" ><img src="' . $icon['custom'] . '" style="max-width :27px;max-height: 25px;" /></span>';
                        break;
                }
            }
            $tab = array(
                'title' => $tab_icon . __($title, 'yith-woocommerce-tab-manager'),
                'priority' => $priority + $this->get_priority(),
                'callback' => array($this, $callback)
            );

            return $tab;
        }

        /**print icon tab
         * @param $title
         * @param $key
         * @since 1.1.0
         */
        public function decode_html_tab($title, $key)
        {

            return htmlspecialchars_decode($title);
        }


        public function is_empty( $key ){
            global $product;


            if (substr($key, 0, 4) === 'ywtm') {
                $key = explode('_', $key);
                $key = $key[1];

            }
            $type_content = get_post_meta($key, '_ywtm_enable_custom_content', true);
            $type_layout = get_post_meta($key, '_ywtm_layout_type', true);
            $args = array();

            $is_empty = false;

            switch ($type_layout) {

                case 'download' :

                    if (true == $type_content)
                        $args['download'] = get_post_meta($key, '_ywtm_download', true);
                    else
                        $args['download'] = get_post_meta($product->id, $key . '_custom_list_file', true);

                   $is_empty = empty( $args['download'] );
                    break;

                case 'faq' :

                    if (true == $type_content)
                        $args['faqs'] = get_post_meta($key, '_ywtm_faqs', true);

                    else
                        $args['faqs'] = get_post_meta($product->id, $key . '_custom_list_faqs', true);

                    $is_empty = empty( $args['faqs'] );
                    break;

                case 'map' :

                    if (true == $type_content) {
                        $address = get_post_meta($key, '_ywtm_google_map_overlay_address', true);

                    } else{
                        $args['map'] = get_post_meta($product->id, $key . '_custom_map', true);
                        $address = isset( $args['map']['addr'] ) ? $args['map']['addr'] : '';
                    }

                   $is_empty = empty( $address );
                    break;

                case 'contact':

                    if (true == $type_content)
                        $args['form'] = get_post_meta($key, '_ywtm_form_tab', true);
                    else
                        $args['form'] = get_post_meta($product->id, $key . '_custom_form', true);

                    $is_empty = empty(  $args['form'] );
                    break;

                case 'gallery':

                    if (true == $type_content) {

                        $gallery = get_post_meta($key, '_ywtm_gallery', true);

                    } else {

                        $result = get_post_meta($product->id, $key . '_custom_gallery', true);
                        $gallery = isset( $result['images'] ) && !empty( $result['images'] ) ? 'gallery' : '';

                    }
                    $is_empty = empty( $gallery );
                    break;

                case 'video':

                    if (true == $type_content) {
                        $result = get_post_meta($key, '_ywtm_video', true);
                        $video = $result['video_info'];


                    } else {

                        $result = get_post_meta($product->id, $key . '_custom_video', true);
                        $video = $result ? 'video' : '';
                    }

                   $is_empty = empty( $video );
                    break;

                case 'shortcode':
                    if (true == $type_content) {

                        $args['shortcode'] = get_post_meta($key, '_ywtm_shortcode_tab', true);
                    } else
                        $args['shortcode'] = get_post_meta($product->id, $key . '_custom_shortcode', true);

                    $is_empty = empty( $args['shortcode'] );
                    break;

                default :

                    if (true == $type_content) {
                        $args['content'] = get_post_meta($key, '_ywtm_text_tab', true);
                    } else {

                        $args['content'] = get_post_meta($product->id, $key . '_default_editor', true);
                    }

                    $is_empty = empty( $args['content'] );
                    break;
            }

            return $is_empty;
        }
        /**
         * put_content_tabs
         * Put the content at the tabs
         * @param $key
         * @param $tab
         */
        public function put_content_tabs($key, $tab)
        {

            global $product;


            if (substr($key, 0, 4) === 'ywtm') {
                $key = explode('_', $key);
                $key = $key[1];

            }
            $type_content = get_post_meta($key, '_ywtm_enable_custom_content', true);
            $type_layout = get_post_meta($key, '_ywtm_layout_type', true);
            $args = array();

            switch ($type_layout) {

                case 'download' :

                    if (true == $type_content)
                        $args['download'] = get_post_meta($key, '_ywtm_download', true);
                    else
                        $args['download'] = get_post_meta($product->id, $key . '_custom_list_file', true);

                    yit_plugin_get_template(YWTM_DIR, 'download.php', $args);
                    break;

                case 'faq' :

                    if (true == $type_content)
                        $args['faqs'] = get_post_meta($key, '_ywtm_faqs', true);

                    else
                        $args['faqs'] = get_post_meta($product->id, $key . '_custom_list_faqs', true);

                    yit_plugin_get_template(YWTM_DIR, 'faq.php', $args);
                    break;

                case 'map' :

                    if (true == $type_content) {
                        $address = get_post_meta($key, '_ywtm_google_map_overlay_address', true);
                        $width = get_post_meta($key, '_ywtm_google_map_width', true);
                        $height = get_post_meta($key, '_ywtm_google_map_height', true);
                        $zoom = get_post_meta($key, '_ywtm_google_map_overlay_zoom', true);
                        $show_w = get_post_meta($key, '_ywtm_google_map_full_width', true);

                        /*addr, heig,wid,zoom*/
                        $map_setting = array(
                            'addr' => $address,
                            'wid' => $width,
                            'heig' => $height,
                            'zoom' => $zoom,
                            'show_width' => $show_w
                        );

                        $args['map'] = $map_setting;

                    } else
                        $args['map'] = get_post_meta($product->id, $key . '_custom_map', true);

                    yit_plugin_get_template(YWTM_DIR, 'map.php', $args);
                    break;

                case 'contact':

                    if (true == $type_content)
                        $args['form'] = get_post_meta($key, '_ywtm_form_tab', true);
                    else
                        $args['form'] = get_post_meta($product->id, $key . '_custom_form', true);

                    yit_plugin_get_template(YWTM_DIR, 'contact_form.php', $args);
                    break;

                case 'gallery':

                    if (true == $type_content) {
                        $columns = get_post_meta($key, '_ywtm_gallery_columns', true);
                        $gallery = get_post_meta($key, '_ywtm_gallery', true);
                        $args['images'] = array('columns' => $columns, 'gallery' => $gallery);
                    } else {

                        $result = get_post_meta($product->id, $key . '_custom_gallery', true);
                        if (isset($result['settings'])) {
                            $columns = $result['settings']['columns'];

                            $gallery = '';

                            foreach ($result['images'] as $key => $image)
                                $gallery .= $image['id'] . ',';

                            if (substr($gallery, -1) == ',')
                                $gallery = substr($gallery, 0, -1);

                            $args['images'] = array('columns' => $columns, 'gallery' => $gallery);
                        }
                    }

                    $args['tab_id'] = $key;
                    yit_plugin_get_template(YWTM_DIR, 'image_gallery.php', $args);
                    break;

                case 'video':

                    if (true == $type_content) {
                        $result = get_post_meta($key, '_ywtm_video', true);

                        $columns = $result['columns'];
                        $video = $result['video_info'];
                        $args['videos'] = array('columns' => $columns, 'video' => $video);

                    } else {

                        $result = get_post_meta($product->id, $key . '_custom_video', true);

                        if ($result) {
                            $columns = $result['settings']['columns'];
                            $video = $result['video'];
                            $args['videos'] = array('columns' => $columns, 'video' => $video);
                        }

                    }

                    yit_plugin_get_template(YWTM_DIR, 'video_gallery.php', $args);
                    break;

                case 'shortcode':
                    if (true == $type_content) {

                        $args['shortcode'] = get_post_meta($key, '_ywtm_shortcode_tab', true);
                    } else
                        $args['shortcode'] = get_post_meta($product->id, $key . '_custom_shortcode', true);

                    yit_plugin_get_template(YWTM_DIR, 'shortcode.php', $args);
                    break;

                default :

                    if (true == $type_content) {
                        $args['content'] = get_post_meta($key, '_ywtm_text_tab', true);
                    } else {

                        $args['content'] = get_post_meta($product->id, $key . '_default_editor', true);
                    }

                    yit_plugin_get_template(YWTM_DIR, $this->_default_layout . '.php', $args);
                    break;
            }


        }

        /** show or hide default tabs
         * @author YIThemes
         * @since 1.0.0
         * @param $tabs
         * @return mixed
         */
        public function show_or_hide_woocommerce_tab( $tabs ){

            $tab_type = array( 'description','reviews','additional_information' );
            global $product;

            foreach( $tab_type as $type ){

                $is_hide = get_post_meta( $product->id, '_ywtm_hide_'.$type, true );
                $is_over = get_post_meta( $product->id, '_ywtm_override_'.$type, true );
                if( $is_hide === 'yes' )
                    unset( $tabs[$type] );
                elseif( $is_over === 'yes' ){

                    $title =  get_post_meta( $product->id, '_ywtm_title_tab_'.$type, true );

                    $tabs[$type]['priority'] = get_post_meta( $product->id, '_ywtm_priority_tab_'.$type, true );
                    $tabs[$type]['title'] = $type === 'reviews' ? str_replace('%d',$product->get_review_count(),$title ) : $title;

                    if( $type === 'description' ){

                        $tabs[$type]['callback'] = array( $this, 'ywtm_custom_wc_description_content' );
                    }
                }

            }

            return $tabs;
        }

        /**
         * get custom content for description tab
         * @author YIThemes
         * @since 1.1.0
         */
        public function ywtm_custom_wc_description_content(){

            global $product;
            $content = get_post_meta( $product->id, '_ywtm_content_tab_description', true );

            $args = array(
                'content'   => $content
            );
            yit_plugin_get_template(YWTM_DIR, $this->_default_layout . '.php', $args);
        }


        /**get_tab_categories
         *
         * Load all categories in Category chosen field
         * @author Yithemes
         * @since 1.0.0
         * @return array
         */
        public function get_tab_categories()
        {

            $args = array('hide_empty' => 0);

            $categories_term = get_terms('product_cat', $args);

            $categories = array();

            foreach ($categories_term as $category) {

                $categories[$category->term_id] = '#' . $category->term_id . ' - ' . $category->name;
            }

            return $categories;

        }

        /**json_search_product_categories
         * search product category in taxonomy 'product_cat'
         * @param string $x
         * @param array $taxonomy_types
         * @author Yithemes
         * @return json
         */
        public function json_search_product_categories($x = '', $taxonomy_types = array('product_cat'))
        {

            if (isset($_GET['plugin']) && YWTM_SLUG == $_GET['plugin']) {

                global $wpdb;
                $term = (string)urldecode(stripslashes(strip_tags($_GET['term'])));
                $term = "%" . $term . "%";


                $query_cat = $wpdb->prepare("SELECT {$wpdb->terms}.term_id,{$wpdb->terms}.name
                                   FROM {$wpdb->terms} INNER JOIN {$wpdb->term_taxonomy} ON {$wpdb->terms}.term_id = {$wpdb->term_taxonomy}.term_id
                                   WHERE {$wpdb->term_taxonomy}.taxonomy IN (%s) AND {$wpdb->terms}.slug LIKE %s", implode(",", $taxonomy_types), $term);

                $product_categories = $wpdb->get_results($query_cat);

                $to_json = array();

                foreach ($product_categories as $product_category) {

                    $to_json[$product_category->term_id] = "#" . $product_category->term_id . " - " . $product_category->name;
                }

                wp_send_json($to_json);
            }

        }

        /* Add select category scripts
         *
         * @Author Yithemes
         * @since 1.0.0
         * @return void
         * @use yith_json_search_product_categories
         */
        public function add_select_category_script()
        {

            $inline_js = "
                jQuery('select#_ywtm_tab_category').ajaxChosen({
                    method: 		'GET',
                    url: 			'" . admin_url('admin-ajax.php') . "',
                    dataType: 		'json',
                    afterTypeDelay: 100,
                    minTermLength: 	3,
                    data:		{
                        action: 	'yith_json_search_product_categories',
                        security: 	'" . wp_create_nonce("search-product-category") . "',
                        default: 	'',
                        plugin:     '" . YWTM_SLUG . "'
                    }
                }, function (data) {

                    var terms = {};

                    $.each(data, function (i, val) {
                        terms[i] = val;

                    });

                   return terms;
                });
            ";


            wc_enqueue_js($inline_js);
        }

        /**Add multiple dependence in yit metaboxes
         * @author YITHEMES
         * @since 1.0.0
         * @use admin_enqueue_scripts
         */
        public function multiple_metabox_script()
        {

            $inline_js = "(function ($) {
                                //dependencies handler
                                $('.metaboxes-tab [data-field]').each(function(){
                                        var t = $(this);

                                        var deps= t.data('dep').split(',');


                                        if(isArray(deps) && deps.length>1){
                                            var field = '#' + t.data('field');
                                            var values= t.data('value').split(',');
                                            multi_dependencies_handler( field, deps,values,true );
                                            for( var i=0; i<deps.length; i++){
                                                deps[i]= '#'+deps[i];
                                                }

                                            for( var i=0; i<deps.length; i++)
                                                    $(deps[i]).on('change', function(){
                                                        multi_dependencies_handler( field, deps,values,false );
                                                        }).change();
                                                    }
                                    });

                                //Handle multi-dependencies
                                function multi_dependencies_handler ( id, deps, values, first) {
                                    var result = true;

                                    for (var i = 0; i < deps.length; i++) {

                                            if( deps[i].substr( 0, 6 ) == ':radio' )
                                                {deps[i] = deps[i] + ':checked'; }

                                            var val = $( deps[i] ).val();

                                            if( $(deps[i]).attr('type') == 'checkbox'){
                                                var thisCheck = $(deps[i]);
                                                 if ( thisCheck.is ( ':checked' ) ) {
                                                    val = 'yes';
                                                    }
                                                else {
                                                    val = 'no';
                                                    }
                                            }
                                            if( result && (val==values[i]) ){
                                                     result=true;
                                            }
                                            else {
                                                result=false;
                                                break;
                                                }
                                    }

                                    if( !result ) {
                                     $( id + '-container' ).parent().hide();
                                    } else {
                                        $( id + '-container' ).parent().show();
                                        }
                                    };

                                function isArray(myArray) {
                                        return myArray.constructor.toString().indexOf('Array') > -1;
                                    };

                                })(jQuery);";

            wc_enqueue_js($inline_js);
        }

        /**Enable custom metabox type
         * @author YITHEMES
         * @param $args
         * @use yit_fw_metaboxes_type_args
         * @return mixed
         */
        public function add_custom_metaboxes($args)
        {
            if ('faqs' == $args['type']) {
                $args['basename'] = YWTM_DIR;
                $args['path'] = 'metaboxes/types/';
            }

            if ('downloads' == $args['type']) {
                $args['basename'] = YWTM_DIR;
                $args['path'] = 'metaboxes/types/';
            }

            if ('video-gallery' == $args['type']) {
                $args['basename'] = YWTM_DIR;
                $args['path'] = 'metaboxes/types/';
            }

            if ('forms' == $args['type']) {
                $args['basename'] = YWTM_DIR;
                $args['path'] = 'metaboxes/types/';
            }

            if ('iconlist' == $args['type']) {
                $args['basename'] = YWTM_DIR;
                $args['path'] = 'metaboxes/types/';
            }

            return $args;
        }

        /**
         * Register plugins for activation tab
         *
         * @return void
         * @since    2.0.0
         * @author   Andrea Grillo <andrea.grillo@yithemes.com>
         */
        public function register_plugin_for_activation()
        {
            if (!class_exists('YIT_Plugin_Licence')) {
                require_once YWTM_DIR.'plugin-fw/licence/lib/yit-licence.php';
                require_once YWTM_DIR.'plugin-fw/licence/lib/yit-plugin-licence.php';
            }
            YIT_Plugin_Licence()->register(YWTM_INIT, YWTM_SECRET_KEY, YWTM_SLUG);
        }

        /**
         * Register plugins for update tab
         *
         * @return void
         * @since    1.0.0
         * @author   Andrea Grillo <andrea.grillo@yithemes.com>
         */
        public function register_plugin_for_updates()
        {
            if (!class_exists('YIT_Upgrade')) {
                require_once( YWTM_DIR.'plugin-fw/lib/yit-upgrade.php' );
            }
            YIT_Upgrade()->register( YWTM_SLUG, YWTM_INIT );
        }

        /**
         * print custom style
         * @author YIThemes
         * @since 1.1.1
         */
        public function print_custom_style(){

            $custom_style = get_option( 'ywtm_custom_style' );

            if( !empty( $custom_style ) ){?>

                    <style type="text/css">
                        <?php echo $custom_style;?>
                    </style>
            <?php
            }
        }

    }
}