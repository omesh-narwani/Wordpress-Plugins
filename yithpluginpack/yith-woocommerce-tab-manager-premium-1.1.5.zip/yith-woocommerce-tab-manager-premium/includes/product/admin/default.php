<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<div id="<?php echo $tab;?>_tab" class="panel woocommerce_options_panel">
     <div class="custom_tab_options" >
         <p class="form-field"><label for="<?php echo $post->ID,$tab.'_default_editor'?>"><?php _e( 'Tab Content', 'yith-woocommerce-tab-manager' ); ?></label></p>
         <div class="editor" style="margin:30px;">
             <?php
             $content =  get_post_meta($post->ID,$tab.'_default_editor',true);
             $editor_id = $tab.'_default_editor';
             wp_editor( $content, $editor_id );
             ?>
         </div>
     </div>
</div>
