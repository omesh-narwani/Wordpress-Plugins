<?php
/**
 * Created by PhpStorm.
 * User: Your Inspiration
 * Date: 18/03/2015
 * Time: 14:44
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly


return array(

    'settings' => array(

        'section_general_settings'     => array(
            'name' => __( 'General settings', 'yith-woocommerce-tab-manager' ),
            'type' => 'title',
            'id'   => 'ywtm_section_general'
        ),

        'enable_plugin' => array(
            'name'    => __( 'Enable plugin', 'yith-woocommerce-tab-manager' ),
            'desc'    => '',
            'id'      => 'ywtm_enable_plugin',
            'default' => 'no',
            'type'    => 'checkbox'
        ),
        'custom_css' => array(
          'name' => __( 'Custom Style', 'yith-woocommerce-tab-manager'),
          'type' => 'textarea',
           'id' => 'ywtm_custom_style',
            'css' => 'width:100%;min-height:100px;',
            'desc'    => __( 'Insert here your custom CSS', 'yith-woocommerce-tab-manager' ),
            'default' => ''
        ),

         'section_general_settings_end' => array(
            'type' => 'sectionend',
            'id'   => 'ywtm_section_general_end'
        )
    )
);