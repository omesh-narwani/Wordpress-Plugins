<?php
$content = wpautop( $content );
?>

<div id="tab-editor-container" class="ywtm_content_tab"> <?php echo do_shortcode( $content ); ?></div>