<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if( isset( $map ) && !empty( $map ) && $map!="" && $map['addr']!=""){
$id = 'map_canvas_' .mt_rand();
extract($map);
//$full_width = ( $full_width == "yes" ) ? true : false;
$css_width = "";

if( !$show_width ){
    if( $wid != '' && $wid != 0 ){
        $css_width .= "width: " . $wid . "px;";
    } else{
        $css_width .= "width: auto;";
    }
}else{
    $wid = '';
}


//$latitude = ( isset( $lat ) && $lat != '' ) ? ' data-lat="' . $lat . '"' : '';
//$longitude = ( isset( $long ) && $long != '' ) ? ' data-lng="' . $long . '"' : '';
$address = ( isset( $addr ) && $addr != '' ) ? $addr  : '';
$zoom = ( isset( $zoom ) && $zoom != '' ) ?  $zoom : 15;
//$marker = ( isset( $mark ) && $mark != '' ) ? ' data-marker="' . $mark . '"' : '';
//$style = ( isset( $style ) && $style != '' ) ? ' data-style="' . $style . '"' : '';
$width_syle = ( $show_width ) ? "full-width section_fullwidth" : "" ;

?>

<div class="google-map ywtm_content_tab">
    <div id="tab-map" class="gmap3 ywtm_map"   style="height:<?php echo $heig ?>px;<?php echo $css_width ?>" data-zoom="<?php echo $zoom;?>" data-address="<?php echo $address;?>"></div>
    <a class="link_google_map" target="_blank" href="<?php echo esc_url( add_query_arg( array( 'q' => urlencode( $addr ) ),  '//maps.google.com/' ) )?>"><?php _e('Show in Google Map', 'yith-woocommerce-tab-manager');?></a>
</div>
<?php }
else
    echo '<p>'.__('No map for this product', 'yith-woocommerce-tab-manager').'</p>';
?>