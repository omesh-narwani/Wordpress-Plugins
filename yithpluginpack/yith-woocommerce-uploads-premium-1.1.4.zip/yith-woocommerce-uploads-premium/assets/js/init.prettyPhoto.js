(function ($) {
    var init_plugin = function () {
        $('a[rel="prettyPhoto[ywau_upload_rules]"]').prettyPhoto({
            markup: '<div id="ywau_upload_modal" class="pp_pic_holder"> \
                        <a class="pp_close" href="#"></a> \
						<div class="pp_content_container"> \
						    <div id="pp_full_res"></div> \
						</div> \
                     </div>\
					<div class="pp_overlay"></div>',
            hook: 'rel',
            social_tools: false,
            theme: 'pp_woocommerce',
            default_width: '500px',
            default_height: '80%',
            horizontal_padding: 20,
            opacity: 0.8,
            deeplinking: false,
            keyboard_shortcuts: true
        });
    };

    init_plugin();

    $("body").on("updated_checkout", init_plugin);
})
(jQuery);

