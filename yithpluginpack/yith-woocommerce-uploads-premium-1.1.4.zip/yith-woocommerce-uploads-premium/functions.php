<?php

//region    ***************  METAKEY name definition    *******************

if ( ! defined ( 'YWAU_METAKEY_ORDER_ITEM_FILES' ) ) {
    define ( 'YWAU_METAKEY_ORDER_ITEM_FILES', '_ywau_order_item_files' );
}

if ( ! defined ( 'YWAU_CART_UPLOAD_RESULTS' ) ) {
    define ( 'YWAU_CART_UPLOAD_RESULTS', 'ywau_upload_results' );
}

if ( ! defined ( 'YWAU_METAKEY_ORDER_FILE_UPLOADED' ) ) {
    define ( 'YWAU_METAKEY_ORDER_FILE_UPLOADED', '_ywau_order_file' );
}

if ( ! defined ( 'YWAU_ACTION_DOWNLOAD_FILE' ) ) {
    define ( 'YWAU_ACTION_DOWNLOAD_FILE', 'download-file' );
}

//endregion


