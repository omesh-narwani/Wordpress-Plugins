<?php
if ( ! defined ( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! class_exists ( 'YWAU_Uploaded_Items' ) ) {

    /**
     *
     * @class   YWAU_Uploaded_Items
     * @package Yithemes
     * @since   1.0.0
     * @author  Lorenzo Giuffrida
     */
    class YWAU_Uploaded_Items {

        private $is_cart = true;

        private $current_item_id = 0;

        private $items = array ();


        /**
         * Constructor
         *
         * Initialize items
         *
         * @since  1.0
         * @author Lorenzo Giuffrida
         */
        public function __construct () {
        }

        /**
         * Load items into the current object, from cart or from a specific order
         *
         * @param bool $is_cart it's a cart item
         * @param int  $item_id the current item id
         *
         * @return array of items
         */
        public function load_items ( $is_cart = false, $item_id = 0 ) {
            $this->is_cart         = $is_cart;
            $this->current_item_id = $item_id;

            if ( ! $this->is_cart ) {
                $this->items = wc_get_order_item_meta ( $item_id, YWAU_METAKEY_ORDER_ITEM_FILES );
            } else {
                $this->items = WC ()->session->get ( YWAU_CART_UPLOAD_RESULTS );
            }

            return $this->get_items ();
        }

        /**
         * Save items into the cart or order metadata
         */
        public function save_items () {

            if ( ! $this->is_cart ) {
                wc_update_order_item_meta ( $this->current_item_id, YWAU_METAKEY_ORDER_ITEM_FILES, $this->items );
            } else {
                WC ()->session->set ( YWAU_CART_UPLOAD_RESULTS, $this->items );
            }
        }

        public function item_exists ( $item_id ) {
            return isset( $this->items[ $item_id ] );
        }

        public function get_item ( $item_id, $rule_id ) {
            if ( isset( $this->items[ $item_id ][ $rule_id ] ) ) {

                //return new YWAU_Uploaded_Item( $this->items[ $item_id ][ $rule_id ] );
                return new YWAU_Uploaded_Item( $this->items[ $item_id ][ $rule_id ] );
            }

            return null;
        }

        /**
         * @param $uploaded_item YWAU_Uploaded_Item
         * @param $item_id       int
         * @param $rule_id       int
         */
        public function set_item ( $uploaded_item, $item_id, $rule_id ) {
            $this->items[ $item_id ][ $rule_id ] = $uploaded_item->to_array ();
        }

        /**
         * Retrieve all items
         *
         * @return array
         */
        public function get_items () {
            $results = array ();

            if ( $this->items ) {
                foreach ( $this->items as $key => $value ) {
                    foreach ( $value as $item ) {
                        $results[] = new YWAU_Uploaded_Item( $item );
                    }
                }
            }

            return $results;
        }

        /**
         * Retrieve all items for a product
         *
         * @return array
         */
        public function get_items_by_key ( $item_key ) {
            //todo verify the use of this method after the edit
            $results = array ();

            if ( $this->items && isset( $this->items [ $item_key ] ) ) {
                foreach ( $this->items [ $item_key ] as $key => $value ) {
                    $results[] = new YWAU_Uploaded_Item( $value );
                }
            }

            return $results;
        }

        /**
         * Delete a specific item
         *
         * @param $item YWAU_Uploaded_Item
         */
        public function delete_item ( $item ) {
            if ( ! isset( $item ) ) {
                return;
            }

            if ( isset( $this->items[ $item->item_id ][ $item->rule_id ] ) ) {
                unset( $this->items[ $item->item_id ][ $item->rule_id ] );
            }
        }
    }
}