=== YITH WooCommerce Uploads Premium ===

Contributors: yithemes
Tags: woocommerce, e-commerce, ecommerce, shop, file upload, attach file, append file, customize order.
Requires at least: 4.0
Tested up to: 4.4.2
Stable tag: 1.1.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

It lets your customers attach and upload a file to their order. You can also set limits to file size and extension to avoid wrong uploads.

== Description ==

A concrete way to customize your orders: upload a file with your image and complete your order, or attach the PDF copy of your ID card which is required to purchase that specific item. YITH WooCommerce Uploads allows both your customers to  add something personal to their purchase and you to help them not forget essential documents needed to complete their order. Attach a file is an essential feature that can make you save a lot of time when dealing with customers via email about details of the order.

== Changelog ==

= Version 1.1.4 - RELEASED: FEB 08, 2016 =

* Fixed: jQuery script that shows the upload rules on cart page

= Version 1.1.3 - RELEASED: JAN 25, 2016 =

* Fixed: unable to modify a file if it was rejected

= Version 1.1.2 - RELEASED: JAN 21, 2016 =

* Fixed: upload fails when the option Storing mode is set to "order number"

= Version 1.1.1 - RELEASED: JAN 20, 2016 =

* Fixed: some layout issue

= Version 1.1.0 - RELEASED: JAN 18, 2016 =

* Updated: plugin ready for WooCommerce 2.5
* Fixed: some method call fails with PHP prior than 5.6

= Version 1.0.8 - RELEASED: DEC 18, 2015 =

* Fixed: deleting uploaded file fails on simple products

= Version 1.0.7 - RELEASED: NOV 23, 2015 =

* Updated: script enqueue priority changed to 199 to ensure PrettyPhoto will be registered
* Updated: changed action used for YITH Plugin FW loading from after_setup_theme to plugins_loaded

= Version 1.0.6 - RELEASED: NOV 03, 2015 =

* Fixed: totals on checkout page doesn't update changing shipping methods

= Version 1.0.5 - RELEASED: OCT 29, 2015 =

* Added: Separated lines in cart for multiple items of same product
* Updated: YITH plugin framework

= Version 1.0.4 - RELEASED: OCT 26, 2015 =

* Fixed: wrong file path used while including emogrifier.php file

= Version 1.0.3 - RELEASED: OCT 06, 2015 =

* Fixed: files attached to variations not downloadable.

= Version 1.0.2 - RELEASED: SEP 17, 2015 =

* Added: new option to allow file upload from checkout page or thank you page.
* Added: you can add different upload rules for each variation instead of using the same rules for any product variations.
* Added: users can edit uploaded files even from cart page.

= Version 1.0.1 - RELEASED: SEP 01, 2015 =

* Fixed: removed deprecated woocommerce_update_option_X hook.

= 1.0.0  - RELEASED: AUG 14, 2015 =

* Initial release
