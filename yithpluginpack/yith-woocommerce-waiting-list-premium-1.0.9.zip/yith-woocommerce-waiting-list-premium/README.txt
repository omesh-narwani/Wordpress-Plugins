== Changelog ==

= 1.0.9 = 04-01-2016 =

* Added: Compatibility with WooCommerce 2.5 BETA
* Updated: Plugin Core
* Updated: Language file .pot

= 1.0.8 = 15-12-2015 =

* Fixed: Compatibility issue with YITH WooCommerce Multi Vendor 
* Updated: Changed text domain from yith-wcwtl to yith-woocommerce-waiting-list
* Updated: Language file .pot
 
= 1.0.7 = 11-12-2015 =

* Added: Compatibility with Wordpress 4.4
* Fixed: Double menu entry for YITH Plugins
* Updated: Plugin Core

= 1.0.6 = 24-11-2015 =

* Added: Compatibility with YITH WooCommerce Multi Vendor
* Updated: Plugin Core
* Updated: Language file

= 1.0.5 = 12-10-2015 =

* Added: Mandrill Integration
* Added: Advanced text editor for content email options
* Updated: Plugin Core

= 1.0.4 = 09-09-2015 =

* Fixed: Automatic email for variable product
* Fixed: Redirect to correct page after sending mail

= 1.0.3 = 21-08-2015 =

* Added: Compatibility with Wordpress 4.3
* Fixed: Exclusion List and Waiting List Tables error
* Fixed: WPML config xml

= 1.0.2 = 13-08-2015 =

* Added: Compatibility with WooCommerce 2.4
* Updated: Plugin Core
* Updated: Language file

= 1.0.1 = 21-04-2015 =

* Initial release