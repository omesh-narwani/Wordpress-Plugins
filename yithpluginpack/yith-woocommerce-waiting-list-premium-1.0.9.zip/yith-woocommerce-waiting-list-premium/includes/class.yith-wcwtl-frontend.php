<?php
/**
 * Frontend class
 *
 * @author Yithemes
 * @package YITH WooCommerce Waiting List
 * @version 1.1.1
 */

if ( ! defined( 'YITH_WCWTL' ) ) {
	exit;
} // Exit if accessed directly

if( ! class_exists( 'YITH_WCWTL_Frontend' ) ) {
	/**
	 * Frontend class.
	 * The class manage all the Frontend behaviors.
	 *
	 * @since 1.0.0
	 */
	class YITH_WCWTL_Frontend {

		/**
		 * Single instance of the class
		 *
		 * @var \YITH_WCWTL_Frontend
		 * @since 1.0.0
		 */
		protected static $instance;

		/**
		 * Plugin version
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public $version = YITH_WCWTL_VERSION;

		/**
		 * Current object product
		 *
		 * @var object
		 * @since 1.0.0
		 */
		protected $current_product = false;

		/**
		 * Returns single instance of the class
		 *
		 * @return \YITH_WCWTL_Frontend
		 * @since 1.0.0
		 */
		public static function get_instance(){
			if( is_null( self::$instance ) ){
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Constructor
		 *
		 * @access public
		 * @since 1.0.0
		 */
		public function __construct() {

			// add form
			add_action( 'woocommerce_before_main_content', array( $this, 'add_form' ) );

			add_action( 'wp', array( $this, 'yith_waiting_submit' ), 100 );

			// my waitlist section on my account
			add_action( 'woocommerce_before_my_account', array( $this, 'add_waitlist_my_account' ) );

			// enqueue frontend js
			add_action( 'wp_enqueue_scripts', array( $this, 'register_scripts' ) );

			// update user meta
			add_action( 'woocommerce_created_customer', array( $this, 'add_meta_to_new_user' ), 10, 3 );
		}

		/**
		 * Register scripts frontend
		 *
		 * @access public
		 * @since 1.0.0
		 * @author Francesco Licandro <francesco.licandro@yithemes.com>
		 */
		public function register_scripts(){

			wp_register_script( 'yith-wcwtl-frontend', YITH_WCWTL_ASSETS_URL . '/js/frontend.js', array( 'jquery'), YITH_WCWTL_VERSION, true );
		}

		/**
		 * Enqueue scripts and style
		 *
		 * @since 1.0.8
		 * @access public
		 * @author Francesco Licandro
		 */
		public function enqueue_scripts(){

			wp_enqueue_script( 'yith-wcwtl-frontend' );

			$size = get_option( 'yith-wcwtl-general-font-size' );

			if( $size < 1 ) {
				$size = 1;
			}
			elseif( $size > 99 ) {
				$size = 99;
			}

			?>
			<style>
				#yith-wcwtl-output {
					margin-bottom: 20px;
				}
				#yith-wcwtl-output:after,
				#yith-wcwtl-output:before {
					content: '';
					clear: both;
					display: table;
				}
				#yith-wcwtl-output .button.alt {
					background: <?php echo get_option( 'yith-wcwtl-button-add-background' ) ?>;
					color: <?php echo get_option( 'yith-wcwtl-button-add-text-color' ) ?>;
				}
				#yith-wcwtl-output .button.alt:hover {
					background: <?php echo get_option( 'yith-wcwtl-button-add-background-hover' ) ?>;
					color: <?php echo get_option( 'yith-wcwtl-button-add-text-color-hover' ) ?>;
				}
				#yith-wcwtl-output .button.button-leave.alt {
					background: <?php echo get_option( 'yith-wcwtl-button-leave-background' ) ?>;
					color: <?php echo get_option( 'yith-wcwtl-button-leave-text-color' ) ?>;
				}
				#yith-wcwtl-output .button.button-leave.alt:hover {
					background: <?php echo get_option( 'yith-wcwtl-button-leave-background-hover' ) ?>;
					color: <?php echo get_option( 'yith-wcwtl-button-leave-text-color-hover' ) ?>;
				}
				#yith-wcwtl-output p, #yith-wcwtl-output label {
					font-size: <?php echo $size ?>px;
					color: <?php echo get_option( 'yith-wcwtl-general-font-color' ) ?>;
					margin-bottom: 10px;
				}
				#yith-wcwtl-output input {
					margin-bottom: 10px;
				}
			</style>

			<?php
		}

		/**
		 * Add form to stock html
		 *
		 * @access public
		 * @since 1.0.0
		 * @return string
		 * @author Francesco Licandro <francesco.licandro@yithemes.com>
		 */
		public function add_form() {
			global $post;

			if( get_post_type( $post->ID ) == 'product' && is_product() ) {

				$this->current_product = wc_get_product( $post->ID );

				if ( $this->current_product->product_type == 'grouped' || yith_waitlist_is_excluded( $this->current_product->id ) ) {
					return;
				}

				// first enqueue scripts
				$this->enqueue_scripts();

				if( $this->current_product->product_type == 'variable' ){
					add_action( 'woocommerce_stock_html', array( $this, 'output_form' ), 20, 3 );
				}
				else {
					add_action( 'woocommerce_stock_html', array( $this, 'output_form' ), 20, 2 );
				}
			}
		}

		/**
		 * Add form to stock html
		 *
		 * @access public
		 * @since 1.0.0
		 * @param string $html
		 * @param int $availability
		 * @param object | boolean $product
		 * @return string
		 * @author Francesco Licandro <francesco.licandro@yithemes.com>
		 */
		public function output_form( $html, $availability, $product = false ) {

			if( ! $product ) {
				$product = $this->current_product;
			}

			return $html . $this->the_form( $product );
		}

		/**
		 * Output the form according to product type and user
		 *
		 * @access public
		 * @since 1.0.0
		 * @param $product
		 * @return string
		 * @author Francesco Licandro <francesco.licandro@yithemes.com>
		 */
		public function the_form( $product ) {

			$html = '';

			// control if variation is in excluded list
			if( $product->is_in_stock() || ( isset( $product->variation_id ) && yith_waitlist_is_excluded( $product->variation_id ) ) ) {
				return $html;
			}

			$user           = wp_get_current_user();
			$product_type   = $product->product_type;
			$product_id     = ( $product_type == 'simple' ) ? $product->id : $product->variation_id;
			$waitlist       = yith_waitlist_get( $product_id );
			$url            = ( $product_type == 'simple' ) ? get_permalink( $product->id ) : get_permalink( $product->parent->id );

			// set query
			$url = add_query_arg( YITH_WCWTL_META , $product_id, $url );
			$url = wp_nonce_url( $url, 'action_waitlist' );
			$url = add_query_arg( YITH_WCWTL_META . '-action' , 'register', $url );

			//add message
			$html .= '<div id="yith-wcwtl-output"><p class="yith-wcwtl-msg">' . get_option( 'yith-wcwtl-form-message' ) . '</p>';

			// get buttons label from options
			$label_button_add   = get_option( 'yith-wcwtl-button-add-label' );
			$label_button_leave = get_option( 'yith-wcwtl-button-leave-label' );

			if( $product_type == 'simple' && ! $user->exists() ) {

				$html .= '<form method="post" action="' . esc_url( $url ) . '">';
				$html .= '<label for="yith-wcwtl-email">' . __( 'Email Address', 'yith-woocommerce-waiting-list' ) . '<input type="email" name="yith-wcwtl-email" id="yith-wcwtl-email" /></label>';
				$html .= '<input type="submit" value="' . $label_button_add . '" class="button alt" />';
				$html .= '</form>';

			}
			elseif( $product_type == 'variation' && ! $user->exists() ) {

				$html .= '<input type="email" name="yith-wcwtl-email" id="yith-wcwtl-email" class="wcwtl-variation" />';
				$html .= '<a href="' . esc_url( $url ) . '" class="button alt">' . $label_button_add . '</a>';
			}
			elseif( is_array( $waitlist ) && yith_waitlist_user_is_register( $user->user_email, $waitlist ) ) {
				$url   = add_query_arg( YITH_WCWTL_META . '-action' , 'leave', $url );
				$html .= '<a href="' . esc_url( $url ) . '" class="button button-leave alt">' . $label_button_leave . '</a>';
			}
			else {
				$html .= '<a href="' . esc_url( $url ) . '" class="button alt">' . $label_button_add . '</a>';
			}

			$html .= '</div>';

			return $html;
		}

		/**
		 * Add user to waitlist
		 *
		 * @access public
		 * @since 1.0.0
		 * @author Francesco Licandro <francesco.licandro@yithemes.com>
		 */
		public function yith_waiting_submit() {

			$user = wp_get_current_user();

			if( ! ( isset( $_REQUEST[ YITH_WCWTL_META ] ) && is_numeric( $_REQUEST[ YITH_WCWTL_META ] ) && isset( $_REQUEST[ YITH_WCWTL_META . '-action' ] ) ) ) {
				return;
			}

			if( ! $user->exists() && empty( $_REQUEST[ 'yith-wcwtl-email' ] ) ) {
				wc_add_notice( __( 'You must provide a valid email address to join the waiting list of this product', 'yith-woocommerce-waiting-list' ), 'error' );
				return;
			}

			$action = $_REQUEST[ YITH_WCWTL_META . '-action' ];

			$user_email = ( isset( $_REQUEST[ 'yith-wcwtl-email' ] ) ) ? $_REQUEST[ 'yith-wcwtl-email' ] : $user->user_email;
			$product_id = $_REQUEST[ YITH_WCWTL_META ];

			// set standard msg and type
			$msg        = get_option( 'yith-wcwtl-button-success-msg' );
			$msg_type   = 'success';

			// start user session and set cookies
			if( ! isset( $_COOKIE['woocommerce_items_in_cart'] ) ) {
				do_action( 'woocommerce_set_cart_cookies', true );
			}

			if( $action == 'register' ) {
				// register user;
				$res = yith_waitlist_register_user( $user_email, $product_id );

				if( ! $res ) {
					$msg = get_option( 'yith-wcwtl-button-error-msg' );
					$msg_type = 'error';
				}
				else {
					// send email
					do_action( 'send_yith_waitlist_mail_subscribe', $user_email, $product_id );
				}
			}
			elseif( $action == 'leave' ) {
				// unregister user
				yith_waitlist_unregister_user( $user_email, $product_id );
				$msg = get_option( 'yith-wcwtl-button-leave-msg' );
			}
			else {
				$msg = get_option( 'yith-wcwtl-button-error-msg' );
				$msg_type = 'error';
			}

			wc_add_notice( $msg, $msg_type );

			//redirect to product page
			$dest = remove_query_arg( array( YITH_WCWTL_META, YITH_WCWTL_META . '-action', '_wpnonce', 'yith-wcwtl-email' ) );
			wp_redirect( esc_url( $dest ) );
			exit;
		}

		/**
		 * Add waitlist section to my-account page
		 *
		 * @access public
		 * @since 1.0.0
		 * @author Francesco Licandro <francesco.licandro@yithemes.com>
		 */
		public function add_waitlist_my_account() {
			wc_get_template( 'yith-wcwtl-my-waitlist.php', array(), '', YITH_WCWTL_DIR . 'templates/' );
		}

		/**
		 * Update user meta after registration
		 *
		 * @access public
		 * @since 1.0.0
		 * @param int $customer_id
		 * @param mixed $new_customer_data
		 * @param string $password_generated
		 * @author Francesco Licandro <francesco.licandro@yithemes.com>
		 */
		public function add_meta_to_new_user( $customer_id, $new_customer_data, $password_generated ){

			global $wpdb;
			// get ids
			$query = "SELECT post_id FROM " . $wpdb->prefix . "postmeta WHERE meta_value LIKE '%" . $new_customer_data['user_email'] . "%'";
			$ids = $wpdb->get_col( $query );

			// update post meta for new user
			update_user_meta( $customer_id, YITH_WCWTL_META_USER, $ids );
		}

	}
}
/**
 * Unique access to instance of YITH_WCWT_Frontend class
 *
 * @return \YITH_WCWTL_Frontend
 * @since 1.0.0
 */
function YITH_WCWTL_Frontend(){
	return YITH_WCWTL_Frontend::get_instance();
}
