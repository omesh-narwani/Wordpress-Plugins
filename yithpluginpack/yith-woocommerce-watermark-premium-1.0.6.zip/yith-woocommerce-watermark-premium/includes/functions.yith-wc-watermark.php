<?php
if( !defined('ABSPATH'))
    exit;

if( !function_exists( 'ywcwat_backup_file_name')){

    function ywcwat_backup_file_name( $original_file_name ){

        $backup_file_name = dirname( $original_file_name ) . DIRECTORY_SEPARATOR . YWCWAT_BACKUP_FILE . basename( $original_file_name );

        return $backup_file_name;
    }
}


if( !function_exists( 'ywcwat_backup_file' ) ){

    function ywcwat_backup_file( $original_file ){

        $original_file = str_replace( 'jpeg', 'jpg', $original_file );
        $original_file = strtolower( $original_file );
        $backup_file = ywcwat_backup_file_name( $original_file );

        if( is_file( $original_file ) && !is_file( $backup_file ) ){
         return copy( $original_file, $backup_file );
        }

        return false;
    }
}


if( !function_exists( 'ywcwat_get_all_product_attach')){

    function ywcwat_get_all_product_attach(){

        global $wpdb;

        $result = $wpdb->get_results(

            "SELECT {$wpdb->posts}.ID FROM {$wpdb->posts}
             WHERE {$wpdb->posts}.post_type='attachment' AND post_mime_type LIKE 'image/%'
            AND {$wpdb->posts}.ID IN (
                                  SELECT DISTINCT {$wpdb->postmeta}.meta_value FROM {$wpdb->postmeta} INNER JOIN {$wpdb->posts} ON {$wpdb->postmeta}.post_id= {$wpdb->posts}.ID
                                  WHERE {$wpdb->postmeta}.meta_key= '_thumbnail_id' AND {$wpdb->posts}.post_type IN ('product', 'product_variation')  )
                ORDER BY {$wpdb->posts}.ID ASC" );


        return $result;
    }
}

if( !function_exists( 'ywcwat_generate_backup' ) ){

    function ywcwat_generate_backup(){

        $attach_ids = ywcwat_get_all_product_attach();

        foreach( $attach_ids as $attach_id ){


            $file_path = get_attached_file( $attach_id->ID );

             ywcwat_backup_file( $file_path );
        }

        do_action('ywcwat_backup_image_gallery' );
    }
}