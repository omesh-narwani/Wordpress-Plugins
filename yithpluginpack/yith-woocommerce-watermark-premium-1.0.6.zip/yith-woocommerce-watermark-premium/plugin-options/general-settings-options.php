<?php
if( !defined( 'ABSPATH' ) )
    exit;


$settings = array(

    'general-settings'  =>  array(

        'general_section_start'   =>  array(
            'name'  => __('General Settings', 'yith-woocommerce-watermark'),
            'type' =>   'title',
            'id' => 'ywcwat_generalsectionstart'
        ),


        'watermark_button_apply'    => array(
            'name' => '',
            'type'  =>'watermark-apply',
            'id'    =>  'ywcwat_watermark_apply'
        ),

        'general_section_end' =>  array(
            'type'  =>  'sectionend',
            'id'    =>  'ywcwat_generalsectionend'
        ),

    )
);

return apply_filters( 'ywcwat_free_options', $settings );