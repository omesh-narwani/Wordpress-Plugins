<?php
if( !defined('ABSPATH'))
    exit;

global $post;

$product_watermark = get_post_meta( $post->ID, '_ywcwat_product_watermark', true );
$is_enabled = get_post_meta( $post->ID, 'ywcwat_product_enabled_watermark', true );

?>
<div id="ywcwat_watermark_data" class="panel woocommerce_options_panel" xmlns="http://www.w3.org/1999/html">
        <div class="options_group ywcwat_enabled_custom_watermark">
            <p class="form-field">
                <label for="ywcwat_custom_watermark"><?php _e('Add Watermark','yith-woocommerce-watermark');?></label>
               <button type="button" class="button add_product_watermark"><?php _e('Add','yith-woocommerce-watermark');?></button>
            </p>
        </div>
        <div id="ywcwat_product_watermark_list">
            <?php
                if( !empty( $product_watermark )){

                    foreach( $product_watermark as $i=>$single_watermark ){

                        $watermark_type = isset( $single_watermark['ywcwat_watermark_type'] ) ? $single_watermark['ywcwat_watermark_type'] : 'type_img';
                        $watermark_position = isset( $single_watermark['ywcwat_watermark_position'] ) ? $single_watermark['ywcwat_watermark_position'] : 'bottom_right';
                        $watermark_margin_x = isset( $single_watermark['ywcwat_watermark_margin_x'] ) ? $single_watermark['ywcwat_watermark_margin_x'] : 0;
                        $watermark_margin_y = isset( $single_watermark['ywcwat_watermark_margin_y'] ) ? $single_watermark['ywcwat_watermark_margin_y'] : 0;
                        $watermark_sizes = isset( $single_watermark['ywcwat_watermark_sizes'] ) ? $single_watermark['ywcwat_watermark_sizes'] : 'shop_single';


                        $global_params = array(
                            'option_id'    => 'ywcwat_custom_watermark',
                            'current_row' => $i,
                            'watermark_position' => $watermark_position,
                            'watermark_margin_x'    => $watermark_margin_x,
                            'watermark_margin_y'    => $watermark_margin_y,
                            'watermark_sizes'   => $watermark_sizes,
                            'watermark_type' => $watermark_type
                        );

                        if( $watermark_type == 'type_text' ){

                            $watermark_text =  isset( $single_watermark['ywcwat_watermark_text'] ) ? $single_watermark['ywcwat_watermark_text'] : '';
                            $watermark_font =  isset( $single_watermark['ywcwat_watermark_font'] ) ? $single_watermark['ywcwat_watermark_font'] : '';
                            $watermark_font_size = isset( $single_watermark['ywcwat_watermark_font_size'] ) ? $single_watermark['ywcwat_watermark_font_size'] : 11;
                            $watermark_font_color = isset( $single_watermark['ywcwat_watermark_font_color'] ) ? $single_watermark['ywcwat_watermark_font_color'] : '#000000';
                            $watermark_box_width  = isset( $single_watermark['ywcwat_watermark_width'] ) ? $single_watermark['ywcwat_watermark_width'] : 100;
                            $watermark_box_height  = isset( $single_watermark['ywcwat_watermark_height'] ) ? $single_watermark['ywcwat_watermark_height'] : 50;
                            $watermark_bg_color = isset( $single_watermark['ywcwat_watermark_bg_color'] ) ? $single_watermark['ywcwat_watermark_bg_color'] : '#ffffff';
                            $watermark_opacity = isset( $single_watermark['ywcwat_watermark_opacity'] ) ? $single_watermark['ywcwat_watermark_opacity'] : 75;
                            $watermark_line_height = isset( $single_watermark['ywcwat_watermark_line_height'] ) ? $single_watermark['ywcwat_watermark_line_height'] : -1;

                            $type_params = array(
                                'watermark_text'    => $watermark_text,
                                'watermark_font'    =>$watermark_font,
                                'watermark_font_color'  => $watermark_font_color,
                                'watermark_font_size'   => $watermark_font_size,
                                'watermark_bg_color' =>$watermark_bg_color,
                                'watermark_opacity' => $watermark_opacity,
                                'watermark_box_width'   => $watermark_box_width,
                                'watermark_box_height'  => $watermark_box_height,
                                'watermark_line_height' => $watermark_line_height

                            );

                        }else{

                            $watermark_id =  isset( $single_watermark['ywcwat_watermark_id'] ) ? $single_watermark['ywcwat_watermark_id'] : '';
                            $watermark_url = '';

                            if (!empty($watermark_id)) {
                                $watermark_url = wp_get_attachment_image_src($watermark_id, 'full');
                                $watermark_url = $watermark_url[0];
                            }
                            $type_params = array(
                                'watermark_url' => $watermark_url,
                                'watermark_id'  => $watermark_id,
                            );

                        }

                        $params = array_merge( $global_params, $type_params );

                        $params['params'] = $params;

                        echo yith_wcwat_get_template( 'single-product-watermark-template.php', $params, true );


                    }
                }
            ?>
        </div>
</div>
<script type="text/javascript">
jQuery(document).ready(function($){

    $('.add_product_watermark').on('click', function(){

        var product_wat_list_size = $('.ywcwat_product_watermark_row').size(),
            container_list = $('#ywcwat_product_watermark_list');

        var data = {
            ywcwat_product_addnewwat: product_wat_list_size,
            ywcwat_product_option_id : 'ywcwat_custom_watermark',
            action: 'add_new_product_watermark_admin'
        };

        $.ajax({

            type: 'POST',
            url: ywcwat_params.ajax_url,
            data: data,
            dataType: 'json',
            success: function (response) {

                container_list.append( response.result );
               $('body').trigger('init_product_color_picker').trigger('initial_product_position_watermark');
            }

        });

    });
});
</script>