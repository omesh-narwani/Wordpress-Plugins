=== YITH WooCommerce Zoom Magnifier Premium ===

Contributors: yithemes
Tags: zoom, magnifier, woocommerce, product image, themes, yit, e-commerce, shop, thumbnail, thumbnail slider, zoom image, carousel, image carousel
Requires at least: 3.5.1
Tested up to: 4.4.1
Stable tag: 1.2.13
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= Version 1.2.13 - RELEASED: JAN 18, 2016 =

* Updated: plugin ready for WooCommerce 2.5
* Added: filter yith_ywzm_zoom_wrap_additional_css for customizing CSS class for the wrapping div

= Version 1.2.12 - RELEASED: DEC 29, 2015 =

* Added: Compatibility with YIT WooCommerce Featured Audio & Video Content
* Updated: text domain changed to yith-woocommerce-zoom-magnifier

= Version 1.2.11 - RELEASED: DEC 15, 2015 =

* Fixed: YITH Plugin Framework issue with WordPress 4.4, YIT menu is shown twice

= Version 1.2.10 - RELEASED: OCT 23, 2015 =

* Updated: compatibility with YITH WooCommerce Quick View.

= Version 1.2.9 - RELEASED: OCT 07, 2015 =

* Updated: text-domain changed to yith-woocommerce-zoom-magnifier.

= Version 1.2.8 - RELEASED: SEP 04, 2015 =

* Updated: Languages file
* Fixed: Changed plugin text domain from yit to ywmz 
* Fix: featured image shown one time on slider.
* Fix: div not shown if loading text is empty.

= Version 1.2.7 - RELEASED: SEP 01, 2015 =

* Fix: removed deprecated woocommerce_update_option_X hook.

= Version 1.2.6 - RELEASED: AUG 28, 2015 =

* Fix: resolved XSS vulnerability.
* Fix: Single Product Exclusion List bug.

= Version 1.2.5 - RELEASED: JUL 23, 2015 =

* Added: italian language.

= Version 1.2.4 - RELEASED: JUN 26, 2015 =

* Added: support to srcset and src-orig attributes.

= Version 1.2.3 - RELEASED: MAY 29, 2015 =

* Added: included jquery-migrate as prerequisite.

= Version 1.2.2 - RELEASED: MAY 22, 2015 =

* Fixed: CSS fix for EssentialGrid conflicts.

= Version 1.2.1 - RELEASED: MAY 04, 2015 =

* Fixed: removed z-index that made the zoom area hiding other elements in certain themes.

= Version 1.2.0 - RELEASED: APR 22, 2015 ==

* Fix : security issue (https://make.wordpress.org/plugins/2015/04/20/fixing-add_query_arg-and-remove_query_arg-usage/)
* Tweak : support up to Wordpress 4.2

= 1.1.7 =

* Fixed: compatibility with some YITHEMES themes.

= 1.1.6 =

Initial release